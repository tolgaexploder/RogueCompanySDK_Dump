// WidgetBlueprintGeneratedClass TeamHealthContainer.TeamHealthContainer_C
// Size: 0x248 (Inherited: 0x238)
struct UTeamHealthContainer_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UVerticalBox* TeammateHealths; // 0x240(0x08)

	void Construct(); // Function TeamHealthContainer.TeamHealthContainer_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void UpdateTeammateHealthBars(); // Function TeamHealthContainer.TeamHealthContainer_C.UpdateTeammateHealthBars // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandlePlayerSpawn(struct AKSCharacterBase* NewCharacter); // Function TeamHealthContainer.TeamHealthContainer_C.HandlePlayerSpawn // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandlePhaseChnage(struct FName NewPhaseName, struct FName PreviousPhaseName); // Function TeamHealthContainer.TeamHealthContainer_C.HandlePhaseChnage // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleSetupStart(); // Function TeamHealthContainer.TeamHealthContainer_C.HandleSetupStart // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_TeamHealthContainer(int32_t EntryPoint); // Function TeamHealthContainer.TeamHealthContainer_C.ExecuteUbergraph_TeamHealthContainer // (Final|UbergraphFunction) // @ game+0x2587100
};

