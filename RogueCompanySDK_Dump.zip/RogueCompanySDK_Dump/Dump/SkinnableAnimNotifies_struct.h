// ScriptStruct SkinnableAnimNotifies.PropIdentifier
// Size: 0x10 (Inherited: 0x00)
struct FPropIdentifier {
	struct FName PropIdentifierName; // 0x00(0x08)
	struct FWeakObjectPtr<struct USkeletalMeshComponent> SkelMeshComp; // 0x08(0x08)
};

// ScriptStruct SkinnableAnimNotifies.ActiveSkelProp
// Size: 0x88 (Inherited: 0x00)
struct FActiveSkelProp {
	char UnknownData_0[0x80]; // 0x00(0x80)
	struct USkinnableSkeletalMeshComponent* MeshComp; // 0x80(0x08)
};

// ScriptStruct SkinnableAnimNotifies.ActiveStaticProp
// Size: 0x88 (Inherited: 0x00)
struct FActiveStaticProp {
	char UnknownData_0[0x80]; // 0x00(0x80)
	struct USkinnableStaticMeshComponent* MeshComp; // 0x80(0x08)
};

