// WidgetBlueprintGeneratedClass VehicleSpeedometer.VehicleSpeedometer_C
// Size: 0x518 (Inherited: 0x4e0)
struct UVehicleSpeedometer_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UImage* Needle; // 0x4e8(0x08)
	struct UTextBlock* Reading; // 0x4f0(0x08)
	struct UImage* WheelBack; // 0x4f8(0x08)
	struct UImage* WheelFill; // 0x500(0x08)
	float MaxSpeed; // 0x508(0x04)
	float TargetValue; // 0x50c(0x04)
	float CurrentValue; // 0x510(0x04)
	float LerpPerSecond; // 0x514(0x04)

	void SetTargetValue(float TargetValue); // Function VehicleSpeedometer.VehicleSpeedometer_C.SetTargetValue // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetValue(float Speedo); // Function VehicleSpeedometer.VehicleSpeedometer_C.SetValue // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function VehicleSpeedometer.VehicleSpeedometer_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_VehicleSpeedometer(int32_t EntryPoint); // Function VehicleSpeedometer.VehicleSpeedometer_C.ExecuteUbergraph_VehicleSpeedometer // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

