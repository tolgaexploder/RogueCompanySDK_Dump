// BlueprintGeneratedClass TextTypeEffect.TextTypeEffect_C
// Size: 0x6c (Inherited: 0x28)
struct UTextTypeEffect_C : UObject {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x28(0x08)
	struct UTextBlock* TextComponent; // 0x30(0x08)
	struct FText Text; // 0x38(0x18)
	struct FString CursorToken; // 0x50(0x10)
	float ElapsedTime; // 0x60(0x04)
	float TypeSpeed; // 0x64(0x04)
	float CursorSpeed; // 0x68(0x04)

	void SetText(struct FText Text); // Function TextTypeEffect.TextTypeEffect_C.SetText // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Tick(float dt); // Function TextTypeEffect.TextTypeEffect_C.Tick // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void StartType(); // Function TextTypeEffect.TextTypeEffect_C.StartType // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_TextTypeEffect(int32_t EntryPoint); // Function TextTypeEffect.TextTypeEffect_C.ExecuteUbergraph_TextTypeEffect // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

