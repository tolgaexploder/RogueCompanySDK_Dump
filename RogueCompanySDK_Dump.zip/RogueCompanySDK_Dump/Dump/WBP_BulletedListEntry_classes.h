// WidgetBlueprintGeneratedClass WBP_BulletedListEntry.WBP_BulletedListEntry_C
// Size: 0x260 (Inherited: 0x238)
struct UWBP_BulletedListEntry_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct URichTextBlock* TextBlock; // 0x240(0x08)
	struct FText Text; // 0x248(0x18)

	void SetText(struct FText Text); // Function WBP_BulletedListEntry.WBP_BulletedListEntry_C.SetText // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PreConstruct(bool IsDesignTime); // Function WBP_BulletedListEntry.WBP_BulletedListEntry_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function WBP_BulletedListEntry.WBP_BulletedListEntry_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_BulletedListEntry(int32_t EntryPoint); // Function WBP_BulletedListEntry.WBP_BulletedListEntry_C.ExecuteUbergraph_WBP_BulletedListEntry // (Final|UbergraphFunction) // @ game+0x2587100
};

