// WidgetBlueprintGeneratedClass WBP_BattlePassOffersScreen.WBP_BattlePassOffersScreen_C
// Size: 0x518 (Inherited: 0x4e0)
struct UWBP_BattlePassOffersScreen_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UWBP_BattlePassOfferPanel_C* BattlePassOffer; // 0x4e8(0x08)
	struct UHorizontalBox* BattlePassOffers; // 0x4f0(0x08)
	struct UTextBlock* CountdownTimeRemaining; // 0x4f8(0x08)
	struct UImage* Image_172; // 0x500(0x08)
	struct UWBP_BattlePassOfferPanel_C* PremiumPassOffer; // 0x508(0x08)
	struct UWBP_Header1_C* WBP_Header1; // 0x510(0x08)

	void Handle on Offer Panel Clicked(struct UPUMG_StoreItem* BattlePassOffer); // Function WBP_BattlePassOffersScreen.WBP_BattlePassOffersScreen_C.Handle on Offer Panel Clicked // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GetNavigationWidgets(struct TArray<struct UWBP_BattlePassOfferPanel_C*> Widgets); // Function WBP_BattlePassOffersScreen.WBP_BattlePassOffersScreen_C.GetNavigationWidgets // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	bool NavigateBack(); // Function WBP_BattlePassOffersScreen.WBP_BattlePassOffersScreen_C.NavigateBack // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnShown(); // Function WBP_BattlePassOffersScreen.WBP_BattlePassOffersScreen_C.OnShown // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function WBP_BattlePassOffersScreen.WBP_BattlePassOffersScreen_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnBackPrompt(); // Function WBP_BattlePassOffersScreen.WBP_BattlePassOffersScreen_C.OnBackPrompt // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidgetNavigation(); // Function WBP_BattlePassOffersScreen.WBP_BattlePassOffersScreen_C.InitializeWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_BattlePassOffersScreen(int32_t EntryPoint); // Function WBP_BattlePassOffersScreen.WBP_BattlePassOffersScreen_C.ExecuteUbergraph_WBP_BattlePassOffersScreen // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

