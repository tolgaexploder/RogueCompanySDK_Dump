// Enum MoviePlayer.EMoviePlaybackType
enum class EMoviePlaybackType : uint8 {
	MT_Normal,
	MT_Looped,
	MT_LoadingLoop,
	MT_MAX,
};

