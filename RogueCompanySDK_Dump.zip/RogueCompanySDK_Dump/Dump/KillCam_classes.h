// WidgetBlueprintGeneratedClass KillCam.KillCam_C
// Size: 0x538 (Inherited: 0x510)
struct UKillCam_C : UKSViewedPawnWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x510(0x08)
	struct UTextBlock* EliminatorTitle; // 0x518(0x08)
	struct UImage* Image_1; // 0x520(0x08)
	struct UTextBlock* SpectatedEliminatorText; // 0x528(0x08)
	struct AKSPlayerState* PreviousPlayerState; // 0x530(0x08)

	void PostSetPlayerState(); // Function KillCam.KillCam_C.PostSetPlayerState // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void SetPlayerStateUIRelevanceChanged(); // Function KillCam.KillCam_C.SetPlayerStateUIRelevanceChanged // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_KillCam(int32_t EntryPoint); // Function KillCam.KillCam_C.ExecuteUbergraph_KillCam // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

