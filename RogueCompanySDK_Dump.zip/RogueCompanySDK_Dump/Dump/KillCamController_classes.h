// BlueprintGeneratedClass KillCamController.KillCamController_C
// Size: 0xe08 (Inherited: 0xe00)
struct AKillCamController_C : AKSKillCamController {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xe00(0x08)

	void ReceiveBeginPlay(); // Function KillCamController.KillCamController_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_KillCamController(int32_t EntryPoint); // Function KillCamController.KillCamController_C.ExecuteUbergraph_KillCamController // (Final|UbergraphFunction) // @ game+0x2587100
};

