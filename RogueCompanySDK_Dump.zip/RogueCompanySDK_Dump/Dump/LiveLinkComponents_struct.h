// ScriptStruct LiveLinkComponents.LiveLinkTransformControllerData
// Size: 0x04 (Inherited: 0x00)
struct FLiveLinkTransformControllerData {
	bool bWorldTransform; // 0x00(0x01)
	bool bUseScale; // 0x01(0x01)
	bool bSweep; // 0x02(0x01)
	bool bTeleport; // 0x03(0x01)
};

