// WidgetBlueprintGeneratedClass EnemyPingMinimapIcon.EnemyPingMinimapIcon_C
// Size: 0x378 (Inherited: 0x318)
struct UEnemyPingMinimapIcon_C : UKSMapIconWidgetBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x318(0x08)
	struct UWidgetAnimation* Ping_noIntro; // 0x320(0x08)
	struct UWidgetAnimation* Ping; // 0x328(0x08)
	struct UImage* AboveIndicator; // 0x330(0x08)
	struct UImage* BelowIndicator; // 0x338(0x08)
	struct UImage* Image_1; // 0x340(0x08)
	struct UImage* ImageIcon; // 0x348(0x08)
	struct UImage* PingRing; // 0x350(0x08)
	struct FMulticastInlineDelegate PingExpired; // 0x358(0x10)
	enum class EKSPingType PingType; // 0x368(0x01)
	char UnknownData_369[0x3]; // 0x369(0x03)
	struct FVector ActivePingLoation; // 0x36c(0x0c)

	struct FVector GetWorldPosition(); // Function EnemyPingMinimapIcon.EnemyPingMinimapIcon_C.GetWorldPosition // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void Construct(); // Function EnemyPingMinimapIcon.EnemyPingMinimapIcon_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Re Ping(struct FKSClientShotInfo ShotInfo); // Function EnemyPingMinimapIcon.EnemyPingMinimapIcon_C.Re Ping // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateMeetsHeightThreshold(bool bHeight, bool bDepth); // Function EnemyPingMinimapIcon.EnemyPingMinimapIcon_C.UpdateMeetsHeightThreshold // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_EnemyPingMinimapIcon(int32_t EntryPoint); // Function EnemyPingMinimapIcon.EnemyPingMinimapIcon_C.ExecuteUbergraph_EnemyPingMinimapIcon // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void PingExpired__DelegateSignature(enum class None Icon Type, int32_t UniqueId); // Function EnemyPingMinimapIcon.EnemyPingMinimapIcon_C.PingExpired__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

