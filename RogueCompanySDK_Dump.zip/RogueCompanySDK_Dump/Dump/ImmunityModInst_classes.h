// BlueprintGeneratedClass ImmunityModInst.ImmunityModInst_C
// Size: 0x198 (Inherited: 0x190)
struct UImmunityModInst_C : UDamageResistModInst_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x190(0x08)

	void ReceiveBeginPlay(); // Function ImmunityModInst.ImmunityModInst_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ReceiveTick(float DeltaSeconds); // Function ImmunityModInst.ImmunityModInst_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function ImmunityModInst.ImmunityModInst_C.ReceiveEndPlay // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnNewCharacter(); // Function ImmunityModInst.ImmunityModInst_C.OnNewCharacter // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_ImmunityModInst(int32_t EntryPoint); // Function ImmunityModInst.ImmunityModInst_C.ExecuteUbergraph_ImmunityModInst // (Final|UbergraphFunction) // @ game+0x2587100
};

