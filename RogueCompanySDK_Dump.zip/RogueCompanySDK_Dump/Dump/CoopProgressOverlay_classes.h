// WidgetBlueprintGeneratedClass CoopProgressOverlay.CoopProgressOverlay_C
// Size: 0x52c (Inherited: 0x4e0)
struct UCoopProgressOverlay_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UEscapeTeammatesStatus_C* EscapeTeammatesStatus; // 0x4e8(0x08)
	struct UTextBlock* FilesRemainingText; // 0x4f0(0x08)
	struct UTextBlock* HackDefendProgressText; // 0x4f8(0x08)
	struct UImage* Image_1; // 0x500(0x08)
	struct UImage* Image_2; // 0x508(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_1; // 0x510(0x08)
	int32_t Remaining pickups; // 0x518(0x04)
	struct FName Current Phase; // 0x51c(0x08)
	int32_t Pickups Used; // 0x524(0x04)
	float Round Progress; // 0x528(0x04)

	void Refresh Appearance(); // Function CoopProgressOverlay.CoopProgressOverlay_C.Refresh Appearance // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function CoopProgressOverlay.CoopProgressOverlay_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Round Start(struct FRoundInitState RoundInitState); // Function CoopProgressOverlay.CoopProgressOverlay_C.Handle Round Start // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Coop Pickup(struct AKSObjectiveBase* Pickup, int32_t PickupsUsed, int32_t PickupsLeft); // Function CoopProgressOverlay.CoopProgressOverlay_C.Handle Coop Pickup // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Computers Unlocked(); // Function CoopProgressOverlay.CoopProgressOverlay_C.Handle Computers Unlocked // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Successful Hack(struct AKSExtractionComputer* Computer); // Function CoopProgressOverlay.CoopProgressOverlay_C.Handle Successful Hack // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Escape Point Changed(struct TArray<struct AKSPlayerState*> ContainedPlayers); // Function CoopProgressOverlay.CoopProgressOverlay_C.Handle Escape Point Changed // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Phase Change(struct FName CurrentPhaseName, struct FName PreviousPhaseName); // Function CoopProgressOverlay.CoopProgressOverlay_C.Handle Phase Change // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Timer Second Tick(float NewTruncatedSeconds); // Function CoopProgressOverlay.CoopProgressOverlay_C.Handle Timer Second Tick // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Player Downed Changed(struct AKSPlayerState* PlayerState); // Function CoopProgressOverlay.CoopProgressOverlay_C.Handle Player Downed Changed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Player Death(struct FCombatEventInfo EventInfo); // Function CoopProgressOverlay.CoopProgressOverlay_C.Handle Player Death // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_CoopProgressOverlay(int32_t EntryPoint); // Function CoopProgressOverlay.CoopProgressOverlay_C.ExecuteUbergraph_CoopProgressOverlay // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

