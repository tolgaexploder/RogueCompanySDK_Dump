// WidgetBlueprintGeneratedClass StandardContainer.StandardContainer_C
// Size: 0x290 (Inherited: 0x238)
struct UStandardContainer_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UButton* CloseButton; // 0x240(0x08)
	struct UNamedSlot* Content; // 0x248(0x08)
	struct UTextBlock* Header; // 0x250(0x08)
	struct UOverlay* HeaderContainer; // 0x258(0x08)
	struct FText HeaderText; // 0x260(0x18)
	bool ShowCloseButton; // 0x278(0x01)
	char UnknownData_279[0x7]; // 0x279(0x07)
	struct FMulticastInlineDelegate OnContainerClose; // 0x280(0x10)

	enum class ESlateVisibility EvaluateHeaderVisibility(); // Function StandardContainer.StandardContainer_C.EvaluateHeaderVisibility // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	enum class ESlateVisibility EvaluateCloseButtonVisibility(); // Function StandardContainer.StandardContainer_C.EvaluateCloseButtonVisibility // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void PreConstruct(bool IsDesignTime); // Function StandardContainer.StandardContainer_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void BndEvt__CloseButton_K2Node_ComponentBoundEvent_7_OnButtonClickedEvent__DelegateSignature(); // Function StandardContainer.StandardContainer_C.BndEvt__CloseButton_K2Node_ComponentBoundEvent_7_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_StandardContainer(int32_t EntryPoint); // Function StandardContainer.StandardContainer_C.ExecuteUbergraph_StandardContainer // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void OnContainerClose__DelegateSignature(); // Function StandardContainer.StandardContainer_C.OnContainerClose__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

