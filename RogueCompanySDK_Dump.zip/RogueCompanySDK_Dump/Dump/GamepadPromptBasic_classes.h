// WidgetBlueprintGeneratedClass GamepadPromptBasic.GamepadPromptBasic_C
// Size: 0x281 (Inherited: 0x238)
struct UGamepadPromptBasic_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UTextBlock* ActionText; // 0x240(0x08)
	struct UImage* ButtonIcon; // 0x248(0x08)
	struct FButtonPromptData Data; // 0x250(0x30)
	bool IsSet; // 0x280(0x01)

	void SetPrompt(struct FButtonPromptData Data); // Function GamepadPromptBasic.GamepadPromptBasic_C.SetPrompt // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Populate(); // Function GamepadPromptBasic.GamepadPromptBasic_C.Populate // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function GamepadPromptBasic.GamepadPromptBasic_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_GamepadPromptBasic(int32_t EntryPoint); // Function GamepadPromptBasic.GamepadPromptBasic_C.ExecuteUbergraph_GamepadPromptBasic // (Final|UbergraphFunction) // @ game+0x2587100
};

