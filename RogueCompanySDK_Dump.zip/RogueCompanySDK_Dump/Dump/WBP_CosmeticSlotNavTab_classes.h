// WidgetBlueprintGeneratedClass WBP_CosmeticSlotNavTab.WBP_CosmeticSlotNavTab_C
// Size: 0x5d9 (Inherited: 0x5d0)
struct UWBP_CosmeticSlotNavTab_C : UWBP_subscreen_nav_tab_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5d0(0x08)
	enum class EMercCosmeticSlot CosmeticSlot; // 0x5d8(0x01)

	void Construct(); // Function WBP_CosmeticSlotNavTab.WBP_CosmeticSlotNavTab_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_CosmeticSlotNavTab(int32_t EntryPoint); // Function WBP_CosmeticSlotNavTab.WBP_CosmeticSlotNavTab_C.ExecuteUbergraph_WBP_CosmeticSlotNavTab // (Final|UbergraphFunction) // @ game+0x2587100
};

