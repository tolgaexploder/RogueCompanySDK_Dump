// WidgetBlueprintGeneratedClass WBP_CustomizeAvatar.WBP_CustomizeAvatar_C
// Size: 0x580 (Inherited: 0x4e0)
struct UWBP_CustomizeAvatar_C : UKSPlayerCosmeticWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UWidgetAnimation* ShowAnim; // 0x4e8(0x08)
	struct UKSSortableGridPanel* ItemContainer; // 0x4f0(0x08)
	struct UScrollBox* ScrollBox_1; // 0x4f8(0x08)
	struct UWBP_CosmeticItem_Avatar_C* WBP_CosmeticItem_Avatar; // 0x500(0x08)
	struct UWBP_CosmeticItem_Avatar_C* WBP_CosmeticItem_Avatar_2; // 0x508(0x08)
	struct UWBP_CosmeticItem_Avatar_C* WBP_CosmeticItem_Avatar_3; // 0x510(0x08)
	struct UWBP_CosmeticItem_Avatar_C* WBP_CosmeticItem_Avatar_4; // 0x518(0x08)
	struct UWBP_CosmeticItem_Avatar_C* WBP_CosmeticItem_Avatar_5; // 0x520(0x08)
	struct UWBP_CosmeticItem_Avatar_C* WBP_CosmeticItem_Avatar_6; // 0x528(0x08)
	struct UWBP_CosmeticItem_Avatar_C* WBP_CosmeticItem_Avatar_7; // 0x530(0x08)
	struct UWBP_CosmeticItem_Avatar_C* WBP_CosmeticItem_Avatar_8; // 0x538(0x08)
	struct UWBP_CosmeticItem_Avatar_C* WBP_CosmeticItem_Avatar_9; // 0x540(0x08)
	struct UWBP_PlayerIDCustomize_C* WBP_PlayerIDCustomize; // 0x548(0x08)
	struct TArray<struct UWBP_CosmeticItem_Avatar_C*> AvatarItems; // 0x550(0x10)
	struct UWBP_CosmeticItem_Avatar_C* EquippedAvatar; // 0x560(0x08)
	struct UKSLoadoutDataFactory* LoadoutDataFactory; // 0x568(0x08)
	struct UKSItem* HoveredItem; // 0x570(0x08)
	int32_t VisibleGridRows; // 0x578(0x04)
	int32_t VisibleGridColumns; // 0x57c(0x04)

	bool OnSortRarityDescNameAsc(struct UWidget* LHS, struct UWidget* RHS); // Function WBP_CustomizeAvatar.WBP_CustomizeAvatar_C.OnSortRarityDescNameAsc // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	bool NavigateBack(); // Function WBP_CustomizeAvatar.WBP_CustomizeAvatar_C.NavigateBack // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	struct FEventReply OnKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function WBP_CustomizeAvatar.WBP_CustomizeAvatar_C.OnKeyDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void AddEmptySlots(); // Function WBP_CustomizeAvatar.WBP_CustomizeAvatar_C.AddEmptySlots // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetActiveStates(struct UWBP_CosmeticItem_Avatar_C* ActiveWidget); // Function WBP_CustomizeAvatar.WBP_CustomizeAvatar_C.SetActiveStates // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void RegisterNavigation(); // Function WBP_CustomizeAvatar.WBP_CustomizeAvatar_C.RegisterNavigation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void IsAvatarItemEquipped(struct UKSItem* KSItem, bool IsEquipped); // Function WBP_CustomizeAvatar.WBP_CustomizeAvatar_C.IsAvatarItemEquipped // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void ResetAvatarSelection(); // Function WBP_CustomizeAvatar.WBP_CustomizeAvatar_C.ResetAvatarSelection // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetContextBar(); // Function WBP_CustomizeAvatar.WBP_CustomizeAvatar_C.SetContextBar // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetAvatarSelection(); // Function WBP_CustomizeAvatar.WBP_CustomizeAvatar_C.SetAvatarSelection // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnShown(); // Function WBP_CustomizeAvatar.WBP_CustomizeAvatar_C.OnShown // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnBackPrompt(); // Function WBP_CustomizeAvatar.WBP_CustomizeAvatar_C.OnBackPrompt // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidgetNavigation(); // Function WBP_CustomizeAvatar.WBP_CustomizeAvatar_C.InitializeWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function WBP_CustomizeAvatar.WBP_CustomizeAvatar_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnAvatarHover(struct UKSItem* KSItem); // Function WBP_CustomizeAvatar.WBP_CustomizeAvatar_C.OnAvatarHover // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnAvatarUnhover(); // Function WBP_CustomizeAvatar.WBP_CustomizeAvatar_C.OnAvatarUnhover // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnAvatarSelected(struct UKSItem* KSItem, struct UWidget* Widget); // Function WBP_CustomizeAvatar.WBP_CustomizeAvatar_C.OnAvatarSelected // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnAvatarGamepadHover(struct UPUMG_Widget* Widget, bool bHovered); // Function WBP_CustomizeAvatar.WBP_CustomizeAvatar_C.OnAvatarGamepadHover // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnHide(); // Function WBP_CustomizeAvatar.WBP_CustomizeAvatar_C.OnHide // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_CustomizeAvatar(int32_t EntryPoint); // Function WBP_CustomizeAvatar.WBP_CustomizeAvatar_C.ExecuteUbergraph_WBP_CustomizeAvatar // (Final|UbergraphFunction) // @ game+0x2587100
};

