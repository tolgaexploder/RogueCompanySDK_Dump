// WidgetBlueprintGeneratedClass DropdownList.DropdownList_C
// Size: 0x558 (Inherited: 0x4e0)
struct UDropdownList_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UScrollBox* DropdownScroll; // 0x4e8(0x08)
	struct USizeBox* SizeBox_1; // 0x4f0(0x08)
	struct TArray<struct FText> Options; // 0x4f8(0x10)
	struct FMulticastInlineDelegate OnSelection; // 0x508(0x10)
	struct FMulticastInlineDelegate OnCancel; // 0x518(0x10)
	struct TArray<struct UDropdownEntry_C*> DropdownEntries; // 0x528(0x10)
	struct UDropdownEntry_C* SelectedEntry; // 0x538(0x08)
	float SizeBoxMaxHeight; // 0x540(0x04)
	char UnknownData_544[0x4]; // 0x544(0x04)
	struct FMulticastInlineDelegate OnHoverPreview; // 0x548(0x10)

	bool NavigateBack(); // Function DropdownList.DropdownList_C.NavigateBack // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function DropdownList.DropdownList_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Selection(int32_t Index, struct FText Text); // Function DropdownList.DropdownList_C.Selection // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnMouseLeave(struct FPointerEvent MouseEvent); // Function DropdownList.DropdownList_C.OnMouseLeave // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x2587100
	void InitializeWidgetNavigation(); // Function DropdownList.DropdownList_C.InitializeWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void HandleOnHover(struct UWidget* Widget, int32_t Index); // Function DropdownList.DropdownList_C.HandleOnHover // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetSelectedEntryByIndex(int32_t Index); // Function DropdownList.DropdownList_C.SetSelectedEntryByIndex // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_DropdownList(int32_t EntryPoint); // Function DropdownList.DropdownList_C.ExecuteUbergraph_DropdownList // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void OnHoverPreview__DelegateSignature(int32_t Index); // Function DropdownList.DropdownList_C.OnHoverPreview__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnCancel__DelegateSignature(); // Function DropdownList.DropdownList_C.OnCancel__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnSelection__DelegateSignature(int32_t Index, struct FText Text); // Function DropdownList.DropdownList_C.OnSelection__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

