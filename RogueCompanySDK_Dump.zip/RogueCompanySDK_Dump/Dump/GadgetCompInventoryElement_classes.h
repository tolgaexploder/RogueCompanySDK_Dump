// WidgetBlueprintGeneratedClass GadgetCompInventoryElement.GadgetCompInventoryElement_C
// Size: 0x5d1 (Inherited: 0x520)
struct UGadgetCompInventoryElement_C : UKSWeaponComponentAmmoWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x520(0x08)
	struct UWidgetAnimation* ResupplyAnim; // 0x528(0x08)
	struct UWidgetAnimation* SetCannotFireNow; // 0x530(0x08)
	struct UCanvasPanel* ActivationEffect; // 0x538(0x08)
	struct UImage* background; // 0x540(0x08)
	struct UImage* EmptyBackground; // 0x548(0x08)
	struct UWidgetSwitcher* gadget_switcher; // 0x550(0x08)
	struct USizeBox* GadgetEmpty; // 0x558(0x08)
	struct UPUMG_AsyncImage* GadgetIcon; // 0x560(0x08)
	struct UImage* JammedEffect; // 0x568(0x08)
	struct UOverlay* JammedWrapper; // 0x570(0x08)
	struct UTextBlock* QuantityText; // 0x578(0x08)
	struct UImage* Scanlines; // 0x580(0x08)
	struct UImage* ScanlinesStroke; // 0x588(0x08)
	struct UWBP_InputCallout_C* WBP_InputCallout; // 0x590(0x08)
	struct AKSWeapon* EquipPoint; // 0x598(0x08)
	struct FMulticastInlineDelegate OnGadgetAdded; // 0x5a0(0x10)
	struct FMulticastInlineDelegate OnGadgetRemoved; // 0x5b0(0x10)
	struct UKSWeaponComponent* WeaponComponent_1; // 0x5c0(0x08)
	struct UKSSettingsDataFactory* SettingDataFactory; // 0x5c8(0x08)
	bool bCannotFireNow; // 0x5d0(0x01)

	void Set Jammed(bool Is Jammed); // Function GadgetCompInventoryElement.GadgetCompInventoryElement_C.Set Jammed // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnAmmoChanged(int32_t OldInClip, int32_t OldClipSize, int32_t OldReserve, int32_t NewInClip, int32_t NewClipSize, int32_t NewReserve); // Function GadgetCompInventoryElement.GadgetCompInventoryElement_C.OnAmmoChanged // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function GadgetCompInventoryElement.GadgetCompInventoryElement_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function GadgetCompInventoryElement.GadgetCompInventoryElement_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void PostSetWeaponComponent(); // Function GadgetCompInventoryElement.GadgetCompInventoryElement_C.PostSetWeaponComponent // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void PreClearWeaponComponent(); // Function GadgetCompInventoryElement.GadgetCompInventoryElement_C.PreClearWeaponComponent // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnBecomeActiveWeaponComponent(); // Function GadgetCompInventoryElement.GadgetCompInventoryElement_C.OnBecomeActiveWeaponComponent // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnSetCannotFireNow(bool bCannotFire); // Function GadgetCompInventoryElement.GadgetCompInventoryElement_C.OnSetCannotFireNow // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleOnGadgetResupply(); // Function GadgetCompInventoryElement.GadgetCompInventoryElement_C.HandleOnGadgetResupply // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_GadgetCompInventoryElement(int32_t EntryPoint); // Function GadgetCompInventoryElement.GadgetCompInventoryElement_C.ExecuteUbergraph_GadgetCompInventoryElement // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void OnGadgetRemoved__DelegateSignature(); // Function GadgetCompInventoryElement.GadgetCompInventoryElement_C.OnGadgetRemoved__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnGadgetAdded__DelegateSignature(); // Function GadgetCompInventoryElement.GadgetCompInventoryElement_C.OnGadgetAdded__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

