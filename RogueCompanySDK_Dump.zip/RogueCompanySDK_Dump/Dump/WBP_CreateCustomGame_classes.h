// WidgetBlueprintGeneratedClass WBP_CreateCustomGame.WBP_CreateCustomGame_C
// Size: 0x6a4 (Inherited: 0x5d0)
struct UWBP_CreateCustomGame_C : UKSQuickPlay {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5d0(0x08)
	struct UWidgetAnimation* PopulateMaps; // 0x5d8(0x08)
	struct UImage* Image_112; // 0x5e0(0x08)
	struct UKSScrollBox* MapScrollBox; // 0x5e8(0x08)
	struct UWBP_ControllerPrompt_C* MapScrollPrompt; // 0x5f0(0x08)
	struct USizeBox* MapScrollPromptContainer; // 0x5f8(0x08)
	struct UUniformGridPanel* MapSelectionPanel; // 0x600(0x08)
	struct UWBP_CreateCustomGame_MapButton_C* WBP_CreateCustomGame_MapButton_C_1; // 0x608(0x08)
	struct UWBP_CreateCustomGame_MapButton_C* WBP_CreateCustomGame_MapButton_C_2; // 0x610(0x08)
	struct UWBP_CreateCustomGame_MapButton_C* WBP_CreateCustomGame_MapButton_C_3; // 0x618(0x08)
	struct UWBP_CreateCustomGame_MapButton_C* WBP_CreateCustomGame_MapButton_C_4; // 0x620(0x08)
	struct UWBP_CreateCustomGame_MapButton_C* WBP_CreateCustomGame_MapButton_C_5; // 0x628(0x08)
	struct UWBP_CreateCustomGame_MapButton_C* WBP_CreateCustomGame_MapButton_C_6; // 0x630(0x08)
	struct UWBP_CreateCustomGame_MapButton_C* WBP_CreateCustomGame_MapButton_C_7; // 0x638(0x08)
	struct UWBP_CustomGameConfirmation_C* WBP_CustomGameConfirmation; // 0x640(0x08)
	struct UWBP_GameModeInfoPanel_C* WBP_GameModeInfoPanel; // 0x648(0x08)
	struct UWBP_Header1_C* WBP_Header1; // 0x650(0x08)
	struct UWBP_NavBar_C* WBP_NavBar; // 0x658(0x08)
	struct TArray<struct FClientQueueInfo> CustomQueues; // 0x660(0x10)
	int32_t CurrentTabIndex; // 0x670(0x04)
	char UnknownData_674[0x4]; // 0x674(0x04)
	struct TArray<struct UWBP_CreateCustomGame_MapButton_C*> MapButtons; // 0x678(0x10)
	int32_t TabCount; // 0x688(0x04)
	char UnknownData_68C[0x4]; // 0x68c(0x04)
	struct UKSQueueDataFactory* QueueDataFactory; // 0x690(0x08)
	struct UDataTable* DTCustomQueues; // 0x698(0x08)
	float MapScrollSpeed; // 0x6a0(0x04)

	void Handle Input State Changed(enum class PGAME_INPUT_STATE InputState); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.Handle Input State Changed // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	struct FEventReply OnKeyUp(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.OnKeyUp // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GetQueueImageById(int32_t QueueId, struct UTexture2D* QueueImage); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.GetQueueImageById // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void SetupQueueInfoPanel(struct FClientQueueInfo ClientQueueInfo); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.SetupQueueInfoPanel // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnLobbyCreated(int32_t QueueId); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.OnLobbyCreated // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnLobbyCanceled(); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.OnLobbyCanceled // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetupConfirmation(); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.SetupConfirmation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ShowConfirmation(int32_t QueueId, int32_t MapId); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.ShowConfirmation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BindConfirmationNavigation(); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.BindConfirmationNavigation // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GoToLastScreen(); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.GoToLastScreen // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	bool NavigateBack(); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.NavigateBack // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	struct FEventReply OnKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.OnKeyDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnPreviousTab(); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.OnPreviousTab // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnNextTab(); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.OnNextTab // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetNavigation(int32_t NumColumns); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.SetNavigation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ResetMapSelection(); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.ResetMapSelection // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnMapSelected(int32_t MapId); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.OnMapSelected // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnTabSelected(int32_t ButtonIndex); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.OnTabSelected // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Setup Custom Tabs(); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.Setup Custom Tabs // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidgetNavigation(); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.InitializeWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void CheckIsInCustomMatch(enum class EPUMG_MatchStatus MatchStatus); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.CheckIsInCustomMatch // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnButtonsCreated(); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.OnButtonsCreated // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnBackButtonClicked(); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.OnBackButtonClicked // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnHide(); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.OnHide // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnShown(); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.OnShown // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void PreConstruct(bool IsDesignTime); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void HandleMapScrollChange(); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.HandleMapScrollChange // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_CreateCustomGame(int32_t EntryPoint); // Function WBP_CreateCustomGame.WBP_CreateCustomGame_C.ExecuteUbergraph_WBP_CreateCustomGame // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

