// WidgetBlueprintGeneratedClass GameTimerBarPlayer.GameTimerBarPlayer_C
// Size: 0x5c8 (Inherited: 0x4e0)
struct UGameTimerBarPlayer_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UWidgetAnimation* Pulse; // 0x4e8(0x08)
	struct UImage* Bg; // 0x4f0(0x08)
	struct UWidgetSwitcher* BGSwitcher; // 0x4f8(0x08)
	struct UWidgetSwitcher* BombIndicatorSwitcher; // 0x500(0x08)
	struct UImage* DeadIcon; // 0x508(0x08)
	struct UImage* DownedIcon; // 0x510(0x08)
	struct UImage* Gradient; // 0x518(0x08)
	struct UImage* Image_229; // 0x520(0x08)
	struct UImage* LinkIcon; // 0x528(0x08)
	struct UScaleBox* LocalPlayerIdentifier; // 0x530(0x08)
	struct UImage* ObjectiveIndicator; // 0x538(0x08)
	struct UCanvasPanel* PlayerRespawns; // 0x540(0x08)
	struct UImage* PulseSquare; // 0x548(0x08)
	struct UTextBlock* QueueRespawnPlace; // 0x550(0x08)
	struct UTextBlock* RespawnsCount; // 0x558(0x08)
	struct USizeBox* RogueGameplayIconWrapper; // 0x560(0x08)
	struct UImage* RogueIcon; // 0x568(0x08)
	struct UWidgetSwitcher* RogueIconSwitcher; // 0x570(0x08)
	struct UImage* RoguePortraitIcon; // 0x578(0x08)
	struct UCanvasPanel* RoguePortraitIconWrapper; // 0x580(0x08)
	struct UScaleBox* ScaleBox; // 0x588(0x08)
	struct UScaleBox* ScaleBox_1; // 0x590(0x08)
	struct UImage* SelectionFrame; // 0x598(0x08)
	struct UImage* TicketIcon; // 0x5a0(0x08)
	struct UImage* TimerIcon; // 0x5a8(0x08)
	struct AKSPlayerState* KS Player State; // 0x5b0(0x08)
	enum class GameTimerBarPlayerState CurrentViewState; // 0x5b8(0x01)
	bool IsAlly; // 0x5b9(0x01)
	bool HadValidPlayer; // 0x5ba(0x01)
	bool bPortraitDisplay; // 0x5bb(0x01)
	char UnknownData_5BC[0x4]; // 0x5bc(0x04)
	struct UTexture2D* ObjectiveIcon; // 0x5c0(0x08)

	void InitGradientBackgroundColor(); // Function GameTimerBarPlayer.GameTimerBarPlayer_C.InitGradientBackgroundColor // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitSelectionFrameColor(); // Function GameTimerBarPlayer.GameTimerBarPlayer_C.InitSelectionFrameColor // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnModActivationChange(struct UKSPlayerMod_Activated* ActivatedMod, bool Active); // Function GameTimerBarPlayer.GameTimerBarPlayer_C.OnModActivationChange // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnRespawnQueueChanged(struct AKSTeamState* Team); // Function GameTimerBarPlayer.GameTimerBarPlayer_C.OnRespawnQueueChanged // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Unbind Player State Delegates(); // Function GameTimerBarPlayer.GameTimerBarPlayer_C.Unbind Player State Delegates // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Try Update Is Ally(bool ValueHasChanged); // Function GameTimerBarPlayer.GameTimerBarPlayer_C.Try Update Is Ally // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GameTimerBarPlayer_AutoGenFunc(struct AKSTeamState* Team); // Function GameTimerBarPlayer.GameTimerBarPlayer_C.GameTimerBarPlayer_AutoGenFunc // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void On Player Respawns Changed(struct AKSPlayerState* KSPlayerState); // Function GameTimerBarPlayer.GameTimerBarPlayer_C.On Player Respawns Changed // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleBindingsForPlayerStateChanges(); // Function GameTimerBarPlayer.GameTimerBarPlayer_C.HandleBindingsForPlayerStateChanges // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Set Merc Icon(); // Function GameTimerBarPlayer.GameTimerBarPlayer_C.Set Merc Icon // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetLocalIdentifier(); // Function GameTimerBarPlayer.GameTimerBarPlayer_C.SetLocalIdentifier // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Set View State(enum class GameTimerBarPlayerState State, bool Force); // Function GameTimerBarPlayer.GameTimerBarPlayer_C.Set View State // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Set Player State(struct AKSPlayerState* In Player State); // Function GameTimerBarPlayer.GameTimerBarPlayer_C.Set Player State // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PreConstruct(bool IsDesignTime); // Function GameTimerBarPlayer.GameTimerBarPlayer_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function GameTimerBarPlayer.GameTimerBarPlayer_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void On Player State Downed Changed(struct AKSPlayerState* KSPlayerState); // Function GameTimerBarPlayer.GameTimerBarPlayer_C.On Player State Downed Changed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Player Mods Changed(struct UKSPlayerMod* Mod, struct UKSPlayerModInstance* ModInstance); // Function GameTimerBarPlayer.GameTimerBarPlayer_C.Handle Player Mods Changed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Icon Showing Changed(struct TScriptInterface<None> StatusIconInterface); // Function GameTimerBarPlayer.GameTimerBarPlayer_C.Handle Icon Showing Changed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Bound Icon Mod Removed(); // Function GameTimerBarPlayer.GameTimerBarPlayer_C.Handle Bound Icon Mod Removed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void On Character Is Locally Viewed Changed(bool Is Character Locally Viewed); // Function GameTimerBarPlayer.GameTimerBarPlayer_C.On Character Is Locally Viewed Changed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function GameTimerBarPlayer.GameTimerBarPlayer_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Handle Bomb State Changed(struct FKSNeutralBombState BombState); // Function GameTimerBarPlayer.GameTimerBarPlayer_C.Handle Bomb State Changed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleOnObjectiveStateChanged(struct TScriptInterface<None> GameObjective); // Function GameTimerBarPlayer.GameTimerBarPlayer_C.HandleOnObjectiveStateChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_GameTimerBarPlayer(int32_t EntryPoint); // Function GameTimerBarPlayer.GameTimerBarPlayer_C.ExecuteUbergraph_GameTimerBarPlayer // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

