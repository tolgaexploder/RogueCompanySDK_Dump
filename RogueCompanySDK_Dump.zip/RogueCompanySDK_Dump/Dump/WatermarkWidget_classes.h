// WidgetBlueprintGeneratedClass WatermarkWidget.WatermarkWidget_C
// Size: 0x528 (Inherited: 0x4e0)
struct UWatermarkWidget_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UWidgetAnimation* FadeOut; // 0x4e8(0x08)
	struct UWidgetAnimation* FadeIn; // 0x4f0(0x08)
	struct UCanvasPanel* WatermarkBounds; // 0x4f8(0x08)
	struct UVerticalBox* WatermarkContentBox; // 0x500(0x08)
	float Time To Reposition Watermark; // 0x508(0x04)
	float WatermarkAlpha; // 0x50c(0x04)
	struct FMargin WatermarkBoundsOffset; // 0x510(0x10)
	struct FTimerHandle ViewportResizeUpdateHandle; // 0x520(0x08)

	void GetNewWatermarkTranslation(struct FVector2D Transform Translation); // Function WatermarkWidget.WatermarkWidget_C.GetNewWatermarkTranslation // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void Construct(); // Function WatermarkWidget.WatermarkWidget_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Reposition Watermark(); // Function WatermarkWidget.WatermarkWidget_C.Reposition Watermark // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Fade In(); // Function WatermarkWidget.WatermarkWidget_C.Fade In // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Fade Out(); // Function WatermarkWidget.WatermarkWidget_C.Fade Out // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Move Watermark To Random Position(); // Function WatermarkWidget.WatermarkWidget_C.Move Watermark To Random Position // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void StartPositionChanging(); // Function WatermarkWidget.WatermarkWidget_C.StartPositionChanging // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnResizeViewport(struct FIntPoint Viewport Size); // Function WatermarkWidget.WatermarkWidget_C.OnResizeViewport // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WatermarkWidget(int32_t EntryPoint); // Function WatermarkWidget.WatermarkWidget_C.ExecuteUbergraph_WatermarkWidget // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

