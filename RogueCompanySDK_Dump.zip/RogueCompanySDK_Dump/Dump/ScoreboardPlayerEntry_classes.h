// WidgetBlueprintGeneratedClass ScoreboardPlayerEntry.ScoreboardPlayerEntry_C
// Size: 0x5d3 (Inherited: 0x4e0)
struct UScoreboardPlayerEntry_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UWidgetAnimation* Hover; // 0x4e8(0x08)
	struct UImage* ActivityIndicator; // 0x4f0(0x08)
	struct UTextBlock* AssistCount; // 0x4f8(0x08)
	struct UImage* CrossplayIcon; // 0x500(0x08)
	struct UTextBlock* deathCount; // 0x508(0x08)
	struct UImage* DeathIcon; // 0x510(0x08)
	struct UBorder* DeathIconWrapper; // 0x518(0x08)
	struct UTextBlock* DownCount; // 0x520(0x08)
	struct UTextBlock* elimCount; // 0x528(0x08)
	struct UImage* Image_1; // 0x530(0x08)
	struct UImage* Image_302; // 0x538(0x08)
	struct UImage* LeftBanner; // 0x540(0x08)
	struct UWBP_AsyncIcon_C* MercIcon; // 0x548(0x08)
	struct UImage* Mic; // 0x550(0x08)
	struct UImage* MuteSymbol; // 0x558(0x08)
	struct UStandardButtonNoBorder_C* PlayerButton; // 0x560(0x08)
	struct UTextBlock* PlayerName; // 0x568(0x08)
	struct UTextBlock* pointCount; // 0x570(0x08)
	struct UTextBlock* reviveCount; // 0x578(0x08)
	struct UImage* ScoreBG; // 0x580(0x08)
	struct UImage* SelfIndicator; // 0x588(0x08)
	struct UImage* TeamColorFill; // 0x590(0x08)
	struct UWBP_BoxStroke_C* WBP_BoxStroke; // 0x598(0x08)
	float TotalTimePlayed; // 0x5a0(0x04)
	char UnknownData_5A4[0x4]; // 0x5a4(0x04)
	struct FMulticastInlineDelegate OnPlayerClicked; // 0x5a8(0x10)
	int32_t MaxNameLength; // 0x5b8(0x04)
	int32_t TeamNum; // 0x5bc(0x04)
	bool CanReport; // 0x5c0(0x01)
	char UnknownData_5C1[0x7]; // 0x5c1(0x07)
	struct UKSPersistentPlayerData* CachedPlayerData; // 0x5c8(0x08)
	bool IsOwningPlayer; // 0x5d0(0x01)
	bool CachedIsTalking; // 0x5d1(0x01)
	bool Hovered; // 0x5d2(0x01)

	void GetPlayerState(struct AKSPlayerState* OutPlayerState); // Function ScoreboardPlayerEntry.ScoreboardPlayerEntry_C.GetPlayerState // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void SetColors(); // Function ScoreboardPlayerEntry.ScoreboardPlayerEntry_C.SetColors // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetStatText(); // Function ScoreboardPlayerEntry.ScoreboardPlayerEntry_C.SetStatText // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetPlayerName(); // Function ScoreboardPlayerEntry.ScoreboardPlayerEntry_C.SetPlayerName // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetIconsAndIndicators(); // Function ScoreboardPlayerEntry.ScoreboardPlayerEntry_C.SetIconsAndIndicators // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetPlayerData(); // Function ScoreboardPlayerEntry.ScoreboardPlayerEntry_C.SetPlayerData // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateVoiceInfo(bool IsTalking, bool IsMuted, bool InVoiceChannel); // Function ScoreboardPlayerEntry.ScoreboardPlayerEntry_C.UpdateVoiceInfo // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetMercIcon(); // Function ScoreboardPlayerEntry.ScoreboardPlayerEntry_C.SetMercIcon // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Update(struct UKSPersistentPlayerData* PlayerData); // Function ScoreboardPlayerEntry.ScoreboardPlayerEntry_C.Update // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BndEvt__PlayerButton_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature(); // Function ScoreboardPlayerEntry.ScoreboardPlayerEntry_C.BndEvt__PlayerButton_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__PlayerButton_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function ScoreboardPlayerEntry.ScoreboardPlayerEntry_C.BndEvt__PlayerButton_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__PlayerButton_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function ScoreboardPlayerEntry.ScoreboardPlayerEntry_C.BndEvt__PlayerButton_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void DoUnhoverState(); // Function ScoreboardPlayerEntry.ScoreboardPlayerEntry_C.DoUnhoverState // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void DoHoverState(); // Function ScoreboardPlayerEntry.ScoreboardPlayerEntry_C.DoHoverState // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function ScoreboardPlayerEntry.ScoreboardPlayerEntry_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnShown(); // Function ScoreboardPlayerEntry.ScoreboardPlayerEntry_C.OnShown // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnNeedUpdatePlayerUI(struct AKSPlayerState* PlayerState); // Function ScoreboardPlayerEntry.ScoreboardPlayerEntry_C.OnNeedUpdatePlayerUI // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UninitializeWidget(); // Function ScoreboardPlayerEntry.ScoreboardPlayerEntry_C.UninitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function ScoreboardPlayerEntry.ScoreboardPlayerEntry_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void ScheduleUpdate(); // Function ScoreboardPlayerEntry.ScoreboardPlayerEntry_C.ScheduleUpdate // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_ScoreboardPlayerEntry(int32_t EntryPoint); // Function ScoreboardPlayerEntry.ScoreboardPlayerEntry_C.ExecuteUbergraph_ScoreboardPlayerEntry // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void OnPlayerClicked__DelegateSignature(struct UKSPersistentPlayerData* NewPlayerState, struct UWidget* Widget); // Function ScoreboardPlayerEntry.ScoreboardPlayerEntry_C.OnPlayerClicked__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

