// WidgetBlueprintGeneratedClass GameTimerBar.GameTimerBar_C
// Size: 0x7aa (Inherited: 0x500)
struct UGameTimerBar_C : UKSGameInfoOverlayBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x500(0x08)
	struct UWidgetAnimation* TicketChangeRight; // 0x508(0x08)
	struct UWidgetAnimation* TicketChangeLeft; // 0x510(0x08)
	struct UWidgetAnimation* FadeAnim; // 0x518(0x08)
	struct UWidgetAnimation* MessageChangedAnim; // 0x520(0x08)
	struct UTextBlock* AllyAttackDefendRoleText; // 0x528(0x08)
	struct UImage* AllyIntraScoreIcon; // 0x530(0x08)
	struct UHorizontalBox* AllyIntraTeamScore; // 0x538(0x08)
	struct UCanvasPanel* AllyTeamExtractionCanvas; // 0x540(0x08)
	struct UImage* AllyTicketReducedChevron0; // 0x548(0x08)
	struct UImage* AllyTicketReducedChevron1; // 0x550(0x08)
	struct UImage* AllyTicketReducedChevron2; // 0x558(0x08)
	struct UImage* AllyTicketReducedChevron3; // 0x560(0x08)
	struct UOverlay* AllyTicketsReducedChevrons; // 0x568(0x08)
	struct UTextBlock* EnemyAttackDefendRoleText; // 0x570(0x08)
	struct UImage* EnemyDemoRoleIcon; // 0x578(0x08)
	struct UImage* EnemyIntraScoreIcon; // 0x580(0x08)
	struct UHorizontalBox* EnemyIntraTeamScore; // 0x588(0x08)
	struct UHorizontalBox* EnemyScoring; // 0x590(0x08)
	struct UCanvasPanel* EnemyTeamExtractionCanvas; // 0x598(0x08)
	struct UTextBlock* EnemyTeamScore; // 0x5a0(0x08)
	struct UTextBlock* EnemyTeamTicketCount; // 0x5a8(0x08)
	struct USizeBox* EnemyTicketMeterGroup; // 0x5b0(0x08)
	struct UImage* EnemyTicketReducedChevron0; // 0x5b8(0x08)
	struct UImage* EnemyTicketReducedChevron1; // 0x5c0(0x08)
	struct UImage* EnemyTicketReducedChevron2; // 0x5c8(0x08)
	struct UImage* EnemyTicketReducedChevron3; // 0x5d0(0x08)
	struct UOverlay* EnemyTicketsReducedChevrons; // 0x5d8(0x08)
	struct UImage* FriendlyDemoRoleIcon; // 0x5e0(0x08)
	struct UHorizontalBox* FriendlyScoring; // 0x5e8(0x08)
	struct UTextBlock* FriendlyTeamScore; // 0x5f0(0x08)
	struct UTextBlock* FriendlyTeamTicketCount; // 0x5f8(0x08)
	struct USizeBox* FriendlyTicketMeterGroup; // 0x600(0x08)
	struct UGameTimerBarCenter_C* GameTimerBarCenter; // 0x608(0x08)
	struct UImage* left_frame_body; // 0x610(0x08)
	struct UImage* left_frame_rim; // 0x618(0x08)
	struct UImage* left_team_accent; // 0x620(0x08)
	struct UImage* left_team_bg_outline; // 0x628(0x08)
	struct UHorizontalBox* left_team_players; // 0x630(0x08)
	struct UGameTimerBarPips_C* LeftTeamPips; // 0x638(0x08)
	struct UTextBlock* LeftTeamScore; // 0x640(0x08)
	struct UCanvasPanel* MainWrapper; // 0x648(0x08)
	struct UCanvasPanel* Module_AttackDefend; // 0x650(0x08)
	struct UOverlay* Module_BombPointsIndicator; // 0x658(0x08)
	struct UTextBlock* ObjectiveUnlockingText; // 0x660(0x08)
	struct UImage* right_frame_body; // 0x668(0x08)
	struct UImage* right_frame_rim; // 0x670(0x08)
	struct UImage* right_team_accent; // 0x678(0x08)
	struct UImage* right_team_bg_outline; // 0x680(0x08)
	struct UHorizontalBox* right_team_players; // 0x688(0x08)
	struct UGameTimerBarPips_C* RightTeamPips; // 0x690(0x08)
	struct UTextBlock* RightTeamScore; // 0x698(0x08)
	struct UTextBlock* RoundText; // 0x6a0(0x08)
	struct UTextBlock* ScoreObjective; // 0x6a8(0x08)
	struct UImage* TeamRabbitIcon; // 0x6b0(0x08)
	struct UImage* TicketIcon_2; // 0x6b8(0x08)
	struct UImage* TicketIcon_3; // 0x6c0(0x08)
	struct UHorizontalBox* TicketsEnemySide; // 0x6c8(0x08)
	struct UImage* TicketsFillEnemy; // 0x6d0(0x08)
	struct UOverlay* TicketsFillEnemyWrapper; // 0x6d8(0x08)
	struct UImage* TicketsFillFriendly; // 0x6e0(0x08)
	struct UOverlay* TicketsFillFriendlyWrapper; // 0x6e8(0x08)
	struct UHorizontalBox* TicketsFriendlySide; // 0x6f0(0x08)
	struct UWidgetSwitcher* TopTextSwitcher; // 0x6f8(0x08)
	int32_t Cache_RoundsToWin; // 0x700(0x04)
	float CountdownMax; // 0x704(0x04)
	struct TArray<struct UGameTimerBarPlayer_C*> LeftTeamPlayers; // 0x708(0x10)
	struct TArray<struct UGameTimerBarPlayer_C*> RightTeamPlayers; // 0x718(0x10)
	int32_t CurrentLeftTeamScore; // 0x728(0x04)
	int32_t CurrentRightTeamScore; // 0x72c(0x04)
	struct TMap<struct AKSPlayerState*, struct UGameTimerBarPlayer_C*> PlayerStateToWidgetMap; // 0x730(0x50)
	bool ShouldHide; // 0x780(0x01)
	bool TeamEventBinded; // 0x781(0x01)
	char UnknownData_782[0x2]; // 0x782(0x02)
	struct FObjectiveState CachedObjectiveState; // 0x784(0x14)
	struct AKSControlPoint* CachedControlPoint; // 0x798(0x08)
	struct UTexture2D* ObjectiveIcon; // 0x7a0(0x08)
	bool PreSetTicketDisplay; // 0x7a8(0x01)
	enum class ETopbarTicketDisplay TicketDisplay; // 0x7a9(0x01)

	void SetTicketIcon(); // Function GameTimerBar.GameTimerBar_C.SetTicketIcon // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ResetIntraScore(); // Function GameTimerBar.GameTimerBar_C.ResetIntraScore // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetIntraScoreIcons(); // Function GameTimerBar.GameTimerBar_C.SetIntraScoreIcons // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetGameBarFromComponent(struct UTexture2D* ObjectiveIcon, bool UseBombTimer, bool UseTicketSystem, struct UTexture2D* TicketIcon, enum class ETopbarTicketDisplay TicketDisplay); // Function GameTimerBar.GameTimerBar_C.SetGameBarFromComponent // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleIntraGoalChanged(struct AKSTeamState* TeamState); // Function GameTimerBar.GameTimerBar_C.HandleIntraGoalChanged // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleIntraScoreChanged(struct AKSTeamState* TeamState); // Function GameTimerBar.GameTimerBar_C.HandleIntraScoreChanged // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetupIntraScoring(); // Function GameTimerBar.GameTimerBar_C.SetupIntraScoring // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleTicketDisplay(enum class ETopbarTicketDisplay TicketDisplay); // Function GameTimerBar.GameTimerBar_C.HandleTicketDisplay // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnTeamObjectiveRoleChanged(struct AKSTeamState* Team); // Function GameTimerBar.GameTimerBar_C.OnTeamObjectiveRoleChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Set ObjectiveRole Icon for Team(struct UImage* Icon, struct AKSTeamState* Team); // Function GameTimerBar.GameTimerBar_C.Set ObjectiveRole Icon for Team // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void CheckTeamSides(); // Function GameTimerBar.GameTimerBar_C.CheckTeamSides // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Bind Player State(); // Function GameTimerBar.GameTimerBar_C.Bind Player State // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ResetPlayerStates(); // Function GameTimerBar.GameTimerBar_C.ResetPlayerStates // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnTeamChanged(struct AKSPlayerState* KSPlayerState); // Function GameTimerBar.GameTimerBar_C.OnTeamChanged // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateRoundNumberText(); // Function GameTimerBar.GameTimerBar_C.UpdateRoundNumberText // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnTotalRoundsSet(); // Function GameTimerBar.GameTimerBar_C.OnTotalRoundsSet // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnRoundsToWinSet(); // Function GameTimerBar.GameTimerBar_C.OnRoundsToWinSet // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BindRoundEvents(); // Function GameTimerBar.GameTimerBar_C.BindRoundEvents // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnTeamScoreChanged(struct AKSTeamState* KSTeamState); // Function GameTimerBar.GameTimerBar_C.OnTeamScoreChanged // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void On Team Respawns Changed(struct AKSTeamState* KSTeamState); // Function GameTimerBar.GameTimerBar_C.On Team Respawns Changed // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnMemberRemoved(struct AKSPlayerState* KSPlayerState); // Function GameTimerBar.GameTimerBar_C.OnMemberRemoved // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnMemberAdded(struct AKSPlayerState* KSPlayerState); // Function GameTimerBar.GameTimerBar_C.OnMemberAdded // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnTeamAdded(struct AKSTeamState* KSTeamState); // Function GameTimerBar.GameTimerBar_C.OnTeamAdded // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Bind Team Events(); // Function GameTimerBar.GameTimerBar_C.Bind Team Events // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	struct FText GetRoundInProgressText(); // Function GameTimerBar.GameTimerBar_C.GetRoundInProgressText // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void SetAttackDefendIcons(); // Function GameTimerBar.GameTimerBar_C.SetAttackDefendIcons // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandlePhaseChanged(struct FName NewPhase, struct FName PreviousPhase); // Function GameTimerBar.GameTimerBar_C.HandlePhaseChanged // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PlayBombCountdownSFX(float Seconds); // Function GameTimerBar.GameTimerBar_C.PlayBombCountdownSFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ShouldPlayCountdownSFX(bool ShouldPlay); // Function GameTimerBar.GameTimerBar_C.ShouldPlayCountdownSFX // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void PlayFinalCountdownSFX(float Current Second); // Function GameTimerBar.GameTimerBar_C.PlayFinalCountdownSFX // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Set Timer Text(float Seconds); // Function GameTimerBar.GameTimerBar_C.Set Timer Text // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Neutral Bomb State Changed(struct FKSNeutralBombState BombState); // Function GameTimerBar.GameTimerBar_C.Handle Neutral Bomb State Changed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function GameTimerBar.GameTimerBar_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function GameTimerBar.GameTimerBar_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Handle Timer Second Tick(float Seconds Remaining); // Function GameTimerBar.GameTimerBar_C.Handle Timer Second Tick // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Round Info Changed(); // Function GameTimerBar.GameTimerBar_C.Handle Round Info Changed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Computers Unlocked(); // Function GameTimerBar.GameTimerBar_C.Handle Computers Unlocked // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Round Start(struct FRoundInitState Round Init State); // Function GameTimerBar.GameTimerBar_C.Handle Round Start // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Computer Update(struct AKSObjectiveBase* Objective); // Function GameTimerBar.GameTimerBar_C.Handle Computer Update // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Round End(struct AKSGameState* GameState, struct FRoundResult RoundResult); // Function GameTimerBar.GameTimerBar_C.Handle Round End // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function GameTimerBar.GameTimerBar_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleKillCamEnabled(bool bIsEnabled); // Function GameTimerBar.GameTimerBar_C.HandleKillCamEnabled // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleFadeAnimEnd(); // Function GameTimerBar.GameTimerBar_C.HandleFadeAnimEnd // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnUIRelevantPlayerStateChanged(struct AKSPlayerState* PlayerState); // Function GameTimerBar.GameTimerBar_C.OnUIRelevantPlayerStateChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnControlPointUpdate(struct AKSObjectiveBase* Objective); // Function GameTimerBar.GameTimerBar_C.OnControlPointUpdate // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnControlPointScored(struct AKSTeamState* TeamState, struct AKSControlPoint* ControlPoint); // Function GameTimerBar.GameTimerBar_C.OnControlPointScored // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Attacking Team Updated(struct AKSTeamState* NewTeam); // Function GameTimerBar.GameTimerBar_C.Handle Attacking Team Updated // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Deferred Game State Open(); // Function GameTimerBar.GameTimerBar_C.Deferred Game State Open // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Deferred Bind Computer Open(); // Function GameTimerBar.GameTimerBar_C.Deferred Bind Computer Open // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void DeferredPlayerStateOpen(); // Function GameTimerBar.GameTimerBar_C.DeferredPlayerStateOpen // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UnbindControlPointDelegates(); // Function GameTimerBar.GameTimerBar_C.UnbindControlPointDelegates // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ScorePeriodElapsed(struct AKSControlPoint* ControlPoint); // Function GameTimerBar.GameTimerBar_C.ScorePeriodElapsed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void StopTickCaptureProgress(); // Function GameTimerBar.GameTimerBar_C.StopTickCaptureProgress // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void TickCaptureProgress(); // Function GameTimerBar.GameTimerBar_C.TickCaptureProgress // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void DeferredBindControlPointOpen(); // Function GameTimerBar.GameTimerBar_C.DeferredBindControlPointOpen // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_GameTimerBar(int32_t EntryPoint); // Function GameTimerBar.GameTimerBar_C.ExecuteUbergraph_GameTimerBar // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

