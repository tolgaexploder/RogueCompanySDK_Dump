// BlueprintGeneratedClass SettingsInfo_Quality.SettingsInfo_Quality_C
// Size: 0x128 (Inherited: 0x120)
struct USettingsInfo_Quality_C : UKSSettingsInfo_Generic {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x120(0x08)

	void InitializeValue(); // Function SettingsInfo_Quality.SettingsInfo_Quality_C.InitializeValue // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_SettingsInfo_Quality(int32_t EntryPoint); // Function SettingsInfo_Quality.SettingsInfo_Quality_C.ExecuteUbergraph_SettingsInfo_Quality // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

