// WidgetBlueprintGeneratedClass WBP_ActiveBoosterEntry.WBP_ActiveBoosterEntry_C
// Size: 0x299 (Inherited: 0x238)
struct UWBP_ActiveBoosterEntry_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UWidgetAnimation* GlowPulse; // 0x240(0x08)
	struct UImage* BGGradient; // 0x248(0x08)
	struct UWBP_AsyncIcon_C* BonusIcon; // 0x250(0x08)
	struct UVerticalBox* BoostDescriptionContainer; // 0x258(0x08)
	struct USizeBox* BoosterIconSize; // 0x260(0x08)
	struct UImage* BoosterShine; // 0x268(0x08)
	struct URichTextBlock* DescRichText; // 0x270(0x08)
	struct UTextBlock* EventName; // 0x278(0x08)
	struct UTextBlock* EventTimeRemaining; // 0x280(0x08)
	struct UImage* TimeRemainingIcon; // 0x288(0x08)
	struct USizeBox* TimeRemainingIconWrapper; // 0x290(0x08)
	bool isCompactView; // 0x298(0x01)

	void SetDisplayType(); // Function WBP_ActiveBoosterEntry.WBP_ActiveBoosterEntry_C.SetDisplayType // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PreConstruct(bool IsDesignTime); // Function WBP_ActiveBoosterEntry.WBP_ActiveBoosterEntry_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function WBP_ActiveBoosterEntry.WBP_ActiveBoosterEntry_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Set Item Properties(struct FAccountConsumableDetails Item Details); // Function WBP_ActiveBoosterEntry.WBP_ActiveBoosterEntry_C.Set Item Properties // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_ActiveBoosterEntry(int32_t EntryPoint); // Function WBP_ActiveBoosterEntry.WBP_ActiveBoosterEntry_C.ExecuteUbergraph_WBP_ActiveBoosterEntry // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

