// Class PlatformInventoryItem.PInv_AssetManager
// Size: 0x588 (Inherited: 0x440)
struct UPInv_AssetManager : UAssetManager {
	bool bHasCompletedInitialAssetScan; // 0x440(0x01)
	char UnknownData_441[0x147]; // 0x441(0x147)
};

// Class PlatformInventoryItem.PlatformInventoryItem
// Size: 0x158 (Inherited: 0x30)
struct UPlatformInventoryItem : UPrimaryDataAsset {
	int32_t ItemId; // 0x30(0x04)
	char UnknownData_34[0x4]; // 0x34(0x04)
	struct FText ItemDisplayName; // 0x38(0x18)
	struct FText ItemDescription; // 0x50(0x18)
	struct FString FriendlySearchName; // 0x68(0x10)
	bool IsOwnableInventoryItem; // 0x78(0x01)
	char UnknownData_79[0x7]; // 0x79(0x07)
	struct TArray<int64_t> DisplayableLootIds; // 0x80(0x10)
	struct TSoftObjectPtr<struct UTexture2D> ItemIcon; // 0x90(0x28)
	struct TArray<struct FIconReference> Icons; // 0xb8(0x10)
	struct FGameplayTagContainer CollectionContainer; // 0xc8(0x20)
	struct TMap<enum class EExternalSkuSource, struct FString> ExternalProductSkus; // 0xe8(0x50)
	char UnknownData_138[0x20]; // 0x138(0x20)

	bool ShouldDisplayToUser(int64_t LootId); // Function PlatformInventoryItem.PlatformInventoryItem.ShouldDisplayToUser // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x840b20
	void SetFriendlySearchName(struct FString InFriendlyName); // Function PlatformInventoryItem.PlatformInventoryItem.SetFriendlySearchName // (Final|Native|Public|BlueprintCallable) // @ game+0x840a80
	void SetCollectionContainer(struct FGameplayTagContainer InContainer); // Function PlatformInventoryItem.PlatformInventoryItem.SetCollectionContainer // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8409c0
	void GetTextureAsync(struct TSoftObjectPtr<struct UTexture2D> Texture, struct FDelegate IconLoadedEvent); // Function PlatformInventoryItem.PlatformInventoryItem.GetTextureAsync // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x840890
	struct TSoftObjectPtr<struct UTexture2D> GetSoftItemIcon(); // Function PlatformInventoryItem.PlatformInventoryItem.GetSoftItemIcon // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x840860
	bool GetSoftIconByName(struct FName IconType, struct TSoftObjectPtr<struct UTexture2D> Icon); // Function PlatformInventoryItem.PlatformInventoryItem.GetSoftIconByName // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x840760
	struct FString GetItemNameAsString(); // Function PlatformInventoryItem.PlatformInventoryItem.GetItemNameAsString // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x840610
	struct FText GetItemName(); // Function PlatformInventoryItem.PlatformInventoryItem.GetItemName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x840560
	int32_t GetItemId(); // Function PlatformInventoryItem.PlatformInventoryItem.GetItemId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x840540
	struct FString GetItemDescriptionAsString(); // Function PlatformInventoryItem.PlatformInventoryItem.GetItemDescriptionAsString // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x840410
	struct FText GetItemDescription(); // Function PlatformInventoryItem.PlatformInventoryItem.GetItemDescription // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x840360
	struct TSoftObjectPtr<struct UPlatformInventoryItem> GetItemByFriendlyName(struct FString InFriendlyName); // Function PlatformInventoryItem.PlatformInventoryItem.GetItemByFriendlyName // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x840250
	struct FGameplayTagContainer GetCollectionContainer(); // Function PlatformInventoryItem.PlatformInventoryItem.GetCollectionContainer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x840220
};

// Class PlatformInventoryItem.PlatformStoreAsset
// Size: 0x168 (Inherited: 0x158)
struct UPlatformStoreAsset : UPlatformInventoryItem {
	int32_t LootId; // 0x158(0x04)
	struct FPrimaryAssetRules Rules; // 0x15c(0x0c)

	int32_t GetLootId(); // Function PlatformInventoryItem.PlatformStoreAsset.GetLootId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x840740
};

