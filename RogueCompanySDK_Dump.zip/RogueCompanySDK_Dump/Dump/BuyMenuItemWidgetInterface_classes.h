// BlueprintGeneratedClass BuyMenuItemWidgetInterface.BuyMenuItemWidgetInterface_C
// Size: 0x28 (Inherited: 0x28)
struct UBuyMenuItemWidgetInterface_C : UInterface {

	void RefreshData(struct AKSPlayerShop* Player Shop); // Function BuyMenuItemWidgetInterface.BuyMenuItemWidgetInterface_C.RefreshData // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PurchaseAcknowledge(); // Function BuyMenuItemWidgetInterface.BuyMenuItemWidgetInterface_C.PurchaseAcknowledge // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Get Shop Item Type(enum class EShopItemType Return Value); // Function BuyMenuItemWidgetInterface.BuyMenuItemWidgetInterface_C.Get Shop Item Type // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

