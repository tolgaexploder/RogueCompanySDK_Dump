// WidgetBlueprintGeneratedClass MedDroneMenu.MedDroneMenu_C
// Size: 0x560 (Inherited: 0x4e0)
struct UMedDroneMenu_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UGamepadPromptBasic_C* AcceptCallout; // 0x4e8(0x08)
	struct UGamepadPromptBasic_C* CancelCallout; // 0x4f0(0x08)
	struct UHorizontalBox* GamepadCallouts; // 0x4f8(0x08)
	struct UImage* Image_1; // 0x500(0x08)
	struct UImage* Image_2; // 0x508(0x08)
	struct UImage* Image_3; // 0x510(0x08)
	struct UImage* Image_4; // 0x518(0x08)
	struct UVerticalBox* OptionsContainer; // 0x520(0x08)
	struct UButton* OutButton; // 0x528(0x08)
	struct UMedDroneMenuOption_C* SampleOption0; // 0x530(0x08)
	struct UMedDroneMenuOption_C* SampleOption1; // 0x538(0x08)
	struct UMedDroneMenuOption_C* SampleOption2; // 0x540(0x08)
	struct AKSWeapon_Targeted* Targeting Weapon; // 0x548(0x08)
	struct TArray<struct AActor*> Targets; // 0x550(0x10)

	void Construct(); // Function MedDroneMenu.MedDroneMenu_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void OptionSelected(struct AKSPlayerState* Selected Target); // Function MedDroneMenu.MedDroneMenu_C.OptionSelected // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BndEvt__OutButton_K2Node_ComponentBoundEvent_40_OnButtonClickedEvent__DelegateSignature(); // Function MedDroneMenu.MedDroneMenu_C.BndEvt__OutButton_K2Node_ComponentBoundEvent_40_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void Close(bool Should Cancel); // Function MedDroneMenu.MedDroneMenu_C.Close // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidgetNavigation(); // Function MedDroneMenu.MedDroneMenu_C.InitializeWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function MedDroneMenu.MedDroneMenu_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Input State Change(enum class PGAME_INPUT_STATE InputState); // Function MedDroneMenu.MedDroneMenu_C.Handle Input State Change // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_MedDroneMenu(int32_t EntryPoint); // Function MedDroneMenu.MedDroneMenu_C.ExecuteUbergraph_MedDroneMenu // (Final|UbergraphFunction) // @ game+0x2587100
};

