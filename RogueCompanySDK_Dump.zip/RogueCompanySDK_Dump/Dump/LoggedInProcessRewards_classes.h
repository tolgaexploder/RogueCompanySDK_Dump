// WidgetBlueprintGeneratedClass LoggedInProcessRewards.LoggedInProcessRewards_C
// Size: 0x4f8 (Inherited: 0x4e0)
struct ULoggedInProcessRewards_C : UKSLoginProcessRewards {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UImage* background; // 0x4e8(0x08)
	struct UWBP_ThrobberShield_C* WBP_ThrobberShield; // 0x4f0(0x08)

	void OnShown(); // Function LoggedInProcessRewards.LoggedInProcessRewards_C.OnShown // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_LoggedInProcessRewards(int32_t EntryPoint); // Function LoggedInProcessRewards.LoggedInProcessRewards_C.ExecuteUbergraph_LoggedInProcessRewards // (Final|UbergraphFunction) // @ game+0x2587100
};

