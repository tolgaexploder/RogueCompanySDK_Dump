// DynamicClass Master_WeaponComponent.Master_WeaponComponent_C
// Size: 0x11a0 (Inherited: 0x5d8)
struct UMaster_WeaponComponent_C : UKSWeaponComponent {
	bool Is ADS; // 0x5d8(0x01)
	char UnknownData_5D9[0x3]; // 0x5d9(0x03)
	struct FName Owner Fire Section; // 0x5dc(0x08)
	char UnknownData_5E4[0x4]; // 0x5e4(0x04)
	struct TArray<struct FName> Owner 1p ADS Fire Section; // 0x5e8(0x10)
	struct FName Deattach Slot Name; // 0x5f8(0x08)
	struct FName Attach Slot Name; // 0x600(0x08)
	struct FName MIrror Attach Slot Name; // 0x608(0x08)
	int32_t Weapon Fire Sound ID; // 0x610(0x04)
	bool Weapon Fire Sound Interrupts; // 0x614(0x01)
	char UnknownData_615[0x3]; // 0x615(0x03)
	struct UAkAudioEvent* Weapon Casing Sound; // 0x618(0x08)
	struct UAkAudioEvent* Equip Sound; // 0x620(0x08)
	float Speed of Sound; // 0x628(0x04)
	float Echo Max Distance; // 0x62c(0x04)
	struct TArray<struct FRotator> Echo Directions; // 0x630(0x10)
	struct FVector Echo Sound Location; // 0x640(0x0c)
	char UnknownData_64C[0x4]; // 0x64c(0x04)
	struct UParticleSystem* Muzzle Flash 3p; // 0x650(0x08)
	struct UParticleSystem* Muzzle Flash 1p; // 0x658(0x08)
	struct FName Muzzle Flash Attach Name; // 0x660(0x08)
	struct FName Cartridge Ejection Attach Name; // 0x668(0x08)
	struct FHitDecalInfo Default Decal Info; // 0x670(0x28)
	struct TMap<enum class EPhysicalSurface, struct FHitDecalInfo> Physical Decal Materials; // 0x698(0x50)
	struct UParticleSystem* Tracer Template; // 0x6e8(0x08)
	float Next Tracer Time; // 0x6f0(0x04)
	float Minimum Tracer Delay; // 0x6f4(0x04)
	float Maximum Tracer Delay; // 0x6f8(0x04)
	int32_t Shot Count; // 0x6fc(0x04)
	struct UStaticMesh* Tracer Mesh; // 0x700(0x08)
	int32_t Tracer Frequency; // 0x708(0x04)
	enum class EPhysicalSurface Decal Physical Surface; // 0x70c(0x01)
	char UnknownData_70D[0x3]; // 0x70d(0x03)
	struct FVector Decal Location; // 0x710(0x0c)
	char UnknownData_71C[0x4]; // 0x71c(0x04)
	struct UMaterialInterface* Temp Mesh Material Override; // 0x720(0x08)
	int32_t CountedShotsLeft; // 0x728(0x04)
	char UnknownData_72C[0x4]; // 0x72c(0x04)
	struct UObject* 1P ADS Camera Shake; // 0x730(0x08)
	struct TArray<struct FName> Owner 3p Fire Section; // 0x738(0x10)
	int32_t Counter; // 0x748(0x04)
	char UnknownData_74C[0x4]; // 0x74c(0x04)
	struct UObject* AOS Camera Shake; // 0x750(0x08)
	struct UObject* 3P Camera Shake; // 0x758(0x08)
	int32_t CountedMagSize; // 0x760(0x04)
	bool bIsSecondaryWeapon; // 0x764(0x01)
	bool Is Pistol; // 0x765(0x01)
	bool Is Dual Guns; // 0x766(0x01)
	bool ShouldSpawnTracers; // 0x767(0x01)
	bool ShouldHaveBulletFX; // 0x768(0x01)
	bool ShouldHaveBulletSpangs; // 0x769(0x01)
	bool bWasFiredByOwner; // 0x76a(0x01)
	char UnknownData_76B[0x1]; // 0x76b(0x01)
	float NearMissDistance; // 0x76c(0x04)
	struct FName MagazineDropBone; // 0x770(0x08)
	bool DropMagazineMirror Enabled; // 0x778(0x01)
	char UnknownData_779[0x3]; // 0x779(0x03)
	struct FName Mirror_MagazineDropBone; // 0x77c(0x08)
	bool DropBoneOnWeapon; // 0x784(0x01)
	bool TrackingMagDropBone; // 0x785(0x01)
	char UnknownData_786[0xa]; // 0x786(0x0a)
	struct FTransform DropMagSpawnTransformOveride; // 0x790(0x30)
	struct FVector DropBonePreviousPosition; // 0x7c0(0x0c)
	struct FVector DropBoneVelocity; // 0x7cc(0x0c)
	struct FVector DropVelocityOverride; // 0x7d8(0x0c)
	bool Is Gun Holstered; // 0x7e4(0x01)
	bool DropMultipleMags; // 0x7e5(0x01)
	bool Drop Multiple Mags Velocity Inheritance Override; // 0x7e6(0x01)
	char UnknownData_7E7[0x1]; // 0x7e7(0x01)
	struct TArray<struct FMultiMagDropInfo> MultiMagArray; // 0x7e8(0x10)
	bool Is Multi Stage Reload; // 0x7f8(0x01)
	bool Maintain Holster; // 0x7f9(0x01)
	char UnknownData_7FA[0x2]; // 0x7fa(0x02)
	struct FName Target BackSlot; // 0x7fc(0x08)
	bool Is Shotgun; // 0x804(0x01)
	char UnknownData_805[0x3]; // 0x805(0x03)
	struct FRotator Target Shell Housing Spin; // 0x808(0x0c)
	int32_t Missing Shell Count; // 0x814(0x04)
	bool Is Revolver; // 0x818(0x01)
	char UnknownData_819[0x3]; // 0x819(0x03)
	float Interp Speed; // 0x81c(0x04)
	float VsWorldAlphaDiff; // 0x820(0x04)
	float LastUpdatedAlpha; // 0x824(0x04)
	bool Prevent Vs World Active; // 0x828(0x01)
	bool Is Vs World Force Reset Delay; // 0x829(0x01)
	char UnknownData_82A[0x2]; // 0x82a(0x02)
	float Vs World Reset Delay Time; // 0x82c(0x04)
	bool Able to Magdrop?; // 0x830(0x01)
	bool Force Holster Mantle; // 0x831(0x01)
	bool Force Holster Zipline; // 0x832(0x01)
	bool Scope Mesh Scale; // 0x833(0x01)
	float Scope Scale Alpha; // 0x834(0x04)
	struct TArray<struct UMaterialInterface*> Hide Materials Array; // 0x838(0x10)
	bool Is Vcol Hide Needed; // 0x848(0x01)
	char UnknownData_849[0x7]; // 0x849(0x07)
	struct FMulticastInlineDelegate OnSetScopeScaleAlpha; // 0x850(0x10)
	struct FMulticastInlineDelegate OnSetRevolverChamberRotate; // 0x860(0x10)
	float CosmeticShotTraceDist; // 0x870(0x04)
	char UnknownData_874[0x4]; // 0x874(0x04)
	struct TArray<struct UParticleSystemComponent*> CartridgeEjectParticles; // 0x878(0x10)
	struct TArray<struct UParticleSystemComponent*> 1PMuzzleFlashParticles; // 0x888(0x10)
	struct TArray<struct UParticleSystemComponent*> 3pMuzzleFlashParticles; // 0x898(0x10)
	bool bShouldPlayADSFire; // 0x8a8(0x01)
	char UnknownData_8A9[0x3]; // 0x8a9(0x03)
	float ADSFirePlayPosition; // 0x8ac(0x04)
	float AOSFirePlayPosition; // 0x8b0(0x04)
	float ADSFireDelay; // 0x8b4(0x04)
	struct FMulticastInlineDelegate OnSetLobbyState; // 0x8b8(0x10)
	bool DropMagazineLockout; // 0x8c8(0x01)
	char UnknownData_8C9[0x7]; // 0x8c9(0x07)
	struct UObject* 3P Camera Shake Hi; // 0x8d0(0x08)
	struct UObject* Bullet Near Miss Camera Shake; // 0x8d8(0x08)
	float Bullet Near Miss Camera Shake Distance; // 0x8e0(0x04)
	char UnknownData_8E4[0x4]; // 0x8e4(0x04)
	struct UObject* FireCameraModifier; // 0x8e8(0x08)
	struct TArray<struct FFullFireRepData> QueuedAimData; // 0x8f0(0x10)
	struct TArray<struct FHitResult> ValidHits_Event; // 0x900(0x10)
	bool Should Play Impact Sound; // 0x910(0x01)
	bool Should Hide On Holster; // 0x911(0x01)
	enum class EFireAudioMode FireAudioMode; // 0x912(0x01)
	bool AllowNewShotAudio; // 0x913(0x01)
	float Post Reload Delay Period; // 0x914(0x04)
	bool Folded Stock; // 0x918(0x01)
	char UnknownData_919[0x3]; // 0x919(0x03)
	struct FRotator Stock Rotation; // 0x91c(0x0c)
	struct FRotator Stock alt Rotation; // 0x928(0x0c)
	bool Multi Stage Reload Lockout; // 0x934(0x01)
	char UnknownData_935[0x3]; // 0x935(0x03)
	struct FVector ViewPawnForwardDir; // 0x938(0x0c)
	struct FVector ViewPawnLeftDir; // 0x944(0x0c)
	float LastBulletMissTime; // 0x950(0x04)
	float LoopingFireAudioCheckTriggerDelay; // 0x954(0x04)
	int32_t LoopingFireAudioFadeOutDuration; // 0x958(0x04)
	bool IsFirstShot; // 0x95c(0x01)
	bool IsPlayerControlled; // 0x95d(0x01)
	bool Lunging Active; // 0x95e(0x01)
	char UnknownData_95F[0x1]; // 0x95f(0x01)
	struct TArray<struct UParticleSystemComponent*> 1PAuxMuzzleFlashParticles; // 0x960(0x10)
	struct TArray<struct UParticleSystemComponent*> 3pAuxMuzzleFlashParticles; // 0x970(0x10)
	bool ShouldPlayBlockedImpactSound; // 0x980(0x01)
	char UnknownData_981[0x7]; // 0x981(0x07)
	struct FTimerHandle Revolving timer; // 0x988(0x08)
	struct FRotator Eval Target Shell Housing Spin; // 0x990(0x0c)
	bool ShouldComputeCosmeticHits; // 0x99c(0x01)
	bool On Init Hide Magazine; // 0x99d(0x01)
	bool Use laser sight; // 0x99e(0x01)
	char UnknownData_99F[0x1]; // 0x99f(0x01)
	struct UMaterialInstanceDynamic* Reticle Material; // 0x9a0(0x08)
	enum class ECombatState RetrieveCombatState; // 0x9a8(0x01)
	char UnknownData_9A9[0x7]; // 0x9a9(0x07)
	struct FTimerHandle Post Reload Timer; // 0x9b0(0x08)
	enum class EWeaponStateNew Old State; // 0x9b8(0x01)
	char UnknownData_9B9[0x3]; // 0x9b9(0x03)
	struct FVector TracerStartPointLocalToOwner; // 0x9bc(0x0c)
	float TracerMinimumOffsetLocallyViewed; // 0x9c8(0x04)
	float TracerMaximumOffsetLocallyViewed; // 0x9cc(0x04)
	float TracerMinimumOffsetNPC; // 0x9d0(0x04)
	float TracerMaximumOffsetNPC; // 0x9d4(0x04)
	float Combat State Change Time; // 0x9d8(0x04)
	bool Mirror Deattach Slot Active; // 0x9dc(0x01)
	char UnknownData_9DD[0x3]; // 0x9dd(0x03)
	struct FName Mirror Deattach Slot Name; // 0x9e0(0x08)
	struct UObject* ScopeWidgetClass; // 0x9e8(0x08)
	struct AActor* ScopeWidgetActor; // 0x9f0(0x08)
	struct FMulticastInlineDelegate OnSetShieldActive; // 0x9f8(0x10)
	struct FHitResult K2Node_CustomEvent_Hit; // 0xa08(0x88)
	bool CallFunc_BreakHitResult_bBlockingHit; // 0xa90(0x01)
	bool CallFunc_BreakHitResult_bInitialOverlap; // 0xa91(0x01)
	char UnknownData_A92[0x2]; // 0xa92(0x02)
	float CallFunc_BreakHitResult_Time; // 0xa94(0x04)
	float CallFunc_BreakHitResult_Distance; // 0xa98(0x04)
	struct FVector CallFunc_BreakHitResult_Location; // 0xa9c(0x0c)
	struct FVector CallFunc_BreakHitResult_ImpactPoint; // 0xaa8(0x0c)
	struct FVector CallFunc_BreakHitResult_Normal; // 0xab4(0x0c)
	struct FVector CallFunc_BreakHitResult_ImpactNormal; // 0xac0(0x0c)
	char UnknownData_ACC[0x4]; // 0xacc(0x04)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat; // 0xad0(0x08)
	struct AActor* CallFunc_BreakHitResult_HitActor; // 0xad8(0x08)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent; // 0xae0(0x08)
	struct FName CallFunc_BreakHitResult_HitBoneName; // 0xae8(0x08)
	int32_t CallFunc_BreakHitResult_HitItem; // 0xaf0(0x04)
	int32_t CallFunc_BreakHitResult_FaceIndex; // 0xaf4(0x04)
	struct FVector CallFunc_BreakHitResult_TraceStart; // 0xaf8(0x0c)
	struct FVector CallFunc_BreakHitResult_TraceEnd; // 0xb04(0x0c)
	bool CallFunc_BreakHitResult_bBlockingHit_2; // 0xb10(0x01)
	bool CallFunc_BreakHitResult_bInitialOverlap_2; // 0xb11(0x01)
	char UnknownData_B12[0x2]; // 0xb12(0x02)
	float CallFunc_BreakHitResult_Time_2; // 0xb14(0x04)
	float CallFunc_BreakHitResult_Distance_2; // 0xb18(0x04)
	struct FVector CallFunc_BreakHitResult_Location_2; // 0xb1c(0x0c)
	struct FVector CallFunc_BreakHitResult_ImpactPoint_2; // 0xb28(0x0c)
	struct FVector CallFunc_BreakHitResult_Normal_2; // 0xb34(0x0c)
	struct FVector CallFunc_BreakHitResult_ImpactNormal_2; // 0xb40(0x0c)
	char UnknownData_B4C[0x4]; // 0xb4c(0x04)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat_2; // 0xb50(0x08)
	struct AActor* CallFunc_BreakHitResult_HitActor_2; // 0xb58(0x08)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent_2; // 0xb60(0x08)
	struct FName CallFunc_BreakHitResult_HitBoneName_2; // 0xb68(0x08)
	int32_t CallFunc_BreakHitResult_HitItem_2; // 0xb70(0x04)
	int32_t CallFunc_BreakHitResult_FaceIndex_2; // 0xb74(0x04)
	struct FVector CallFunc_BreakHitResult_TraceStart_2; // 0xb78(0x0c)
	struct FVector CallFunc_BreakHitResult_TraceEnd_2; // 0xb84(0x0c)
	struct FHitDecalInfo CallFunc_Get_Decal_Material_Decal_Info; // 0xb90(0x28)
	bool K2Node_CustomEvent_bBlockingHit; // 0xbb8(0x01)
	char UnknownData_BB9[0x7]; // 0xbb9(0x07)
	struct TArray<struct FHitResult> K2Node_CustomEvent_OutHits; // 0xbc0(0x10)
	struct FVector K2Node_CustomEvent_Start; // 0xbd0(0x0c)
	struct FVector K2Node_CustomEvent_End; // 0xbdc(0x0c)
	bool K2Node_CustomEvent_bBlockingHit_2; // 0xbe8(0x01)
	char UnknownData_BE9[0x7]; // 0xbe9(0x07)
	struct TArray<struct FHitResult> K2Node_CustomEvent_OutHits_2; // 0xbf0(0x10)
	struct FVector K2Node_CustomEvent_Start_2; // 0xc00(0x0c)
	struct FVector K2Node_CustomEvent_End_2; // 0xc0c(0x0c)
	bool K2Node_CustomEvent_bBlockingHit_3; // 0xc18(0x01)
	char UnknownData_C19[0x7]; // 0xc19(0x07)
	struct TArray<struct FHitResult> K2Node_CustomEvent_OutHits_3; // 0xc20(0x10)
	struct FVector K2Node_CustomEvent_Start_3; // 0xc30(0x0c)
	struct FVector K2Node_CustomEvent_End_3; // 0xc3c(0x0c)
	struct FFullFireRepData K2Node_CustomEvent_Data; // 0xc48(0x68)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller; // 0xcb0(0x08)
	bool K2Node_DynamicCast_bSuccess; // 0xcb8(0x01)
	char UnknownData_CB9[0x3]; // 0xcb9(0x03)
	struct FName Temp_name_Variable; // 0xcbc(0x08)
	char UnknownData_CC4[0x4]; // 0xcc4(0x04)
	struct UKSDefaultAimTargetingModule* K2Node_DynamicCast_AsKSDefault_Aim_Targeting_Module; // 0xcc8(0x08)
	bool K2Node_DynamicCast_bSuccess_2; // 0xcd0(0x01)
	char UnknownData_CD1[0x3]; // 0xcd1(0x03)
	struct FVector CallFunc_IsWallMarkerActive_WallLocation; // 0xcd4(0x0c)
	bool K2Node_CustomEvent_Blocking_Hit; // 0xce0(0x01)
	char UnknownData_CE1[0x7]; // 0xce1(0x07)
	struct TArray<struct FHitResult> K2Node_CustomEvent_Out_Hits; // 0xce8(0x10)
	struct FVector K2Node_CustomEvent_Start_4; // 0xcf8(0x0c)
	struct FVector K2Node_CustomEvent_End_4; // 0xd04(0x0c)
	bool K2Node_CustomEvent_Allow_Spangs; // 0xd10(0x01)
	bool K2Node_CustomEvent_Allow_Tracers; // 0xd11(0x01)
	bool K2Node_CustomEvent_Allow_Decals; // 0xd12(0x01)
	char UnknownData_D13[0x5]; // 0xd13(0x05)
	struct TArray<struct FHitResult> CallFunc_Filter_Cosmetic_Hit_Results_Filtered_Hit_Results; // 0xd18(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate; // 0xd28(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2; // 0xd38(0x10)
	float K2Node_Event_DeltaSeconds; // 0xd48(0x04)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3; // 0xd4c(0x10)
	enum class EWeaponStateNew K2Node_Event_OldState; // 0xd5c(0x01)
	enum class EWeaponStateNew K2Node_Event_NewState; // 0xd5d(0x01)
	bool K2Node_SwitchEnum_CmpSuccess; // 0xd5e(0x01)
	char UnknownData_D5F[0x1]; // 0xd5f(0x01)
	struct FFullFireRepData K2Node_Event_Data; // 0xd60(0x68)
	struct TArray<struct FHitResult> K2Node_CustomEvent_Hits; // 0xdc8(0x10)
	struct FVector K2Node_CustomEvent_Start_5; // 0xdd8(0x0c)
	struct FVector K2Node_CustomEvent_End_5; // 0xde4(0x0c)
	bool K2Node_SwitchEnum_CmpSuccess_2; // 0xdf0(0x01)
	char UnknownData_DF1[0x3]; // 0xdf1(0x03)
	int32_t CallFunc_GetAnimMontage_Priority; // 0xdf4(0x04)
	int32_t CallFunc_GetAnimMontage_Priority_2; // 0xdf8(0x04)
	int32_t Temp_int_Loop_Counter_Variable; // 0xdfc(0x04)
	struct TArray<struct FHitResult> K2Node_CustomEvent_Hits_2; // 0xe00(0x10)
	struct FVector K2Node_CustomEvent_Trace_End; // 0xe10(0x0c)
	int32_t Temp_int_Array_Index_Variable; // 0xe1c(0x04)
	struct UParticleSystemComponent* CallFunc_Array_Get_Item; // 0xe20(0x08)
	int32_t CallFunc_GetBool_Priority; // 0xe28(0x04)
	char UnknownData_E2C[0x4]; // 0xe2c(0x04)
	struct UKSCharacterAnimInst* CallFunc_Get_Character_Anim_Instance_Anim_Inst; // 0xe30(0x08)
	int32_t CallFunc_GetBool_Priority_2; // 0xe38(0x04)
	char UnknownData_E3C[0x4]; // 0xe3c(0x04)
	struct TArray<struct FHitResult> K2Node_CustomEvent_Hits_3; // 0xe40(0x10)
	bool K2Node_CustomEvent_bBlockingHit_4; // 0xe50(0x01)
	char UnknownData_E51[0x7]; // 0xe51(0x07)
	struct TArray<struct FHitResult> K2Node_CustomEvent_OutHits_4; // 0xe58(0x10)
	struct FVector K2Node_CustomEvent_Start_6; // 0xe68(0x0c)
	struct FVector K2Node_CustomEvent_End_6; // 0xe74(0x0c)
	struct APawn* K2Node_CustomEvent_ViewPawn; // 0xe80(0x08)
	enum class ECombatState K2Node_CustomEvent_NewState; // 0xe88(0x01)
	char UnknownData_E89[0x7]; // 0xe89(0x07)
	struct UKSCharacterAnimInst* CallFunc_Get_Character_Anim_Instance_Anim_Inst_2; // 0xe90(0x08)
	struct UKSCharacterAnimInst* CallFunc_Get_Character_Anim_Instance_Anim_Inst_3; // 0xe98(0x08)
	struct FFullFireRepData K2Node_CustomEvent_Fire_Data; // 0xea0(0x68)
	struct UKSCharacterAnimInst* CallFunc_Get_Character_Anim_Instance_Anim_Inst_4; // 0xf08(0x08)
	int32_t Temp_int_Variable; // 0xf10(0x04)
	int32_t CallFunc_GetAudioEvent_Priority; // 0xf14(0x04)
	int32_t CallFunc_GetAudioEvent_Priority_2; // 0xf18(0x04)
	int32_t CallFunc_GetAudioEvent_Priority_3; // 0xf1c(0x04)
	int32_t CallFunc_GetAnimMontage_Priority_3; // 0xf20(0x04)
	char UnknownData_F24[0x4]; // 0xf24(0x04)
	struct UAnimMontage* CallFunc_Get_Player_1P_Fire_Montage_Montage; // 0xf28(0x08)
	int32_t CallFunc_GetAnimMontage_Priority_4; // 0xf30(0x04)
	int32_t CallFunc_GetAnimMontage_Priority_5; // 0xf34(0x04)
	struct USkinnableSkeletalMeshComponent* K2Node_Event_SkinnableSkelComp; // 0xf38(0x08)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4; // 0xf40(0x10)
	int32_t Temp_int_Array_Index_Variable_2; // 0xf50(0x04)
	char UnknownData_F54[0x4]; // 0xf54(0x04)
	struct UParticleSystemComponent* CallFunc_Array_Get_Item_2; // 0xf58(0x08)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable; // 0xf60(0x10)
	int32_t Temp_int_Loop_Counter_Variable_2; // 0xf70(0x04)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5; // 0xf74(0x10)
	int32_t Temp_int_Array_Index_Variable_3; // 0xf84(0x04)
	struct UParticleSystemComponent* CallFunc_Array_Get_Item_3; // 0xf88(0x08)
	int32_t Temp_int_Array_Index_Variable_4; // 0xf90(0x04)
	bool K2Node_SwitchEnum_CmpSuccess_3; // 0xf94(0x01)
	char UnknownData_F95[0x3]; // 0xf95(0x03)
	int32_t Temp_int_Loop_Counter_Variable_3; // 0xf98(0x04)
	char UnknownData_F9C[0x4]; // 0xf9c(0x04)
	struct TArray<struct AActor*> Temp_object_Variable; // 0xfa0(0x10)
	int32_t Temp_int_Array_Index_Variable_5; // 0xfb0(0x04)
	char UnknownData_FB4[0x4]; // 0xfb4(0x04)
	struct UParticleSystemComponent* CallFunc_Array_Get_Item_4; // 0xfb8(0x08)
	enum class EEndPlayReason K2Node_Event_EndPlayReason; // 0xfc0(0x01)
	char UnknownData_FC1[0x7]; // 0xfc1(0x07)
	struct AKSCharacterBase* K2Node_CustomEvent_KillerCharacter; // 0xfc8(0x08)
	struct AKSCharacterBase* K2Node_CustomEvent_KilledCharacter; // 0xfd0(0x08)
	bool K2Node_SwitchEnum_CmpSuccess_4; // 0xfd8(0x01)
	char UnknownData_FD9[0x7]; // 0xfd9(0x07)
	struct AController* K2Node_CustomEvent_NewController; // 0xfe0(0x08)
	struct AKSPlayerController* K2Node_DynamicCast_AsKSPlayer_Controller; // 0xfe8(0x08)
	bool K2Node_DynamicCast_bSuccess_3; // 0xff0(0x01)
	char UnknownData_FF1[0x3]; // 0xff1(0x03)
	int32_t Temp_int_Loop_Counter_Variable_4; // 0xff4(0x04)
	struct FDelegate Temp_delegate_Variable; // 0xff8(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_2; // 0x1008(0x10)
	int32_t Temp_int_Loop_Counter_Variable_5; // 0x1018(0x04)
	int32_t CallFunc_GetBool_Priority_3; // 0x101c(0x04)
	int32_t CallFunc_GetAnimMontage_Priority_6; // 0x1020(0x04)
	int32_t CallFunc_GetAnimMontage_Priority_7; // 0x1024(0x04)
	struct UKSCharacterAnimInst* CallFunc_Get_Character_Anim_Instance_Anim_Inst_5; // 0x1028(0x08)
	struct FDelegate Temp_delegate_Variable_2; // 0x1030(0x10)
	struct UKSCharacterAnimInst* CallFunc_Get_Character_Anim_Instance_Anim_Inst_6; // 0x1040(0x08)
	int32_t CallFunc_GetAnimMontage_Priority_8; // 0x1048(0x04)
	int32_t CallFunc_GetAnimMontage_Priority_9; // 0x104c(0x04)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_3; // 0x1050(0x10)
	struct FDelegate Temp_delegate_Variable_3; // 0x1060(0x10)
	int32_t CallFunc_GetBool_Priority_4; // 0x1070(0x04)
	int32_t CallFunc_GetAnimMontage_Priority_10; // 0x1074(0x04)
	int32_t CallFunc_GetAnimMontage_Priority_11; // 0x1078(0x04)
	int32_t CallFunc_GetAnimMontage_Priority_12; // 0x107c(0x04)
	struct UKSCharacterAnimInst* CallFunc_Get_Character_Anim_Instance_Anim_Inst_7; // 0x1080(0x08)
	struct UKSCharacterAnimInst* CallFunc_Get_Character_Anim_Instance_Anim_Inst_8; // 0x1088(0x08)
	int32_t CallFunc_GetAnimMontage_Priority_13; // 0x1090(0x04)
	char UnknownData_1094[0x4]; // 0x1094(0x04)
	struct TArray<struct UMaterialInterface*> CallFunc_GetMaterials_ReturnValue; // 0x1098(0x10)
	int32_t CallFunc_GetAnimMontage_Priority_14; // 0x10a8(0x04)
	char UnknownData_10AC[0x4]; // 0x10ac(0x04)
	struct UMaterialInterface* CallFunc_Array_Get_Item_5; // 0x10b0(0x08)
	struct UMaterialInstanceDynamic* K2Node_DynamicCast_AsMaterial_Instance_Dynamic; // 0x10b8(0x08)
	bool K2Node_DynamicCast_bSuccess_4; // 0x10c0(0x01)
	bool Temp_bool_Variable; // 0x10c1(0x01)
	char UnknownData_10C2[0x6]; // 0x10c2(0x06)
	struct UAnimMontage* K2Node_Select_Default; // 0x10c8(0x08)
	struct UKSCharacterAnimInst* CallFunc_Get_Character_Anim_Instance_Anim_Inst_9; // 0x10d0(0x08)
	bool CallFunc_End_Reload_Weapon_Cancelled_A_Reload; // 0x10d8(0x01)
	char UnknownData_10D9[0x7]; // 0x10d9(0x07)
	struct UKSCharacterAnimInst* CallFunc_Get_Character_Anim_Instance_Anim_Inst_10; // 0x10e0(0x08)
	int32_t Temp_int_Variable_2; // 0x10e8(0x04)
	int32_t Temp_int_Array_Index_Variable_6; // 0x10ec(0x04)
	struct UParticleSystemComponent* CallFunc_Array_Get_Item_6; // 0x10f0(0x08)
	int32_t CallFunc_GetAudioEvent_Priority_4; // 0x10f8(0x04)
	int32_t CallFunc_GetAnimMontage_Priority_15; // 0x10fc(0x04)
	int32_t Temp_int_Variable_3; // 0x1100(0x04)
	char UnknownData_1104[0x4]; // 0x1104(0x04)
	struct UTexture2D* Temp_object_Variable_2; // 0x1108(0x08)
	enum class ECombatState K2Node_CustomEvent_OldCombatState; // 0x1110(0x01)
	enum class ECombatState K2Node_CustomEvent_NewCombatState; // 0x1111(0x01)
	char UnknownData_1112[0x2]; // 0x1112(0x02)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6; // 0x1114(0x10)
	bool Temp_bool_Variable_2; // 0x1124(0x01)
	char UnknownData_1125[0x3]; // 0x1125(0x03)
	struct UTexture2D* K2Node_Select_Default_2; // 0x1128(0x08)
	struct UKSCharacterAnimInst* CallFunc_Get_Character_Anim_Instance_Anim_Inst_11; // 0x1130(0x08)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_7; // 0x1138(0x10)
	struct UKSCharacterAnimInst* CallFunc_Get_Character_Anim_Instance_Anim_Inst_12; // 0x1148(0x08)
	struct FDelegate Temp_delegate_Variable_4; // 0x1150(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_4; // 0x1160(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_8; // 0x1170(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_9; // 0x1180(0x10)
	int32_t Temp_int_Loop_Counter_Variable_6; // 0x1190(0x04)
	char UnknownData_1194[0xc]; // 0x1194(0x0c)

	void OnSetShieldActive__DelegateSignature(bool bpp__ShieldIsActive__pf); // DelegateFunction Master_WeaponComponent.Master_WeaponComponent_C.OnSetShieldActive__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnSetScopeScaleAlpha__DelegateSignature(float bpp__NewxAlpha__pfT); // DelegateFunction Master_WeaponComponent.Master_WeaponComponent_C.OnSetScopeScaleAlpha__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnSetRevolverChamberRotate__DelegateSignature(struct FRotator bpp__NewxRevolverxChamberxRotator__pfTTT); // DelegateFunction Master_WeaponComponent.Master_WeaponComponent_C.OnSetRevolverChamberRotate__DelegateSignature // (Public|Delegate|HasDefaults) // @ game+0x2587100
	void OnSetLobbyState__DelegateSignature(bool bpp__LobbyxState__pfT); // DelegateFunction Master_WeaponComponent.Master_WeaponComponent_C.OnSetLobbyState__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void Update Tracer Start Point(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Update Tracer Start Point // (Native|Public|BlueprintCallable) // @ game+0x1a05160
	void Update Combat State(enum class ECombatState bpp__NewState__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Update Combat State // (Native|Public|BlueprintCallable) // @ game+0x1a050e0
	void UpdateMagDropBoneVelocity(float bpp__DeltaTime__pf, int32_t bpp__Index__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.UpdateMagDropBoneVelocity // (Native|Public|BlueprintCallable) // @ game+0x1a05010
	void UpdateAimDownSightsBlurValues(); // Function Master_WeaponComponent.Master_WeaponComponent_C.UpdateAimDownSightsBlurValues // (Native|Event|Public|BlueprintCallable) // @ game+0x1a04ff0
	void TryDisableCameraModifier(struct UObject* bpp__CameraxModifier__pfT, int32_t bpp__PlayerxIndex__pfT, bool bpp__Found__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.TryDisableCameraModifier // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1a04ee0
	void SyncComputeCosmeticHits(struct FFullFireRepData bpp__FireData__pf, struct TArray<struct FHitResult> bpp__Hits__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.SyncComputeCosmeticHits // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1a04db0
	void Spawn Tracers Simple(struct TArray<struct FHitResult> bpp__Hits__pf, struct FVector bpp__TracexEnd__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Spawn Tracers Simple // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x1a04ca0
	void Spawn Tracer(struct FVector bpp__EndPoint__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Spawn Tracer // (Native|Public|HasDefaults|BlueprintCallable) // @ game+0x1a04c10
	void Spawn Spangs and Decals(struct FFullFireRepData bpp__Data__pf__const, struct TArray<struct FHitResult> bpp__Hits__pf, struct FFullFireRepData bpp__OutxData__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Spawn Spangs and Decals // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1a04a70
	void SpawnTracers(struct TArray<struct FHitResult> bpp__Hits__pf, struct TArray<struct FFullFireRepData> bpp__AimData__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.SpawnTracers // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1a04930
	void SpawnSpangs(struct TArray<struct FHitResult> bpp__Hits__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.SpawnSpangs // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1a04880
	void SpawnDecals(struct TArray<struct FHitResult> bpp__Hits__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.SpawnDecals // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1a047d0
	void ShouldPlayFireAnim1P(bool bpp__Playx1PxFire__pfTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.ShouldPlayFireAnim1P // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1a04730
	void Set Scope Scale Alpha(float bpp__NewxAlpha__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Set Scope Scale Alpha // (Native|Public|BlueprintCallable) // @ game+0x1a046b0
	void Set Revolver Chamber Rotate(struct FRotator bpp__TargetxRotator__pfT, bool bpp__ResetxRotation__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Set Revolver Chamber Rotate // (Native|Public|HasDefaults|BlueprintCallable) // @ game+0x1a045d0
	void Set Muzzle Flash Emitter and Offset(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Set Muzzle Flash Emitter and Offset // (Native|Public|BlueprintCallable) // @ game+0x1a045b0
	void Setup Character Anim Init Callback(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Setup Character Anim Init Callback // (Native|Public|BlueprintCallable) // @ game+0x1a04590
	void SetUIWidget(); // Function Master_WeaponComponent.Master_WeaponComponent_C.SetUIWidget // (Native|Public|BlueprintCallable) // @ game+0x1a04570
	struct UAnimMontage* Select Weapon Reload Montage(bool bpp__IsxQuickxReload__pfTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Select Weapon Reload Montage // (Native|Public|BlueprintCallable) // @ game+0x1a044d0
	void Select Reload Montage(struct UAnimMontage* bpp__ReloadMontage__pf, struct UAnimMontage* bpp__QuickReloadMontage__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Select Reload Montage // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1a043f0
	void Retrieve Weapon(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Retrieve Weapon // (Native|Public|BlueprintCallable) // @ game+0x1a043d0
	void Reticle Rotate(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Reticle Rotate // (Native|Public|BlueprintCallable) // @ game+0x1a043b0
	void Reset Variables at Start of Firing Instance(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Reset Variables at Start of Firing Instance // (Native|Public|BlueprintCallable) // @ game+0x1a04390
	void Reload Weapon(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Reload Weapon // (Native|Public|BlueprintCallable) // @ game+0x891350
	void Reload Mirror Delay End(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Reload Mirror Delay End // (Native|Public|BlueprintCallable) // @ game+0x1a04370
	void Reload Cooldown Weapon(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Reload Cooldown Weapon // (Native|Public|BlueprintCallable) // @ game+0x1a04350
	void ReceiveTick(float bpp__DeltaSeconds__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.ReceiveTick // (Native|Event|Public) // @ game+0x1a042d0
	void ReceiveEndPlay(enum class EEndPlayReason bpp__EndPlayReason__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.ReceiveEndPlay // (Native|Event|Public) // @ game+0x1a041d0
	void ReceiveBeginPlay(); // Function Master_WeaponComponent.Master_WeaponComponent_C.ReceiveBeginPlay // (Native|Event|Public) // @ game+0x74e300
	void Pre Fire Weapon(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Pre Fire Weapon // (Native|Public|BlueprintCallable) // @ game+0x1a041b0
	void Prepare Next Tracer Spawn(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Prepare Next Tracer Spawn // (Native|Public|BlueprintCallable) // @ game+0x1a04190
	void Post Fire Weapon(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Post Fire Weapon // (Native|Public|BlueprintCallable) // @ game+0x1a04170
	void Play Weapon Reload animation(float bpp__PlayRate__pf, bool bpp__IsxQuickxReload__pfTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Play Weapon Reload animation // (Native|Public|BlueprintCallable) // @ game+0x1a040a0
	void Play Reload MultiStage(float bpp__PlayxRate__pfT, struct UAnimMontage* bpp__SelectedxMontage__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Play Reload MultiStage // (Native|Public|BlueprintCallable) // @ game+0x1a03fd0
	void Play Reload Logic(struct UAnimMontage* bpp__ReloadxMontage__pfT, struct UAnimMontage* bpp__QuickReloadxMontage__pfT, bool bpp__IsxMultixStagexReloadx__pfTTTzy); // Function Master_WeaponComponent.Master_WeaponComponent_C.Play Reload Logic // (Native|Public|BlueprintCallable) // @ game+0x1a03ed0
	void Play Reload Base(float bpp__PlayxRate__pfT, struct UAnimMontage* bpp__SelectedxMontage__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Play Reload Base // (Native|Public|BlueprintCallable) // @ game+0x1a03e00
	void Play Post Reload(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Play Post Reload // (Native|Public|BlueprintCallable) // @ game+0x1a03de0
	void Play Fire Tail Sound(enum class EAkCallbackType bpp__CallbackxType__pfT, struct UAkCallbackInfo* bpp__CallbackxInfo__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Play Fire Tail Sound // (Native|Public|BlueprintCallable) // @ game+0x1a03d10
	void Play Fire Camera Shakes(bool bpp__LocalOnly__pf, struct UObject* bpp__PrimaryxShake__pfT, struct UObject* bpp__HiFreqxShake__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Play Fire Camera Shakes // (Native|Public|BlueprintCallable) // @ game+0x1a03c00
	void Play Casing Sound(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Play Casing Sound // (Native|Public|BlueprintCallable) // @ game+0x1a03be0
	void Play Bullet Impact SFX(struct FHitResult bpp__HitResult__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Play Bullet Impact SFX // (Native|Public|BlueprintCallable) // @ game+0x1a03ab0
	void PlayInvalidFireSound(); // Function Master_WeaponComponent.Master_WeaponComponent_C.PlayInvalidFireSound // (Native|Public|BlueprintCallable) // @ game+0x7ba340
	void PlayFireSound(struct FAimData bpp__InputPin__pf__const); // Function Master_WeaponComponent.Master_WeaponComponent_C.PlayFireSound // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1a03a00
	void PlayEmptyFireAudio(); // Function Master_WeaponComponent.Master_WeaponComponent_C.PlayEmptyFireAudio // (Native|Public|BlueprintCallable) // @ game+0x1a039e0
	void PlayBulletNearMissSound(struct FVector bpp__InxTracexStart__pfTT, struct FVector bpp__InxTracexEnd__pfTT, struct TArray<struct FHitResult> bpp__Hits__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.PlayBulletNearMissSound // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x1a03890
	void On Cosmetic Trace Complete Internal(bool bpp__BlockingxHit__pfT__const, struct TArray<struct FHitResult> bpp__OutxHits__pfT, struct FVector bpp__Start__pf__const, struct FVector bpp__End__pf__const, bool bpp__AllowxSpangs__pfT, bool bpp__AllowxTracers__pfT, bool bpp__AllowxDecals__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.On Cosmetic Trace Complete Internal // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x1a03630
	void On Comestic Trace Complete(bool bpp__bBlockingHit__pf, struct TArray<struct FHitResult> bpp__OutHits__pf__const, struct FVector bpp__Start__pf__const, struct FVector bpp__End__pf__const); // Function Master_WeaponComponent.Master_WeaponComponent_C.On Comestic Trace Complete // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x1a03490
	void On Character Anim Initialized(); // Function Master_WeaponComponent.Master_WeaponComponent_C.On Character Anim Initialized // (Native|Public|BlueprintCallable) // @ game+0x1a03470
	void OnPossessedBy_Event_1(struct AController* bpp__NewController__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.OnPossessedBy_Event_1 // (Native|Public|BlueprintCallable) // @ game+0x1a033e0
	void OnKilled_Event_1(struct AKSCharacterBase* bpp__KillerCharacter__pf__const, struct AKSCharacterBase* bpp__KilledCharacter__pf__const); // Function Master_WeaponComponent.Master_WeaponComponent_C.OnKilled_Event_1 // (Native|Public|BlueprintCallable) // @ game+0x1a03310
	void NotifyStopFireReceived(); // Function Master_WeaponComponent.Master_WeaponComponent_C.NotifyStopFireReceived // (BlueprintCosmetic|Native|Event|Public) // @ game+0x1a032f0
	bool IsDropMeshValid(int32_t bpp__Index__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.IsDropMeshValid // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x1a03250
	void IdleWeapon(enum class EWeaponStateNew bpp__OldState__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.IdleWeapon // (Native|Public|BlueprintCallable) // @ game+0x1a031d0
	void Holster Weapon(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Holster Weapon // (Native|Public|BlueprintCallable) // @ game+0x1a031b0
	void Hide Magazine(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Hide Magazine // (Native|Public|BlueprintCallable) // @ game+0x1a03190
	void HasUIWidget(bool bpp__HasUIWidget__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.HasUIWidget // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1a030d0
	void HandleWeaponFiringClientEffects(struct FFullFireRepData bpp__Data__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.HandleWeaponFiringClientEffects // (Native|Public|BlueprintCallable) // @ game+0x1a03020
	void Get Tracer Offset(float bpp__Offset__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Tracer Offset // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1a02f80
	void Get Spang Particle System(struct FHitResult bpp__Hit__pf, struct UParticleSystem* bpp__SpangxToxUse__pfTT, bool bpp__PlayOnHitCharacter__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Spang Particle System // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1a02de0
	void Get Scaled Reload Playrate(struct UAnimMontage* bpp__AnimxMontage__pfT, float bpp__ScaledxPlayrate__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Scaled Reload Playrate // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1a02d00
	void Get Scaled Post Reload Playrate(struct UAnimMontage* bpp__AnimxMontage__pfT, float bpp__ScaledxPlayrate__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Scaled Post Reload Playrate // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1a02c20
	void Get Scaled Multistage Reload Playrate(struct UAnimMontage* bpp__AnimxMontage__pfT, float bpp__ScaledxPlayrate__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Scaled Multistage Reload Playrate // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1a02b40
	void Get Reticle Material(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Reticle Material // (Native|Public|BlueprintCallable) // @ game+0x1a02a40
	void Get Post Reload Weapon Section Time(struct UAnimMontage* bpp__AnimxMontage__pfT, float bpp__PostxReloadxPosition__pfTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Post Reload Weapon Section Time // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1a02960
	void Get Player 3P Lunge Montage(struct UAnimMontage* bpp__Montage__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Player 3P Lunge Montage // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1a028c0
	void Get Player 3P Fire Montage(struct UAnimMontage* bpp__Montage__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Player 3P Fire Montage // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1a02820
	void Get Player 1P Fire Montage(struct UAnimMontage* bpp__Montage__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Player 1P Fire Montage // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1a02780
	void Get Expected Aim Data(struct FAimData bpp__AimData__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Expected Aim Data // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1a026d0
	void Get Decal Material(struct FHitResult bpp__Hit__pf, struct FHitDecalInfo bpp__DecalxInfo__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Decal Material // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1a02550
	void Get Deattach Slot Name(struct AKSCharacter* bpp__KSCharacter__pf, struct FName bpp__SlotxName__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Deattach Slot Name // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1a02470
	void Get Character Anim Instance(struct UKSCharacterAnimInst* bpp__AnimxInst__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Character Anim Instance // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1a023d0
	void Get Character 3p Fire Section(struct FName bpp__3pxFirexSection__pfTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Character 3p Fire Section // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1a02330
	void Get Character 1p Fire Section(struct FName bpp__1pxFirexSection__pfTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Character 1p Fire Section // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1a02290
	void Get Attach Slot Name(struct AKSCharacter* bpp__KSCharacter__pf, struct FName bpp__SlotxName__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Attach Slot Name // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1a021b0
	void GetTracerStartPoint(struct FVector bpp__TracerStartLocation__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.GetTracerStartPoint // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x1a02120
	void GetTableRowNameForHit(struct FHitResult bpp__Hit__pf, struct FName bpp__RowNamePrefix__pf, struct FName bpp__RowName__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.GetTableRowNameForHit // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1a01fa0
	void GetPercentRemainingAmmo(float bpp__Percent__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.GetPercentRemainingAmmo // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1a01f00
	void GetMagDropBoneRotation(int32_t bpp__Index__pf, struct FRotator bpp__WorldRotation__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.GetMagDropBoneRotation // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x1a01d90
	void GetMagDropBoneLocation(int32_t bpp__Index__pf, struct FVector bpp__WorldLocation__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.GetMagDropBoneLocation // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x1a01cc0
	void GetMagazineDropBoneName(struct FName bpp__Name__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.GetMagazineDropBoneName // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1a01e60
	struct UAkAudioEvent* GetFirstShotAudioEvent(); // Function Master_WeaponComponent.Master_WeaponComponent_C.GetFirstShotAudioEvent // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x1a01c90
	struct UAkAudioEvent* GetFireAudioEvent(); // Function Master_WeaponComponent.Master_WeaponComponent_C.GetFireAudioEvent // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x1a01c60
	struct UAkAudioEvent* GetEchoAudioEvent(); // Function Master_WeaponComponent.Master_WeaponComponent_C.GetEchoAudioEvent // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x1a01c30
	void GetDropVelocity(int32_t bpp__Index__pf, struct FVector bpp__WorldVelocity__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.GetDropVelocity // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x1a01b60
	void GetDropMesh(int32_t bpp__Index__pf, struct USkeletalMesh* bpp__SkelMesh__pf, struct UStaticMesh* bpp__StaticMesh__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.GetDropMesh // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1a01a40
	void Force Exit ADS Pose(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Force Exit ADS Pose // (Native|Public|BlueprintCallable) // @ game+0x74e320
	void Force ADS Scope(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Force ADS Scope // (Native|Public|BlueprintCallable) // @ game+0x1a01a20
	void ForceRetrieveWeapon(); // Function Master_WeaponComponent.Master_WeaponComponent_C.ForceRetrieveWeapon // (Native|Event|Public|BlueprintCallable) // @ game+0x1a01a00
	void ForceRetrieveState(); // Function Master_WeaponComponent.Master_WeaponComponent_C.ForceRetrieveState // (Native|Event|Public|BlueprintCallable) // @ game+0x1a019e0
	void ForceHolsterWeapon(); // Function Master_WeaponComponent.Master_WeaponComponent_C.ForceHolsterWeapon // (Native|Event|Public|BlueprintCallable) // @ game+0x1a019c0
	void ForceAttachWeaponToHolsterSocket(); // Function Master_WeaponComponent.Master_WeaponComponent_C.ForceAttachWeaponToHolsterSocket // (Native|Event|Public|BlueprintCallable) // @ game+0x1a019a0
	void ForceAttachWeaponToActiveSocket(); // Function Master_WeaponComponent.Master_WeaponComponent_C.ForceAttachWeaponToActiveSocket // (Native|Event|Public|BlueprintCallable) // @ game+0x1a01980
	void Fixup Laser Sight(struct USkinnableSkeletalMeshComponent* bpp__MeshComponent__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Fixup Laser Sight // (Native|Public|BlueprintCallable) // @ game+0x1a018f0
	void Fixup Attach Point(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Fixup Attach Point // (Native|Public|BlueprintCallable) // @ game+0x1a018d0
	void Fire Weapon(struct FFullFireRepData bpp__Data__pf, bool bpp__PlayNoChainFireMontage__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Fire Weapon // (Native|Public|BlueprintCallable) // @ game+0x1a017c0
	void Fire Montage Jump To Section(struct FString bpp__Section__pf__const); // Function Master_WeaponComponent.Master_WeaponComponent_C.Fire Montage Jump To Section // (Native|Public|BlueprintCallable) // @ game+0x1a01720
	void Filter Cosmetic Hit Results(struct TArray<struct FHitResult> bpp__TracexHitxResults__pfTT, struct TArray<struct FHitResult> bpp__FilteredxHitxResults__pfTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Filter Cosmetic Hit Results // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1a01600
	void ExecuteUbergraph_Master_WeaponComponent_6(int32_t bpp__EntryPoint__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.ExecuteUbergraph_Master_WeaponComponent_6 // (Final|Native|Public) // @ game+0x1a01580
	void ExecuteUbergraph_Master_WeaponComponent_40(int32_t bpp__EntryPoint__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.ExecuteUbergraph_Master_WeaponComponent_40 // (Final|Native|Public) // @ game+0x1a01480
	void ExecuteUbergraph_Master_WeaponComponent_39(int32_t bpp__EntryPoint__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.ExecuteUbergraph_Master_WeaponComponent_39 // (Final|Native|Public) // @ game+0x1a01400
	void ExecuteUbergraph_Master_WeaponComponent_37(int32_t bpp__EntryPoint__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.ExecuteUbergraph_Master_WeaponComponent_37 // (Final|Native|Public) // @ game+0x1a01380
	void ExecuteUbergraph_Master_WeaponComponent_33(int32_t bpp__EntryPoint__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.ExecuteUbergraph_Master_WeaponComponent_33 // (Final|Native|Public) // @ game+0x1a01300
	void ExecuteUbergraph_Master_WeaponComponent_4(int32_t bpp__EntryPoint__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.ExecuteUbergraph_Master_WeaponComponent_4 // (Final|Native|Public) // @ game+0x1a01500
	void Evaluate Shield Mesh Anim State(bool bpp__ShieldxState__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Evaluate Shield Mesh Anim State // (Native|Public|BlueprintCallable) // @ game+0x1a011f0
	void Evaluate Revolver Chamber Rotate(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Evaluate Revolver Chamber Rotate // (Native|Public|BlueprintCallable) // @ game+0x1a011d0
	void End Reload Weapon(bool bpp__AbortxReloadxAnimation__pfTT, bool bpp__CancelledxAxReload__pfTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.End Reload Weapon // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1a010f0
	void EnableOrAddCameraModifier(struct UObject* bpp__Modifier__pf, int32_t bpp__PlayerIndex__pf, struct UCameraModifier* bpp__ModifierxObject__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.EnableOrAddCameraModifier // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1a00fe0
	void DropMagInternal(int32_t bpp__Index__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.DropMagInternal // (Native|Public|BlueprintCallable) // @ game+0x1a00f30
	void DropMagazine(); // Function Master_WeaponComponent.Master_WeaponComponent_C.DropMagazine // (Native|Event|Public|BlueprintCallable) // @ game+0x1a00fc0
	void DetermineMagSize(); // Function Master_WeaponComponent.Master_WeaponComponent_C.DetermineMagSize // (Native|Public|BlueprintCallable) // @ game+0x1a00f10
	void Delay Spawn Tracers(struct TArray<struct FHitResult> bpp__Hits__pf__const, struct FVector bpp__TracexEnd__pfT__const); // Function Master_WeaponComponent.Master_WeaponComponent_C.Delay Spawn Tracers // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x1a00e00
	void Delay Spawn Spangs(struct TArray<struct FHitResult> bpp__Hits__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Delay Spawn Spangs // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1a00d50
	void Delay Spawn Decals(struct TArray<struct FHitResult> bpp__Hits__pf__const, struct FVector bpp__Start__pf, struct FVector bpp__End__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Delay Spawn Decals // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x1a00bf0
	void CheckKillCamScope(struct APawn* bpp__ViewPawn__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.CheckKillCamScope // (Native|Public|BlueprintCallable) // @ game+0x1a00ad0
	void Character Combat State Changed(enum class ECombatState bpp__OldCombatState__pf, enum class ECombatState bpp__NewCombatState__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Character Combat State Changed // (Native|Public|BlueprintCallable) // @ game+0x1a00a10
	void Can Spawn Tracer Now(bool bpp__CanxSpawnxxTracer__pfTTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Can Spawn Tracer Now // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1a00970
	void CancelReloadCosmetic(); // Function Master_WeaponComponent.Master_WeaponComponent_C.CancelReloadCosmetic // (BlueprintCosmetic|Native|Event|Public|BlueprintCallable) // @ game+0x1a00950
	void Calculate Reload Time(struct UAnimMontage* bpp__ReloadxMontage__pfT, struct UAnimMontage* bpp__QuickxReloadxMontage__pfTT, float bpp__PlayRate__pf, struct UAnimMontage* bpp__SelectedxMontage__pfT, bool bpp__IsxQuickReload__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Calculate Reload Time // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1a00780
	void Calculate Multistage Reload Time(struct UAnimMontage* bpp__ReloadxMontage__pfT, struct UAnimMontage* bpp__QuickxReloadxMontage__pfTT, float bpp__PlayRate__pf, struct UAnimMontage* bpp__SelectedxMontage__pfT, bool bpp__IsxQuickReload__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Calculate Multistage Reload Time // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1a005b0
	void BuildupWeapon(); // Function Master_WeaponComponent.Master_WeaponComponent_C.BuildupWeapon // (Native|Public|BlueprintCallable) // @ game+0x1a00590
	void BlueprintPrepareKillCamPlayback(); // Function Master_WeaponComponent.Master_WeaponComponent_C.BlueprintPrepareKillCamPlayback // (Native|Event|Public) // @ game+0x1a00570
	void BlueprintPersistentCosmeticsUpdate(); // Function Master_WeaponComponent.Master_WeaponComponent_C.BlueprintPersistentCosmeticsUpdate // (Native|Event|Public) // @ game+0x74e440
	void AudioOnCooldown(); // Function Master_WeaponComponent.Master_WeaponComponent_C.AudioOnCooldown // (Native|Public|BlueprintCallable) // @ game+0x1a00550
	void Attach Weapon To Holster Socket(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Attach Weapon To Holster Socket // (Native|Public|BlueprintCallable) // @ game+0x1a00530
	void Attach Weapon To Active Socket(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Attach Weapon To Active Socket // (Native|Public|BlueprintCallable) // @ game+0x1a00510
	void AsyncComputeCosmeticHitsAndPlay(struct FFullFireRepData bpp__FirexData__pfT__const); // Function Master_WeaponComponent.Master_WeaponComponent_C.AsyncComputeCosmeticHitsAndPlay // (Native|Public|BlueprintCallable) // @ game+0x1a00460
	void Apply Spang From Hit Result(struct FHitResult bpp__Hit__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Apply Spang From Hit Result // (Native|Public|BlueprintCallable) // @ game+0x1a00330
	void ApplyDecalFromHit(struct FHitResult bpp__Hit__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.ApplyDecalFromHit // (Native|Public|BlueprintCallable) // @ game+0x1a00200
	void Anim Init Set Weapon State(struct UKSWeaponAnimInstance* bpp__KSxWeaponxAnimxInst__pfTTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Anim Init Set Weapon State // (Native|Public|BlueprintCallable) // @ game+0x1a00170
	void Anim Init Set Use Weapon Additive(struct UKSWeaponAnimInstance* bpp__KSxWeaponxAnimxInst__pfTTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Anim Init Set Use Weapon Additive // (Native|Public|BlueprintCallable) // @ game+0x1a000e0
	void Anim Init Set Shield Is Active(struct UKSWeaponAnimInstance* bpp__KSxWeaponxAnimxInst__pfTTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Anim Init Set Shield Is Active // (Native|Public|BlueprintCallable) // @ game+0x1a00050
	void Anim Init Set Scope Mesh Scale(struct UKSWeaponAnimInstance* bpp__KSxWeaponxAnimxInst__pfTTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Anim Init Set Scope Mesh Scale // (Native|Public|BlueprintCallable) // @ game+0x19fffc0
	void Anim Init Set Lobby State(struct UKSWeaponAnimInstance* bpp__KSxWeaponxAnimxInst__pfTTT, struct UAnimInstance* bpp__BackupxAnimxInst__pfTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Anim Init Set Lobby State // (Native|Public|BlueprintCallable) // @ game+0x19ffef0
	void Anim Init Set Hide Magazine(struct UKSWeaponAnimInstance* bpp__KSxWeaponxAnimxInst__pfTTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Anim Init Set Hide Magazine // (Native|Public|BlueprintCallable) // @ game+0x19ffe60
	void Anim Init Set Folding Stock(struct UKSWeaponAnimInstance* bpp__KSxWeaponxAnimxInst__pfTTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Anim Init Set Folding Stock // (Native|Public|BlueprintCallable) // @ game+0x19ffdd0
	void Anim Init On Weapon Mesh(struct USkinnableSkeletalMeshComponent* bpp__SkelComp__pf, struct UAnimInstance* bpp__AnimInstance__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Anim Init On Weapon Mesh // (Native|Public|BlueprintCallable) // @ game+0x19ffd00
	void Ancillary Mesh Scale Set(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Ancillary Mesh Scale Set // (Native|Public|BlueprintCallable) // @ game+0x19ffce0
	void After Spawn Tracers Delay(bool bpp__bBlockingHit__pf, struct TArray<struct FHitResult> bpp__OutHits__pf__const, struct FVector bpp__Start__pf__const, struct FVector bpp__End__pf__const); // Function Master_WeaponComponent.Master_WeaponComponent_C.After Spawn Tracers Delay // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x19ffb40
	void After Spawn Spangs Delay(bool bpp__bBlockingHit__pf, struct TArray<struct FHitResult> bpp__OutHits__pf__const, struct FVector bpp__Start__pf__const, struct FVector bpp__End__pf__const); // Function Master_WeaponComponent.Master_WeaponComponent_C.After Spawn Spangs Delay // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x19ff9a0
	void After Spawn Decals Delay(bool bpp__bBlockingHit__pf, struct TArray<struct FHitResult> bpp__OutHits__pf__const, struct FVector bpp__Start__pf__const, struct FVector bpp__End__pf__const); // Function Master_WeaponComponent.Master_WeaponComponent_C.After Spawn Decals Delay // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x19ff800
	void OnWeaponComponentStateChanged__DelegateSignature(struct UKSWeaponComponent* bpp__WeaponComponent__pf, enum class EWeaponStateNew bpp__OldState__pf, enum class EWeaponStateNew bpp__NewState__pf); // DelegateFunction Master_WeaponComponent.Master_WeaponComponent_C.OnWeaponComponentStateChanged__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnPossessedBy__DelegateSignature(struct AController* bpp__NewController__pf); // DelegateFunction Master_WeaponComponent.Master_WeaponComponent_C.OnPossessedBy__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnKilled__DelegateSignature(struct AKSCharacterBase* bpp__KillerCharacter__pf, struct AKSCharacterBase* bpp__KilledCharacter__pf); // DelegateFunction Master_WeaponComponent.Master_WeaponComponent_C.OnKilled__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnCombatStateChanged__DelegateSignature(enum class ECombatState bpp__OldCombatState__pf, enum class ECombatState bpp__NewCombatState__pf); // DelegateFunction Master_WeaponComponent.Master_WeaponComponent_C.OnCombatStateChanged__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnAnimInitializedOnSkinnableMesh__DelegateSignature(struct USkinnableSkeletalMeshComponent* bpp__SkinnableSkelComp__pf, struct UAnimInstance* bpp__AnimInstance__pf); // DelegateFunction Master_WeaponComponent.Master_WeaponComponent_C.OnAnimInitializedOnSkinnableMesh__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnAnimInitialized__DelegateSignature(); // DelegateFunction Master_WeaponComponent.Master_WeaponComponent_C.OnAnimInitialized__DelegateSignature // (Public|Delegate) // @ game+0x2587100
};

