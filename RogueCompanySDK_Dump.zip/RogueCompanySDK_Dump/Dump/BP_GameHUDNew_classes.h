// BlueprintGeneratedClass BP_GameHUDNew.BP_GameHUDNew_C
// Size: 0x750 (Inherited: 0x678)
struct ABP_GameHUDNew_C : AKSGameHUDNew {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x678(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x680(0x08)
	struct UGameHUDWidget_C* HUD Widget; // 0x688(0x08)
	float HUDXRatio; // 0x690(0x04)
	float HUDYRatio; // 0x694(0x04)
	bool AccuracyDebugMode; // 0x698(0x01)
	char UnknownData_699[0x7]; // 0x699(0x07)
	struct FMulticastInlineDelegate OnSwimmingChanged; // 0x6a0(0x10)
	struct FMulticastInlineDelegate HUDMessage; // 0x6b0(0x10)
	struct TMap<struct UUserWidget*, struct FString> WidgetsToAddToHUD; // 0x6c0(0x50)
	struct FMulticastInlineDelegate OnRuleWidgetCreated; // 0x710(0x10)
	struct TArray<struct FAsyncWidgetInfoParams> AsyncWidgetInfos; // 0x720(0x10)
	struct UUserWidget* WatermarkWidget; // 0x730(0x08)
	struct UCINE_Walkin_Widget_C* WalkInWidget; // 0x738(0x08)
	struct FMulticastInlineDelegate OnHUDReady; // 0x740(0x10)

	void FocusFirstFocusableWidget(struct TArray<struct UPUMG_Widget*> PUMG Widgets); // Function BP_GameHUDNew.BP_GameHUDNew_C.FocusFirstFocusableWidget // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GetFocusableWidgets(struct TArray<struct UPUMG_Widget*> FocusableWidgets); // Function BP_GameHUDNew.BP_GameHUDNew_C.GetFocusableWidgets // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	struct UKSContextBarWidget* GetContextBarWidget(); // Function BP_GameHUDNew.BP_GameHUDNew_C.GetContextBarWidget // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void ToggleWatermarkDisplay(bool Show); // Function BP_GameHUDNew.BP_GameHUDNew_C.ToggleWatermarkDisplay // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GetAsyncWidgetsForString(struct FString String, struct TArray<struct UUserWidget*> UserWidgets); // Function BP_GameHUDNew.BP_GameHUDNew_C.GetAsyncWidgetsForString // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetupJobSelectionManager(); // Function BP_GameHUDNew.BP_GameHUDNew_C.SetupJobSelectionManager // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	struct UPUMG_PopupManager* GetPopupManager(); // Function BP_GameHUDNew.BP_GameHUDNew_C.GetPopupManager // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnLoaded_9A584D3E423F982EA7A073A29FBFC2FD(struct UObject* Loaded); // Function BP_GameHUDNew.BP_GameHUDNew_C.OnLoaded_9A584D3E423F982EA7A073A29FBFC2FD // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ReceiveBeginPlay(); // Function BP_GameHUDNew.BP_GameHUDNew_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void HandleReturnToHomeClick(); // Function BP_GameHUDNew.BP_GameHUDNew_C.HandleReturnToHomeClick // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnShowHUD(); // Function BP_GameHUDNew.BP_GameHUDNew_C.OnShowHUD // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnHideHUD(); // Function BP_GameHUDNew.BP_GameHUDNew_C.OnHideHUD // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Spawn Tutorial Widget(); // Function BP_GameHUDNew.BP_GameHUDNew_C.Spawn Tutorial Widget // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnToggleHUD(); // Function BP_GameHUDNew.BP_GameHUDNew_C.OnToggleHUD // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnToggleTopBar(bool ShouldShow); // Function BP_GameHUDNew.BP_GameHUDNew_C.OnToggleTopBar // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetHUDVisible(bool bVisible); // Function BP_GameHUDNew.BP_GameHUDNew_C.SetHUDVisible // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void CreateGameRuleWidget(struct FKSWidgetInfoParams WidgetInfoParams); // Function BP_GameHUDNew.BP_GameHUDNew_C.CreateGameRuleWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BroadcastWidgetMessage(struct FName Message); // Function BP_GameHUDNew.BP_GameHUDNew_C.BroadcastWidgetMessage // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BindEventToWidgetMessages(struct FDelegate Callback); // Function BP_GameHUDNew.BP_GameHUDNew_C.BindEventToWidgetMessages // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleOnPhaseChanged(struct FName NewPhaseName, struct FName PreviousPhaseName); // Function BP_GameHUDNew.BP_GameHUDNew_C.HandleOnPhaseChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleOpenTextChat(bool BeginChatCommand); // Function BP_GameHUDNew.BP_GameHUDNew_C.HandleOpenTextChat // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void DisplayWatermark(); // Function BP_GameHUDNew.BP_GameHUDNew_C.DisplayWatermark // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnAsyncWidgetInfoLoaded(struct UObject* LoadedClass, struct FString ParentWidget, struct AKSWidgetInfoActor* WidgetInfoActor); // Function BP_GameHUDNew.BP_GameHUDNew_C.OnAsyncWidgetInfoLoaded // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OpenTextChatToPlayer(struct UPUMG_PlayerInfo* Player); // Function BP_GameHUDNew.BP_GameHUDNew_C.OpenTextChatToPlayer // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ApplySafeFrameScale(float SafeFrameScale); // Function BP_GameHUDNew.BP_GameHUDNew_C.ApplySafeFrameScale // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void NetworkLagStateChanged(struct UWorld* World, struct UNetDriver* NetDriver, enum class ENetworkLagState LagType); // Function BP_GameHUDNew.BP_GameHUDNew_C.NetworkLagStateChanged // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void SetUIFocus(); // Function BP_GameHUDNew.BP_GameHUDNew_C.SetUIFocus // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Play Cinematic Nameplate Anim(int32_t Index); // Function BP_GameHUDNew.BP_GameHUDNew_C.Play Cinematic Nameplate Anim // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Set Cinematic Nameplate Data(struct UKSPersistentPlayerData* Player Data, int32_t Index); // Function BP_GameHUDNew.BP_GameHUDNew_C.Set Cinematic Nameplate Data // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void EvaluateFocus(); // Function BP_GameHUDNew.BP_GameHUDNew_C.EvaluateFocus // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Init WalkIn Widget(struct AKSJobSelectPreviewActor* In Player 01, struct AKSJobSelectPreviewActor* In Player 02, struct AKSJobSelectPreviewActor* In Player 03, struct AKSJobSelectPreviewActor* In Player 04); // Function BP_GameHUDNew.BP_GameHUDNew_C.Init WalkIn Widget // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_BP_GameHUDNew(int32_t EntryPoint); // Function BP_GameHUDNew.BP_GameHUDNew_C.ExecuteUbergraph_BP_GameHUDNew // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void OnHUDReady__DelegateSignature(); // Function BP_GameHUDNew.BP_GameHUDNew_C.OnHUDReady__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnRuleWidgetCreated__DelegateSignature(struct UUserWidget* UserWidget, struct FString Placement); // Function BP_GameHUDNew.BP_GameHUDNew_C.OnRuleWidgetCreated__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HUDMessage__DelegateSignature(struct FName Message); // Function BP_GameHUDNew.BP_GameHUDNew_C.HUDMessage__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnSwimmingChanged__DelegateSignature(bool IsSwimming); // Function BP_GameHUDNew.BP_GameHUDNew_C.OnSwimmingChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

