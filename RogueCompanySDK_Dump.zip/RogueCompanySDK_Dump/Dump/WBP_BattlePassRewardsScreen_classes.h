// WidgetBlueprintGeneratedClass WBP_BattlePassRewardsScreen.WBP_BattlePassRewardsScreen_C
// Size: 0x558 (Inherited: 0x4e0)
struct UWBP_BattlePassRewardsScreen_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UWidgetAnimation* Outro; // 0x4e8(0x08)
	struct UWidgetAnimation* Intro; // 0x4f0(0x08)
	struct UTextBlock* Countdown; // 0x4f8(0x08)
	struct UImage* Image_221; // 0x500(0x08)
	struct UWBP_ItemPreviewStack_C* ItemPreviewStack; // 0x508(0x08)
	struct UImage* ReflectedgradientShade; // 0x510(0x08)
	struct UWBP_BattlePassLevelPurchase_C* WBP_BattlePassLevelPurchase; // 0x518(0x08)
	struct UWBP_BattlePassTitle_C* WBP_BattlePassTitle; // 0x520(0x08)
	struct UWBP_BattlePassUpsellPanel_C* WBP_BattlePassUpsellPanel; // 0x528(0x08)
	struct UWBP_ItemInfoContainer_Description_C* WBP_ItemInfoContainer_Description; // 0x530(0x08)
	struct UWBP_RewardsTrack_C* WBP_RewardsTrack; // 0x538(0x08)
	struct UKSActivityInstance* ActivityInstance; // 0x540(0x08)
	struct UWBP_RewardListEntry_C* SelectedEntry; // 0x548(0x08)
	struct UPUMG_StoreItem* SelectedData; // 0x550(0x08)

	struct FEventReply OnKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function WBP_BattlePassRewardsScreen.WBP_BattlePassRewardsScreen_C.OnKeyDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleOnLevelPurchase(); // Function WBP_BattlePassRewardsScreen.WBP_BattlePassRewardsScreen_C.HandleOnLevelPurchase // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleOnBattlePassOffers(); // Function WBP_BattlePassRewardsScreen.WBP_BattlePassRewardsScreen_C.HandleOnBattlePassOffers // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleOnPageNavigated(int32_t Direction); // Function WBP_BattlePassRewardsScreen.WBP_BattlePassRewardsScreen_C.HandleOnPageNavigated // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Select Initial Item(); // Function WBP_BattlePassRewardsScreen.WBP_BattlePassRewardsScreen_C.Select Initial Item // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnRewardButtonClicked(struct UWBP_RewardListEntry_C* Widget, struct FCosmeticSlotDetails RewardSlotDetails, struct UPUMG_StoreItem* StoreItem); // Function WBP_BattlePassRewardsScreen.WBP_BattlePassRewardsScreen_C.OnRewardButtonClicked // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	bool NavigateBack(); // Function WBP_BattlePassRewardsScreen.WBP_BattlePassRewardsScreen_C.NavigateBack // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PerformInitialSetup(); // Function WBP_BattlePassRewardsScreen.WBP_BattlePassRewardsScreen_C.PerformInitialSetup // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnShown(); // Function WBP_BattlePassRewardsScreen.WBP_BattlePassRewardsScreen_C.OnShown // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function WBP_BattlePassRewardsScreen.WBP_BattlePassRewardsScreen_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnBackPrompt(); // Function WBP_BattlePassRewardsScreen.WBP_BattlePassRewardsScreen_C.OnBackPrompt // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidgetNavigation(); // Function WBP_BattlePassRewardsScreen.WBP_BattlePassRewardsScreen_C.InitializeWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void FocusGroupNavigateRightFailure(int32_t FocusGroup); // Function WBP_BattlePassRewardsScreen.WBP_BattlePassRewardsScreen_C.FocusGroupNavigateRightFailure // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void FocusGroupNavigateLeftFailure(int32_t FocusGroup); // Function WBP_BattlePassRewardsScreen.WBP_BattlePassRewardsScreen_C.FocusGroupNavigateLeftFailure // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeWidgetButtonListeners(); // Function WBP_BattlePassRewardsScreen.WBP_BattlePassRewardsScreen_C.InitializeWidgetButtonListeners // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnTriggerPageLeft(); // Function WBP_BattlePassRewardsScreen.WBP_BattlePassRewardsScreen_C.OnTriggerPageLeft // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnTriggerPageRight(); // Function WBP_BattlePassRewardsScreen.WBP_BattlePassRewardsScreen_C.OnTriggerPageRight // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnHide(); // Function WBP_BattlePassRewardsScreen.WBP_BattlePassRewardsScreen_C.OnHide // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_BattlePassRewardsScreen(int32_t EntryPoint); // Function WBP_BattlePassRewardsScreen.WBP_BattlePassRewardsScreen_C.ExecuteUbergraph_WBP_BattlePassRewardsScreen // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

