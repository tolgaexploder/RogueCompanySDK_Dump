// WidgetBlueprintGeneratedClass DamageModifierDisplay.DamageModifierDisplay_C
// Size: 0x4f8 (Inherited: 0x4e0)
struct UDamageModifierDisplay_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UBruteStrengthModifierWarning_C* BruteStrengthModifierWarning; // 0x4e8(0x08)
	struct UHorizontalBox* ModifierTray; // 0x4f0(0x08)

	void InitializeWidget(struct APUMG_HUD* HUD); // Function DamageModifierDisplay.DamageModifierDisplay_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_DamageModifierDisplay(int32_t EntryPoint); // Function DamageModifierDisplay.DamageModifierDisplay_C.ExecuteUbergraph_DamageModifierDisplay // (Final|UbergraphFunction) // @ game+0x2587100
};

