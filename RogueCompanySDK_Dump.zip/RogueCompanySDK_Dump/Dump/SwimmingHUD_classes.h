// WidgetBlueprintGeneratedClass SwimmingHUD.SwimmingHUD_C
// Size: 0x520 (Inherited: 0x510)
struct USwimmingHUD_C : UKSViewedPawnWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x510(0x08)
	struct UBreathMeter_C* BreathMeter; // 0x518(0x08)

	void Construct(); // Function SwimmingHUD.SwimmingHUD_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void SwimmingChanged(bool bIsSwimming); // Function SwimmingHUD.SwimmingHUD_C.SwimmingChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PostSetPawn(); // Function SwimmingHUD.SwimmingHUD_C.PostSetPawn // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void PreClearPawn(); // Function SwimmingHUD.SwimmingHUD_C.PreClearPawn // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_SwimmingHUD(int32_t EntryPoint); // Function SwimmingHUD.SwimmingHUD_C.ExecuteUbergraph_SwimmingHUD // (Final|UbergraphFunction) // @ game+0x2587100
};

