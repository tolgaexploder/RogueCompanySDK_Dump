// WidgetBlueprintGeneratedClass GadgetElementWrapper.GadgetElementWrapper_C
// Size: 0x5f0 (Inherited: 0x5a8)
struct UGadgetElementWrapper_C : UKSViewedPawnInventoryWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5a8(0x08)
	struct UOverlay* Overlay_1; // 0x5b0(0x08)
	struct UGadgetCompInventoryElement_C* TrueDisplayElement; // 0x5b8(0x08)
	struct FGameplayTagContainer ValidGameplayTagContainer; // 0x5c0(0x20)
	bool IsInactive; // 0x5e0(0x01)
	char UnknownData_5E1[0x7]; // 0x5e1(0x07)
	struct UKSWeaponComponent* Tracked Gadget; // 0x5e8(0x08)

	void Get Current Cannot Fire Now(bool bCanFireNow); // Function GadgetElementWrapper.GadgetElementWrapper_C.Get Current Cannot Fire Now // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Set Jammed(bool Is Jammed); // Function GadgetElementWrapper.GadgetElementWrapper_C.Set Jammed // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function GadgetElementWrapper.GadgetElementWrapper_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PostSetPawn(); // Function GadgetElementWrapper.GadgetElementWrapper_C.PostSetPawn // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnWeaponInventoryChanged(); // Function GadgetElementWrapper.GadgetElementWrapper_C.OnWeaponInventoryChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GadgetSwapped(struct AKSCharacter* EquipmentOwner, struct UKSWeaponComponent* Equipment); // Function GadgetElementWrapper.GadgetElementWrapper_C.GadgetSwapped // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnSetCannotFireNow(bool bInCannotFire); // Function GadgetElementWrapper.GadgetElementWrapper_C.OnSetCannotFireNow // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Set Tracked Gadget(struct UKSWeaponComponent* New Gadget); // Function GadgetElementWrapper.GadgetElementWrapper_C.Set Tracked Gadget // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Clear Tracked Gadget(); // Function GadgetElementWrapper.GadgetElementWrapper_C.Clear Tracked Gadget // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PreClearPawn(); // Function GadgetElementWrapper.GadgetElementWrapper_C.PreClearPawn // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void GadgetResupplied(); // Function GadgetElementWrapper.GadgetElementWrapper_C.GadgetResupplied // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_GadgetElementWrapper(int32_t EntryPoint); // Function GadgetElementWrapper.GadgetElementWrapper_C.ExecuteUbergraph_GadgetElementWrapper // (Final|UbergraphFunction) // @ game+0x2587100
};

