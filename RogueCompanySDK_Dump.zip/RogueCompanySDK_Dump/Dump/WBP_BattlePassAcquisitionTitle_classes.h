// WidgetBlueprintGeneratedClass WBP_BattlePassAcquisitionTitle.WBP_BattlePassAcquisitionTitle_C
// Size: 0x528 (Inherited: 0x4e0)
struct UWBP_BattlePassAcquisitionTitle_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UTextBlock* BattlePassSeasonName; // 0x4e8(0x08)
	struct UImage* Image; // 0x4f0(0x08)
	struct UImage* Image_183; // 0x4f8(0x08)
	struct UImage* Image_533; // 0x500(0x08)
	struct UTextBlock* TitleText; // 0x508(0x08)
	struct UWidgetSwitcher* TypeSwitcher; // 0x510(0x08)
	struct UTextBlock* UpsellSubtitle; // 0x518(0x08)
	struct UWBP_BattlePassEmblem_C* WBP_BattlePassEmblem; // 0x520(0x08)

	void SetPremiumUpsellState(int32_t PremiumItems); // Function WBP_BattlePassAcquisitionTitle.WBP_BattlePassAcquisitionTitle_C.SetPremiumUpsellState // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWithAcquisition(struct UKSAcquisition* Acquisition); // Function WBP_BattlePassAcquisitionTitle.WBP_BattlePassAcquisitionTitle_C.InitializeWithAcquisition // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function WBP_BattlePassAcquisitionTitle.WBP_BattlePassAcquisitionTitle_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_BattlePassAcquisitionTitle(int32_t EntryPoint); // Function WBP_BattlePassAcquisitionTitle.WBP_BattlePassAcquisitionTitle_C.ExecuteUbergraph_WBP_BattlePassAcquisitionTitle // (Final|UbergraphFunction) // @ game+0x2587100
};

