// WidgetBlueprintGeneratedClass WBP_BattlepassTransitionBanner.WBP_BattlepassTransitionBanner_C
// Size: 0x6c0 (Inherited: 0x4e0)
struct UWBP_BattlepassTransitionBanner_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UWidgetAnimation* NewTierPremium; // 0x4e8(0x08)
	struct UWidgetAnimation* NewTierFree; // 0x4f0(0x08)
	struct UWidgetAnimation* PremiumUnlocked; // 0x4f8(0x08)
	struct UBorder* AreaShimmer_ColorWrapper; // 0x500(0x08)
	struct UImage* AreaShineLeft_2; // 0x508(0x08)
	struct UImage* AreaShineRight_2; // 0x510(0x08)
	struct UImage* Arrow; // 0x518(0x08)
	struct UImage* Arrow_2; // 0x520(0x08)
	struct UImage* Arrow_3; // 0x528(0x08)
	struct UImage* Arrow_4; // 0x530(0x08)
	struct UImage* Arrow_5; // 0x538(0x08)
	struct UImage* Arrow_6; // 0x540(0x08)
	struct UOverlay* BackgroundDecoration; // 0x548(0x08)
	struct UImage* BackgroundFlare; // 0x550(0x08)
	struct UBorder* BackgroundFlare_ColorWrapper; // 0x558(0x08)
	struct UImage* Badge; // 0x560(0x08)
	struct UImage* BadgeShimmer; // 0x568(0x08)
	struct UImage* Bottomtri; // 0x570(0x08)
	struct UImage* CenterGradient; // 0x578(0x08)
	struct UBorder* DiamondBack_ColorWrapper; // 0x580(0x08)
	struct UImage* DiamondBase; // 0x588(0x08)
	struct UImage* DiamondBase_2; // 0x590(0x08)
	struct UImage* DiamondBlur; // 0x598(0x08)
	struct UBorder* DiamondInterior_ColorWrapper; // 0x5a0(0x08)
	struct UImage* EdgeGlow; // 0x5a8(0x08)
	struct UImage* EdgeGlow_2; // 0x5b0(0x08)
	struct UImage* Fill; // 0x5b8(0x08)
	struct UImage* FillShadow; // 0x5c0(0x08)
	struct UImage* Glitch_Center; // 0x5c8(0x08)
	struct UBorder* GlitchCenter_ColorWrapper; // 0x5d0(0x08)
	struct UBorder* GlowBanner_ColorWrapper; // 0x5d8(0x08)
	struct UWBP_AdditiveImage_C* glowLine; // 0x5e0(0x08)
	struct UWBP_AdditiveImage_C* glowLine_3; // 0x5e8(0x08)
	struct UImage* Godrays; // 0x5f0(0x08)
	struct UBorder* IconFlares_ColorWrapper; // 0x5f8(0x08)
	struct UImage* LenseFlare1; // 0x600(0x08)
	struct UBorder* LineShimmer_ColorWrapper; // 0x608(0x08)
	struct UImage* LineShineLeft; // 0x610(0x08)
	struct UImage* LineShineRight; // 0x618(0x08)
	struct UImage* PrimaryBannerShade; // 0x620(0x08)
	struct UTextBlock* PrimaryBannerText; // 0x628(0x08)
	struct UWBP_AdditiveImage_C* Scanlines; // 0x630(0x08)
	struct UWBP_AdditiveImage_C* Scanlines_3; // 0x638(0x08)
	struct UImage* SheenLeft; // 0x640(0x08)
	struct UImage* SheenRight; // 0x648(0x08)
	struct UImage* ShieldLogo; // 0x650(0x08)
	struct UImage* SideDeco_2; // 0x658(0x08)
	struct UImage* SideDeco_3; // 0x660(0x08)
	struct UImage* Stroke; // 0x668(0x08)
	struct UImage* SubtitleBannerShade; // 0x670(0x08)
	struct UTextBlock* SubtitleText; // 0x678(0x08)
	struct UImage* VictoryDefeatGlow; // 0x680(0x08)
	struct UImage* VictoryDefeatGlow_2; // 0x688(0x08)
	struct UImage* VictoryDefeatGlow_Pulse; // 0x690(0x08)
	struct UImage* VictoryDefeatGlow_Pulse_2; // 0x698(0x08)
	struct UWBP_BattlePassEmblem_C* WBP_BattlePassEmblem; // 0x6a0(0x08)
	float TickTime; // 0x6a8(0x04)
	char UnknownData_6AC[0x4]; // 0x6ac(0x04)
	struct FMulticastInlineDelegate TransitionFinished; // 0x6b0(0x10)

	void SequenceEvent__ENTRYPOINTWBP_BattlepassTransitionBanner_2(); // Function WBP_BattlepassTransitionBanner.WBP_BattlepassTransitionBanner_C.SequenceEvent__ENTRYPOINTWBP_BattlepassTransitionBanner_2 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SequenceEvent__ENTRYPOINTWBP_BattlepassTransitionBanner_1(); // Function WBP_BattlepassTransitionBanner.WBP_BattlepassTransitionBanner_C.SequenceEvent__ENTRYPOINTWBP_BattlepassTransitionBanner_1 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void DisplayAcquiredTier(struct UKSAcquisition* Acquisition); // Function WBP_BattlepassTransitionBanner.WBP_BattlepassTransitionBanner_C.DisplayAcquiredTier // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PlayAnimation_PremiumUnlocked(); // Function WBP_BattlepassTransitionBanner.WBP_BattlepassTransitionBanner_C.PlayAnimation_PremiumUnlocked // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PlayAnimation_NewTierPremium(); // Function WBP_BattlepassTransitionBanner.WBP_BattlepassTransitionBanner_C.PlayAnimation_NewTierPremium // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PlayAnimation_NewTierFree(); // Function WBP_BattlepassTransitionBanner.WBP_BattlepassTransitionBanner_C.PlayAnimation_NewTierFree // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateColors_Premium(); // Function WBP_BattlepassTransitionBanner.WBP_BattlepassTransitionBanner_C.UpdateColors_Premium // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateColors_Free(); // Function WBP_BattlepassTransitionBanner.WBP_BattlepassTransitionBanner_C.UpdateColors_Free // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PreConstruct(bool IsDesignTime); // Function WBP_BattlepassTransitionBanner.WBP_BattlepassTransitionBanner_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_BattlepassTransitionBanner.WBP_BattlepassTransitionBanner_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void MakeColorsPremium(); // Function WBP_BattlepassTransitionBanner.WBP_BattlepassTransitionBanner_C.MakeColorsPremium // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetBannerText_NewTier(); // Function WBP_BattlepassTransitionBanner.WBP_BattlepassTransitionBanner_C.SetBannerText_NewTier // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetBannerText_PremiumUnlocked(); // Function WBP_BattlepassTransitionBanner.WBP_BattlepassTransitionBanner_C.SetBannerText_PremiumUnlocked // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void MakeColorsFree(); // Function WBP_BattlepassTransitionBanner.WBP_BattlepassTransitionBanner_C.MakeColorsFree // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnAnimationFinished(struct UWidgetAnimation* Animation); // Function WBP_BattlepassTransitionBanner.WBP_BattlepassTransitionBanner_C.OnAnimationFinished // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnAnimationStarted(struct UWidgetAnimation* Animation); // Function WBP_BattlepassTransitionBanner.WBP_BattlepassTransitionBanner_C.OnAnimationStarted // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x2587100
	void SequenceEvent_1(); // Function WBP_BattlepassTransitionBanner.WBP_BattlepassTransitionBanner_C.SequenceEvent_1 // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function WBP_BattlepassTransitionBanner.WBP_BattlepassTransitionBanner_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_BattlepassTransitionBanner(int32_t EntryPoint); // Function WBP_BattlepassTransitionBanner.WBP_BattlepassTransitionBanner_C.ExecuteUbergraph_WBP_BattlepassTransitionBanner // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void TransitionFinished__DelegateSignature(); // Function WBP_BattlepassTransitionBanner.WBP_BattlepassTransitionBanner_C.TransitionFinished__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

