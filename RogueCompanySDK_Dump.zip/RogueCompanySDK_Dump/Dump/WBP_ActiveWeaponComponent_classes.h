// WidgetBlueprintGeneratedClass WBP_ActiveWeaponComponent.WBP_ActiveWeaponComponent_C
// Size: 0x688 (Inherited: 0x5c8)
struct UWBP_ActiveWeaponComponent_C : UKSLowAmmoAlertWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5c8(0x08)
	struct UWidgetAnimation* LowAmmoWarning; // 0x5d0(0x08)
	struct UWBP_AsyncIcon_C* ActiveWeaponIcon; // 0x5d8(0x08)
	struct UHorizontalBox* AmmoCountWrapper; // 0x5e0(0x08)
	struct USizeBox* AmmoInClipSizeWrapper; // 0x5e8(0x08)
	struct URichTextBlock* AmmoQtyDisplay; // 0x5f0(0x08)
	struct UTextBlock* AmmoReserveText; // 0x5f8(0x08)
	struct UImage* Image_83; // 0x600(0x08)
	struct UWidgetSwitcher* InfiniteAmmoSwitcher; // 0x608(0x08)
	struct UTextBlock* InfiniteClipText; // 0x610(0x08)
	struct UTextBlock* InfiniteReserveText; // 0x618(0x08)
	struct UWidgetSwitcher* ReserveAmmoTextSwitcher; // 0x620(0x08)
	struct USizeBox* ReserveAmmoWrapper; // 0x628(0x08)
	struct UTextBlock* Slash; // 0x630(0x08)
	struct FSlateColor ActiveTextColor; // 0x638(0x28)
	struct FSlateColor InactiveTextColor; // 0x660(0x28)

	void SetAmmoInClipDisplaySize(); // Function WBP_ActiveWeaponComponent.WBP_ActiveWeaponComponent_C.SetAmmoInClipDisplaySize // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetClipCount(); // Function WBP_ActiveWeaponComponent.WBP_ActiveWeaponComponent_C.SetClipCount // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void DetermineLowAmmo(); // Function WBP_ActiveWeaponComponent.WBP_ActiveWeaponComponent_C.DetermineLowAmmo // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnAmmoChange(struct UKSWeaponComponent* WeaponComponent); // Function WBP_ActiveWeaponComponent.WBP_ActiveWeaponComponent_C.OnAmmoChange // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetReserveAmmo(int32_t ReserveAmmo); // Function WBP_ActiveWeaponComponent.WBP_ActiveWeaponComponent_C.SetReserveAmmo // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PostSetActiveWeaponComponent(); // Function WBP_ActiveWeaponComponent.WBP_ActiveWeaponComponent_C.PostSetActiveWeaponComponent // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void PreClearActiveWeaponComponent(); // Function WBP_ActiveWeaponComponent.WBP_ActiveWeaponComponent_C.PreClearActiveWeaponComponent // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function WBP_ActiveWeaponComponent.WBP_ActiveWeaponComponent_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_ActiveWeaponComponent(int32_t EntryPoint); // Function WBP_ActiveWeaponComponent.WBP_ActiveWeaponComponent_C.ExecuteUbergraph_WBP_ActiveWeaponComponent // (Final|UbergraphFunction) // @ game+0x2587100
};

