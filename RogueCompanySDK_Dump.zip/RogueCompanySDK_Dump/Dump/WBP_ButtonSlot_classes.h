// WidgetBlueprintGeneratedClass WBP_ButtonSlot.WBP_ButtonSlot_C
// Size: 0x570 (Inherited: 0x4e0)
struct UWBP_ButtonSlot_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UWidgetAnimation* OnHover; // 0x4e8(0x08)
	struct UImage* background; // 0x4f0(0x08)
	struct UImage* BackgroundDecro; // 0x4f8(0x08)
	struct UNamedSlot* ButtonContent; // 0x500(0x08)
	struct UButton* HitTarget; // 0x508(0x08)
	struct UImage* SelectedBackgroundFill; // 0x510(0x08)
	struct UImage* SelectedFrame; // 0x518(0x08)
	struct UImage* SelectedGradient; // 0x520(0x08)
	struct FMulticastInlineDelegate OnBtnClicked; // 0x528(0x10)
	struct FMulticastInlineDelegate OnBtnHovered; // 0x538(0x10)
	struct FMulticastInlineDelegate OnBtnUnhovered; // 0x548(0x10)
	bool bIsDisable; // 0x558(0x01)
	bool bIsActive; // 0x559(0x01)
	char UnknownData_55A[0x6]; // 0x55a(0x06)
	struct UAkAudioEvent* ClickBtnSlotSFX; // 0x560(0x08)
	struct UAkAudioEvent* HoverBtnSlotSFX; // 0x568(0x08)

	void OnHoveredLogic(bool IsGamepad); // Function WBP_ButtonSlot.WBP_ButtonSlot_C.OnHoveredLogic // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	bool NavigateConfirm(); // Function WBP_ButtonSlot.WBP_ButtonSlot_C.NavigateConfirm // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnClickSound(); // Function WBP_ButtonSlot.WBP_ButtonSlot_C.OnClickSound // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnHoverSound(); // Function WBP_ButtonSlot.WBP_ButtonSlot_C.OnHoverSound // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function WBP_ButtonSlot.WBP_ButtonSlot_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnGamepadConfirmed(); // Function WBP_ButtonSlot.WBP_ButtonSlot_C.OnGamepadConfirmed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_ButtonSlot.WBP_ButtonSlot_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function WBP_ButtonSlot.WBP_ButtonSlot_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature(); // Function WBP_ButtonSlot.WBP_ButtonSlot_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void GamepadHover(); // Function WBP_ButtonSlot.WBP_ButtonSlot_C.GamepadHover // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void GamepadUnhover(); // Function WBP_ButtonSlot.WBP_ButtonSlot_C.GamepadUnhover // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void DisableButton(bool bShouldDisable); // Function WBP_ButtonSlot.WBP_ButtonSlot_C.DisableButton // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void CallButtonHover(); // Function WBP_ButtonSlot.WBP_ButtonSlot_C.CallButtonHover // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void CallButtonUnhover(); // Function WBP_ButtonSlot.WBP_ButtonSlot_C.CallButtonUnhover // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetIsActiveState(bool bIsActive); // Function WBP_ButtonSlot.WBP_ButtonSlot_C.SetIsActiveState // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_ButtonSlot(int32_t EntryPoint); // Function WBP_ButtonSlot.WBP_ButtonSlot_C.ExecuteUbergraph_WBP_ButtonSlot // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void OnBtnUnhovered__DelegateSignature(); // Function WBP_ButtonSlot.WBP_ButtonSlot_C.OnBtnUnhovered__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnBtnHovered__DelegateSignature(bool IsGamepad); // Function WBP_ButtonSlot.WBP_ButtonSlot_C.OnBtnHovered__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnBtnClicked__DelegateSignature(); // Function WBP_ButtonSlot.WBP_ButtonSlot_C.OnBtnClicked__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

