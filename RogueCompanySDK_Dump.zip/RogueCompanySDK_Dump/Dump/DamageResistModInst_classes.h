// BlueprintGeneratedClass DamageResistModInst.DamageResistModInst_C
// Size: 0x190 (Inherited: 0x188)
struct UDamageResistModInst_C : UKSPlayerModInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x188(0x08)

	void OnNewCharacter(); // Function DamageResistModInst.DamageResistModInst_C.OnNewCharacter // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void DamageTaken(struct AActor* DamagedActor, float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function DamageResistModInst.DamageResistModInst_C.DamageTaken // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_DamageResistModInst(int32_t EntryPoint); // Function DamageResistModInst.DamageResistModInst_C.ExecuteUbergraph_DamageResistModInst // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

