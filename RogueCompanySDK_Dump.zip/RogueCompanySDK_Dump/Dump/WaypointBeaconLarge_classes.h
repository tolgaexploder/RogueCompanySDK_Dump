// BlueprintGeneratedClass WaypointBeaconLarge.WaypointBeaconLarge_C
// Size: 0x248 (Inherited: 0x238)
struct AWaypointBeaconLarge_C : AKSPingBeaconBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UParticleSystemComponent* ParticleSystem; // 0x240(0x08)

	void UserConstructionScript(); // Function WaypointBeaconLarge.WaypointBeaconLarge_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ReceiveBeginPlay(); // Function WaypointBeaconLarge.WaypointBeaconLarge_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void SetupBeaconDisplay(); // Function WaypointBeaconLarge.WaypointBeaconLarge_C.SetupBeaconDisplay // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WaypointBeaconLarge(int32_t EntryPoint); // Function WaypointBeaconLarge.WaypointBeaconLarge_C.ExecuteUbergraph_WaypointBeaconLarge // (Final|UbergraphFunction) // @ game+0x2587100
};

