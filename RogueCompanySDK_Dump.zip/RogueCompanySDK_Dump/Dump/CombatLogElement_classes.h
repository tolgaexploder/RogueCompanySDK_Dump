// WidgetBlueprintGeneratedClass CombatLogElement.CombatLogElement_C
// Size: 0x5a0 (Inherited: 0x4f0)
struct UCombatLogElement_C : UKSScreenLogWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4f0(0x08)
	struct UWidgetAnimation* BGTransition; // 0x4f8(0x08)
	struct UWidgetAnimation* FadeOutNew; // 0x500(0x08)
	struct UWidgetAnimation* FadeInNew; // 0x508(0x08)
	struct UImage* ActionIcon; // 0x510(0x08)
	struct USizeBox* ActionIcon_Sizebox; // 0x518(0x08)
	struct UWBP_AsyncIcon_C* DamageWeapon; // 0x520(0x08)
	struct UCanvasPanel* EntryContentWrapper; // 0x528(0x08)
	struct UTextBlock* InfoText; // 0x530(0x08)
	struct UTextBlock* InstigatorName; // 0x538(0x08)
	struct UScaleBox* KillingWeaponScale; // 0x540(0x08)
	struct USizeBox* VerticalSizer; // 0x548(0x08)
	enum class EScreenLogType ScreenLogType; // 0x550(0x01)
	char UnknownData_551[0x7]; // 0x551(0x07)
	struct APlayerState* Instigator; // 0x558(0x08)
	struct APlayerState* Victim; // 0x560(0x08)
	struct UKSItem* ResponsibleWeapon; // 0x568(0x08)
	bool Down; // 0x570(0x01)
	char UnknownData_571[0x7]; // 0x571(0x07)
	struct UKSRadialMenuItem* RadialMenuItem; // 0x578(0x08)
	float VisibleTime; // 0x580(0x04)
	float StandardIconSize; // 0x584(0x04)
	struct UWorldMessages_C* OwningPanel; // 0x588(0x08)
	struct TArray<struct FTimerHandle> TimerHandles; // 0x590(0x10)

	void ClearInfo(); // Function CombatLogElement.CombatLogElement_C.ClearInfo // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnSetInfo(); // Function CombatLogElement.CombatLogElement_C.OnSetInfo // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetMessageData(struct FScreenLogData MessageData, struct UCombatLogElement_C* CombatLogElement); // Function CombatLogElement.CombatLogElement_C.SetMessageData // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GetVictimTextColor(struct FSlateColor Color); // Function CombatLogElement.CombatLogElement_C.GetVictimTextColor // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void GetInstigatorTextColor(struct FSlateColor Color); // Function CombatLogElement.CombatLogElement_C.GetInstigatorTextColor // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void OnIconUpdated(struct UTexture2D* Texture); // Function CombatLogElement.CombatLogElement_C.OnIconUpdated // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Transition(); // Function CombatLogElement.CombatLogElement_C.Transition // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnIconUpdated_Event_1(struct UTexture2D* Texture); // Function CombatLogElement.CombatLogElement_C.OnIconUpdated_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnFadeOutAnimFinished(); // Function CombatLogElement.CombatLogElement_C.OnFadeOutAnimFinished // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function CombatLogElement.CombatLogElement_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void FadeOut(); // Function CombatLogElement.CombatLogElement_C.FadeOut // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void StopAnimsAndTimers(); // Function CombatLogElement.CombatLogElement_C.StopAnimsAndTimers // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_CombatLogElement(int32_t EntryPoint); // Function CombatLogElement.CombatLogElement_C.ExecuteUbergraph_CombatLogElement // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

