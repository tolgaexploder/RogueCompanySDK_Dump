// ScriptStruct GeometryCache.TrackRenderData
// Size: 0x70 (Inherited: 0x00)
struct FTrackRenderData {
	char UnknownData_0[0x70]; // 0x00(0x70)
};

// ScriptStruct GeometryCache.GeometryCacheMeshData
// Size: 0xa8 (Inherited: 0x00)
struct FGeometryCacheMeshData {
	char UnknownData_0[0xa8]; // 0x00(0xa8)
};

// ScriptStruct GeometryCache.GeometryCacheVertexInfo
// Size: 0x08 (Inherited: 0x00)
struct FGeometryCacheVertexInfo {
	char UnknownData_0[0x8]; // 0x00(0x08)
};

// ScriptStruct GeometryCache.GeometryCacheMeshBatchInfo
// Size: 0x0c (Inherited: 0x00)
struct FGeometryCacheMeshBatchInfo {
	char UnknownData_0[0xc]; // 0x00(0x0c)
};

