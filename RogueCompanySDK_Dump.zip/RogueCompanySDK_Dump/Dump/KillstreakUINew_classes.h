// Class KillstreakUINew.GuidedMenuCalloutData
// Size: 0x50 (Inherited: 0x28)
struct UGuidedMenuCalloutData : UObject {
	struct FText HeaderText; // 0x28(0x18)
	struct TArray<struct FGuidedCalloutCardData> CalloutCards; // 0x40(0x10)
};

// Class KillstreakUINew.GuidedMenuCalloutsViewRedirector
// Size: 0x38 (Inherited: 0x28)
struct UGuidedMenuCalloutsViewRedirector : UPUMG_ViewRedirecter {
	struct UDataTable* GuidedCalloutsTable; // 0x28(0x08)
	char UnknownData_30[0x8]; // 0x30(0x08)

	void SetNPEGuidedCalloutSeen(enum class EConfigPropertyGuidedCalloutScenes GuidedCalloutScene); // Function KillstreakUINew.GuidedMenuCalloutsViewRedirector.SetNPEGuidedCalloutSeen // (Final|Native|Public) // @ game+0x21f3fb0
	bool HasSeenNPEGuidedCallout(enum class EConfigPropertyGuidedCalloutScenes GuidedCalloutScene); // Function KillstreakUINew.GuidedMenuCalloutsViewRedirector.HasSeenNPEGuidedCallout // (Final|Native|Public) // @ game+0x21f34f0
};

// Class KillstreakUINew.KSWidget
// Size: 0x4e0 (Inherited: 0x4a0)
struct UKSWidget : UPUMG_Widget {
	bool bIsUIOnlyWidget; // 0x4a0(0x01)
	bool bIsExclusiveMenuWidget; // 0x4a1(0x01)
	char UnknownData_4A2[0x6]; // 0x4a2(0x06)
	struct UTickAnimationManager* TickAnimations; // 0x4a8(0x08)
	struct FDelegate ViewportEvent; // 0x4b0(0x10)
	bool bSubstituteKillCamWorld; // 0x4c0(0x01)
	bool bSubstituteKillCamOwningPlayer; // 0x4c1(0x01)
	bool bWantsKillCamCallbacks; // 0x4c2(0x01)
	char UnknownData_4C3[0x1d]; // 0x4c3(0x1d)

	void UnbindFromViewportSizeChange(); // Function KillstreakUINew.KSWidget.UnbindFromViewportSizeChange // (Final|Native|Public|BlueprintCallable) // @ game+0x223f150
	void TriggerGlobalInvalidate(); // Function KillstreakUINew.KSWidget.TriggerGlobalInvalidate // (Final|Native|Public|BlueprintCallable) // @ game+0x223f130
	void StopTickAnimation(struct FName AnimName); // Function KillstreakUINew.KSWidget.StopTickAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0x223f0b0
	void SkipToEndTickAnimation(struct FName AnimName); // Function KillstreakUINew.KSWidget.SkipToEndTickAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0x223f030
	void SetAllAnimationsPlaybackSpeed(float PlaybackSpeed); // Function KillstreakUINew.KSWidget.SetAllAnimationsPlaybackSpeed // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x223eae0
	void ResumeTickAnimation(struct FName AnimName); // Function KillstreakUINew.KSWidget.ResumeTickAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0x223ea60
	void RemoveTickAnimation(struct FName AnimName); // Function KillstreakUINew.KSWidget.RemoveTickAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0x223e9e0
	void PlayTickAnimation(struct FName AnimName); // Function KillstreakUINew.KSWidget.PlayTickAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0x223e850
	void PauseTickAnimation(struct FName AnimName); // Function KillstreakUINew.KSWidget.PauseTickAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0x223e7d0
	bool IsInKillCamPlayback(); // Function KillstreakUINew.KSWidget.IsInKillCamPlayback // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x223e250
	void InitializeTickAnimations(); // Function KillstreakUINew.KSWidget.InitializeTickAnimations // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	bool GetTickAnimationInfo(struct FName AnimName, struct FTickAnimationParams OutAnimParams); // Function KillstreakUINew.KSWidget.GetTickAnimationInfo // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x223dc80
	struct APlayerController* GetNormalOwningPlayer(); // Function KillstreakUINew.KSWidget.GetNormalOwningPlayer // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x223d9e0
	struct APlayerController* GetKillCamSpectatorController(); // Function KillstreakUINew.KSWidget.GetKillCamSpectatorController // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x20a0530
	struct APlayerController* GetActivePlayerController(); // Function KillstreakUINew.KSWidget.GetActivePlayerController // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x223d920
	void BlueprintPrepareKillCamPlayback(); // Function KillstreakUINew.KSWidget.BlueprintPrepareKillCamPlayback // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void BlueprintFinishKillCamPlayback(); // Function KillstreakUINew.KSWidget.BlueprintFinishKillCamPlayback // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void BindToViewportSizeChange(struct FDelegate InViewportEvent); // Function KillstreakUINew.KSWidget.BindToViewportSizeChange // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x223d830
	void AddTickAnimation(struct FName AnimName, float Duration, struct FDelegate UpdateEvent, struct FDelegate FinishedEvent); // Function KillstreakUINew.KSWidget.AddTickAnimation // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x223d6a0
};

// Class KillstreakUINew.KSAccoladeQueueWidget
// Size: 0x530 (Inherited: 0x4e0)
struct UKSAccoladeQueueWidget : UKSWidget {
	bool IsBusy; // 0x4e0(0x01)
	char UnknownData_4E1[0x3]; // 0x4e1(0x03)
	int32_t NumInQueue; // 0x4e4(0x04)
	struct FMulticastInlineDelegate OnAccoladeReceived; // 0x4e8(0x10)
	struct FMulticastInlineDelegate OnAccoladeUpdateMultiplier; // 0x4f8(0x10)
	char UnknownData_508[0x28]; // 0x508(0x28)

	void Queue(struct TArray<struct FAccoladeEventEntry> Accolades); // Function KillstreakUINew.KSAccoladeQueueWidget.Queue // (Final|Native|Protected|BlueprintCallable) // @ game+0x21f39e0
	void OnAccoladeRemovedFromScreen(struct FAccoladeDisplayInfo AccoladeRemoved); // Function KillstreakUINew.KSAccoladeQueueWidget.OnAccoladeRemovedFromScreen // (Final|Native|Protected|BlueprintCallable) // @ game+0x21f3660
	bool GetNext(struct FAccoladeDisplayInfo Accolade); // Function KillstreakUINew.KSAccoladeQueueWidget.GetNext // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x21f2710
	void ClearAccoladeQueue(); // Function KillstreakUINew.KSAccoladeQueueWidget.ClearAccoladeQueue // (Final|Native|Protected|BlueprintCallable) // @ game+0x21f21c0
};

// Class KillstreakUINew.KSAcquisitionModal
// Size: 0x4e0 (Inherited: 0x4e0)
struct UKSAcquisitionModal : UKSWidget {

	void SetupBindings(); // Function KillstreakUINew.KSAcquisitionModal.SetupBindings // (Final|Native|Public|BlueprintCallable) // @ game+0x21f4050
	void HandleShowAcquisitionModal(struct UPUMG_StoreItem* pItem); // Function KillstreakUINew.KSAcquisitionModal.HandleShowAcquisitionModal // (Native|Event|Public|BlueprintEvent) // @ game+0x21f33e0
	struct UPUMG_AcquisitionManager* GetAcquisitionManager(); // Function KillstreakUINew.KSAcquisitionModal.GetAcquisitionManager // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x21f2440
};

// Class KillstreakUINew.KSActiveBonusesWidget
// Size: 0x4e8 (Inherited: 0x4e0)
struct UKSActiveBonusesWidget : UKSWidget {
	struct UDataTable* EventLookupTable; // 0x4e0(0x08)

	void GetBonusAppliedToLastMatch(struct TArray<struct FKSLimitedTimeEventMetadataRow> ActiveEvents); // Function KillstreakUINew.KSActiveBonusesWidget.GetBonusAppliedToLastMatch // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x21f2580
};

// Class KillstreakUINew.KSPawnWidget
// Size: 0x500 (Inherited: 0x4e0)
struct UKSPawnWidget : UKSWidget {
	char UnknownData_4E0[0x20]; // 0x4e0(0x20)

	void SetPlayerStateUIRelevanceChanged(); // Function KillstreakUINew.KSPawnWidget.SetPlayerStateUIRelevanceChanged // (Native|Event|Protected|BlueprintEvent) // @ game+0x20a1de0
	void SetPawn(struct AKSCharacter* NewPawn); // Function KillstreakUINew.KSPawnWidget.SetPawn // (Final|Native|Public|BlueprintCallable) // @ game+0x2212da0
	void PreClearPlayerState(); // Function KillstreakUINew.KSPawnWidget.PreClearPlayerState // (Native|Event|Protected|BlueprintEvent) // @ game+0x220e280
	void PreClearPawn(); // Function KillstreakUINew.KSPawnWidget.PreClearPawn // (Native|Event|Protected|BlueprintEvent) // @ game+0x21f4090
	void PostSetPlayerState(); // Function KillstreakUINew.KSPawnWidget.PostSetPlayerState // (Native|Event|Protected|BlueprintEvent) // @ game+0x19dbee0
	void PostSetPawn(); // Function KillstreakUINew.KSPawnWidget.PostSetPawn // (Native|Event|Protected|BlueprintEvent) // @ game+0x21f40b0
	void OnBoundPlayerStateDestroyed(struct AActor* DestroyedActor); // Function KillstreakUINew.KSPawnWidget.OnBoundPlayerStateDestroyed // (Final|Native|Protected) // @ game+0x2212880
	void OnBoundPawnDestroyed(struct AActor* DestroyedActor); // Function KillstreakUINew.KSPawnWidget.OnBoundPawnDestroyed // (Final|Native|Protected) // @ game+0x2212800
	struct AKSPlayerState* GetPlayerState(); // Function KillstreakUINew.KSPawnWidget.GetPlayerState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2211be0
	struct AKSCharacterBase* GetPawnBase(); // Function KillstreakUINew.KSPawnWidget.GetPawnBase // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2211b00
	struct AKSCharacter* GetPawn(); // Function KillstreakUINew.KSPawnWidget.GetPawn // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2211ac0
};

// Class KillstreakUINew.KSPawnInventoryWidget
// Size: 0x570 (Inherited: 0x500)
struct UKSPawnInventoryWidget : UKSPawnWidget {
	struct TMap<struct FKSEquipmentId, struct UKSWeaponComponentWidget*> EquipmentWidgets; // 0x500(0x50)
	char UnknownData_550[0x20]; // 0x550(0x20)

	bool RemoveWidgetFor(struct UKSWeaponComponent* InWeaponComponent); // Function KillstreakUINew.KSPawnInventoryWidget.RemoveWidgetFor // (Final|Native|Protected|BlueprintCallable) // @ game+0x2212b30
	struct UKSWeaponComponentWidget* GetWidgetForWeaponComponent(struct UKSWeaponComponent* InWeaponComponent); // Function KillstreakUINew.KSPawnInventoryWidget.GetWidgetForWeaponComponent // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2211ec0
	void EquipmentRemoved(struct UKSWeaponComponent* RemovedEquipment); // Function KillstreakUINew.KSPawnInventoryWidget.EquipmentRemoved // (Native|Event|Protected|BlueprintEvent) // @ game+0x2211450
	void EquipmentEndActive(struct UKSWeaponComponent* InactiveEquipment); // Function KillstreakUINew.KSPawnInventoryWidget.EquipmentEndActive // (Native|Event|Protected|BlueprintEvent) // @ game+0x2139140
	void EquipmentBecomeActive(struct UKSWeaponComponent* ActiveEquipment); // Function KillstreakUINew.KSPawnInventoryWidget.EquipmentBecomeActive // (Native|Event|Protected|BlueprintEvent) // @ game+0x22113c0
	void EquipmentAdded(struct UKSWeaponComponent* AddedEquipment); // Function KillstreakUINew.KSPawnInventoryWidget.EquipmentAdded // (Native|Event|Protected|BlueprintEvent) // @ game+0x2211330
	struct UKSWeaponComponentWidget* CreateWeaponComponentWidgetFor(struct UObject* WorldContextObject, struct UKSWeaponComponent* InWeaponComponent, struct UKSWeaponComponentWidget* WidgetClass, struct APlayerController* OwningPlayer); // Function KillstreakUINew.KSPawnInventoryWidget.CreateWeaponComponentWidgetFor // (Final|Native|Protected|BlueprintCallable) // @ game+0x22111e0
};

// Class KillstreakUINew.KSActiveWeaponComponentWidget
// Size: 0x5a8 (Inherited: 0x570)
struct UKSActiveWeaponComponentWidget : UKSPawnInventoryWidget {
	int32_t ActiveWeaponSlot; // 0x570(0x04)
	char UnknownData_574[0x4]; // 0x574(0x04)
	struct FGameplayTagContainer EquipPointsToIgnore; // 0x578(0x20)
	bool bDelayClearUntilNextTick; // 0x598(0x01)
	char UnknownData_599[0x3]; // 0x599(0x03)
	struct FWeakObjectPtr<struct UKSWeaponComponent> WeakActiveWeaponComponentPtr; // 0x59c(0x08)
	char UnknownData_5A4[0x4]; // 0x5a4(0x04)

	void PreClearActiveWeaponComponent(); // Function KillstreakUINew.KSActiveWeaponComponentWidget.PreClearActiveWeaponComponent // (Native|Event|Protected|BlueprintEvent) // @ game+0x21f39c0
	void PostSetActiveWeaponComponent(); // Function KillstreakUINew.KSActiveWeaponComponentWidget.PostSetActiveWeaponComponent // (Native|Event|Protected|BlueprintEvent) // @ game+0x21f39a0
	struct UKSWeaponComponent* GetActiveWeaponComponent(); // Function KillstreakUINew.KSActiveWeaponComponentWidget.GetActiveWeaponComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21f2470
};

// Class KillstreakUINew.KSActivity_ViewRedirector
// Size: 0x38 (Inherited: 0x28)
struct UKSActivity_ViewRedirector : UPUMG_ViewRedirecter {
	struct TArray<struct TSoftObjectPtr<struct UKSActivity>> ActivitiesToCheck; // 0x28(0x10)

	struct UKSActivityManagerBase* GetRelevantActivityManager(struct UKSGameInstance* GameInstance); // Function KillstreakUINew.KSActivity_ViewRedirector.GetRelevantActivityManager // (Native|Event|Protected|BlueprintEvent|Const) // @ game+0x21f2c70
};

// Class KillstreakUINew.KSAimAssistDebugWidget
// Size: 0x240 (Inherited: 0x238)
struct UKSAimAssistDebugWidget : UUserWidget {
	bool bDrawAimAssistBoundary; // 0x238(0x01)
	bool bDrawHeadAimCorrectionBoundary; // 0x239(0x01)
	bool bDrawMagnetismDebug; // 0x23a(0x01)
	bool bDrawTargetInfo; // 0x23b(0x01)
	char UnknownData_23C[0x4]; // 0x23c(0x04)

	struct AKSPlayerController* GetOwningKSPlayer(); // Function KillstreakUINew.KSAimAssistDebugWidget.GetOwningKSPlayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21f2960
	struct UKSAimAssistComponent* GetAimAssistComponent(); // Function KillstreakUINew.KSAimAssistDebugWidget.GetAimAssistComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21f24b0
};

// Class KillstreakUINew.KSMapIconWidgetBase
// Size: 0x318 (Inherited: 0x238)
struct UKSMapIconWidgetBase : UUserWidget {
	bool bDoesIconRotate; // 0x238(0x01)
	char UnknownData_239[0x3]; // 0x239(0x03)
	float MarkerAnchorHeight; // 0x23c(0x04)
	float HeightThreshold; // 0x240(0x04)
	char UnknownData_244[0x4]; // 0x244(0x04)
	float CachedRawMetersAway; // 0x248(0x04)
	int32_t UniqueId; // 0x24c(0x04)
	struct FWeakObjectPtr<struct AKSPlayerState> CreatingPlayer; // 0x250(0x08)
	enum class EDisplayType ParentMapDisplayType; // 0x258(0x01)
	char UnknownData_259[0x3]; // 0x259(0x03)
	struct FWeakObjectPtr<struct AActor> AssociatedActor; // 0x25c(0x08)
	struct FWeakObjectPtr<struct UObject> AssociatedObject; // 0x264(0x08)
	struct FVector DefaultLocation; // 0x26c(0x0c)
	float Lifespan; // 0x278(0x04)
	struct FWeakObjectPtr<struct UKSMapWidgetBase> ParentMapWidget; // 0x27c(0x08)
	struct FVector2D ScreenMargins; // 0x284(0x08)
	float CenterPercentageWidth; // 0x28c(0x04)
	float CenterPercentageHeight; // 0x290(0x04)
	float OpacityWhenAiming; // 0x294(0x04)
	bool DoesFadeOutWhenAiming; // 0x298(0x01)
	char UnknownData_299[0x3]; // 0x299(0x03)
	float AimTransitionOpacity; // 0x29c(0x04)
	struct FVector IconOffset; // 0x2a0(0x0c)
	char UnknownData_2AC[0x18]; // 0x2ac(0x18)
	float HoverDelaySeconds; // 0x2c4(0x04)
	char UnknownData_2C8[0x18]; // 0x2c8(0x18)
	struct FMulticastInlineDelegate OnMapIconWidgetReady; // 0x2e0(0x10)
	struct FMulticastInlineDelegate OnMapIconWidgetRemove; // 0x2f0(0x10)
	bool bIsWidgetPool; // 0x300(0x01)
	char UnknownData_301[0x7]; // 0x301(0x07)
	struct FString WidgetPoolName; // 0x308(0x10)

	void UpdateScreenRegion(); // Function KillstreakUINew.KSMapIconWidgetBase.UpdateScreenRegion // (Final|Native|Public|BlueprintCallable) // @ game+0x2209920
	void UpdateOpacityWhenAiming(); // Function KillstreakUINew.KSMapIconWidgetBase.UpdateOpacityWhenAiming // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x89f050
	void UpdateMetersAway(int32_t Meters); // Function KillstreakUINew.KSMapIconWidgetBase.UpdateMetersAway // (Native|Event|Public|BlueprintEvent) // @ game+0x2209860
	void UpdateMeetsHeightThreshold(bool bHeight, bool bDepth); // Function KillstreakUINew.KSMapIconWidgetBase.UpdateMeetsHeightThreshold // (Native|Event|Public|BlueprintEvent) // @ game+0x2209790
	enum class ESlateVisibility Update(); // Function KillstreakUINew.KSMapIconWidgetBase.Update // (Native|Event|Public|BlueprintEvent) // @ game+0x89f020
	bool ShouldUpdateOpacityWhenAiming(); // Function KillstreakUINew.KSMapIconWidgetBase.ShouldUpdateOpacityWhenAiming // (Native|Event|Public|BlueprintEvent) // @ game+0x89f070
	bool ShouldUpdateHover(); // Function KillstreakUINew.KSMapIconWidgetBase.ShouldUpdateHover // (Native|Event|Public|BlueprintEvent) // @ game+0x22095a0
	bool ShouldUpdate(); // Function KillstreakUINew.KSMapIconWidgetBase.ShouldUpdate // (Native|Event|Public|BlueprintEvent) // @ game+0x2209570
	void SetScreenRegion(enum class EIconMarkerScreenRegion ScreenRegion); // Function KillstreakUINew.KSMapIconWidgetBase.SetScreenRegion // (Native|Event|Public|BlueprintEvent) // @ game+0x22094d0
	void SetLifeSpan(float InLifespan); // Function KillstreakUINew.KSMapIconWidgetBase.SetLifeSpan // (Final|Native|Public|BlueprintCallable) // @ game+0x22093c0
	void SetDisplayInfo(int32_t InUniqueId, struct AKSPlayerState* InCreatingPlayer, enum class EDisplayType InParentMapDisplayType, struct AActor* InAssociatedActor, struct UObject* InAssociatedObject, struct FVector InDefaultLocation, float InLifespan); // Function KillstreakUINew.KSMapIconWidgetBase.SetDisplayInfo // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x22091b0
	void SetArrowAngle(float Angle); // Function KillstreakUINew.KSMapIconWidgetBase.SetArrowAngle // (Native|Event|Public|BlueprintEvent) // @ game+0x2208e20
	void ResetDisplayInfo(); // Function KillstreakUINew.KSMapIconWidgetBase.ResetDisplayInfo // (Native|Public) // @ game+0x7ba320
	void OnUnhoverTimerComplete(); // Function KillstreakUINew.KSMapIconWidgetBase.OnUnhoverTimerComplete // (Final|Native|Private) // @ game+0x2208c30
	void OnHoverTimerComplete(); // Function KillstreakUINew.KSMapIconWidgetBase.OnHoverTimerComplete // (Final|Native|Private) // @ game+0x2208a90
	void OnHoverStateChanged(enum class EIconHoverState NewHoverState); // Function KillstreakUINew.KSMapIconWidgetBase.OnHoverStateChanged // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnAssociatedActorDestroyed(struct AActor* Actor); // Function KillstreakUINew.KSMapIconWidgetBase.OnAssociatedActorDestroyed // (Final|Native|Private) // @ game+0x2208990
	void OnAimStateChanged(enum class EKSCharacterAimMode NewAimState, float NewAimTransitionOffset); // Function KillstreakUINew.KSMapIconWidgetBase.OnAimStateChanged // (Native|Event|Public|BlueprintEvent) // @ game+0x22088d0
	void IsScreenRegion(bool InsideCenter, bool InsideMargins); // Function KillstreakUINew.KSMapIconWidgetBase.IsScreenRegion // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x22087f0
	bool IsInCenteredScreenRect(float PositionX, float PositionY, float XMargin, float YMargin); // Function KillstreakUINew.KSMapIconWidgetBase.IsInCenteredScreenRect // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2208610
	bool IsHovering(); // Function KillstreakUINew.KSMapIconWidgetBase.IsHovering // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x89eff0
	void HandleMapIconWidgetHide(); // Function KillstreakUINew.KSMapIconWidgetBase.HandleMapIconWidgetHide // (Final|Native|Private) // @ game+0x2208570
	float GetWorldYaw(); // Function KillstreakUINew.KSMapIconWidgetBase.GetWorldYaw // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2208200
	struct FVector GetWorldPosition(); // Function KillstreakUINew.KSMapIconWidgetBase.GetWorldPosition // (Native|Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x22081c0
	enum class EIconHoverState GetHoverState(); // Function KillstreakUINew.KSMapIconWidgetBase.GetHoverState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2207f00
	float GetEdgeArrowAngleBase(float Angle); // Function KillstreakUINew.KSMapIconWidgetBase.GetEdgeArrowAngleBase // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2207e70
	float GetDistanceToIcon(); // Function KillstreakUINew.KSMapIconWidgetBase.GetDistanceToIcon // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2207da0
	void GetArrowPosition(bool IsIconVisible, float Angle, struct FVector2D ArrowPosition); // Function KillstreakUINew.KSMapIconWidgetBase.GetArrowPosition // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x2207c10
};

// Class KillstreakUINew.KSAllyMarkerWidget
// Size: 0x370 (Inherited: 0x318)
struct UKSAllyMarkerWidget : UKSMapIconWidgetBase {
	struct UWidget* ArrowWidget; // 0x318(0x08)
	struct UWidget* NameOrStatusWidget; // 0x320(0x08)
	struct UWidget* DownedSectionWidget; // 0x328(0x08)
	struct FMulticastInlineDelegate OnGameModeModActivationChanged; // 0x330(0x10)
	struct UDataTable* ContextualPingTypesDT; // 0x340(0x08)
	struct UDataTable* ContextualPingMessagesDT; // 0x348(0x08)
	char UnknownData_350[0x20]; // 0x350(0x20)

	void View_SetSelfPingIcon(enum class EPingType PingType, enum class EPingMessage PingMessage); // Function KillstreakUINew.KSAllyMarkerWidget.View_SetSelfPingIcon // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void View_SetRevivePercent(float PercentValue); // Function KillstreakUINew.KSAllyMarkerWidget.View_SetRevivePercent // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void View_SetNameText(struct FText NameText); // Function KillstreakUINew.KSAllyMarkerWidget.View_SetNameText // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x2587100
	void View_SetMode(enum class EAllyMarkerState AllyMarkerState, bool HasObjective, bool HasSelfPing); // Function KillstreakUINew.KSAllyMarkerWidget.View_SetMode // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void View_SetJob(struct UKSJobItem* Job); // Function KillstreakUINew.KSAllyMarkerWidget.View_SetJob // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void View_SetHealthPercent(float PercentValue); // Function KillstreakUINew.KSAllyMarkerWidget.View_SetHealthPercent // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void View_AcknowledgeSelfPing(struct AKSPlayerState* AcknowledingPlayer); // Function KillstreakUINew.KSAllyMarkerWidget.View_AcknowledgeSelfPing // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void SetPlayerName(); // Function KillstreakUINew.KSAllyMarkerWidget.SetPlayerName // (Final|Native|Protected) // @ game+0x21f4030
	void SetMarkerPlayerState(struct AKSPlayerState* pPlayerState); // Function KillstreakUINew.KSAllyMarkerWidget.SetMarkerPlayerState // (Final|Native|Public|BlueprintCallable) // @ game+0x21f3eb0
	bool IsOwningPlayer(); // Function KillstreakUINew.KSAllyMarkerWidget.IsOwningPlayer // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x21f3580
	void HandleUIRelevantChanged(struct AKSPlayerState* InPlayerState); // Function KillstreakUINew.KSAllyMarkerWidget.HandleUIRelevantChanged // (Final|Native|Protected) // @ game+0x21f3470
	void HandleRemoveSelfPing(struct AKSPlayerState* PingingPlayer); // Function KillstreakUINew.KSAllyMarkerWidget.HandleRemoveSelfPing // (Final|Native|Protected) // @ game+0x21f3360
	void HandlePlayerModActivated(struct UKSPlayerMod_Activated* ActivatedMod, bool Active); // Function KillstreakUINew.KSAllyMarkerWidget.HandlePlayerModActivated // (Final|Native|Protected) // @ game+0x21f3290
	void HandlePlayerDown(struct FCombatEventInfo CombatEventInfo, int32_t ExpBonus); // Function KillstreakUINew.KSAllyMarkerWidget.HandlePlayerDown // (Final|Native|Protected) // @ game+0x21f3150
	void HandlePlayerDeath(struct FCombatEventInfo DeathInfo); // Function KillstreakUINew.KSAllyMarkerWidget.HandlePlayerDeath // (Final|Native|Protected) // @ game+0x21f3040
	void HandleOnJobChanged(); // Function KillstreakUINew.KSAllyMarkerWidget.HandleOnJobChanged // (Final|Native|Protected) // @ game+0x21f3020
	void HandleObjectiveStateChanged(struct TScriptInterface<None> GameObjective); // Function KillstreakUINew.KSAllyMarkerWidget.HandleObjectiveStateChanged // (Final|Native|Protected) // @ game+0x21f2f80
	void HandleChangeSelfPing(struct AKSPlayerState* PingingPlayer, struct AKSPlayerState* AcknowledgingPlayer); // Function KillstreakUINew.KSAllyMarkerWidget.HandleChangeSelfPing // (Final|Native|Protected) // @ game+0x21f2ec0
	void HandleBombStateChanged(struct FKSNeutralBombState BombState); // Function KillstreakUINew.KSAllyMarkerWidget.HandleBombStateChanged // (Final|Native|Protected) // @ game+0x21f2e10
	void HandleAddSelfPing(struct AKSPlayerState* PingingPlayer, enum class EPingType PingType, enum class EPingMessage PingMessage); // Function KillstreakUINew.KSAllyMarkerWidget.HandleAddSelfPing // (Final|Native|Protected) // @ game+0x21f2d10
	bool GetPingIconByType(enum class EPingType PingType, struct TSoftObjectPtr<struct UTexture2D> PingIcon); // Function KillstreakUINew.KSAllyMarkerWidget.GetPingIconByType // (Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x21f2b70
	bool GetPingIconByMessage(enum class EPingMessage PingMessage, struct TSoftObjectPtr<struct UTexture2D> PingIcon); // Function KillstreakUINew.KSAllyMarkerWidget.GetPingIconByMessage // (Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x21f2a70
	bool GetPingColorByType(enum class EPingType PingType, struct FLinearColor PingColor); // Function KillstreakUINew.KSAllyMarkerWidget.GetPingColorByType // (Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x21f2990
	struct FVector2D GetArrowPositionFromAngleBlueprint(float Angle); // Function KillstreakUINew.KSAllyMarkerWidget.GetArrowPositionFromAngleBlueprint // (Native|Event|Protected|HasDefaults|BlueprintEvent) // @ game+0x21f24e0
	bool FindRowByType(enum class EPingType PingType, struct FContextualPingTypesRow ContextualPingTypesRow); // Function KillstreakUINew.KSAllyMarkerWidget.FindRowByType // (Final|Native|Protected|HasOutParms|Const) // @ game+0x21f2320
	bool FindRowByMessage(enum class EPingMessage PingMessage, struct FContextualPingMessagesRow ContextualPingMessagesRow); // Function KillstreakUINew.KSAllyMarkerWidget.FindRowByMessage // (Final|Native|Protected|HasOutParms|Const) // @ game+0x21f2200
	void ChangeOwnerContentVisibility(bool bVisible); // Function KillstreakUINew.KSAllyMarkerWidget.ChangeOwnerContentVisibility // (Event|Protected|BlueprintEvent) // @ game+0x2587100
};

// Class KillstreakUINew.KSAlphaDisclaimer
// Size: 0x4e0 (Inherited: 0x4e0)
struct UKSAlphaDisclaimer : UKSWidget {

	bool LoadAlphaDisclaimerText(struct FString SaveText); // Function KillstreakUINew.KSAlphaDisclaimer.LoadAlphaDisclaimerText // (Final|Native|Static|Protected|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x21f35b0
};

// Class KillstreakUINew.KSWeaponWidget
// Size: 0x4e8 (Inherited: 0x4e0)
struct UKSWeaponWidget : UKSWidget {
	char UnknownData_4E0[0x8]; // 0x4e0(0x08)

	void SetOwningWeapon(struct AKSWeapon* InWeapon); // Function KillstreakUINew.KSWeaponWidget.SetOwningWeapon // (Final|Native|Public|BlueprintCallable) // @ game+0x223ef30
	void PreClearWeapon(); // Function KillstreakUINew.KSWeaponWidget.PreClearWeapon // (Native|Event|Protected|BlueprintEvent) // @ game+0x220e280
	void PostSetWeapon(); // Function KillstreakUINew.KSWeaponWidget.PostSetWeapon // (Native|Event|Protected|BlueprintEvent) // @ game+0x19dbee0
	void OtherWeaponUpdate(); // Function KillstreakUINew.KSWeaponWidget.OtherWeaponUpdate // (Native|Event|Protected|BlueprintEvent) // @ game+0x20a1de0
	void OnOwningWeaponDestroyed(struct AActor* DestroyedWeapon); // Function KillstreakUINew.KSWeaponWidget.OnOwningWeaponDestroyed // (Final|Native|Protected) // @ game+0x223e530
	struct AKSWeapon* GetOwningWeapon(); // Function KillstreakUINew.KSWeaponWidget.GetOwningWeapon // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2211ac0
};

// Class KillstreakUINew.KSAmmoWidget
// Size: 0x508 (Inherited: 0x4e8)
struct UKSAmmoWidget : UKSWeaponWidget {
	int32_t CachedAmmoInClip; // 0x4e8(0x04)
	int32_t CachedClipSize; // 0x4ec(0x04)
	int32_t CachedInReserve; // 0x4f0(0x04)
	bool CachedIsReloading; // 0x4f4(0x01)
	char UnknownData_4F5[0x13]; // 0x4f5(0x13)

	void StopReloading(); // Function KillstreakUINew.KSAmmoWidget.StopReloading // (Native|Event|Protected|BlueprintEvent) // @ game+0x21f40b0
	void StartReloading(); // Function KillstreakUINew.KSAmmoWidget.StartReloading // (Native|Event|Protected|BlueprintEvent) // @ game+0x21f4090
	void OnAmmoChanged(int32_t OldInClip, int32_t OldClipSize, int32_t OldReserve, int32_t NewInClip, int32_t NewClipSize, int32_t NewReserve); // Function KillstreakUINew.KSAmmoWidget.OnAmmoChanged // (Native|Event|Protected|BlueprintEvent) // @ game+0x21f37f0
};

// Class KillstreakUINew.KSAnnouncementQueuedMessageWidget
// Size: 0x528 (Inherited: 0x4e0)
struct UKSAnnouncementQueuedMessageWidget : UKSWidget {
	struct FMulticastInlineDelegate OnEndDisplay; // 0x4e0(0x10)
	struct FAnnouncementData AnnouncementData; // 0x4f0(0x38)

	void DisplayAnnouncement(); // Function KillstreakUINew.KSAnnouncementQueuedMessageWidget.DisplayAnnouncement // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x20a1de0
};

// Class KillstreakUINew.KSAnnouncementQueueWidget
// Size: 0x510 (Inherited: 0x4e0)
struct UKSAnnouncementQueueWidget : UKSWidget {
	bool IsBusy; // 0x4e0(0x01)
	char UnknownData_4E1[0x7]; // 0x4e1(0x07)
	struct FMulticastInlineDelegate OnReadyForNextAnnouncement; // 0x4e8(0x10)
	char UnknownData_4F8[0x18]; // 0x4f8(0x18)

	void Queue(struct FAnnouncementData Announcement); // Function KillstreakUINew.KSAnnouncementQueueWidget.Queue // (Final|Native|Protected|BlueprintCallable) // @ game+0x21f3aa0
	bool GetNext(struct FAnnouncementData Announcement); // Function KillstreakUINew.KSAnnouncementQueueWidget.GetNext // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x21f2850
	void ClearAnnoucementQueue(); // Function KillstreakUINew.KSAnnouncementQueueWidget.ClearAnnoucementQueue // (Final|Native|Protected|BlueprintCallable) // @ game+0x21f21e0
};

// Class KillstreakUINew.KSAsyncImage
// Size: 0x270 (Inherited: 0x260)
struct UKSAsyncImage : UPUMG_AsyncImage {
	struct UMaterialInstanceDynamic* MaterialToUse; // 0x260(0x08)
	struct FName MaterialParameter; // 0x268(0x08)

	void SetMaterialToUse(struct UMaterialInstanceDynamic* InMID); // Function KillstreakUINew.KSAsyncImage.SetMaterialToUse // (Final|Native|Private|BlueprintCallable) // @ game+0x21f3f30
	void SetBrushFromTextureOnItem(struct UPlatformInventoryItem* Item, struct TSoftObjectPtr<struct UTexture2D> Texture, bool bMatchSize); // Function KillstreakUINew.KSAsyncImage.SetBrushFromTextureOnItem // (Final|Native|Public|BlueprintCallable) // @ game+0x21f3cc0
	void SetBrushFromItemIcon(struct UPlatformInventoryItem* Item, bool bMatchSize); // Function KillstreakUINew.KSAsyncImage.SetBrushFromItemIcon // (Final|Native|Public|BlueprintCallable) // @ game+0x21f3bf0
};

// Class KillstreakUINew.KSBoostInventoryWidget
// Size: 0x4e0 (Inherited: 0x4e0)
struct UKSBoostInventoryWidget : UKSWidget {
};

// Class KillstreakUINew.KSBoostInventoryItemWidget
// Size: 0x4f0 (Inherited: 0x4e0)
struct UKSBoostInventoryItemWidget : UKSWidget {
	struct FAccountConsumableDetails CurrentItemDetails; // 0x4e0(0x10)

	void View_SetFromItem(struct FAccountConsumableDetails ItemDetails); // Function KillstreakUINew.KSBoostInventoryItemWidget.View_SetFromItem // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void ShowBoostPopup(); // Function KillstreakUINew.KSBoostInventoryItemWidget.ShowBoostPopup // (Final|Native|Protected|BlueprintCallable) // @ game+0x21f4070
	void SetItem(struct FAccountConsumableDetails ItemDetails); // Function KillstreakUINew.KSBoostInventoryItemWidget.SetItem // (Final|Native|Protected|BlueprintCallable) // @ game+0x21f3e20
	void PlayBoostConfirmationSound(); // Function KillstreakUINew.KSBoostInventoryItemWidget.PlayBoostConfirmationSound // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnActivateBoostConfirm(); // Function KillstreakUINew.KSBoostInventoryItemWidget.OnActivateBoostConfirm // (Final|Native|Protected) // @ game+0x21f37d0
	void OnActivateBoostCancel(); // Function KillstreakUINew.KSBoostInventoryItemWidget.OnActivateBoostCancel // (Final|Native|Protected) // @ game+0xbc5780
};

// Class KillstreakUINew.KSChatDataFactory
// Size: 0x118 (Inherited: 0x118)
struct UKSChatDataFactory : UPUMG_ChatDataFactory {
};

// Class KillstreakUINew.KSComponentReticleWidgetBase
// Size: 0x5c8 (Inherited: 0x5a8)
struct UKSComponentReticleWidgetBase : UKSActiveWeaponComponentWidget {
	float ShrinkAnimationTime; // 0x5a8(0x04)
	float BlockedShotIconMaxScale; // 0x5ac(0x04)
	float BlockedShotIconMinScale; // 0x5b0(0x04)
	float BlockedShotMinScaleSqDist; // 0x5b4(0x04)
	bool bGrenadeCooking; // 0x5b8(0x01)
	bool bInADS; // 0x5b9(0x01)
	bool bCachedBlockIconVisible; // 0x5ba(0x01)
	char UnknownData_5BB[0x1]; // 0x5bb(0x01)
	float CachedWeaponAccuracy; // 0x5bc(0x04)
	float CachedReticleOffset; // 0x5c0(0x04)
	char UnknownData_5C4[0x4]; // 0x5c4(0x04)

	void ViewedPawnInstigatedDamageNotify(struct FCombatEventInfo DamageInfo); // Function KillstreakUINew.KSComponentReticleWidgetBase.ViewedPawnInstigatedDamageNotify // (Native|Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x21f40d0
	void UpdateReticleOffset(float OffsetFromCenterScreen); // Function KillstreakUINew.KSComponentReticleWidgetBase.UpdateReticleOffset // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void UpdateBlockedShotIcon(bool IconVisible, struct FVector2D Translation, struct FVector2D IconScale); // Function KillstreakUINew.KSComponentReticleWidgetBase.UpdateBlockedShotIcon // (Event|Protected|HasDefaults|BlueprintEvent) // @ game+0x2587100
	void CalculateReticleOffset(float DeltaTime); // Function KillstreakUINew.KSComponentReticleWidgetBase.CalculateReticleOffset // (Final|Native|Protected) // @ game+0x21f2140
	void CalculateBlockedShotIcon(); // Function KillstreakUINew.KSComponentReticleWidgetBase.CalculateBlockedShotIcon // (Final|Native|Protected) // @ game+0x21f2120
};

// Class KillstreakUINew.ContextActionData
// Size: 0x88 (Inherited: 0x28)
struct UContextActionData : UObject {
	struct FName RowName; // 0x28(0x08)
	struct FContextAction RowData; // 0x30(0x48)
	struct FDelegate OnContextAction; // 0x78(0x10)

	void TriggerContextAction(); // Function KillstreakUINew.ContextActionData.TriggerContextAction // (Final|Native|Public|BlueprintCallable) // @ game+0x21f9250
};

// Class KillstreakUINew.KSContextBarWidget
// Size: 0x558 (Inherited: 0x4e0)
struct UKSContextBarWidget : UKSWidget {
	struct UDataTable* ContextActionDT; // 0x4e0(0x08)
	struct TMap<struct FName, struct FRouteContextInfo> RouteContextInfoMap; // 0x4e8(0x50)
	struct FName ActiveRoute; // 0x538(0x08)
	struct TArray<struct FName> OverrideRouteStack; // 0x540(0x10)
	struct FName OverrideRoute; // 0x550(0x08)

	void UpdateContextActions(struct TArray<struct UContextActionData*> ContextActions, struct FName CurrentRoute); // Function KillstreakUINew.KSContextBarWidget.UpdateContextActions // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x2587100
	void SetPrompts(struct FName Route, struct TArray<struct FName> ContextNames); // Function KillstreakUINew.KSContextBarWidget.SetPrompts // (Final|Native|Public|BlueprintCallable) // @ game+0x21f9070
	void SetPromptAction(struct FName Route, struct FName ContextName, struct FDelegate EventCallback); // Function KillstreakUINew.KSContextBarWidget.SetPromptAction // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x21f8f40
	void SetPrompt(struct FName Route, struct FName ContextName); // Function KillstreakUINew.KSContextBarWidget.SetPrompt // (Final|Native|Public|BlueprintCallable) // @ game+0x21f8e80
	void SetOverrideRoute(struct FName Route); // Function KillstreakUINew.KSContextBarWidget.SetOverrideRoute // (Final|Native|Public|BlueprintCallable) // @ game+0x21f8840
	void SetActiveRoute(struct FName Route); // Function KillstreakUINew.KSContextBarWidget.SetActiveRoute // (Final|Native|Public|BlueprintCallable) // @ game+0x21f8960
	void RefreshContextBar(); // Function KillstreakUINew.KSContextBarWidget.RefreshContextBar // (Final|Native|Protected) // @ game+0x21f88c0
	void PushOverrideRoute(struct FName Route); // Function KillstreakUINew.KSContextBarWidget.PushOverrideRoute // (Final|Native|Public|BlueprintCallable) // @ game+0x21f8840
	struct FName PopOverrideRoute(); // Function KillstreakUINew.KSContextBarWidget.PopOverrideRoute // (Final|Native|Public|BlueprintCallable) // @ game+0x21f8800
	void OverrideKeyButtons(); // Function KillstreakUINew.KSContextBarWidget.OverrideKeyButtons // (Final|Native|Protected) // @ game+0x21f87e0
	struct FName GetCurrentContextRoute(); // Function KillstreakUINew.KSContextBarWidget.GetCurrentContextRoute // (Final|Native|Protected|Const) // @ game+0x21f7260
	void ClearPromptByKey(struct FName Route, struct FKey Key); // Function KillstreakUINew.KSContextBarWidget.ClearPromptByKey // (Final|Native|Public|BlueprintCallable) // @ game+0x21f6b70
	void ClearPrompt(struct FName Route, struct FName ContextName); // Function KillstreakUINew.KSContextBarWidget.ClearPrompt // (Final|Native|Public|BlueprintCallable) // @ game+0x21f6ab0
	void ClearOverrideRouteStack(); // Function KillstreakUINew.KSContextBarWidget.ClearOverrideRouteStack // (Final|Native|Public|BlueprintCallable) // @ game+0x21f6a90
	void ClearOverrideRoute(); // Function KillstreakUINew.KSContextBarWidget.ClearOverrideRoute // (Final|Native|Public|BlueprintCallable) // @ game+0x21f6a70
	void ClearAllPrompts(struct FName Route); // Function KillstreakUINew.KSContextBarWidget.ClearAllPrompts // (Final|Native|Public|BlueprintCallable) // @ game+0x21f6970
};

// Class KillstreakUINew.KSContextMenu
// Size: 0x538 (Inherited: 0x4e0)
struct UKSContextMenu : UKSWidget {
	struct FMulticastInlineDelegate OnContextOptionsUpdated; // 0x4e0(0x10)
	struct FMulticastInlineDelegate OnReportPlayer; // 0x4f0(0x10)
	enum class EPlayerContextMenuContext MenuContext; // 0x500(0x01)
	bool bAllowReportPlayer; // 0x501(0x01)
	char UnknownData_502[0x6]; // 0x502(0x06)
	struct UKSPlayerInfo* CurrentPlayerInfo; // 0x508(0x08)
	struct TArray<struct UKSContextMenuButton*> ContextMenuButtons; // 0x510(0x10)
	struct TArray<int64_t> ReportedPlayerIds; // 0x520(0x10)
	enum class EViewSide MenuViewSide; // 0x530(0x01)
	char UnknownData_531[0x3]; // 0x531(0x03)
	int32_t CachedQueuedOrInMatch; // 0x534(0x04)

	void SetPlayerReported(int64_t PlayerId); // Function KillstreakUINew.KSContextMenu.SetPlayerReported // (Final|Native|Public|BlueprintCallable) // @ game+0x21f8e00
	void SetOptionsVisibility(); // Function KillstreakUINew.KSContextMenu.SetOptionsVisibility // (Final|Native|Public|BlueprintCallable) // @ game+0x21f8c70
	struct FVector2D SetMenuPosition(struct UKSWidget* WidgetToMove, struct FMargin WidgetPadding, enum class EViewSide side, float menuWidth, float menuHeight); // Function KillstreakUINew.KSContextMenu.SetMenuPosition // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x21f8ae0
	void SetCurrentPlayerInfo(struct UKSPlayerInfo* playerinfo); // Function KillstreakUINew.KSContextMenu.SetCurrentPlayerInfo // (Final|Native|Public|BlueprintCallable) // @ game+0x21f8a60
	void RemoveContextMenuButton(struct UKSContextMenuButton* ContextButton); // Function KillstreakUINew.KSContextMenu.RemoveContextMenuButton // (Final|Native|Public|BlueprintCallable) // @ game+0x21f88e0
	bool OnOptionSelected(enum class EPlayerContextOptions ContextOption); // Function KillstreakUINew.KSContextMenu.OnOptionSelected // (Final|Native|Public|BlueprintCallable) // @ game+0x21f84f0
	bool HasReportedPlayer(struct UKSPlayerInfo* playerinfo); // Function KillstreakUINew.KSContextMenu.HasReportedPlayer // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x21f83b0
	void HandleOnQueueStatusChange(enum class EPUMG_MatchStatus QueueStatus); // Function KillstreakUINew.KSContextMenu.HandleOnQueueStatusChange // (Final|Native|Protected) // @ game+0x21f82a0
	struct UPUMG_QueueDataFactory* GetQueueDataFactory(); // Function KillstreakUINew.KSContextMenu.GetQueueDataFactory // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x21f7940
	struct UKSPlayerDataFactory* GetPlayerDataFactory(); // Function KillstreakUINew.KSContextMenu.GetPlayerDataFactory // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x21f7910
	struct UPUMG_PartyDataFactory* GetPartyDataFactory(); // Function KillstreakUINew.KSContextMenu.GetPartyDataFactory // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x21f7570
	struct UKSFriendDataFactory* GetFriendDataFactory(); // Function KillstreakUINew.KSContextMenu.GetFriendDataFactory // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x21f72a0
	struct UKSContextMenuButton* GetContextButtonByEnum(enum class EPlayerContextOptions ContextOption); // Function KillstreakUINew.KSContextMenu.GetContextButtonByEnum // (Final|Native|Public|BlueprintCallable) // @ game+0x21f70e0
	void ClearAllContextMenuButton(); // Function KillstreakUINew.KSContextMenu.ClearAllContextMenuButton // (Final|Native|Public|BlueprintCallable) // @ game+0x21f6950
	void AddContextMenuButton(struct UKSContextMenuButton* ContextButton); // Function KillstreakUINew.KSContextMenu.AddContextMenuButton // (Final|Native|Public|BlueprintCallable) // @ game+0x21f6620
};

// Class KillstreakUINew.KSContextMenuButton
// Size: 0x4e8 (Inherited: 0x4e0)
struct UKSContextMenuButton : UKSWidget {
	enum class EPlayerContextOptions ContextOption; // 0x4e0(0x01)
	char UnknownData_4E1[0x7]; // 0x4e1(0x07)

	void SetContextOption(enum class EPlayerContextOptions Context); // Function KillstreakUINew.KSContextMenuButton.SetContextOption // (Final|Native|Public|BlueprintCallable) // @ game+0x21f89e0
	void HandleVisibility(bool isVisibility); // Function KillstreakUINew.KSContextMenuButton.HandleVisibility // (Native|Event|Public|BlueprintEvent) // @ game+0x21f8320
	void HandleActive(bool IsActive); // Function KillstreakUINew.KSContextMenuButton.HandleActive // (Native|Event|Public|BlueprintEvent) // @ game+0x21f8040
	enum class EPlayerContextOptions GetContextOption(); // Function KillstreakUINew.KSContextMenuButton.GetContextOption // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21f7170
};

// Class KillstreakUINew.KSContextualPingMarkerWidget
// Size: 0x3a0 (Inherited: 0x318)
struct UKSContextualPingMarkerWidget : UKSMapIconWidgetBase {
	struct FMulticastInlineDelegate OnPingRemovedCalled; // 0x318(0x10)
	struct FMulticastInlineDelegate OnPingChangedCalled; // 0x328(0x10)
	struct FPingInfo CurrentPingInfo; // 0x338(0x50)
	struct UKSPingManager* PingManager; // 0x388(0x08)
	struct UDataTable* ContextualPingTypesDT; // 0x390(0x08)
	struct UDataTable* ContextualPingMessagesDT; // 0x398(0x08)

	void SetupPingOnReady(); // Function KillstreakUINew.KSContextualPingMarkerWidget.SetupPingOnReady // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void SetPingInfo(struct FPingInfo PingInfoVal); // Function KillstreakUINew.KSContextualPingMarkerWidget.SetPingInfo // (Final|Native|Public) // @ game+0x21f8c90
	void OnPingUnhovered(int32_t PingId, struct AKSPlayerState* PingingPlayer); // Function KillstreakUINew.KSContextualPingMarkerWidget.OnPingUnhovered // (Final|Native|Public|BlueprintCallable) // @ game+0x21f8640
	void OnPingHovered(int32_t PingId, struct AKSPlayerState* PingingPlayer); // Function KillstreakUINew.KSContextualPingMarkerWidget.OnPingHovered // (Final|Native|Public|BlueprintCallable) // @ game+0x21f8580
	void OnInitializePing(); // Function KillstreakUINew.KSContextualPingMarkerWidget.OnInitializePing // (Final|Native|Public|BlueprintCallable) // @ game+0x21f84d0
	bool IsInvisiblePingType(enum class EPingType PingType); // Function KillstreakUINew.KSContextualPingMarkerWidget.IsInvisiblePingType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21f8440
	void HandleOnContextualPingRemoved(int32_t PingId, struct AKSPlayerState* PingingPlayer); // Function KillstreakUINew.KSContextualPingMarkerWidget.HandleOnContextualPingRemoved // (Native|Public) // @ game+0x21f81d0
	void HandleOnContextualPingChanged(int32_t PingId, struct AKSPlayerState* PingingPlayer, struct AKSPlayerState* AcknowledgingPlayer); // Function KillstreakUINew.KSContextualPingMarkerWidget.HandleOnContextualPingChanged // (Native|Public) // @ game+0x21f80d0
	float GetPingLifeSpan(enum class EPingType PingType); // Function KillstreakUINew.KSContextualPingMarkerWidget.GetPingLifeSpan // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x21f7880
	bool GetPingIconByType(enum class EPingType PingType, struct TSoftObjectPtr<struct UTexture2D> PingIcon); // Function KillstreakUINew.KSContextualPingMarkerWidget.GetPingIconByType // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x21f7780
	bool GetPingIconByMessage(enum class EPingMessage PingMessage, struct TSoftObjectPtr<struct UTexture2D> PingIcon); // Function KillstreakUINew.KSContextualPingMarkerWidget.GetPingIconByMessage // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x21f7680
	bool GetPingColorByType(enum class EPingType PingType, struct FLinearColor PingColor); // Function KillstreakUINew.KSContextualPingMarkerWidget.GetPingColorByType // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x21f75a0
	bool FindRowByType(enum class EPingType PingType, struct FContextualPingTypesRow ContextualPingTypesRow); // Function KillstreakUINew.KSContextualPingMarkerWidget.FindRowByType // (Final|Native|Protected|HasOutParms|Const) // @ game+0x21f6db0
	bool FindRowByMessage(enum class EPingMessage PingMessage, struct FContextualPingMessagesRow ContextualPingMessagesRow); // Function KillstreakUINew.KSContextualPingMarkerWidget.FindRowByMessage // (Final|Native|Protected|HasOutParms|Const) // @ game+0x21f6c90
};

// Class KillstreakUINew.KSCosmeticItemSelectorWidget
// Size: 0x4e0 (Inherited: 0x4e0)
struct UKSCosmeticItemSelectorWidget : UKSWidget {
};

// Class KillstreakUINew.KSCustomizationSelection
// Size: 0x510 (Inherited: 0x4e0)
struct UKSCustomizationSelection : UKSWidget {
	char UnknownData_4E0[0x8]; // 0x4e0(0x08)
	struct TArray<struct FRogueCustomizationRelatedInfo> RogueCustomizationRelatedInfos; // 0x4e8(0x10)
	struct TArray<enum class EMercCosmeticSlot> ActiveCosmeticSlots; // 0x4f8(0x10)
	int32_t TabIndex; // 0x508(0x04)
	char UnknownData_50C[0x4]; // 0x50c(0x04)

	void TabRight(); // Function KillstreakUINew.KSCustomizationSelection.TabRight // (Final|Native|Public|BlueprintCallable) // @ game+0x21f9230
	void TabLeft(); // Function KillstreakUINew.KSCustomizationSelection.TabLeft // (Final|Native|Public|BlueprintCallable) // @ game+0x21f9210
	void SetWingSuitAsset(struct UKSWeaponAsset* WingSuit); // Function KillstreakUINew.KSCustomizationSelection.SetWingSuitAsset // (Final|Native|Protected|BlueprintCallable) // @ game+0x21f9190
	void OnVendorLoaded(int32_t GroupId, struct TArray<int32_t> VendorIds); // Function KillstreakUINew.KSCustomizationSelection.OnVendorLoaded // (Final|Native|Protected|HasOutParms) // @ game+0x21f8700
	bool GetWingSuitItems(struct TArray<struct UPUMG_StoreItem*> WingSuitSkinItems); // Function KillstreakUINew.KSCustomizationSelection.GetWingSuitItems // (Final|Native|Protected|HasOutParms) // @ game+0x21f7f80
	struct UKSWeaponAsset* GetWingSuitAsset(); // Function KillstreakUINew.KSCustomizationSelection.GetWingSuitAsset // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x20fee90
	bool GetWeaponSlotItems(enum class EWeaponSlot WeaponSlotType, struct UKSJobItem* JobItem, struct TArray<struct UPUMG_StoreItem*> WeaponSkinItems); // Function KillstreakUINew.KSCustomizationSelection.GetWeaponSlotItems // (Final|Native|Protected|HasOutParms) // @ game+0x21f7e50
	bool GetWeaponItem(enum class EWeaponSlot WeaponSlotType, struct UKSJobItem* JobItem, struct UKSWeaponAsset* Weapon); // Function KillstreakUINew.KSCustomizationSelection.GetWeaponItem // (Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x21f7d40
	bool GetSkinItemsForJobItem(struct UKSJobItem* JobItem, struct TArray<struct UPUMG_StoreItem*> JobSkinItems); // Function KillstreakUINew.KSCustomizationSelection.GetSkinItemsForJobItem // (Final|Native|Protected|HasOutParms) // @ game+0x21f7c40
	struct UKSScrollBox* GetScrollBoxForCosmeticSlot(enum class EMercCosmeticSlot CheckCosmeticSlot); // Function KillstreakUINew.KSCustomizationSelection.GetScrollBoxForCosmeticSlot // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x21f7bb0
	struct FRogueCustomizationRelatedInfo GetRogueCustomizationRelatedInfoForCosmeticSlot(enum class EMercCosmeticSlot CheckCosmeticSlot); // Function KillstreakUINew.KSCustomizationSelection.GetRogueCustomizationRelatedInfoForCosmeticSlot // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x21f7b00
	bool GetRadialMenuItems(struct TSoftObjectPtr<struct UKSJobItem> ForJobItem, struct TArray<struct UPUMG_StoreItem*> RadialMenuItems, int32_t LootTableId); // Function KillstreakUINew.KSCustomizationSelection.GetRadialMenuItems // (Final|Native|Protected|HasOutParms) // @ game+0x21f7970
	struct UKSNavTabWidget* GetNavTabForCosmeticSlot(enum class EMercCosmeticSlot CheckCosmeticSlot); // Function KillstreakUINew.KSCustomizationSelection.GetNavTabForCosmeticSlot // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x21f74e0
	struct TArray<struct UPUMG_StoreItem*> GetItemsForSlot(enum class EMercCosmeticSlot SlotType, enum class EWeaponSlot WeaponSlotType, struct UKSJobItem* JobItem); // Function KillstreakUINew.KSCustomizationSelection.GetItemsForSlot // (Final|Native|Protected|BlueprintCallable) // @ game+0x21f7390
	struct UKSStoreItemHelper* GetItemHelper(); // Function KillstreakUINew.KSCustomizationSelection.GetItemHelper // (Final|Native|Protected|BlueprintCallable) // @ game+0x21f7360
	struct UKSSortableGridPanel* GetItemContainerForCosmeticSlot(enum class EMercCosmeticSlot CheckCosmeticSlot); // Function KillstreakUINew.KSCustomizationSelection.GetItemContainerForCosmeticSlot // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x21f72d0
	struct TArray<struct UKSCosmeticItemSelectorWidget*> GetCosmeticItemSelectorsForCosmeticSlot(enum class EMercCosmeticSlot CheckCosmeticSlot); // Function KillstreakUINew.KSCustomizationSelection.GetCosmeticItemSelectorsForCosmeticSlot // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x21f7190
	struct UKSSortableGridPanel* GetActiveSortableGridPanel(); // Function KillstreakUINew.KSCustomizationSelection.GetActiveSortableGridPanel // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x21f70b0
	struct UKSScrollBox* GetActiveScrollBox(); // Function KillstreakUINew.KSCustomizationSelection.GetActiveScrollBox // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x21f7080
	struct FRogueCustomizationRelatedInfo GetActiveRogueCustomizationRelatedInfo(); // Function KillstreakUINew.KSCustomizationSelection.GetActiveRogueCustomizationRelatedInfo // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x21f7030
	struct UKSNavTabWidget* GetActiveNavTab(); // Function KillstreakUINew.KSCustomizationSelection.GetActiveNavTab // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x21f7000
	enum class EMercCosmeticSlot GetActiveCosmeticSlot(); // Function KillstreakUINew.KSCustomizationSelection.GetActiveCosmeticSlot // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x21f6fd0
	struct TArray<struct UKSCosmeticItemSelectorWidget*> GetActiveCosmeticItemSelectors(); // Function KillstreakUINew.KSCustomizationSelection.GetActiveCosmeticItemSelectors // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x21f6f50
	void ForceSetTabIndex(int32_t NewTabIndex); // Function KillstreakUINew.KSCustomizationSelection.ForceSetTabIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x21f6ed0
	void ClearCosmeticItemsForCosmeticSlot(enum class EMercCosmeticSlot CheckCosmeticSlot); // Function KillstreakUINew.KSCustomizationSelection.ClearCosmeticItemsForCosmeticSlot // (Final|Native|Public|BlueprintCallable) // @ game+0x21f69f0
	void ChangeToNewTab(); // Function KillstreakUINew.KSCustomizationSelection.ChangeToNewTab // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void AddRogueCustomizationRelatedInfo(int32_t NewSwitcherIndex, enum class EMercCosmeticSlot NewCosmeticSlot, struct UKSNavTabWidget* NewNavTab, struct UKSScrollBox* NewScrollBox, struct UKSSortableGridPanel* NewSortableGridPanel); // Function KillstreakUINew.KSCustomizationSelection.AddRogueCustomizationRelatedInfo // (Final|Native|Public|BlueprintCallable) // @ game+0x21f67c0
	void AddCosmeticItemsForCosmeticSlot(enum class EMercCosmeticSlot CheckCosmeticSlot, struct TArray<struct UKSCosmeticItemSelectorWidget*> NewCosmeticItems); // Function KillstreakUINew.KSCustomizationSelection.AddCosmeticItemsForCosmeticSlot // (Final|Native|Public|BlueprintCallable) // @ game+0x21f66a0
};

// Class KillstreakUINew.KSDataSocialCategory
// Size: 0xe0 (Inherited: 0x28)
struct UKSDataSocialCategory : UObject {
	struct FMulticastInlineDelegate OnPlayersUpdated; // 0x28(0x10)
	struct FMulticastInlineDelegate OnHeaderUpdated; // 0x38(0x10)
	struct FMulticastInlineDelegate OnMessageUpdated; // 0x48(0x10)
	char UnknownData_58[0x78]; // 0x58(0x78)
	struct TArray<struct UKSDataSocialPlayer*> SortedPlayerList; // 0xd0(0x10)

	bool TryConsumeOpenOnUpdate(); // Function KillstreakUINew.KSDataSocialCategory.TryConsumeOpenOnUpdate // (Final|Native|Public|BlueprintCallable) // @ game+0x21fdc40
	void SetOpenOnUpdate(bool Value); // Function KillstreakUINew.KSDataSocialCategory.SetOpenOnUpdate // (Final|Native|Public|BlueprintCallable) // @ game+0x21fd990
	void SetMessageText(bool bProcessing, struct FText MessageText); // Function KillstreakUINew.KSDataSocialCategory.SetMessageText // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x21fd870
	void SetHeaderText(struct FText Header); // Function KillstreakUINew.KSDataSocialCategory.SetHeaderText // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x21fd690
	int32_t Num(); // Function KillstreakUINew.KSDataSocialCategory.Num // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21fd010
	bool IsProcessing(); // Function KillstreakUINew.KSDataSocialCategory.IsProcessing // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21fcfa0
	struct TArray<struct UKSDataSocialPlayer*> GetPlayerList(); // Function KillstreakUINew.KSDataSocialCategory.GetPlayerList // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x21fc800
	struct FText GetMessageText(); // Function KillstreakUINew.KSDataSocialCategory.GetMessageText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21fc4a0
	struct FText GetHeaderText(); // Function KillstreakUINew.KSDataSocialCategory.GetHeaderText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21fc3d0
	enum class None BP_GetSectionValue(); // Function KillstreakUINew.KSDataSocialCategory.BP_GetSectionValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21fbed0
};

// Class KillstreakUINew.KSDataSocialPlayer
// Size: 0x40 (Inherited: 0x28)
struct UKSDataSocialPlayer : UObject {
	struct FMulticastInlineDelegate OnDataUpdate; // 0x28(0x10)
	struct UKSPlayerInfo* Info; // 0x38(0x08)

	void KSSocialPlayerUpdate__DelegateSignature(struct UKSPlayerInfo* playerinfo); // DelegateFunction KillstreakUINew.KSDataSocialPlayer.KSSocialPlayerUpdate__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x2587100
	bool IsValid(); // Function KillstreakUINew.KSDataSocialPlayer.IsValid // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21fcfc0
	struct UKSPlayerInfo* GetPlayerInfo(); // Function KillstreakUINew.KSDataSocialPlayer.GetPlayerInfo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21fc7e0
};

// Class KillstreakUINew.KSDebugMenu
// Size: 0x4f0 (Inherited: 0x4e0)
struct UKSDebugMenu : UKSWidget {
	struct TArray<struct FDebugMenuCommandInfo> DebugCommands; // 0x4e0(0x10)

	bool GetSubmenu(struct FDebugMenuCommandInfo BaseCommand, struct TArray<struct FDebugMenuCommandInfo> Submenu); // Function KillstreakUINew.KSDebugMenu.GetSubmenu // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x21fcb60
	void GetSortedBaseDebugCommands(struct TArray<struct FDebugMenuCommandInfo> SortedCommands); // Function KillstreakUINew.KSDebugMenu.GetSortedBaseDebugCommands // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x21fca90
	enum class EConsoleCommandParamType GetParamTypeForSubCommand(struct FString BaseCommandString); // Function KillstreakUINew.KSDebugMenu.GetParamTypeForSubCommand // (Native|Event|Protected|BlueprintEvent) // @ game+0x21fc6b0
};

// Class KillstreakUINew.KSDownloadProgressWidget
// Size: 0x248 (Inherited: 0x238)
struct UKSDownloadProgressWidget : UUserWidget {
	float UpdatePeriod; // 0x238(0x04)
	bool bMarkedFinished; // 0x23c(0x01)
	char UnknownData_23D[0x3]; // 0x23d(0x03)
	float TimeUntilNextUpdate; // 0x240(0x04)
	char UnknownData_244[0x4]; // 0x244(0x04)

	void UpdateFinished(); // Function KillstreakUINew.KSDownloadProgressWidget.UpdateFinished // (Native|Event|Protected|BlueprintEvent) // @ game+0x1a0f700
	void UpdatedDownloadProgress(float Progress, float Total, float Eta, bool bSupportsEta); // Function KillstreakUINew.KSDownloadProgressWidget.UpdatedDownloadProgress // (Native|Event|Protected|BlueprintEvent) // @ game+0x21fdc70
};

// Class KillstreakUINew.KSEditableTextBox
// Size: 0xa40 (Inherited: 0xa30)
struct UKSEditableTextBox : UEditableTextBox {
	struct FDelegate OnKeyDown; // 0xa30(0x10)
};

// Class KillstreakUINew.KSViewedPawnWidget
// Size: 0x510 (Inherited: 0x500)
struct UKSViewedPawnWidget : UKSPawnWidget {
	char UnknownData_500[0x10]; // 0x500(0x10)
};

// Class KillstreakUINew.KSEliminationMessageWidget
// Size: 0x510 (Inherited: 0x510)
struct UKSEliminationMessageWidget : UKSViewedPawnWidget {

	void ShowMessageForTakenDown(struct AKSPlayerState* Instigator, bool IsElimination); // Function KillstreakUINew.KSEliminationMessageWidget.ShowMessageForTakenDown // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ShowMessageForTakedown(struct AKSPlayerState* Victim, bool IsElimination); // Function KillstreakUINew.KSEliminationMessageWidget.ShowMessageForTakedown // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ShowMessageForAssist(struct AKSPlayerState* Victim, bool IsElimination); // Function KillstreakUINew.KSEliminationMessageWidget.ShowMessageForAssist // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnPlayerDownReceived(struct FCombatEventInfo EventInfo, int32_t ExpBonus); // Function KillstreakUINew.KSEliminationMessageWidget.OnPlayerDownReceived // (Final|Native|Public|BlueprintCallable) // @ game+0x21fd3e0
	void OnPlayerDeathReceived(struct FCombatEventInfo EventInfo); // Function KillstreakUINew.KSEliminationMessageWidget.OnPlayerDeathReceived // (Final|Native|Public|BlueprintCallable) // @ game+0x21fd2d0
	void OnPlayerAssistReceived(struct FAssistInfo EventInfo); // Function KillstreakUINew.KSEliminationMessageWidget.OnPlayerAssistReceived // (Final|Native|Public|BlueprintCallable) // @ game+0x21fd1f0
	void ClearMessages(); // Function KillstreakUINew.KSEliminationMessageWidget.ClearMessages // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

// Class KillstreakUINew.KSEMODataFactory
// Size: 0x108 (Inherited: 0x38)
struct UKSEMODataFactory : UPUMG_DataFactory {
	char UnknownData_38[0xc]; // 0x38(0x0c)
	bool haveRecieveMatchReport; // 0x44(0x01)
	char UnknownData_45[0xa3]; // 0x45(0xa3)
	struct FMulticastInlineDelegate OnRewardsRecieved; // 0xe8(0x10)
	struct FMulticastInlineDelegate OnProgressionRecieved; // 0xf8(0x10)

	void SetupTestData(int32_t PlayerXp, int32_t RankedXp, int32_t RogueXp, int32_t ReputationEarned, int32_t PlacementMatchNum, int32_t BattlePassXp); // Function KillstreakUINew.KSEMODataFactory.SetupTestData // (Final|Native|Public) // @ game+0x21fda90
	bool IsLocalPlayer(int64_t PlayerId); // Function KillstreakUINew.KSEMODataFactory.IsLocalPlayer // (Final|Native|Public|BlueprintCallable) // @ game+0x21fcf10
	void HandlePlayerRewards(struct FPlayerRewardsSummary PlayerRewardSummary, bool bFakeTestData); // Function KillstreakUINew.KSEMODataFactory.HandlePlayerRewards // (Final|Native|Public|BlueprintCallable) // @ game+0x21fcd60
	void HandleEOMDetail(); // Function KillstreakUINew.KSEMODataFactory.HandleEOMDetail // (Final|Native|Public) // @ game+0x21fcd40
	struct FScoreboardStats GetScoreboardStats(); // Function KillstreakUINew.KSEMODataFactory.GetScoreboardStats // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21fc9f0
	struct FPlayerRewardsSummary GetPlayerRewardsSummary(); // Function KillstreakUINew.KSEMODataFactory.GetPlayerRewardsSummary // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21fc830
	int32_t GetLastMatchQueueId(); // Function KillstreakUINew.KSEMODataFactory.GetLastMatchQueueId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21fc480
	bool FindReputationProgressionActivity(struct UKSActivityInstance* ReputationProgressionActivity); // Function KillstreakUINew.KSEMODataFactory.FindReputationProgressionActivity // (Final|Native|Protected|HasOutParms) // @ game+0x21fc190
	bool FindRankedProgressionActivity(struct UKSActivityInstance* RankedProgressionActivity); // Function KillstreakUINew.KSEMODataFactory.FindRankedProgressionActivity // (Final|Native|Protected|HasOutParms) // @ game+0x21fc0f0
	bool FindPlayerXpProgressionActivity(struct UKSActivityInstance* PlayerXpProgressionActivity); // Function KillstreakUINew.KSEMODataFactory.FindPlayerXpProgressionActivity // (Final|Native|Protected|HasOutParms) // @ game+0x21fc050
	bool FindMiniBattlePassProgressionActivity(struct UKSActivityInstance* MiniBattlePassProgressionActivity); // Function KillstreakUINew.KSEMODataFactory.FindMiniBattlePassProgressionActivity // (Final|Native|Protected|HasOutParms) // @ game+0x21fbfb0
	bool FindBattlePassProgressionActivity(struct UKSActivityInstance* BattlePassProgressionActivity); // Function KillstreakUINew.KSEMODataFactory.FindBattlePassProgressionActivity // (Final|Native|Protected|HasOutParms) // @ game+0x21fbf10
	void ComputeEOMResults(); // Function KillstreakUINew.KSEMODataFactory.ComputeEOMResults // (Final|Native|Public|BlueprintCallable) // @ game+0x21fbef0
};

// Class KillstreakUINew.KSExpDisplayWidget
// Size: 0x530 (Inherited: 0x510)
struct UKSExpDisplayWidget : UKSViewedPawnWidget {
	bool bIsWaitingForNextQueue; // 0x510(0x01)
	char UnknownData_511[0x1f]; // 0x511(0x1f)

	void QueueExpDisplays(struct FExpDisplayInfo ExpInfo); // Function KillstreakUINew.KSExpDisplayWidget.QueueExpDisplays // (Final|Native|Protected|BlueprintCallable) // @ game+0x21fd520
	void NativeHandleDisplayExpInfo(); // Function KillstreakUINew.KSExpDisplayWidget.NativeHandleDisplayExpInfo // (Native|Protected) // @ game+0x21fcff0
	bool GetNextExpDisplay(struct FExpDisplayInfo ExpInfo); // Function KillstreakUINew.KSExpDisplayWidget.GetNextExpDisplay // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x21fc550
	void DisplayExpInfo(); // Function KillstreakUINew.KSExpDisplayWidget.DisplayExpInfo // (Native|Event|Protected|BlueprintEvent) // @ game+0x2138f80
};

// Class KillstreakUINew.KSFloatTickLerpWidgetBase
// Size: 0x260 (Inherited: 0x238)
struct UKSFloatTickLerpWidgetBase : UUserWidget {
	struct FMulticastInlineDelegate OnLerpComplete; // 0x238(0x10)
	float LerpTime; // 0x248(0x04)
	float LerpPower; // 0x24c(0x04)
	char UnknownData_250[0x10]; // 0x250(0x10)

	void SetTargetValue(float Value); // Function KillstreakUINew.KSFloatTickLerpWidgetBase.SetTargetValue // (Final|Native|Public|BlueprintCallable) // @ game+0x21fda10
	void SetLerpTime(float Time); // Function KillstreakUINew.KSFloatTickLerpWidgetBase.SetLerpTime // (Final|Native|Public|BlueprintCallable) // @ game+0x21fd7f0
	void SetLerpPower(float Power); // Function KillstreakUINew.KSFloatTickLerpWidgetBase.SetLerpPower // (Final|Native|Public|BlueprintCallable) // @ game+0x21fd760
	bool IsLerping(); // Function KillstreakUINew.KSFloatTickLerpWidgetBase.IsLerping // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x21fcee0
	float GetCurrentValue(); // Function KillstreakUINew.KSFloatTickLerpWidgetBase.GetCurrentValue // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x21fc2b0
	void ForceCurrentValue(float Value); // Function KillstreakUINew.KSFloatTickLerpWidgetBase.ForceCurrentValue // (Final|Native|Public|BlueprintCallable) // @ game+0x21fc230
	void DisplayForValue(float Value); // Function KillstreakUINew.KSFloatTickLerpWidgetBase.DisplayForValue // (Event|Public|BlueprintEvent) // @ game+0x2587100
};

// Class KillstreakUINew.KSFriendDataFactory
// Size: 0x130 (Inherited: 0x120)
struct UKSFriendDataFactory : UPUMG_FriendDataFactory {
	struct FMulticastInlineDelegate OnUpdateRecentlyPlayedPlayers; // 0x120(0x10)

	void OnEOMRewardsReceived(struct FPlayerRewardsSummary PlayerRewardsSummary, struct FScoreboardStats ScoreboardStats); // Function KillstreakUINew.KSFriendDataFactory.OnEOMRewardsReceived // (Final|Native|Protected) // @ game+0x21fd030
	void KSUpdateRecentlyPlayedPlayers__DelegateSignature(struct UKSFriendDataFactory* Source); // DelegateFunction KillstreakUINew.KSFriendDataFactory.KSUpdateRecentlyPlayedPlayers__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x2587100
	struct TArray<struct UPUMG_PlayerInfo*> GetSuggestedFriends_Info(); // Function KillstreakUINew.KSFriendDataFactory.GetSuggestedFriends_Info // (Final|Native|Public|BlueprintCallable) // @ game+0x21fccc0
	struct TArray<struct UKSPlayerInfo*> GetPlayersPlayedWithThisClientSession_Info(); // Function KillstreakUINew.KSFriendDataFactory.GetPlayersPlayedWithThisClientSession_Info // (Final|Native|Public|BlueprintCallable) // @ game+0x21fc970
	struct TArray<struct UPUMG_PlayerInfo*> GetPendingFriends_Info(); // Function KillstreakUINew.KSFriendDataFactory.GetPendingFriends_Info // (Final|Native|Public|BlueprintCallable) // @ game+0x21fc760
	struct TArray<struct UPUMG_PlayerInfo*> GetOnlineFriends_Info(); // Function KillstreakUINew.KSFriendDataFactory.GetOnlineFriends_Info // (Final|Native|Public|BlueprintCallable) // @ game+0x21fc630
	struct TArray<struct UPUMG_PlayerInfo*> GetFriends_Info(); // Function KillstreakUINew.KSFriendDataFactory.GetFriends_Info // (Final|Native|Public|BlueprintCallable) // @ game+0x21fc350
	struct TArray<struct UPUMG_PlayerInfo*> GetFriendRequests_Info(); // Function KillstreakUINew.KSFriendDataFactory.GetFriendRequests_Info // (Final|Native|Public|BlueprintCallable) // @ game+0x21fc2d0
};

// Class KillstreakUINew.KSFubarPopupWidget
// Size: 0x4e0 (Inherited: 0x4e0)
struct UKSFubarPopupWidget : UKSWidget {

	void ReceiveFubar(enum class EFubarDisplayReason Reason); // Function KillstreakUINew.KSFubarPopupWidget.ReceiveFubar // (Final|Native|Protected) // @ game+0x21fd610
	int32_t GetSecondsToShutdown(); // Function KillstreakUINew.KSFubarPopupWidget.GetSecondsToShutdown // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x21fca60
	void DisplayFubar(enum class EFubarDisplayReason Reason); // Function KillstreakUINew.KSFubarPopupWidget.DisplayFubar // (Event|Protected|BlueprintEvent) // @ game+0x2587100
};

// Class KillstreakUINew.KSMapWidgetBase
// Size: 0x620 (Inherited: 0x4e0)
struct UKSMapWidgetBase : UKSWidget {
	enum class EDisplayType MapDisplayType; // 0x4e0(0x01)
	char UnknownData_4E1[0x7]; // 0x4e1(0x07)
	struct TArray<struct FMapIconWidgetConfig> MapIconWidgetsToPool; // 0x4e8(0x10)
	struct TArray<struct UKSMapIconWidgetPool*> MapIconWidgetPool; // 0x4f8(0x10)
	struct TArray<struct UKSMapIconWidgetBase*> MapIconWidgetPoolShown; // 0x508(0x10)
	float OpacityWhenAiming; // 0x518(0x04)
	bool DoesFadeOutWhenAiming; // 0x51c(0x01)
	char UnknownData_51D[0x3]; // 0x51d(0x03)
	float AimTransitionProgress; // 0x520(0x04)
	char UnknownData_524[0x64]; // 0x524(0x64)
	struct TMap<struct AKSPlayerState*, struct UKSMapIconWidgetBase*> PlayerIconMap; // 0x588(0x50)
	char UnknownData_5D8[0x38]; // 0x5d8(0x38)
	bool AbsoluteRotation; // 0x610(0x01)
	bool CanBeScrambled; // 0x611(0x01)
	bool IsScrambled; // 0x612(0x01)
	bool bAffectedByScramble; // 0x613(0x01)
	char UnknownData_614[0xc]; // 0x614(0x0c)

	void UpdateOpacityWhenAiming(); // Function KillstreakUINew.KSMapWidgetBase.UpdateOpacityWhenAiming // (Native|Event|Protected|BlueprintEvent) // @ game+0x21f40b0
	void UpdateIcon(struct UKSMapIconWidgetBase* Icon); // Function KillstreakUINew.KSMapWidgetBase.UpdateIcon // (Final|Native|Protected) // @ game+0x2209710
	struct FVector2D ToIconRenderCoords(struct FVector2D MapCoords); // Function KillstreakUINew.KSMapWidgetBase.ToIconRenderCoords // (Native|Event|Protected|HasDefaults|BlueprintEvent) // @ game+0x2209680
	float ToIconRenderAngle(float PlayerAngle); // Function KillstreakUINew.KSMapWidgetBase.ToIconRenderAngle // (Native|Event|Protected|BlueprintEvent) // @ game+0x22095f0
	void TickCachedTransform(); // Function KillstreakUINew.KSMapWidgetBase.TickCachedTransform // (Final|Native|Public|BlueprintCallable) // @ game+0x22095d0
	bool ShouldUpdateOpacityWhenAiming(); // Function KillstreakUINew.KSMapWidgetBase.ShouldUpdateOpacityWhenAiming // (Native|Event|Protected|BlueprintEvent) // @ game+0x20a18a0
	void SetScrambleState(bool Scrambled); // Function KillstreakUINew.KSMapWidgetBase.SetScrambleState // (Final|Native|Protected) // @ game+0x2209440
	void RemoveWidgetFromLoaderById(int32_t InId); // Function KillstreakUINew.KSMapWidgetBase.RemoveWidgetFromLoaderById // (Final|Native|Public) // @ game+0x2208c70
	void OnScrambleStateChanged(bool Scrambled); // Function KillstreakUINew.KSMapWidgetBase.OnScrambleStateChanged // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnReceiveDisplayWidgetInfo(struct FDisplayInfo DisplayInfo); // Function KillstreakUINew.KSMapWidgetBase.OnReceiveDisplayWidgetInfo // (Native|Public) // @ game+0x2208ab0
	void OnGameStateSet(struct AGameStateBase* GameStateBase); // Function KillstreakUINew.KSMapWidgetBase.OnGameStateSet // (Final|Native|Public) // @ game+0x2208a10
	bool IsOnMap(struct FVector2D MapCoords); // Function KillstreakUINew.KSMapWidgetBase.IsOnMap // (Native|Event|Protected|HasDefaults|BlueprintEvent) // @ game+0x2208760
	void HandleMoveToWidgetPool(struct UKSMapIconWidgetBase* MapIconWidget); // Function KillstreakUINew.KSMapWidgetBase.HandleMoveToWidgetPool // (Final|Native|Protected) // @ game+0x2208590
	void HandleDisplayFromWidgetPool(struct UKSMapIconWidgetBase* MapIconWidget, struct FDisplayInfo DisplayInfo); // Function KillstreakUINew.KSMapWidgetBase.HandleDisplayFromWidgetPool // (Final|Native|Protected) // @ game+0x22083b0
	void HandleAimStateChange(enum class EKSCharacterAimMode NewAimState); // Function KillstreakUINew.KSMapWidgetBase.HandleAimStateChange // (Final|Native|Protected) // @ game+0x2208330
	struct UKSMapIconWidgetBase* GrabMapIconWidget(struct FString WidgetPoolName); // Function KillstreakUINew.KSMapWidgetBase.GrabMapIconWidget // (Final|Native|Protected) // @ game+0x2208240
	float GetDistanceToIcon(struct UKSMapIconWidgetBase* Icon); // Function KillstreakUINew.KSMapWidgetBase.GetDistanceToIcon // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2207dd0
	struct APawn* GetCachedViewedPawn(); // Function KillstreakUINew.KSMapWidgetBase.GetCachedViewedPawn // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2207d60
	struct FTransform GetCachedTransform(); // Function KillstreakUINew.KSMapWidgetBase.GetCachedTransform // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x2207d20
	void DisplayToMapWidget(struct UKSMapIconWidgetBase* MapIcon); // Function KillstreakUINew.KSMapWidgetBase.DisplayToMapWidget // (Native|Event|Protected|BlueprintEvent) // @ game+0x2139140
	struct UKSMapIconWidgetBase* CreateNewIconWidget(struct UKSMapIconWidgetBase* WidgetClass, int32_t UniqueId, struct AKSPlayerState* CreatingPlayer, enum class EDisplayType ParentMapDisplayType, struct AActor* AssociatedActor, struct UObject* AssociatedObject, struct FVector DefaultLocation, float Lifespan); // Function KillstreakUINew.KSMapWidgetBase.CreateNewIconWidget // (Event|Protected|HasDefaults|BlueprintEvent) // @ game+0x2587100
	void CreateMapIconWidgetPool(struct FMapIconWidgetConfig MapIconWidgetConfig); // Function KillstreakUINew.KSMapWidgetBase.CreateMapIconWidgetPool // (Final|Native|Protected) // @ game+0x2207af0
};

// Class KillstreakUINew.KSFullMapWidget
// Size: 0x630 (Inherited: 0x620)
struct UKSFullMapWidget : UKSMapWidgetBase {
	struct AActor* MinimapRendererActor; // 0x618(0x08)
	float MinimapWidth; // 0x620(0x04)
	char UnknownData_62C[0x4]; // 0x62c(0x04)
};

// Class KillstreakUINew.KSHUDCommon
// Size: 0x5d0 (Inherited: 0x550)
struct AKSHUDCommon : APUMG_HUD {
	struct FMulticastInlineDelegate OnPreferredSiteUpdated; // 0x550(0x10)
	struct UPUMG_LoginDataFactory* LoginDataFactory; // 0x560(0x08)
	struct UKSSettingsDataFactory* SettingsFactory; // 0x568(0x08)
	struct UKSChatDataFactory* ChatDataFactory; // 0x570(0x08)
	struct UKSPartyDataFactory* PartyDataFactory; // 0x578(0x08)
	struct UKSMercManager* MercManager; // 0x580(0x08)
	struct UKSNPEDataFactory* NPEDataFactory; // 0x588(0x08)
	struct UKSPlayerDataFactory* PlayerDataFactory; // 0x590(0x08)
	bool bDisplayWatermark; // 0x598(0x01)
	char UnknownData_599[0x3]; // 0x599(0x03)
	float WatermarkAlpha; // 0x59c(0x04)
	float WatermarkOffsetLeft; // 0x5a0(0x04)
	float WatermarkOffsetTop; // 0x5a4(0x04)
	float WatermarkOffsetRight; // 0x5a8(0x04)
	float WatermarkOffsetBottom; // 0x5ac(0x04)
	float WatermarkChangePositionTime; // 0x5b0(0x04)
	char UnknownData_5B4[0x4]; // 0x5b4(0x04)
	struct UDataTable* ColorPaletteDT; // 0x5b8(0x08)
	struct UDataTable* FontPaletteDT; // 0x5c0(0x08)
	struct UKSSettingsColorOptionsAsset* CrosshairColorOptions; // 0x5c8(0x08)

	void TestChallengeNotification(); // Function KillstreakUINew.KSHUDCommon.TestChallengeNotification // (Final|Exec|Native|Protected) // @ game+0xbc5780
	void ShowErrorPopup(struct FText ErrorMsg); // Function KillstreakUINew.KSHUDCommon.ShowErrorPopup // (Final|Native|Public|BlueprintCallable) // @ game+0x22040b0
	bool ShouldShowCrossplayIconForPlayerState(struct AKSPlayerState* PlayerState); // Function KillstreakUINew.KSHUDCommon.ShouldShowCrossplayIconForPlayerState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2204020
	bool ShouldShowCrossplayIconForPlayer(int64_t PlayerId); // Function KillstreakUINew.KSHUDCommon.ShouldShowCrossplayIconForPlayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2203f90
	void SetPreferredSiteId(int32_t SiteId); // Function KillstreakUINew.KSHUDCommon.SetPreferredSiteId // (Final|Native|Public|BlueprintCallable) // @ game+0x2203f10
	void PrintToLog(struct FText InText); // Function KillstreakUINew.KSHUDCommon.PrintToLog // (Final|Native|Public|BlueprintCallable) // @ game+0x22039f0
	void OpenTextChatToPlayer(struct UPUMG_PlayerInfo* Player); // Function KillstreakUINew.KSHUDCommon.OpenTextChatToPlayer // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x20ed700
	bool MutePlayer(int64_t PlayerId, bool Mute); // Function KillstreakUINew.KSHUDCommon.MutePlayer // (Final|Native|Public|BlueprintCallable) // @ game+0x2202ca0
	void LogErrorMessage(struct FText ErrorMsg); // Function KillstreakUINew.KSHUDCommon.LogErrorMessage // (Final|Native|Public|BlueprintCallable) // @ game+0x2202bc0
	bool IsSamePortalAsLocalPlayer(int64_t PlayerId); // Function KillstreakUINew.KSHUDCommon.IsSamePortalAsLocalPlayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2202b30
	bool IsMuted(int64_t PlayerId); // Function KillstreakUINew.KSHUDCommon.IsMuted // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x22028f0
	void HandleOpenTextChat(bool BeginChatCommand); // Function KillstreakUINew.KSHUDCommon.HandleOpenTextChat // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x22021a0
	void HandleControllerDisconnect(); // Function KillstreakUINew.KSHUDCommon.HandleControllerDisconnect // (Final|Native|Protected) // @ game+0x2201ec0
	struct UKSUISessionManager* GetUISessionManager(); // Function KillstreakUINew.KSHUDCommon.GetUISessionManager // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2201e70
	void GetSiteList(struct TMap<int32_t, struct FText> OutSiteIdToNameMap); // Function KillstreakUINew.KSHUDCommon.GetSiteList // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2201d40
	struct UKSSettingsDataFactory* GetSettingsDataFactory(); // Function KillstreakUINew.KSHUDCommon.GetSettingsDataFactory // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2201d10
	bool GetPreferredSiteId(int32_t OutSiteId); // Function KillstreakUINew.KSHUDCommon.GetPreferredSiteId // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2201c70
	struct UKSPlayerDataFactory* GetPlayerDataFactory(); // Function KillstreakUINew.KSHUDCommon.GetPlayerDataFactory // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2201be0
	struct UKSPartyDataFactory* GetPartyDataFactory(); // Function KillstreakUINew.KSHUDCommon.GetPartyDataFactory // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x20ec190
	struct UKSNPEDataFactory* GetNPEDataFactory(); // Function KillstreakUINew.KSHUDCommon.GetNPEDataFactory // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2201bb0
	struct UKSMercManager* GetMercManager(); // Function KillstreakUINew.KSHUDCommon.GetMercManager // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2201b80
	struct UPUMG_LoginDataFactory* GetLoginDataFactory(); // Function KillstreakUINew.KSHUDCommon.GetLoginDataFactory // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2201b50
	struct UKSLoadoutDataFactory* GetLoadoutDataFactory(); // Function KillstreakUINew.KSHUDCommon.GetLoadoutDataFactory // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2070830
	struct UKSStoreItemHelper* GetItemHelper(); // Function KillstreakUINew.KSHUDCommon.GetItemHelper // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x22017e0
	bool GetFont(struct FName FontName, struct FSlateFontInfo ReturnFont); // Function KillstreakUINew.KSHUDCommon.GetFont // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2201660
	struct TArray<struct UPanelWidget*> GetFocusableWidgetContainers(); // Function KillstreakUINew.KSHUDCommon.GetFocusableWidgetContainers // (Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	struct UKSContextBarWidget* GetContextBarWidget(); // Function KillstreakUINew.KSHUDCommon.GetContextBarWidget // (Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	bool GetColor(struct FName ColorName, struct FLinearColor ReturnColor); // Function KillstreakUINew.KSHUDCommon.GetColor // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x2201560
	struct UKSChatDataFactory* GetChatDataFactory(); // Function KillstreakUINew.KSHUDCommon.GetChatDataFactory // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2201530
	struct UKSAcquisitionManager* GetAcquisitionManager(); // Function KillstreakUINew.KSHUDCommon.GetAcquisitionManager // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2201430
	void EvaluateFocus(); // Function KillstreakUINew.KSHUDCommon.EvaluateFocus // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void DisplayWatermark(); // Function KillstreakUINew.KSHUDCommon.DisplayWatermark // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void ApplySafeFrameScale(float SafeFrameScale); // Function KillstreakUINew.KSHUDCommon.ApplySafeFrameScale // (Event|Public|BlueprintEvent) // @ game+0x2587100
};

// Class KillstreakUINew.KSGameHUDNew
// Size: 0x678 (Inherited: 0x5d0)
struct AKSGameHUDNew : AKSHUDCommon {
	char UnknownData_5D0[0x8]; // 0x5d0(0x08)
	struct UUserWidget* AimAssistDebugWidgetClass; // 0x5d8(0x08)
	struct FWeakObjectPtr<struct UUserWidget> AimAssistDebugWidget; // 0x5e0(0x08)
	struct TArray<struct FDataTableInfo> BaseAssetDataTables; // 0x5e8(0x10)
	struct UDynamicSkinTable* AssetDataTableManager; // 0x5f8(0x08)
	struct UMultiSkinObject* SkinObject; // 0x600(0x08)
	struct UKSHUDStateTracker* HUDStateTracker; // 0x608(0x08)
	char UnknownData_610[0x50]; // 0x610(0x50)
	struct FMulticastInlineDelegate OnHudFubarDel; // 0x660(0x10)
	char UnknownData_670[0x8]; // 0x670(0x08)

	void UIX_ReturnLobby(); // Function KillstreakUINew.KSGameHUDNew.UIX_ReturnLobby // (Final|Native|Public|BlueprintCallable) // @ game+0x2204760
	void ToggleAimAssistDebug(); // Function KillstreakUINew.KSGameHUDNew.ToggleAimAssistDebug // (Final|Exec|Native|Public) // @ game+0xbc5780
	void SetHUDVisible(bool bVisible); // Function KillstreakUINew.KSGameHUDNew.SetHUDVisible // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2203d60
	void ReturnToHome(); // Function KillstreakUINew.KSGameHUDNew.ReturnToHome // (Final|Exec|Native|Public|BlueprintCallable) // @ game+0x2203ca0
	void OnViewedPlayerStateModRemoved(struct UKSPlayerMod* PlayerMod, struct UKSPlayerModInstance* ModInstance); // Function KillstreakUINew.KSGameHUDNew.OnViewedPlayerStateModRemoved // (Final|Native|Private) // @ game+0x2203710
	void OnViewedPlayerStateModAdded(struct UKSPlayerMod* PlayerMod, struct UKSPlayerModInstance* ModInstance); // Function KillstreakUINew.KSGameHUDNew.OnViewedPlayerStateModAdded // (Final|Native|Private) // @ game+0x2203650
	void OnViewedPawnChanged(struct AKSPlayerController* Controller, struct AActor* OldViewTarget, struct AActor* NewViewTarget); // Function KillstreakUINew.KSGameHUDNew.OnViewedPawnChanged // (Final|Native|Private) // @ game+0x2203550
	void OnToggleHUD(); // Function KillstreakUINew.KSGameHUDNew.OnToggleHUD // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2203520
	void OnAssetDataTableManagerChanged(struct TSet<struct FName> UpdatedKeywords); // Function KillstreakUINew.KSGameHUDNew.OnAssetDataTableManagerChanged // (Final|Native|Private|HasOutParms) // @ game+0x2202f10
	void NetworkLagStateChanged(struct UWorld* World, struct UNetDriver* NetDriver, enum class ENetworkLagState LagType); // Function KillstreakUINew.KSGameHUDNew.NetworkLagStateChanged // (Event|Public|BlueprintEvent) // @ game+0x2587100
	bool IsPlayerMuted(struct AKSPlayerState* KSPlayerState); // Function KillstreakUINew.KSGameHUDNew.IsPlayerMuted // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2202a10
	bool IsPlayerInVoiceChannel(struct AKSPlayerState* KSPlayerState); // Function KillstreakUINew.KSGameHUDNew.IsPlayerInVoiceChannel // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2202980
	void HandleLoginStateChange(enum class EPUMG_LoginState LoginState); // Function KillstreakUINew.KSGameHUDNew.HandleLoginStateChange // (Final|Native|Protected) // @ game+0x2202020
	void HandleFubar(enum class EFubarDisplayReason Reason); // Function KillstreakUINew.KSGameHUDNew.HandleFubar // (Final|Native|Private) // @ game+0x2201f20
	struct UKSHUDStateTracker* GetHUDStateTracker(); // Function KillstreakUINew.KSGameHUDNew.GetHUDStateTracker // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x22017c0
};

// Class KillstreakUINew.KSGameInfoOverlayBase
// Size: 0x500 (Inherited: 0x4e0)
struct UKSGameInfoOverlayBase : UKSWidget {
	char UnknownData_4E0[0x20]; // 0x4e0(0x20)

	void HandlePlayerStateReady(struct AKSPlayerState* PlayerState); // Function KillstreakUINew.KSGameInfoOverlayBase.HandlePlayerStateReady // (Event|Protected|BlueprintEvent) // @ game+0x2587100
};

// Class KillstreakUINew.KSGamepadPromptWidget
// Size: 0x4f0 (Inherited: 0x4e0)
struct UKSGamepadPromptWidget : UKSWidget {
	char UnknownData_4E0[0x10]; // 0x4e0(0x10)

	void SetContext(struct FButtonPromptContext PromptContext); // Function KillstreakUINew.KSGamepadPromptWidget.SetContext // (Final|Native|Public|BlueprintCallable) // @ game+0x2203cc0
	void PushContext(struct FButtonPromptContext PromptContext); // Function KillstreakUINew.KSGamepadPromptWidget.PushContext // (Final|Native|Public|BlueprintCallable) // @ game+0x2203ad0
	bool PopContext(struct FButtonPromptContext OutContext); // Function KillstreakUINew.KSGamepadPromptWidget.PopContext // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2203940
	void ClearAllContext(); // Function KillstreakUINew.KSGamepadPromptWidget.ClearAllContext // (Final|Native|Public|BlueprintCallable) // @ game+0x22013a0
	void ApplyContext(struct FButtonPromptContext Context); // Function KillstreakUINew.KSGamepadPromptWidget.ApplyContext // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

// Class KillstreakUINew.KSHealthWidget
// Size: 0x520 (Inherited: 0x500)
struct UKSHealthWidget : UKSPawnWidget {
	float CachedHealth; // 0x500(0x04)
	float CachedArmor; // 0x504(0x04)
	float CachedMaxHealth; // 0x508(0x04)
	float CachedOverheal; // 0x50c(0x04)
	char UnknownData_510[0x10]; // 0x510(0x10)

	void OverhealChangeFromChar(struct AKSCharacterBase* Character, bool bAnimatedChange); // Function KillstreakUINew.KSHealthWidget.OverhealChangeFromChar // (Final|Native|Private) // @ game+0x22037d0
	void OnOverhealChanged(float OldOverheal, float NewOverheal, bool bAnimatedChange); // Function KillstreakUINew.KSHealthWidget.OnOverhealChanged // (Native|Event|Protected|BlueprintEvent) // @ game+0x2203340
	void OnHealthChanged(float OldHealth, float OldMaxHealth, float NewHealth, float NewMaxHealth, bool bAnimatedChange); // Function KillstreakUINew.KSHealthWidget.OnHealthChanged // (Native|Event|Protected|BlueprintEvent) // @ game+0x2203040
	void OnArmorChanged(float OldArmor, float NewArmor); // Function KillstreakUINew.KSHealthWidget.OnArmorChanged // (Native|Event|Protected|BlueprintEvent) // @ game+0x2202e40
	void HealthChangeFromChar(struct AKSCharacterBase* Character, bool bAnimatedChange); // Function KillstreakUINew.KSHealthWidget.HealthChangeFromChar // (Final|Native|Private) // @ game+0x2202820
	void HandlePawnOverhealChange(struct AKSCharacterBase* Character); // Function KillstreakUINew.KSHealthWidget.HandlePawnOverhealChange // (Final|Native|Private) // @ game+0x2202510
	void HandlePawnHealthChange(struct AKSCharacterBase* Character); // Function KillstreakUINew.KSHealthWidget.HandlePawnHealthChange // (Final|Native|Private) // @ game+0x2202490
};

// Class KillstreakUINew.KSHUDStateTracker
// Size: 0x50 (Inherited: 0x28)
struct UKSHUDStateTracker : UObject {
	struct FMulticastInlineDelegate OnHUDMatchPhaseChanged; // 0x28(0x10)
	float PhaseTime; // 0x38(0x04)
	struct FName TrackedCurrentMatchPhase; // 0x3c(0x08)
	char UnknownData_44[0xc]; // 0x44(0x0c)

	void PollMatchPhase(); // Function KillstreakUINew.KSHUDStateTracker.PollMatchPhase // (Final|Native|Protected) // @ game+0x2203920
	void HandleUpdatedMatchPhase(struct FName NewPhaseName, struct FName PreviousPhaseName); // Function KillstreakUINew.KSHUDStateTracker.HandleUpdatedMatchPhase // (Final|Native|Protected) // @ game+0x2202760
	void HandleGameStateBeginPlay(struct AKSGameState* GameState); // Function KillstreakUINew.KSHUDStateTracker.HandleGameStateBeginPlay // (Final|Native|Protected) // @ game+0x2201fa0
};

// Class KillstreakUINew.KSInfoActorWidgetInterface
// Size: 0x28 (Inherited: 0x28)
struct UKSInfoActorWidgetInterface : UInterface {

	bool SetInfoActor(struct AKSWidgetInfoActor* InfoActor); // Function KillstreakUINew.KSInfoActorWidgetInterface.SetInfoActor // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2203df0
};

// Class KillstreakUINew.KSInputManager
// Size: 0xd8 (Inherited: 0xd8)
struct UKSInputManager : UPUMG_InputManager {
};

// Class KillstreakUINew.KSInspectPlayerInterface
// Size: 0x28 (Inherited: 0x28)
struct UKSInspectPlayerInterface : UInterface {

	void UnbindEventFromInspectPlayerChanged(struct FDelegate Callback); // Function KillstreakUINew.KSInspectPlayerInterface.UnbindEventFromInspectPlayerChanged // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	struct AKSPlayerState* GetInspectPlayerState(); // Function KillstreakUINew.KSInspectPlayerInterface.GetInspectPlayerState // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BindEventToInspectPlayerChanged(struct FDelegate Callback); // Function KillstreakUINew.KSInspectPlayerInterface.BindEventToInspectPlayerChanged // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

// Class KillstreakUINew.KSJobSelectionWidget
// Size: 0x4e0 (Inherited: 0x4e0)
struct UKSJobSelectionWidget : UKSWidget {

	void RefreshJobItems(); // Function KillstreakUINew.KSJobSelectionWidget.RefreshJobItems // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnJobVendorLoaded(int32_t GroupId, struct TArray<int32_t> VendorIds); // Function KillstreakUINew.KSJobSelectionWidget.OnJobVendorLoaded // (Final|Native|Protected|HasOutParms) // @ game+0x22031e0
	struct TArray<struct UPUMG_StoreItem*> GetJobStoreItems(); // Function KillstreakUINew.KSJobSelectionWidget.GetJobStoreItems // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x22018e0
	struct UKSStoreItemHelper* GetItemHelper(); // Function KillstreakUINew.KSJobSelectionWidget.GetItemHelper // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x21f7360
};

// Class KillstreakUINew.KSKevinTest
// Size: 0x4e0 (Inherited: 0x4e0)
struct UKSKevinTest : UKSWidget {

	int32_t RequestJobItems(); // Function KillstreakUINew.KSKevinTest.RequestJobItems // (Final|Native|Protected|BlueprintCallable) // @ game+0x2203b70
	struct TArray<struct UPUMG_StoreItem*> GetJobStoreItems(); // Function KillstreakUINew.KSKevinTest.GetJobStoreItems // (Final|Native|Protected|BlueprintCallable) // @ game+0x2201960
	struct UKSStoreItemHelper* GetItemHelper(); // Function KillstreakUINew.KSKevinTest.GetItemHelper // (Final|Native|Protected|BlueprintCallable) // @ game+0x21f7360
};

// Class KillstreakUINew.KSKillCardWidget
// Size: 0x4e8 (Inherited: 0x4e0)
struct UKSKillCardWidget : UKSWidget {
	float DisplayDuration; // 0x4e0(0x04)
	char UnknownData_4E4[0x4]; // 0x4e4(0x04)

	void ShowPlayerAndMessage(struct AKSPlayerState* PlayerState, struct FText Message); // Function KillstreakUINew.KSKillCardWidget.ShowPlayerAndMessage // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ClearMessage(bool UseAnimations); // Function KillstreakUINew.KSKillCardWidget.ClearMessage // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

// Class KillstreakUINew.KSLobbyHUDNew
// Size: 0x6c8 (Inherited: 0x5d0)
struct AKSLobbyHUDNew : AKSHUDCommon {
	char UnknownData_5D0[0x10]; // 0x5d0(0x10)
	struct FMulticastInlineDelegate OnMinuteTimerUpdate; // 0x5e0(0x10)
	char UnknownData_5F0[0x10]; // 0x5f0(0x10)
	struct UKSQueueDataFactory* QueueDataFactory; // 0x600(0x08)
	struct UKSFriendDataFactory* FriendDataFactory; // 0x608(0x08)
	struct UKSPlayerQueryDataFactory* PlayerQueryDataFactory; // 0x610(0x08)
	struct UKSEMODataFactory* EMODataFactory; // 0x618(0x08)
	struct UKSPlayerWhoDataFactory* PlayerWhoDataFactory; // 0x620(0x08)
	struct FWeakObjectPtr<struct UKSMediaPlayerWidget> CurrentMediaPlayerWidget; // 0x628(0x08)
	char UnknownData_630[0x8]; // 0x630(0x08)
	struct FMulticastInlineDelegate OnTriggerBlockerChange; // 0x638(0x10)
	bool EnablePreMatchAnimation; // 0x648(0x01)
	bool EnablePostMatchAnimation; // 0x649(0x01)
	bool EnableEOMIdleAnimation; // 0x64a(0x01)
	char UnknownData_64B[0x5]; // 0x64b(0x05)
	struct FMulticastInlineDelegate LobbyWidgetReady; // 0x650(0x10)
	struct FMulticastInlineDelegate MainLobbyCameraSet; // 0x660(0x10)
	struct FMulticastInlineDelegate LoginCameraSet; // 0x670(0x10)
	struct FMulticastInlineDelegate BeginPlayingPreMatchAnim; // 0x680(0x10)
	struct FMulticastInlineDelegate EndPlayingPreMatchAnim; // 0x690(0x10)
	struct FMulticastInlineDelegate EndPlayingPostMatchAnim; // 0x6a0(0x10)
	enum class ELobbyCharacterAnimState CurrentLobbyCharacterAnimState; // 0x6b0(0x01)
	enum class EPUMG_MatchStatus CurrentMatchStatus; // 0x6b1(0x01)
	char UnknownData_6B2[0x6]; // 0x6b2(0x06)
	float LoadingScreenFadeInDelay; // 0x6b8(0x04)
	float LoadingScreenFadeInDuration; // 0x6bc(0x04)
	char UnknownData_6C0[0x8]; // 0x6c0(0x08)

	void TransitionCamera(struct FName CameraTag, float BlendTime); // Function KillstreakUINew.KSLobbyHUDNew.TransitionCamera // (Final|Exec|Native|Public|BlueprintCallable) // @ game+0x2204690
	void ToggleDisablePartyLobbyCharacters(bool Disable); // Function KillstreakUINew.KSLobbyHUDNew.ToggleDisablePartyLobbyCharacters // (Final|Native|Private|BlueprintCallable) // @ game+0x2204600
	void TestSetStoreRotationOverride(struct FString DateTime); // Function KillstreakUINew.KSLobbyHUDNew.TestSetStoreRotationOverride // (Final|Exec|Native|Protected) // @ game+0x2204520
	void TestPostMatchLobby(int32_t PlayerXp, int32_t RankedXp, int32_t RogueXp, int32_t ReputationEarned, int32_t PlacementMatchNum, int32_t BattlePassXp); // Function KillstreakUINew.KSLobbyHUDNew.TestPostMatchLobby // (Final|Exec|Native|Protected) // @ game+0x2204370
	void TestBattlePassAcquisition(int32_t StartTier, int32_t EndTier); // Function KillstreakUINew.KSLobbyHUDNew.TestBattlePassAcquisition // (Final|Exec|Native|Protected) // @ game+0x22042b0
	void ShowPopupConfirmation(struct FText Message, enum class ESocialMessageType MessageType); // Function KillstreakUINew.KSLobbyHUDNew.ShowPopupConfirmation // (Final|Native|Public|BlueprintCallable) // @ game+0x2204190
	void SetNewLobbyAnimState(enum class ELobbyCharacterAnimState TargetState); // Function KillstreakUINew.KSLobbyHUDNew.SetNewLobbyAnimState // (Final|Native|Protected|BlueprintCallable) // @ game+0x2203e90
	void ResetLobbyCharactersByIndex(struct TArray<enum class ELobbyCharacterIndex> IndicesToReset); // Function KillstreakUINew.KSLobbyHUDNew.ResetLobbyCharactersByIndex // (Final|Native|Protected) // @ game+0x2203bc0
	void ResetLobbyCharacters(); // Function KillstreakUINew.KSLobbyHUDNew.ResetLobbyCharacters // (Final|Native|Protected) // @ game+0x2203ba0
	void PlayLoopingLevelSequence(struct FName LvlSeqTag); // Function KillstreakUINew.KSLobbyHUDNew.PlayLoopingLevelSequence // (Final|Exec|Native|Public|BlueprintCallable) // @ game+0x22038a0
	void OnStoreVendorsLoaded(int32_t GroupId, struct TArray<int32_t> VendorIds); // Function KillstreakUINew.KSLobbyHUDNew.OnStoreVendorsLoaded // (Final|Native|Protected|HasOutParms) // @ game+0x2203440
	void OnNotEnoughCurreny(struct UPUMG_StorePurchaseRequest* PurchaseRequest); // Function KillstreakUINew.KSLobbyHUDNew.OnNotEnoughCurreny // (Final|Native|Protected) // @ game+0x22032c0
	void NotifyViewStateChange(struct FName NewRoute, struct FName PreviousRoute); // Function KillstreakUINew.KSLobbyHUDNew.NotifyViewStateChange // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2202d60
	bool IsPlayerMuted(struct UPUMG_PlayerInfo* PlayerData); // Function KillstreakUINew.KSLobbyHUDNew.IsPlayerMuted // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2202aa0
	void HandleSpecificPartyIdDataUpdated(int64_t PlayerId); // Function KillstreakUINew.KSLobbyHUDNew.HandleSpecificPartyIdDataUpdated // (Final|Native|Protected) // @ game+0x22026e0
	void HandleSpecificPartyDataUpdated(struct FPUMG_PartyMemberData PartyMember); // Function KillstreakUINew.KSLobbyHUDNew.HandleSpecificPartyDataUpdated // (Final|Native|Protected) // @ game+0x22025b0
	void HandleSpecificPartyDataAdded(struct FPUMG_PartyMemberData PartyMember); // Function KillstreakUINew.KSLobbyHUDNew.HandleSpecificPartyDataAdded // (Final|Native|Protected) // @ game+0x22025b0
	void HandleReturnFromBattleLevelSeqStopped(); // Function KillstreakUINew.KSLobbyHUDNew.HandleReturnFromBattleLevelSeqStopped // (Final|Native|Public) // @ game+0x2202590
	void HandlePlayerLoadoutsUpdated(); // Function KillstreakUINew.KSLobbyHUDNew.HandlePlayerLoadoutsUpdated // (Final|Native|Protected) // @ game+0xbc5780
	void HandlePartyMemberDataUpdated(struct FPUMG_PartyMemberData PartyMember, int32_t MemberIndex); // Function KillstreakUINew.KSLobbyHUDNew.HandlePartyMemberDataUpdated // (Final|Native|Protected|HasOutParms) // @ game+0x2202360
	void HandlePartyEmoteMessageReceived(struct UPUMG_PlayerInfo* Sender, struct TSoftObjectPtr<struct UKSEmote> SoftEmotePtr); // Function KillstreakUINew.KSLobbyHUDNew.HandlePartyEmoteMessageReceived // (Final|Native|Protected) // @ game+0x2202250
	void HandlePartyDataUpdated(); // Function KillstreakUINew.KSLobbyHUDNew.HandlePartyDataUpdated // (Final|Native|Protected) // @ game+0x2202230
	void HandleMatchStatusUpdated(enum class EPUMG_MatchStatus MatchStatus); // Function KillstreakUINew.KSLobbyHUDNew.HandleMatchStatusUpdated // (Final|Native|Protected) // @ game+0x2202120
	void HandleLoginUserChange(); // Function KillstreakUINew.KSLobbyHUDNew.HandleLoginUserChange // (Final|Native|Protected) // @ game+0xbc5780
	void HandleLoginStateChange(enum class EPUMG_LoginState LoginState); // Function KillstreakUINew.KSLobbyHUDNew.HandleLoginStateChange // (Final|Native|Protected) // @ game+0x22020a0
	void HandleExitToGameLevelSeqStopped(); // Function KillstreakUINew.KSLobbyHUDNew.HandleExitToGameLevelSeqStopped // (Final|Native|Public) // @ game+0x2201f00
	void HandleDenyPartyInvitation(); // Function KillstreakUINew.KSLobbyHUDNew.HandleDenyPartyInvitation // (Final|Native|Public) // @ game+0x2201ee0
	void HandleAcceptPartyInvitation(); // Function KillstreakUINew.KSLobbyHUDNew.HandleAcceptPartyInvitation // (Final|Native|Public) // @ game+0x2201ea0
	struct UKSPlayerWhoDataFactory* GetPlayerWhoDataFactory(); // Function KillstreakUINew.KSLobbyHUDNew.GetPlayerWhoDataFactory // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2201c30
	struct UKSPlayerQueryDataFactory* GetPlayerQueryDataFactory(); // Function KillstreakUINew.KSLobbyHUDNew.GetPlayerQueryDataFactory // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2201c10
	struct UKSLobbyWidget* GetLobbyWidget(); // Function KillstreakUINew.KSLobbyHUDNew.GetLobbyWidget // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2201b20
	bool GetLobbyCharacterByPosition(enum class ELobbyCharacterIndex CharacterIndex, struct AKSLobbyCharacter* LobbyCharacter); // Function KillstreakUINew.KSLobbyHUDNew.GetLobbyCharacterByPosition // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2201a50
	struct UKSQueueDataFactory* GetKSQueueDataFactory(); // Function KillstreakUINew.KSLobbyHUDNew.GetKSQueueDataFactory // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2201a20
	struct UKSJsonDataFactory* GetJsonDataFactory(); // Function KillstreakUINew.KSLobbyHUDNew.GetJsonDataFactory // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x22019e0
	bool GetJobSelectPreviewActorByPosition(enum class ELobbyCharacterIndex CharacterIndex, struct AKSJobSelectPreviewActor_Lobby* PreviewActor); // Function KillstreakUINew.KSLobbyHUDNew.GetJobSelectPreviewActorByPosition // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x2201810
	struct UKSFriendDataFactory* GetFriendDataFactory(); // Function KillstreakUINew.KSLobbyHUDNew.GetFriendDataFactory // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2201780
	struct UKSEMODataFactory* GetEMODataFactory(); // Function KillstreakUINew.KSLobbyHUDNew.GetEMODataFactory // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2201640
	struct UKSItem* GetDefaultPlayerAccountItem(enum class EPlayerAccountSlot ItemSlot); // Function KillstreakUINew.KSLobbyHUDNew.GetDefaultPlayerAccountItem // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	bool GetCharacterIndexFromPartyIndex(int32_t PartyMemberIndex, enum class ELobbyCharacterIndex OutCharIndex); // Function KillstreakUINew.KSLobbyHUDNew.GetCharacterIndexFromPartyIndex // (Final|Native|Protected|HasOutParms) // @ game+0x2201460
	void ForceMinuteTimerUpdate(); // Function KillstreakUINew.KSLobbyHUDNew.ForceMinuteTimerUpdate // (Final|Native|Protected|BlueprintCallable) // @ game+0x2201400
	void ForceEulaAccept(); // Function KillstreakUINew.KSLobbyHUDNew.ForceEulaAccept // (Final|Native|Public|BlueprintCallable) // @ game+0x22013e0
	void CreateInitialPlayerLoadout(); // Function KillstreakUINew.KSLobbyHUDNew.CreateInitialPlayerLoadout // (Final|Native|Protected) // @ game+0x22013c0
	void CheckForVoucherRedemption(); // Function KillstreakUINew.KSLobbyHUDNew.CheckForVoucherRedemption // (Final|Native|Protected|BlueprintCallable) // @ game+0x2201380
	void CheckForExistingPenaltyTime(); // Function KillstreakUINew.KSLobbyHUDNew.CheckForExistingPenaltyTime // (Final|Native|Protected|BlueprintCallable) // @ game+0x2201360
	void CancelExitToGameLevelAnimStoppedHandling(); // Function KillstreakUINew.KSLobbyHUDNew.CancelExitToGameLevelAnimStoppedHandling // (Final|Native|Public) // @ game+0x2201340
};

// Class KillstreakUINew.KSLobbyNameplateWidget
// Size: 0x4e0 (Inherited: 0x4e0)
struct UKSLobbyNameplateWidget : UKSWidget {

	void SetupRankedManager(); // Function KillstreakUINew.KSLobbyNameplateWidget.SetupRankedManager // (Final|Native|Public|BlueprintCallable) // @ game+0x2209550
	void RefreshRankedData(); // Function KillstreakUINew.KSLobbyNameplateWidget.RefreshRankedData // (Event|Public|BlueprintEvent) // @ game+0x2587100
};

// Class KillstreakUINew.KSLobbyWidget
// Size: 0x4e0 (Inherited: 0x4e0)
struct UKSLobbyWidget : UKSWidget {
};

// Class KillstreakUINew.KSLoginExistingBase
// Size: 0x4e0 (Inherited: 0x4e0)
struct UKSLoginExistingBase : UKSWidget {
};

// Class KillstreakUINew.KSLoginInventoryCheckViewRedirector
// Size: 0x28 (Inherited: 0x28)
struct UKSLoginInventoryCheckViewRedirector : UPUMG_ViewRedirecter {
};

// Class KillstreakUINew.KSLoginInventoryCheck
// Size: 0x4f0 (Inherited: 0x4e0)
struct UKSLoginInventoryCheck : UKSWidget {
	char UnknownData_4E0[0x10]; // 0x4e0(0x10)

	void CancelLogin(); // Function KillstreakUINew.KSLoginInventoryCheck.CancelLogin // (Final|Native|Public|BlueprintCallable) // @ game+0x2207a50
};

// Class KillstreakUINew.KSLoginProcessRewardsViewRedirector
// Size: 0x28 (Inherited: 0x28)
struct UKSLoginProcessRewardsViewRedirector : UPUMG_ViewRedirecter {
};

// Class KillstreakUINew.KSLoginProcessRewards
// Size: 0x4e0 (Inherited: 0x4e0)
struct UKSLoginProcessRewards : UKSWidget {

	void ProcessAccountRewards(); // Function KillstreakUINew.KSLoginProcessRewards.ProcessAccountRewards // (Final|Native|Protected|BlueprintCallable) // @ game+0x2208c50
};

// Class KillstreakUINew.KSLootSiteIconWidget
// Size: 0x320 (Inherited: 0x318)
struct UKSLootSiteIconWidget : UKSMapIconWidgetBase {
	struct AKSLootSiteBase* MarkedLootSite; // 0x318(0x08)
};

// Class KillstreakUINew.KSLootSiteMarkerWidget
// Size: 0x338 (Inherited: 0x318)
struct UKSLootSiteMarkerWidget : UKSMapIconWidgetBase {
	struct AKSLootSiteBase* MarkedLootSite; // 0x318(0x08)
	float MaxDisplayDistance; // 0x320(0x04)
	bool bViewedPawnHasEndedFreeFall; // 0x324(0x01)
	char UnknownData_325[0x3]; // 0x325(0x03)
	struct TArray<enum class ELootSiteRarity> TagsToHide; // 0x328(0x10)
};

// Class KillstreakUINew.KSLowAmmoAlertWidget
// Size: 0x5c8 (Inherited: 0x5a8)
struct UKSLowAmmoAlertWidget : UKSActiveWeaponComponentWidget {
	float LowAmmoThreshold; // 0x5a8(0x04)
	enum class ELowAmmoState CachedLowAmmoState; // 0x5ac(0x01)
	char UnknownData_5AD[0x3]; // 0x5ad(0x03)
	struct FMulticastInlineDelegate OnAmmoStateChangedDel; // 0x5b0(0x10)
	char UnknownData_5C0[0x8]; // 0x5c0(0x08)

	enum class ELowAmmoState GetAmmoState(); // Function KillstreakUINew.KSLowAmmoAlertWidget.GetAmmoState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2207bf0
	enum class ELowAmmoState CalcAmmoState(); // Function KillstreakUINew.KSLowAmmoAlertWidget.CalcAmmoState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2207a20
	void AmmoStateChanged(); // Function KillstreakUINew.KSLowAmmoAlertWidget.AmmoStateChanged // (Native|Event|Protected|BlueprintEvent) // @ game+0x1a0a5d0
};

// Class KillstreakUINew.KSMapIconWidgetPool
// Size: 0x48 (Inherited: 0x28)
struct UKSMapIconWidgetPool : UObject {
	struct FString PoolType; // 0x28(0x10)
	struct TArray<struct UKSMapIconWidgetBase*> MapIconWidgets; // 0x38(0x10)

	struct UKSMapIconWidgetBase* GetMapIconWidget(); // Function KillstreakUINew.KSMapIconWidgetPool.GetMapIconWidget // (Final|Native|Public) // @ game+0x2207f20
	void AddMapIconWidget(struct UKSMapIconWidgetBase* MapIconWidget); // Function KillstreakUINew.KSMapIconWidgetPool.AddMapIconWidget // (Final|Native|Public) // @ game+0x22079a0
};

// Class KillstreakUINew.KSMarkerDisplayBase
// Size: 0x6a0 (Inherited: 0x620)
struct UKSMarkerDisplayBase : UKSMapWidgetBase {
	char UnknownData_620[0x80]; // 0x620(0x80)

	bool GetScreenPositionForMarker(struct FVector TargetLocation, float AnchorHeight, float MarginX, float MarginY, struct FVector2D ScreenLocation); // Function KillstreakUINew.KSMarkerDisplayBase.GetScreenPositionForMarker // (Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x2207f50
};

// Class KillstreakUINew.KSDataMassInviteBase
// Size: 0x78 (Inherited: 0x28)
struct UKSDataMassInviteBase : UObject {
	struct FText Title; // 0x28(0x18)
	struct FText ButtonLabel; // 0x40(0x18)
	struct FDelegate OnShouldShow; // 0x58(0x10)
	struct FDelegate OnClose; // 0x68(0x10)
};

// Class KillstreakUINew.KSDataIndividualInviteSetup
// Size: 0x98 (Inherited: 0x78)
struct UKSDataIndividualInviteSetup : UKSDataMassInviteBase {
	struct FDelegate OnGetIsSelected; // 0x78(0x10)
	struct FDelegate OnSelect; // 0x88(0x10)

	struct UKSDataIndividualInviteSetup* SetCallbacks(struct FDelegate GetIsSelected, struct FDelegate Select, struct FDelegate ShouldShowPlayer, struct FDelegate Close); // Function KillstreakUINew.KSDataIndividualInviteSetup.SetCallbacks // (Final|Native|Public|BlueprintCallable) // @ game+0x2209000
	enum class EKSInviteSelectResult KSInviteSelect__DelegateSignature(struct UKSPlayerInfo* playerinfo); // DelegateFunction KillstreakUINew.KSDataIndividualInviteSetup.KSInviteSelect__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	bool KSInviteGetIsSelected__DelegateSignature(struct UKSPlayerInfo* playerinfo); // DelegateFunction KillstreakUINew.KSDataIndividualInviteSetup.KSInviteGetIsSelected__DelegateSignature // (Public|Delegate) // @ game+0x2587100
};

// Class KillstreakUINew.KSDataBatchInviteSetup
// Size: 0x88 (Inherited: 0x78)
struct UKSDataBatchInviteSetup : UKSDataMassInviteBase {
	struct FDelegate OnSelect; // 0x78(0x10)

	struct UKSDataBatchInviteSetup* SetCallbacks(struct FDelegate Select, struct FDelegate ShouldShowPlayer, struct FDelegate Cancel); // Function KillstreakUINew.KSDataBatchInviteSetup.SetCallbacks // (Final|Native|Public|BlueprintCallable) // @ game+0x2208ea0
	void KSBatchSelect__DelegateSignature(struct TArray<struct UKSPlayerInfo*> playerinfo); // DelegateFunction KillstreakUINew.KSDataBatchInviteSetup.KSBatchSelect__DelegateSignature // (Public|Delegate) // @ game+0x2587100
};

// Class KillstreakUINew.KSMassInviteModal
// Size: 0x4f8 (Inherited: 0x4e0)
struct UKSMassInviteModal : UKSWidget {
	struct TArray<struct UKSPlayerInfo*> SelectedPlayers; // 0x4e0(0x10)
	struct UKSDataMassInviteBase* RouteData; // 0x4f0(0x08)

	bool UpdateRouteData(); // Function KillstreakUINew.KSMassInviteModal.UpdateRouteData // (Final|Native|Protected|BlueprintCallable) // @ game+0x22098f0
	enum class EKSInviteSelectResult SelectPlayer(struct UKSPlayerInfo* Player); // Function KillstreakUINew.KSMassInviteModal.SelectPlayer // (Final|Native|Protected|BlueprintCallable) // @ game+0x2208d90
	void RequestFriends(struct FDelegate OnReceivePlayers); // Function KillstreakUINew.KSMassInviteModal.RequestFriends // (Final|Native|Protected|BlueprintCallable) // @ game+0x2208cf0
	void KSInviteReceivePlayers__DelegateSignature(struct TArray<struct UKSPlayerInfo*> Players); // DelegateFunction KillstreakUINew.KSMassInviteModal.KSInviteReceivePlayers__DelegateSignature // (Public|Delegate|HasOutParms) // @ game+0x2587100
	bool GetShouldSelect(struct UKSPlayerInfo* Player); // Function KillstreakUINew.KSMassInviteModal.GetShouldSelect // (Final|Native|Protected|BlueprintCallable) // @ game+0x2208130
	void CloseScreen(enum class EKSInviteCloseAction CloseAction); // Function KillstreakUINew.KSMassInviteModal.CloseScreen // (Final|Native|Protected|BlueprintCallable) // @ game+0x2207a70
};

// Class KillstreakUINew.KSMatchInvitationModal
// Size: 0x4f8 (Inherited: 0x4e0)
struct UKSMatchInvitationModal : UKSWidget {
	struct FName RouteName; // 0x4e0(0x08)
	char UnknownData_4E8[0x8]; // 0x4e8(0x08)
	struct FTimerHandle InvitationExpireTimeout; // 0x4f0(0x08)

	void ShowInvitation(struct UKSPlayerInfo* playerinfo, struct FClientQueueInfo QueueInfo); // Function KillstreakUINew.KSMatchInvitationModal.ShowInvitation // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x2587100
	void ShowError(struct FText ErrorMessage); // Function KillstreakUINew.KSMatchInvitationModal.ShowError // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x2587100
	void OnInvitationExpired(); // Function KillstreakUINew.KSMatchInvitationModal.OnInvitationExpired // (Final|Native|Private) // @ game+0x220dc30
	void HandleReceivePlayerName(struct UPUMG_PlayerInfo* playerinfo); // Function KillstreakUINew.KSMatchInvitationModal.HandleReceivePlayerName // (Final|Native|Private) // @ game+0x220d4a0
	struct UKSQueueDataFactory* GetQueueDataFactory(); // Function KillstreakUINew.KSMatchInvitationModal.GetQueueDataFactory // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x220d1b0
	float GetInvitationTotalTimeToExpire(); // Function KillstreakUINew.KSMatchInvitationModal.GetInvitationTotalTimeToExpire // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x220d070
	float GetInvitationTimeRemaining(); // Function KillstreakUINew.KSMatchInvitationModal.GetInvitationTimeRemaining // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x220d040
	void DeclineInvite(); // Function KillstreakUINew.KSMatchInvitationModal.DeclineInvite // (Final|Native|Protected|BlueprintCallable) // @ game+0x220cd10
	void CloseScreen(); // Function KillstreakUINew.KSMatchInvitationModal.CloseScreen // (Final|Native|Protected|BlueprintCallable) // @ game+0x220ccf0
	void AcceptInvite(int32_t MapId); // Function KillstreakUINew.KSMatchInvitationModal.AcceptInvite // (Final|Native|Protected|BlueprintCallable) // @ game+0x220c530
};

// Class KillstreakUINew.KSMatchResult
// Size: 0x528 (Inherited: 0x4e0)
struct UKSMatchResult : UKSWidget {
	char UnknownData_4E0[0xc]; // 0x4e0(0x0c)
	float FinalResultEndTime; // 0x4ec(0x04)
	struct FRoundResultAnnoucement RoundResultAnnoucement; // 0x4f0(0x20)
	int32_t pTeamNum; // 0x510(0x04)
	int32_t pOpposeTeamNum; // 0x514(0x04)
	int32_t pTeamScore; // 0x518(0x04)
	int32_t pOpposeTeamScore; // 0x51c(0x04)
	bool bIsEndOfMatch; // 0x520(0x01)
	bool bMatchEndedInSurrender; // 0x521(0x01)
	char UnknownData_522[0x6]; // 0x522(0x06)

	void UpdateRoundBaseScore(struct AKSGameState_RoundGame* pGameState); // Function KillstreakUINew.KSMatchResult.UpdateRoundBaseScore // (Final|Native|Protected|BlueprintCallable) // @ game+0x220e540
	void UpdateResultStatus(enum class EGameResult Result, struct FText Status); // Function KillstreakUINew.KSMatchResult.UpdateResultStatus // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x220e430
	void ProcessResultAnnoucement(enum class EGameResult Result); // Function KillstreakUINew.KSMatchResult.ProcessResultAnnoucement // (Final|Native|Protected|BlueprintCallable) // @ game+0x220ddd0
	void HandleResultReceived(struct FRoundResultAnnoucement ResultAnnoucement); // Function KillstreakUINew.KSMatchResult.HandleResultReceived // (Native|Event|Public|BlueprintEvent) // @ game+0x220d520
	void HandleEndOfMatch(); // Function KillstreakUINew.KSMatchResult.HandleEndOfMatch // (Final|Native|Protected|BlueprintCallable) // @ game+0x220d480
	void GetTeamNames(struct FText pTeamName, struct FText pOpposingTeamName); // Function KillstreakUINew.KSMatchResult.GetTeamNames // (Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x220d310
	void GetSurrenderText(struct FText pSurrenderText); // Function KillstreakUINew.KSMatchResult.GetSurrenderText // (Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x220d240
};

// Class KillstreakUINew.KSMediaPlayerWidget
// Size: 0x538 (Inherited: 0x4e0)
struct UKSMediaPlayerWidget : UKSWidget {
	struct TSoftObjectPtr<struct UDataTable> MediaPlayerPlaylistEntries; // 0x4e0(0x28)
	char UnknownData_508[0x30]; // 0x508(0x30)

	void UIX_SkipEntry(); // Function KillstreakUINew.KSMediaPlayerWidget.UIX_SkipEntry // (Final|Native|Public|BlueprintCallable) // @ game+0x220e140
	void OnShouldShowPromptChanged(bool bCanSkipEntry); // Function KillstreakUINew.KSMediaPlayerWidget.OnShouldShowPromptChanged // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnReadyForPlayback(struct UPlatformMediaSource* PlatformMediaSource, struct UAkAudioEvent* PlayEvent, struct UAkAudioEvent* StopEvent); // Function KillstreakUINew.KSMediaPlayerWidget.OnReadyForPlayback // (Native|Event|Public|BlueprintEvent) // @ game+0x220dc50
	void OnEndLoadingPlaylist(); // Function KillstreakUINew.KSMediaPlayerWidget.OnEndLoadingPlaylist // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnBeginLoadingPlaylist(); // Function KillstreakUINew.KSMediaPlayerWidget.OnBeginLoadingPlaylist // (Event|Public|BlueprintEvent) // @ game+0x2587100
	bool IsCurrentEntrySkippable(); // Function KillstreakUINew.KSMediaPlayerWidget.IsCurrentEntrySkippable // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x220d820
};

// Class KillstreakUINew.KSMercManager
// Size: 0x30 (Inherited: 0x28)
struct UKSMercManager : UObject {
	struct APUMG_HUD* MyHud; // 0x28(0x08)

	void Uninitialize(); // Function KillstreakUINew.KSMercManager.Uninitialize // (Native|Public) // @ game+0x2107f20
	bool IsItemEquippedInSlot(struct UKSItem* CosmeticItem, enum class EMercCosmeticSlot eSlot, int32_t SlotPosition, struct UKSJobItem* JobItem); // Function KillstreakUINew.KSMercManager.IsItemEquippedInSlot // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x220d9f0
	bool IsItemEquippedInAnySlot(struct UKSItem* CosmeticItem, enum class EMercCosmeticSlot eSlot, struct TArray<int32_t> SlotPosition, struct UKSJobItem* JobItem); // Function KillstreakUINew.KSMercManager.IsItemEquippedInAnySlot // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x220d860
	void Initialize(struct APUMG_HUD* InHud); // Function KillstreakUINew.KSMercManager.Initialize // (Native|Public) // @ game+0x220d790
	struct UKSLoadoutDataFactory* GetLoadoutDataFactory(); // Function KillstreakUINew.KSMercManager.GetLoadoutDataFactory // (Final|Native|Protected|Const) // @ game+0x220d0d0
	bool GetEquippedCosmeticItemBySlot(enum class EMercCosmeticSlot eSlot, int32_t SlotPosition, struct UKSJobItem* JobItem, struct UKSItem* CosmeticItem); // Function KillstreakUINew.KSMercManager.GetEquippedCosmeticItemBySlot // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x220cec0
	bool EquipCosmeticItemToSlot(enum class EMercCosmeticSlot eSlot, int32_t SlotPosition, struct UKSJobItem* JobItem, struct UKSItem* CosmeticItem, bool bGlobal); // Function KillstreakUINew.KSMercManager.EquipCosmeticItemToSlot // (Final|Native|Public|BlueprintCallable) // @ game+0x220cd30
	void ClearCosmeticItemOnSlot(enum class EMercCosmeticSlot eSlot, int32_t SlotPosition, struct UKSJobItem* JobItem, bool bGlobal); // Function KillstreakUINew.KSMercManager.ClearCosmeticItemOnSlot // (Final|Native|Public|BlueprintCallable) // @ game+0x220ca40
};

// Class KillstreakUINew.KSMinimapWidgetBase
// Size: 0x630 (Inherited: 0x620)
struct UKSMinimapWidgetBase : UKSMapWidgetBase {
	float MinimapRepresentedWidth; // 0x618(0x04)
	float BackgroundWidth; // 0x61c(0x04)
	enum class EMinimapWidgetClampStyle ClampStyle; // 0x620(0x01)
	char UnknownData_629[0x7]; // 0x629(0x07)

	void UpdateMapMaterialTransform(struct UMaterialInstanceDynamic* MapMaterial, float NormalizedX, float NormalizedY, float Rotation, float Scale); // Function KillstreakUINew.KSMinimapWidgetBase.UpdateMapMaterialTransform // (Final|Native|Public|BlueprintCallable) // @ game+0x220e2a0
};

// Class KillstreakUINew.KSModelViewer
// Size: 0x28 (Inherited: 0x28)
struct UKSModelViewer : UObject {

	void ViewModelByName(struct UObject* WorldContextObject, struct FName InTargetItem, struct UDataTable* InDataTable); // Function KillstreakUINew.KSModelViewer.ViewModelByName // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x220e8f0
	void ViewModelAttachment(struct UObject* WorldContextObject, struct UKSWeaponAttachment* InAttachment, struct FName InSpawnOnActorName, enum class None Slot); // Function KillstreakUINew.KSModelViewer.ViewModelAttachment // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x220e7c0
	void ViewModel(struct UObject* WorldContextObject, struct UKSItem* InItem, struct FName InSpawnOnActorName, enum class EWeaponStateNew DefaultWeaponState, bool InScaleToFitTargetActor, struct FRotator InDefaultRotation, bool InBindControllerToSpawner); // Function KillstreakUINew.KSModelViewer.ViewModel // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x220e5c0
	void UnbindControllerFromSpawner(struct UObject* WorldContextObject, struct FName InSpawnActorName); // Function KillstreakUINew.KSModelViewer.UnbindControllerFromSpawner // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x220e1d0
	void UnbindAllControllersFromSpawners(struct UObject* WorldContextObject); // Function KillstreakUINew.KSModelViewer.UnbindAllControllersFromSpawners // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x220e160
	void SetAnimation(struct UObject* WorldContextObject, struct UAnimSequence* InAnim, struct FName InSpawnOnActorName, bool bLooping); // Function KillstreakUINew.KSModelViewer.SetAnimation // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x220de70
	void HideModelAttachment(struct UObject* WorldContextObject, struct FName InSpawnOnActorName, enum class None Slot); // Function KillstreakUINew.KSModelViewer.HideModelAttachment // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x220d6a0
	void ClearModelAttachments(struct UObject* WorldContextObject, struct FName InSpawnOnActorName); // Function KillstreakUINew.KSModelViewer.ClearModelAttachments // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x220cc40
	void ClearModel(struct UObject* WorldContextObject, struct FName InSpawnOnActorName); // Function KillstreakUINew.KSModelViewer.ClearModel // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x220cb90
	bool BindDelForWeaponModelSet(struct UObject* WorldContextObject, struct FName InSpawnOnActorName, struct FDelegate InEventCallback); // Function KillstreakUINew.KSModelViewer.BindDelForWeaponModelSet // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x220c700
	void BindControllerToSpawner(struct UObject* WorldContextObject, struct FName InSpawnActorName); // Function KillstreakUINew.KSModelViewer.BindControllerToSpawner // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x220c650
};

// Class KillstreakUINew.KSModWidget_DetectEnemy
// Size: 0x4f8 (Inherited: 0x4e0)
struct UKSModWidget_DetectEnemy : UKSWidget {
	char UnknownData_4E0[0x18]; // 0x4e0(0x18)

	void OnDetectChanged(struct UKSModInst_DetectEnemy* DetectEnemyModInst, bool bIsDetectingEnemy); // Function KillstreakUINew.KSModWidget_DetectEnemy.OnDetectChanged // (Final|Native|Private) // @ game+0x220db60
	struct UHorizontalBox* GetIconBox(); // Function KillstreakUINew.KSModWidget_DetectEnemy.GetIconBox // (Event|Public|BlueprintEvent) // @ game+0x2587100
};

// Class KillstreakUINew.KSModWidgetInterface
// Size: 0x28 (Inherited: 0x28)
struct UKSModWidgetInterface : UInterface {

	bool RemoveModInstance(struct UKSPlayerModInstance* InInstance); // Function KillstreakUINew.KSModWidgetInterface.RemoveModInstance // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2203df0
	bool AddModInstance(struct UKSPlayerModInstance* InInstance); // Function KillstreakUINew.KSModWidgetInterface.AddModInstance // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x220c5b0
};

// Class KillstreakUINew.KSNavTabWidget
// Size: 0x520 (Inherited: 0x4e0)
struct UKSNavTabWidget : UKSWidget {
	struct FMulticastInlineDelegate OnNavTabSelected; // 0x4e0(0x10)
	struct FMulticastInlineDelegate OnNavTabUnselected; // 0x4f0(0x10)
	bool bSelected; // 0x500(0x01)
	bool bDisabled; // 0x501(0x01)
	char UnknownData_502[0x6]; // 0x502(0x06)
	struct FText NavText; // 0x508(0x18)

	void UnselectNavTab(); // Function KillstreakUINew.KSNavTabWidget.UnselectNavTab // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x220e280
	void SetSelected(bool bNewSelected); // Function KillstreakUINew.KSNavTabWidget.SetSelected // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x21f8320
	void SetDisabled(bool bNewDisabled); // Function KillstreakUINew.KSNavTabWidget.SetDisabled // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x21f8040
	void SelectNavTab(); // Function KillstreakUINew.KSNavTabWidget.SelectNavTab // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x21f40b0
	bool IsSelected(); // Function KillstreakUINew.KSNavTabWidget.IsSelected // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x220db40
	bool IsDisabled(); // Function KillstreakUINew.KSNavTabWidget.IsDisabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x220d840
};

// Class KillstreakUINew.KSNewsRotatorData
// Size: 0x90 (Inherited: 0x70)
struct UKSNewsRotatorData : UKSJsonData {
	struct UTexture2DDynamic* Image; // 0x70(0x08)
	enum class ENewsActions PanelAction; // 0x78(0x01)
	char UnknownData_79[0x7]; // 0x79(0x07)
	struct FString ActionDetails; // 0x80(0x10)
};

// Class KillstreakUINew.KSNewsRotatorWidget
// Size: 0x4f8 (Inherited: 0x4e0)
struct UKSNewsRotatorWidget : UKSWidget {
	struct FString JsonSection; // 0x4e0(0x10)
	float TimePerSection; // 0x4f0(0x04)
	char UnknownData_4F4[0x4]; // 0x4f4(0x04)

	bool ShouldShowPanel(struct UKSNewsRotatorData* Panel); // Function KillstreakUINew.KSNewsRotatorWidget.ShouldShowPanel // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x220e050
	void OnJsonChanged(); // Function KillstreakUINew.KSNewsRotatorWidget.OnJsonChanged // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	struct TArray<struct UKSNewsRotatorData*> GetPanelData(); // Function KillstreakUINew.KSNewsRotatorWidget.GetPanelData // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x220d100
	struct UKSJsonDataFactory* GetJsonDataFactory(); // Function KillstreakUINew.KSNewsRotatorWidget.GetJsonDataFactory // (Final|Native|Private|BlueprintCallable|BlueprintPure) // @ game+0x220d0a0
};

// Class KillstreakUINew.KSNPEDataFactory
// Size: 0x38 (Inherited: 0x38)
struct UKSNPEDataFactory : UPUMG_DataFactory {

	void UIX_ClaimTutorialActivity(); // Function KillstreakUINew.KSNPEDataFactory.UIX_ClaimTutorialActivity // (Final|Native|Public|BlueprintCallable) // @ game+0x220e120
	void UIX_ClaimRegionSelectedActivity(); // Function KillstreakUINew.KSNPEDataFactory.UIX_ClaimRegionSelectedActivity // (Final|Native|Public|BlueprintCallable) // @ game+0x220e100
	void SkipTutorial(); // Function KillstreakUINew.KSNPEDataFactory.SkipTutorial // (Final|Native|Protected|BlueprintCallable) // @ game+0x220e0e0
	bool ShouldForceTutorial(); // Function KillstreakUINew.KSNPEDataFactory.ShouldForceTutorial // (Final|Native|Protected|BlueprintCallable) // @ game+0x220e020
	void QueueTutorial(); // Function KillstreakUINew.KSNPEDataFactory.QueueTutorial // (Final|Native|Protected|BlueprintCallable) // @ game+0x220de50
	bool HasClaimedActivity(enum class EKSNPEActivityType ActivityType); // Function KillstreakUINew.KSNPEDataFactory.HasClaimedActivity // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x220d610
	struct UKSQueueDataFactory* GetQueueDataFactory(); // Function KillstreakUINew.KSNPEDataFactory.GetQueueDataFactory // (Final|Native|Protected) // @ game+0x220d1e0
	void ClaimActivity(enum class EKSNPEActivityType ActivityType); // Function KillstreakUINew.KSNPEDataFactory.ClaimActivity // (Final|Native|Protected) // @ game+0x220c9c0
};

// Class KillstreakUINew.KSPartyDataFactory
// Size: 0x1a0 (Inherited: 0x178)
struct UKSPartyDataFactory : UPUMG_PartyDataFactory {
	struct FMulticastInlineDelegate OnEmoteMessageReceived; // 0x178(0x10)
	char UnknownData_188[0x18]; // 0x188(0x18)

	void SetSelectedQueueId(int32_t QueueId); // Function KillstreakUINew.KSPartyDataFactory.SetSelectedQueueId // (Final|Native|Public|BlueprintCallable) // @ game+0x220dfa0
	void PlayEmoteInParty(struct UKSEmote* Emote); // Function KillstreakUINew.KSPartyDataFactory.PlayEmoteInParty // (Final|Native|Public|BlueprintCallable) // @ game+0x220dd50
	int32_t GetSelectedQueueId(); // Function KillstreakUINew.KSPartyDataFactory.GetSelectedQueueId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x220d210
	int32_t GetPartyMinimumLevel(); // Function KillstreakUINew.KSPartyDataFactory.GetPartyMinimumLevel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x220d180
	int32_t GetHighestDeserterPenaltySeconds(); // Function KillstreakUINew.KSPartyDataFactory.GetHighestDeserterPenaltySeconds // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x220d010
	bool CanPartyQueueForRanked(struct FString RankedSeasonKey); // Function KillstreakUINew.KSPartyDataFactory.CanPartyQueueForRanked // (Final|Native|Public|BlueprintCallable) // @ game+0x220c910
	void BroadcastPartyInvitationError(struct FText InvitationError); // Function KillstreakUINew.KSPartyDataFactory.BroadcastPartyInvitationError // (Final|Native|Public|BlueprintCallable) // @ game+0x220c830
};

// Class KillstreakUINew.KSPartyManagerWidgetBase
// Size: 0x4f0 (Inherited: 0x4e0)
struct UKSPartyManagerWidgetBase : UKSWidget {
	struct TArray<struct FPUMG_PartyMemberData> CachedDisplayedPartyMembers; // 0x4e0(0x10)

	void RefreshFromPartyData(); // Function KillstreakUINew.KSPartyManagerWidgetBase.RefreshFromPartyData // (Final|Native|Protected|BlueprintCallable) // @ game+0x2212b10
	void HandlePartyMemberUpdateByName(struct FText PlayerName); // Function KillstreakUINew.KSPartyManagerWidgetBase.HandlePartyMemberUpdateByName // (Final|Native|Protected) // @ game+0x2212100
	void HandlePartyMemberUpdateByInfo(struct UPUMG_PlayerInfo* playerinfo); // Function KillstreakUINew.KSPartyManagerWidgetBase.HandlePartyMemberUpdateByInfo // (Final|Native|Protected) // @ game+0x2212080
	void HandlePartyMemberUpdateById(int64_t PlayerId); // Function KillstreakUINew.KSPartyManagerWidgetBase.HandlePartyMemberUpdateById // (Final|Native|Protected) // @ game+0x2212080
	void HandlePartyMemberDataUpdated(struct FPUMG_PartyMemberData MemberData); // Function KillstreakUINew.KSPartyManagerWidgetBase.HandlePartyMemberDataUpdated // (Final|Native|Protected) // @ game+0x2211f50
	struct UPUMG_PlayerInfo* GetSuggestedInvite(); // Function KillstreakUINew.KSPartyManagerWidgetBase.GetSuggestedInvite // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x1b19530
	struct UKSPartyDataFactory* GetPartyDataFactory(); // Function KillstreakUINew.KSPartyManagerWidgetBase.GetPartyDataFactory // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x2211a90
	struct TArray<struct FPUMG_PartyMemberData> GetCachedDisplayedPartyMembers(); // Function KillstreakUINew.KSPartyManagerWidgetBase.GetCachedDisplayedPartyMembers // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x2211800
	void ApplyPartyData(struct TArray<struct FPUMG_PartyMemberData> PartyMembers); // Function KillstreakUINew.KSPartyManagerWidgetBase.ApplyPartyData // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x2587100
	void ApplyEmptyPartyData(); // Function KillstreakUINew.KSPartyManagerWidgetBase.ApplyEmptyPartyData // (Final|Native|Protected|BlueprintCallable) // @ game+0x2211140
};

// Class KillstreakUINew.KSPerkTreeBase
// Size: 0x520 (Inherited: 0x4e0)
struct UKSPerkTreeBase : UKSWidget {
	struct FMulticastInlineDelegate OnPerkHovered; // 0x4e0(0x10)
	struct FMulticastInlineDelegate OnPerkSelected; // 0x4f0(0x10)
	struct FMulticastInlineDelegate OnPerkUnlockRequest; // 0x500(0x10)
	struct UWidget* HoverTarget; // 0x510(0x08)
	char UnknownData_518[0x8]; // 0x518(0x08)

	void SetCursorLerping(bool bLerping); // Function KillstreakUINew.KSPerkTreeBase.SetCursorLerping // (Final|Native|Protected|BlueprintCallable) // @ game+0x2212c90
	void RefreshEdge(struct UKSPerkTreeEdgeBase* Edge, int32_t column, int32_t Row, struct TMap<struct FIntPoint, struct UKSPerkTreeNodeBase*> NodesMap); // Function KillstreakUINew.KSPerkTreeBase.RefreshEdge // (Final|Native|Protected|BlueprintCallable) // @ game+0x2212900
	struct TMap<struct FIntPoint, struct UKSPerkTreeNodeBase*> InitializeNodes(); // Function KillstreakUINew.KSPerkTreeBase.InitializeNodes // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleTreeNodeSelected(struct UKSPerkTreeNodeBase* SelectedNode, struct FCustomLoadoutItem SelectedPerk, bool bAlreadyEquipped); // Function KillstreakUINew.KSPerkTreeBase.HandleTreeNodeSelected // (Final|Native|Public) // @ game+0x22126d0
	void HandleTreeNodeHovered(struct UKSPerkTreeNodeBase* HoveredNode, struct FCustomLoadoutItem HoveredPerk); // Function KillstreakUINew.KSPerkTreeBase.HandleTreeNodeHovered // (Final|Native|Public) // @ game+0x22125e0
	struct UWidget* GetHoverCursor(); // Function KillstreakUINew.KSPerkTreeBase.GetHoverCursor // (Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	struct UKSPerkTreeNodeBase* GetDefaultFocusNode(); // Function KillstreakUINew.KSPerkTreeBase.GetDefaultFocusNode // (Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void BindNode(struct UKSPerkTreeNodeBase* TreeNode); // Function KillstreakUINew.KSPerkTreeBase.BindNode // (Final|Native|Public|BlueprintCallable) // @ game+0x2211160
};

// Class KillstreakUINew.KSPerkTreeEdgeBase
// Size: 0x4f8 (Inherited: 0x4e0)
struct UKSPerkTreeEdgeBase : UKSWidget {
	bool bTopEnabled; // 0x4e0(0x01)
	bool bLeftEnabled; // 0x4e1(0x01)
	bool bDiagonalEnabled; // 0x4e2(0x01)
	bool bBackDiagonalEnabled; // 0x4e3(0x01)
	struct FLinearColor AccentColor; // 0x4e4(0x10)
	char UnknownData_4F4[0x4]; // 0x4f4(0x04)

	void SetViewByState(struct FKSPerkTreeEdgeInfo EdgeInfo); // Function KillstreakUINew.KSPerkTreeEdgeBase.SetViewByState // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

// Class KillstreakUINew.KSPerkTreeNodeBase
// Size: 0x540 (Inherited: 0x4e0)
struct UKSPerkTreeNodeBase : UKSWidget {
	struct TSoftObjectPtr<struct UKSPlayerMod> AssignedPerk; // 0x4e0(0x28)
	struct FMulticastInlineDelegate OnTreeNodeHovered; // 0x508(0x10)
	struct FMulticastInlineDelegate OnTreeNodeSelected; // 0x518(0x10)
	struct FMulticastInlineDelegate OnRequestPerkPurchase; // 0x528(0x10)
	bool bIsPlaceholder; // 0x538(0x01)
	enum class EPerkTreeNodeState NodeState; // 0x539(0x01)
	char UnknownData_53A[0x6]; // 0x53a(0x06)

	void SetNodeState(enum class EPerkTreeNodeState NewNodeState); // Function KillstreakUINew.KSPerkTreeNodeBase.SetNodeState // (Final|Native|Public|BlueprintCallable) // @ game+0x2212d20
	void RefreshView(); // Function KillstreakUINew.KSPerkTreeNodeBase.RefreshView // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	enum class EPerkTreeNodeState GetNodeState(); // Function KillstreakUINew.KSPerkTreeNodeBase.GetNodeState // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2211a60
};

// Class KillstreakUINew.KSViewedActiveWeaponWidget
// Size: 0x4f8 (Inherited: 0x4e8)
struct UKSViewedActiveWeaponWidget : UKSWeaponWidget {
	char UnknownData_4E8[0x10]; // 0x4e8(0x10)
};

// Class KillstreakUINew.KSPlayerAmmoLoaderWidget
// Size: 0x610 (Inherited: 0x4f8)
struct UKSPlayerAmmoLoaderWidget : UKSViewedActiveWeaponWidget {
	SoftClassProperty PendingAmmoWidgetClass; // 0x4f8(0x28)
	struct UKSAmmoWidget* LoadedAmmoWidgetClass; // 0x520(0x08)
	char UnknownData_528[0xe8]; // 0x528(0xe8)

	void SetActiveAmmoWidget(struct UKSAmmoWidget* NewWidgetClass, struct AKSWeapon* NewWeapon); // Function KillstreakUINew.KSPlayerAmmoLoaderWidget.SetActiveAmmoWidget // (Native|Event|Protected|BlueprintEvent) // @ game+0x2212bc0
	struct UKSAmmoWidget* GetActiveAmmoWidget(); // Function KillstreakUINew.KSPlayerAmmoLoaderWidget.GetActiveAmmoWidget // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x22114e0
	void ClearActiveAmmoWidget(); // Function KillstreakUINew.KSPlayerAmmoLoaderWidget.ClearActiveAmmoWidget // (Native|Event|Protected|BlueprintEvent) // @ game+0x21f4090
};

// Class KillstreakUINew.KSPlayerAwardsPanelWidget
// Size: 0x4e0 (Inherited: 0x4e0)
struct UKSPlayerAwardsPanelWidget : UKSWidget {

	void GetSortedRecentlyProgressedData(struct TArray<struct FPlayerAwardsPanelData> AwardData, struct TArray<struct FPlayerAwardsPanelData> RecentlyProgressedData); // Function KillstreakUINew.KSPlayerAwardsPanelWidget.GetSortedRecentlyProgressedData // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2211cb0
	void GetActivityAwardData(struct TArray<struct FPlayerAwardsPanelData> AwardData); // Function KillstreakUINew.KSPlayerAwardsPanelWidget.GetActivityAwardData // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2211510
};

// Class KillstreakUINew.KSPlayerCardModuleBase
// Size: 0x4f0 (Inherited: 0x4e0)
struct UKSPlayerCardModuleBase : UKSWidget {
	struct UPUMG_PlayerInfo* AssignedPlayerInfo; // 0x4e0(0x08)
	char UnknownData_4E8[0x8]; // 0x4e8(0x08)

	void View_SetPlayer(struct UPUMG_PlayerInfo* playerinfo, enum class EKSPlayerOnlineStatus PlayerStatus, bool IsPortalFriend, bool IsPending); // Function KillstreakUINew.KSPlayerCardModuleBase.View_SetPlayer // (Native|Public|BlueprintCallable) // @ game+0x2212e50
	void OnPlayerUpdate(struct UPUMG_PlayerInfo* playerinfo, enum class EKSPlayerOnlineStatus PlayerStatus, bool IsPortalFriend, bool IsPending); // Function KillstreakUINew.KSPlayerCardModuleBase.OnPlayerUpdate // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandlePlayerDataUpdated(struct UPUMG_PlayerInfo* playerinfo); // Function KillstreakUINew.KSPlayerCardModuleBase.HandlePlayerDataUpdated // (Final|Native|Protected) // @ game+0x22121e0
};

// Class KillstreakUINew.KSPlayerCosmeticWidget
// Size: 0x4e0 (Inherited: 0x4e0)
struct UKSPlayerCosmeticWidget : UKSWidget {

	bool GetTitleItems(struct TArray<struct UPUMG_StoreItem*> TitlesItems); // Function KillstreakUINew.KSPlayerCosmeticWidget.GetTitleItems // (Final|Native|Protected|HasOutParms) // @ game+0x2211e00
	struct TArray<struct UPUMG_StoreItem*> GetItemsForSlot(enum class EPlayerAccountSlot SlotType); // Function KillstreakUINew.KSPlayerCosmeticWidget.GetItemsForSlot // (Final|Native|Protected|BlueprintCallable) // @ game+0x2211990
	struct UKSStoreItemHelper* GetItemHelper(); // Function KillstreakUINew.KSPlayerCosmeticWidget.GetItemHelper // (Final|Native|Protected|BlueprintCallable) // @ game+0x21f7360
	bool GetBorderItems(struct TArray<struct UPUMG_StoreItem*> BorderItems); // Function KillstreakUINew.KSPlayerCosmeticWidget.GetBorderItems // (Final|Native|Protected|HasOutParms) // @ game+0x2211740
	bool GetBannerItems(struct TArray<struct UPUMG_StoreItem*> BannerItems); // Function KillstreakUINew.KSPlayerCosmeticWidget.GetBannerItems // (Final|Native|Protected|HasOutParms) // @ game+0x2211680
	bool GetAvatarItems(struct TArray<struct UPUMG_StoreItem*> AvatarItems); // Function KillstreakUINew.KSPlayerCosmeticWidget.GetAvatarItems // (Final|Native|Protected|HasOutParms) // @ game+0x22115c0
};

// Class KillstreakUINew.KSPlayerDataFactory
// Size: 0xc8 (Inherited: 0xb0)
struct UKSPlayerDataFactory : UPUMG_PlayerDataFactory {
	struct UKSPlayerStatsManager* PlayerStatsManager; // 0xb0(0x08)
	struct FMulticastInlineDelegate OnPlayerLevelChanged; // 0xb8(0x10)

	bool ShouldDisplayRankedLevel(); // Function KillstreakUINew.KSPlayerDataFactory.ShouldDisplayRankedLevel // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2212e20
	void HandlePlayerRankIncremented(struct UKSActivityInstance* ActivityInstance, int32_t Count); // Function KillstreakUINew.KSPlayerDataFactory.HandlePlayerRankIncremented // (Final|Native|Protected) // @ game+0x2212520
	void HandlePlayerRankChanged(struct UKSActivityInstance* Activity, int32_t Tier, int32_t Count); // Function KillstreakUINew.KSPlayerDataFactory.HandlePlayerRankChanged // (Final|Native|Protected) // @ game+0x2212420
	void HandlePlayerLevelIncremented(struct UKSActivityInstance* ActivityInstance, int32_t Count); // Function KillstreakUINew.KSPlayerDataFactory.HandlePlayerLevelIncremented // (Final|Native|Protected) // @ game+0x2212360
	void HandlePlayerLevelChanged(struct UKSActivityInstance* Activity, int32_t Tier, int32_t Count); // Function KillstreakUINew.KSPlayerDataFactory.HandlePlayerLevelChanged // (Final|Native|Protected) // @ game+0x2212260
	int32_t GetRogueBucksCount(); // Function KillstreakUINew.KSPlayerDataFactory.GetRogueBucksCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2211c80
	int32_t GetReputationCount(); // Function KillstreakUINew.KSPlayerDataFactory.GetReputationCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2211c50
	int32_t GetRankedLevel(); // Function KillstreakUINew.KSPlayerDataFactory.GetRankedLevel // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2211c20
	float GetPlayerLevelPercent(); // Function KillstreakUINew.KSPlayerDataFactory.GetPlayerLevelPercent // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2211bb0
	int32_t GetPlayerLevel(); // Function KillstreakUINew.KSPlayerDataFactory.GetPlayerLevel // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2211b80
	int32_t GetPlayerId(); // Function KillstreakUINew.KSPlayerDataFactory.GetPlayerId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2211b60
	int32_t GetPlayerBannerIndex(); // Function KillstreakUINew.KSPlayerDataFactory.GetPlayerBannerIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2211b30
};

// Class KillstreakUINew.KSPlayerHealthSegmentBase
// Size: 0x4e0 (Inherited: 0x4e0)
struct UKSPlayerHealthSegmentBase : UKSWidget {

	void View_SetResidualValue(float PercentValue); // Function KillstreakUINew.KSPlayerHealthSegmentBase.View_SetResidualValue // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void View_SetResidualColor(struct FLinearColor Color); // Function KillstreakUINew.KSPlayerHealthSegmentBase.View_SetResidualColor // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void View_SetMainValue(float PercentValue, bool bCanTriggerPulse); // Function KillstreakUINew.KSPlayerHealthSegmentBase.View_SetMainValue // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void View_SetMainColor(struct FLinearColor Color); // Function KillstreakUINew.KSPlayerHealthSegmentBase.View_SetMainColor // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void View_PlayEmptiedPulse(); // Function KillstreakUINew.KSPlayerHealthSegmentBase.View_PlayEmptiedPulse // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void View_PlayDamagePulse(struct FLinearColor PeakColor, struct FLinearColor BaseColor); // Function KillstreakUINew.KSPlayerHealthSegmentBase.View_PlayDamagePulse // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

// Class KillstreakUINew.KSViewedTargetHealthWidget
// Size: 0x530 (Inherited: 0x520)
struct UKSViewedTargetHealthWidget : UKSHealthWidget {
	char UnknownData_520[0x10]; // 0x520(0x10)
};

// Class KillstreakUINew.KSPlayerHealthWidgetBase
// Size: 0x560 (Inherited: 0x530)
struct UKSPlayerHealthWidgetBase : UKSViewedTargetHealthWidget {
	struct FPlayerHealthMeterState CurrentHealthMeterState; // 0x530(0x18)
	char UnknownData_548[0x18]; // 0x548(0x18)

	void View_SetResidualPercent(float ResidualPercent); // Function KillstreakUINew.KSPlayerHealthWidgetBase.View_SetResidualPercent // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void View_SetResidualMode(bool IsHealing); // Function KillstreakUINew.KSPlayerHealthWidgetBase.View_SetResidualMode // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void View_SetResidualAlpha(float ResidualAlpha); // Function KillstreakUINew.KSPlayerHealthWidgetBase.View_SetResidualAlpha // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void View_SetHealthTextValue(float HealthValue, float OverhealValue); // Function KillstreakUINew.KSPlayerHealthWidgetBase.View_SetHealthTextValue // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void View_SetHealthPercent(float HealthPercent); // Function KillstreakUINew.KSPlayerHealthWidgetBase.View_SetHealthPercent // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void View_SetHealthMode(bool IsDowned, bool IsOverhealed); // Function KillstreakUINew.KSPlayerHealthWidgetBase.View_SetHealthMode // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void View_PlayDamagePulse(); // Function KillstreakUINew.KSPlayerHealthWidgetBase.View_PlayDamagePulse // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void View_OnDeathStateChanged(); // Function KillstreakUINew.KSPlayerHealthWidgetBase.View_OnDeathStateChanged // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnJobChanged(struct UKSJobItem* Job); // Function KillstreakUINew.KSPlayerHealthWidgetBase.OnJobChanged // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnHealthMeterStateChanged(); // Function KillstreakUINew.KSPlayerHealthWidgetBase.OnHealthMeterStateChanged // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnHealthDecreased(); // Function KillstreakUINew.KSPlayerHealthWidgetBase.OnHealthDecreased // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void HandlePlayerDownedChanged(struct AKSPlayerState* pKSPlayerState); // Function KillstreakUINew.KSPlayerHealthWidgetBase.HandlePlayerDownedChanged // (Final|Native|Protected) // @ game+0x22167f0
	void HandleJobChanged(); // Function KillstreakUINew.KSPlayerHealthWidgetBase.HandleJobChanged // (Final|Native|Protected) // @ game+0x22161d0
	void HandleDeathStateChanged(); // Function KillstreakUINew.KSPlayerHealthWidgetBase.HandleDeathStateChanged // (Final|Native|Protected) // @ game+0x22161b0
};

// Class KillstreakUINew.JobSelectionEntryDetails
// Size: 0x60 (Inherited: 0x28)
struct UJobSelectionEntryDetails : UObject {
	struct FJobSelectionEntry JobEntry; // 0x28(0x28)
	struct UPUMG_StoreItem* StoreItem; // 0x50(0x08)
	bool AllowIfUnowned; // 0x58(0x01)
	char UnknownData_59[0x7]; // 0x59(0x07)

	bool IsSelf(); // Function KillstreakUINew.JobSelectionEntryDetails.IsSelf // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2216e20
	bool IsOwned(); // Function KillstreakUINew.JobSelectionEntryDetails.IsOwned // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2216df0
	struct FText GetJobName(); // Function KillstreakUINew.JobSelectionEntryDetails.GetJobName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2215af0
	struct UKSJobItem* GetJobItem(); // Function KillstreakUINew.JobSelectionEntryDetails.GetJobItem // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2215a30
};

// Class KillstreakUINew.KSPlayerJobSelectWidgetBase
// Size: 0x530 (Inherited: 0x4e0)
struct UKSPlayerJobSelectWidgetBase : UKSWidget {
	struct UKSJobSelectionManager* JobSelectionManager; // 0x4e0(0x08)
	struct UKSJobSelectionComponent* JobSelectionComponent; // 0x4e8(0x08)
	struct TArray<struct UJobSelectionEntryDetails*> JobDetailEntries; // 0x4f0(0x10)
	enum class EPlayerSelectionState CurrentPlayerSelectionState; // 0x500(0x01)
	char UnknownData_501[0x7]; // 0x501(0x07)
	struct TArray<struct UJobSelectionEntryDetails*> EnemyJobDetailsEntries; // 0x508(0x10)
	struct FWeakObjectPtr<struct UKSJobSelectionComponent> BoundEnemyJobSelectionComponent; // 0x518(0x08)
	struct FWeakObjectPtr<struct UKSJobSelectionComponent> BoundLocalJobSelectionComponent; // 0x520(0x08)
	char UnknownData_528[0x8]; // 0x528(0x08)

	bool UIX_RequestJobSelect(struct UJobSelectionEntryDetails* JobEntry, enum class EJobSelectionState RequestedState); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.UIX_RequestJobSelect // (Final|Native|Public|BlueprintCallable) // @ game+0x22178d0
	void OnResetSelection(); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.OnResetSelection // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnPlayerSelectionStateChanged(enum class EPlayerSelectionState NewState); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.OnPlayerSelectionStateChanged // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnJobEntryChanged(struct UJobSelectionEntryDetails* JobEntry, bool EnemyTeam); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.OnJobEntryChanged // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnJobEntriesReady(struct TArray<struct UJobSelectionEntryDetails*> JobEntries, bool EnemyTeam); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.OnJobEntriesReady // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x2587100
	void HandleTeamAddedToMatch(struct AKSTeamState* NewTeam); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.HandleTeamAddedToMatch // (Final|Native|Protected) // @ game+0x2216b30
	void HandleNewJobSelectionComponent(struct UKSJobSelectionComponent* NewJobSelectionComponent); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.HandleNewJobSelectionComponent // (Final|Native|Protected) // @ game+0x2216610
	void HandleJobSelectionManagerReady(struct UKSJobSelectionManager* JobSelectionManager); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.HandleJobSelectionManagerReady // (Final|Native|Protected) // @ game+0x2216590
	void HandleJobSelectionInitialized(); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.HandleJobSelectionInitialized // (Final|Native|Protected) // @ game+0x2216570
	void HandleJobEntryStateChangedForEnemies(struct FJobSelectionEntry JobEntry); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.HandleJobEntryStateChangedForEnemies // (Final|Native|Protected) // @ game+0x22164d0
	void HandleJobEntryStateChanged(struct FJobSelectionEntry JobEntry); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.HandleJobEntryStateChanged // (Final|Native|Protected) // @ game+0x2216430
	void HandleJobEntryAddedForEnemies(struct FJobSelectionEntry JobEntry); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.HandleJobEntryAddedForEnemies // (Final|Native|Protected) // @ game+0x2216390
	void HandleJobEntryAdded(struct FJobSelectionEntry JobEntry); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.HandleJobEntryAdded // (Final|Native|Protected) // @ game+0x22162f0
	void HandleJobEntryAcknowledge(int32_t ItemId, bool bSuccess, enum class EJobSelectionState RequestState); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.HandleJobEntryAcknowledge // (Final|Native|Protected) // @ game+0x22161f0
	struct UKSJobSelectionComponent* GetJobSelectionComponent(); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.GetJobSelectionComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x997620
	struct UKSJobItem* GetJobItemById(int32_t JobItemId); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.GetJobItemById // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2215a60
	void BindListenersForTeam(struct AKSTeamState* Team); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.BindListenersForTeam // (Final|Native|Public|BlueprintCallable) // @ game+0x20e7090
};

// Class KillstreakUINew.KSPlayerQueryDataFactory
// Size: 0x150 (Inherited: 0x38)
struct UKSPlayerQueryDataFactory : UPUMG_DataFactory {
	char UnknownData_38[0x100]; // 0x38(0x100)
	struct FTimerHandle CheckTimerHandle; // 0x138(0x08)
	char UnknownData_140[0x10]; // 0x140(0x10)

	bool QueryPlayersByNameWithProfiles(struct FText PlayerName, struct FDelegate OnReponse, struct FKSPlayerQueryHandle OutHandle); // Function KillstreakUINew.KSPlayerQueryDataFactory.QueryPlayersByNameWithProfiles // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2217120
	bool QueryPlayersByName(struct FText PlayerName, struct FDelegate OnReponse, struct FKSPlayerQueryHandle OutHandle); // Function KillstreakUINew.KSPlayerQueryDataFactory.QueryPlayersByName // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2216f80
	void OnTimeoutCheck(); // Function KillstreakUINew.KSPlayerQueryDataFactory.OnTimeoutCheck // (Final|Native|Protected) // @ game+0x2216ee0
	struct FText GetQueriedName(struct FKSPlayerQueryHandle InHandle); // Function KillstreakUINew.KSPlayerQueryDataFactory.GetQueriedName // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2215e30
	struct FText GetPlayerQueryErrorMessage(enum class EKSPlayerQueryError Error); // Function KillstreakUINew.KSPlayerQueryDataFactory.GetPlayerQueryErrorMessage // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2215cd0
	void CancelQuery(struct FKSPlayerQueryHandle InHandle); // Function KillstreakUINew.KSPlayerQueryDataFactory.CancelQuery // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2215840
};

// Class KillstreakUINew.KSPlayerShopWidgetBase
// Size: 0x4f8 (Inherited: 0x4e0)
struct UKSPlayerShopWidgetBase : UKSWidget {
	char UnknownData_4E0[0x8]; // 0x4e0(0x08)
	struct AKSPlayerShop* PlayerShop; // 0x4e8(0x08)
	char UnknownData_4F0[0x8]; // 0x4f0(0x08)

	void TriggerDisplayUpdate(bool ForceUpdate); // Function KillstreakUINew.KSPlayerShopWidgetBase.TriggerDisplayUpdate // (Final|Native|Public|BlueprintCallable) // @ game+0x2217840
	void ShopItemChanged(struct FShopItem ChangedItem); // Function KillstreakUINew.KSPlayerShopWidgetBase.ShopItemChanged // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x22176f0
	void SetShopState(bool IsOpen); // Function KillstreakUINew.KSPlayerShopWidgetBase.SetShopState // (Native|Event|Public|BlueprintEvent) // @ game+0x21f8320
	void SetShopContent(); // Function KillstreakUINew.KSPlayerShopWidgetBase.SetShopContent // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x21f4090
	void SetPromptShow(bool ShouldShowPrompt); // Function KillstreakUINew.KSPlayerShopWidgetBase.SetPromptShow // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void SetCashValue(int32_t CashValue); // Function KillstreakUINew.KSPlayerShopWidgetBase.SetCashValue // (Native|Event|Public|BlueprintEvent) // @ game+0x22172c0
	void PurchaseAcknowledge(enum class EShopItemType ShopItemType); // Function KillstreakUINew.KSPlayerShopWidgetBase.PurchaseAcknowledge // (Native|Event|Public|BlueprintEvent) // @ game+0x2216f00
	void HandleTeamsFlipped(); // Function KillstreakUINew.KSPlayerShopWidgetBase.HandleTeamsFlipped // (Final|Native|Protected) // @ game+0x22169d0
	void HandleShopOpened(); // Function KillstreakUINew.KSPlayerShopWidgetBase.HandleShopOpened // (Final|Native|Protected) // @ game+0x2216b10
	void HandleShopItemChanged(struct FShopItem ChangedItem); // Function KillstreakUINew.KSPlayerShopWidgetBase.HandleShopItemChanged // (Final|Native|Protected) // @ game+0x22169f0
	void HandleShopClosed(); // Function KillstreakUINew.KSPlayerShopWidgetBase.HandleShopClosed // (Final|Native|Protected) // @ game+0x22169d0
	void HandleShopAvailabilityChanged(bool bAvailable); // Function KillstreakUINew.KSPlayerShopWidgetBase.HandleShopAvailabilityChanged // (Final|Native|Protected) // @ game+0x2216940
	void HandlePurchaseAcknowledged(enum class EShopItemType ShopItemType, bool bSuccess); // Function KillstreakUINew.KSPlayerShopWidgetBase.HandlePurchaseAcknowledged // (Final|Native|Protected) // @ game+0x2216870
	void HandleCashChanged(int32_t Cash, int32_t Delta); // Function KillstreakUINew.KSPlayerShopWidgetBase.HandleCashChanged // (Final|Native|Protected) // @ game+0x2216030
	void CheckForValidPlayerState(); // Function KillstreakUINew.KSPlayerShopWidgetBase.CheckForValidPlayerState // (Final|Native|Protected) // @ game+0x22158e0
};

// Class KillstreakUINew.KSPlayerWhoDataFactory
// Size: 0x60 (Inherited: 0x60)
struct UKSPlayerWhoDataFactory : UPUMG_PlayerWhoDataFactory {

	void ClearSearchResults(); // Function KillstreakUINew.KSPlayerWhoDataFactory.ClearSearchResults // (Final|Native|Public|BlueprintCallable) // @ game+0x2215900
};

// Class KillstreakUINew.KSPointObjectiveMarkerWidget
// Size: 0x3a8 (Inherited: 0x318)
struct UKSPointObjectiveMarkerWidget : UKSMapIconWidgetBase {
	char UnknownData_318[0x90]; // 0x318(0x90)

	void ViewSetCaptureProgress(float ProgressPercent); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.ViewSetCaptureProgress // (Native|Event|Protected|BlueprintEvent) // @ game+0x2217990
	void ViewApplyTimerValue(float TimerSeconds, float TotalTimerSeconds); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.ViewApplyTimerValue // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	bool ShouldHideObjectiveIcon(); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.ShouldHideObjectiveIcon // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2217810
	void SetView(struct FKSPointObjectiveMarkerViewState ViewState); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.SetView // (Native|Event|Protected|BlueprintEvent) // @ game+0x2217650
	void SetTeamColorsForState(struct TMap<enum class EPointObjectiveMarkerTeamState, struct FLinearColor> StateColors); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.SetTeamColorsForState // (Final|Native|Protected|BlueprintCallable) // @ game+0x22174f0
	bool SetTeamColorForState(enum class EPointObjectiveMarkerTeamState ObjectiveState, struct FLinearColor StateColor); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.SetTeamColorForState // (Final|Native|Protected|HasDefaults|BlueprintCallable) // @ game+0x2217420
	void OnControlTeamScoreUpdated(struct AKSTeamState* TeamState); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.OnControlTeamScoreUpdated // (Native|Event|Protected|BlueprintEvent) // @ game+0x2216e50
	bool IsInTimerState(); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.IsInTimerState // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2216da0
	bool IsInProgressState(); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.IsInProgressState // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2216d40
	bool IsInMatchTimerState(); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.IsInMatchTimerState // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2216ce0
	bool IsInLockedState(); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.IsInLockedState // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2216c90
	bool IsInCountdownState(); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.IsInCountdownState // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2216c40
	bool IsInContestedState(); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.IsInContestedState // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2216c10
	bool IsInCapturedState(); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.IsInCapturedState // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2216bb0
	void HandlePhaseChanged(struct FName NewPhaseName, struct FName PreviousPhaseName); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.HandlePhaseChanged // (Final|Native|Protected) // @ game+0x2216730
	void HandleObjectiveStateChanged(struct TScriptInterface<None> Objective); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.HandleObjectiveStateChanged // (Final|Native|Protected) // @ game+0x2216690
	void HandleControlTeamScoreUpdated(struct AKSTeamState* TeamState, struct AKSControlPoint* ControlPoint); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.HandleControlTeamScoreUpdated // (Final|Native|Protected) // @ game+0x22160f0
	void HandleBombStateChanged(struct FKSNeutralBombState BombState); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.HandleBombStateChanged // (Final|Native|Protected) // @ game+0x2215f80
	bool GetTeamColorForState(struct FLinearColor TeamColor); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.GetTeamColorForState // (Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x2215ee0
	struct FKSPointObjectiveMarkerViewState GetCurrentViewState(); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.GetCurrentViewState // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2215a00
	struct AKSObjectiveBase* GetAssociatedObjective(); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.GetAssociatedObjective // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x22159d0
	bool DoesAttackingTeamExist(bool IsLocalPlayerOnAttackingTeam); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.DoesAttackingTeamExist // (Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x2215930
	void ControlPointStateUpdated(struct AKSControlPoint* Objective); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.ControlPointStateUpdated // (Native|Event|Protected|BlueprintEvent) // @ game+0x19dc0e0
};

// Class KillstreakUINew.KSPortalOffersWidget
// Size: 0x4e0 (Inherited: 0x4e0)
struct UKSPortalOffersWidget : UKSWidget {

	struct TArray<struct UPUMG_StoreItem*> GetPortalOfferItems(); // Function KillstreakUINew.KSPortalOffersWidget.GetPortalOfferItems // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2215db0
	struct UKSStoreItemHelper* GetItemHelper(); // Function KillstreakUINew.KSPortalOffersWidget.GetItemHelper // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x21f7360
};

// Class KillstreakUINew.KSProgressionTallyWidget
// Size: 0x650 (Inherited: 0x4e0)
struct UKSProgressionTallyWidget : UKSWidget {
	struct FPlayerProgression PlayerProgressionData; // 0x4e0(0x170)

	void SetPlayerProgressionData(struct FPlayerProgression PlayerProgression); // Function KillstreakUINew.KSProgressionTallyWidget.SetPlayerProgressionData // (Final|Native|Public|BlueprintCallable) // @ game+0x2217350
	void GetPlayerProgressionBreakdown(int32_t BaseXP, int32_t EventBonusXP, int32_t WinBonusXP); // Function KillstreakUINew.KSProgressionTallyWidget.GetPlayerProgressionBreakdown // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2215b90
};

// Class KillstreakUINew.KSProgressMeterWidgetBase
// Size: 0x500 (Inherited: 0x4e0)
struct UKSProgressMeterWidgetBase : UKSWidget {
	char UnknownData_4E0[0x20]; // 0x4e0(0x20)

	void SetDeltaAnimationParams(float BasePercent, float DeltaPercent, float AnimTime); // Function KillstreakUINew.KSProgressMeterWidgetBase.SetDeltaAnimationParams // (Final|Native|Protected|BlueprintCallable) // @ game+0x221c9d0
	void PlayDeltaAnimation(float StartDelay); // Function KillstreakUINew.KSProgressMeterWidgetBase.PlayDeltaAnimation // (Final|Native|Protected|BlueprintCallable) // @ game+0x221c6a0
	void OnDeltaAnimationTicked(); // Function KillstreakUINew.KSProgressMeterWidgetBase.OnDeltaAnimationTicked // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnDeltaAnimationStarted(); // Function KillstreakUINew.KSProgressMeterWidgetBase.OnDeltaAnimationStarted // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnDeltaAnimationFinished(bool bLevelChange); // Function KillstreakUINew.KSProgressMeterWidgetBase.OnDeltaAnimationFinished // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	bool IsPlayingDeltaAnimation(); // Function KillstreakUINew.KSProgressMeterWidgetBase.IsPlayingDeltaAnimation // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x221ac10
	void EnableDeltaAnimation(); // Function KillstreakUINew.KSProgressMeterWidgetBase.EnableDeltaAnimation // (Final|Native|Protected) // @ game+0x221a850
	void ApplyMeterPercentages_Raw(float BasePercent, float DeltaPercent); // Function KillstreakUINew.KSProgressMeterWidgetBase.ApplyMeterPercentages_Raw // (Final|Native|Protected|BlueprintCallable) // @ game+0x221a370
	void ApplyMeterPercentages(float BasePercent, float DeltaPercent); // Function KillstreakUINew.KSProgressMeterWidgetBase.ApplyMeterPercentages // (Event|Protected|BlueprintEvent) // @ game+0x2587100
};

// Class KillstreakUINew.KSStoreItemWithPurchaseData
// Size: 0x38 (Inherited: 0x28)
struct UKSStoreItemWithPurchaseData : UObject {
	struct UPUMG_StoreItem* StoreItem; // 0x28(0x08)
	int32_t PurchaseQuantity; // 0x30(0x04)
	char UnknownData_34[0x4]; // 0x34(0x04)
};

// Class KillstreakUINew.KSPurchaseConfirmationWidget
// Size: 0x4f0 (Inherited: 0x4e0)
struct UKSPurchaseConfirmationWidget : UKSWidget {
	struct UPUMG_StoreItem* PurchaseItem; // 0x4e0(0x08)
	int32_t PurchaseQuantity; // 0x4e8(0x04)
	char UnknownData_4EC[0x4]; // 0x4ec(0x04)

	bool TryChangePurchaseQuantity(int32_t QuantityChangeAmount); // Function KillstreakUINew.KSPurchaseConfirmationWidget.TryChangePurchaseQuantity // (Final|Native|Protected|BlueprintCallable) // @ game+0x221cea0
	void PromptAlreadyPurchasing(); // Function KillstreakUINew.KSPurchaseConfirmationWidget.PromptAlreadyPurchasing // (Final|Native|Public|BlueprintCallable) // @ game+0x221c740
	struct UKSStoreItemHelper* GetStoreItemHelper(); // Function KillstreakUINew.KSPurchaseConfirmationWidget.GetStoreItemHelper // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x221b9d0
	bool CanChangePurchaseQuantity(int32_t QuantityChangeAmount); // Function KillstreakUINew.KSPurchaseConfirmationWidget.CanChangePurchaseQuantity // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x221a430
};

// Class KillstreakUINew.KSPurchaseModal
// Size: 0x4e0 (Inherited: 0x4e0)
struct UKSPurchaseModal : UKSWidget {

	void SetupBindings(); // Function KillstreakUINew.KSPurchaseModal.SetupBindings // (Final|Native|Public|BlueprintCallable) // @ game+0x221cc60
	void HandleShowPurchaseModal(struct UPUMG_StoreItem* Item, struct UPUMG_StoreItemPrice* Price); // Function KillstreakUINew.KSPurchaseModal.HandleShowPurchaseModal // (Native|Event|Public|BlueprintEvent) // @ game+0x221be70
	struct UPUMG_StoreItemHelper* GetStoreItemHelper(); // Function KillstreakUINew.KSPurchaseModal.GetStoreItemHelper // (Final|Native|Protected|BlueprintCallable) // @ game+0x221ba00
};

// Class KillstreakUINew.KSQueueDataFactory
// Size: 0x2a0 (Inherited: 0x208)
struct UKSQueueDataFactory : UPUMG_QueueDataFactory {
	char UnknownData_208[0x10]; // 0x208(0x10)
	struct FMulticastInlineDelegate OnSetQueueId; // 0x218(0x10)
	struct FMulticastInlineDelegate OnQueueErrorRelevantStateChanged; // 0x228(0x10)
	int32_t ChunksInstallingQueueId; // 0x238(0x04)
	int32_t DefaultSelectedQueueId; // 0x23c(0x04)
	struct FMulticastInlineDelegate OnSetQueueInputState; // 0x240(0x10)
	struct TArray<int64_t> PreviousCustomMatchMemberIds; // 0x250(0x10)
	int32_t SelectedQueueId; // 0x260(0x04)
	float TimeoutForSwitchFromShelteredToMainQueue; // 0x264(0x04)
	bool bWaitingOnLeaveForShelteredSwitch; // 0x268(0x01)
	bool bWaitingOnJoinForShelteredSwitch; // 0x269(0x01)
	char UnknownData_26A[0x2]; // 0x26a(0x02)
	int32_t MaxRetriesForFindingPartyMemberLevels; // 0x26c(0x04)
	float TimeBetweenRetriesForFindingPartyMemberLevels; // 0x270(0x04)
	char UnknownData_274[0x4]; // 0x274(0x04)
	int32_t NumRetriesForFindingPartyMemberLevels; // 0x278(0x04)
	char UnknownData_27C[0x4]; // 0x27c(0x04)
	struct TArray<struct FMapDetail> MapInfos; // 0x280(0x10)
	struct UDataTable* QueueDetailDataTable; // 0x290(0x08)
	char UnknownData_298[0x8]; // 0x298(0x08)

	struct TArray<struct FClientQueueInfo> SortQueues(struct TArray<struct FClientQueueInfo> ClientCachedQueueInfo, bool IsAlphanumerical); // Function KillstreakUINew.KSQueueDataFactory.SortQueues // (Final|Native|Public|BlueprintCallable) // @ game+0x221ccc0
	bool SetSelectedQueueId(int32_t QueueId); // Function KillstreakUINew.KSQueueDataFactory.SetSelectedQueueId // (Native|Public|BlueprintCallable) // @ game+0x221cbc0
	void SetPreviousCustomMatchMemberIds(struct TArray<int64_t> PreviousMembers); // Function KillstreakUINew.KSQueueDataFactory.SetPreviousCustomMatchMemberIds // (Final|Native|Public|BlueprintCallable) // @ game+0x221cae0
	void RetryQueuingForSheltered(int32_t QueueId); // Function KillstreakUINew.KSQueueDataFactory.RetryQueuingForSheltered // (Final|Native|Public) // @ game+0x221c8c0
	void PopulateMapInfos(); // Function KillstreakUINew.KSQueueDataFactory.PopulateMapInfos // (Final|Native|Public|BlueprintCallable) // @ game+0x221c720
	void OnPartyMemberUpdate(struct FPUMG_PartyMemberData Member); // Function KillstreakUINew.KSQueueDataFactory.OnPartyMemberUpdate // (Final|Native|Protected) // @ game+0x221c310
	void OnPartyMemberEvent(int64_t PlayerId); // Function KillstreakUINew.KSQueueDataFactory.OnPartyMemberEvent // (Final|Native|Protected) // @ game+0x221c290
	void OnPartyEvent(); // Function KillstreakUINew.KSQueueDataFactory.OnPartyEvent // (Final|Native|Protected) // @ game+0x221c270
	void OnInputStateChanged(enum class PGAME_INPUT_STATE InputState); // Function KillstreakUINew.KSQueueDataFactory.OnInputStateChanged // (Final|Native|Private) // @ game+0x221c1f0
	bool JoinSelectedQueue(); // Function KillstreakUINew.KSQueueDataFactory.JoinSelectedQueue // (Final|Native|Public|BlueprintCallable) // @ game+0x221c120
	bool IsTutorialQueue(int32_t QueueId); // Function KillstreakUINew.KSQueueDataFactory.IsTutorialQueue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x221c000
	bool IsRankedQueue(int32_t QueueId); // Function KillstreakUINew.KSQueueDataFactory.IsRankedQueue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x221bf70
	bool IsCustomSpectateEnabled(); // Function KillstreakUINew.KSQueueDataFactory.IsCustomSpectateEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x221bf40
	void HandleShelteredMMTimeout(int32_t QueueId); // Function KillstreakUINew.KSQueueDataFactory.HandleShelteredMMTimeout // (Final|Native|Public) // @ game+0x221bdf0
	void HandleShelteredMMSwitchFinish(bool bSendNotify, bool bClearTimer); // Function KillstreakUINew.KSQueueDataFactory.HandleShelteredMMSwitchFinish // (Final|Native|Public) // @ game+0x221bd20
	void HandleShelteredMMQueueSwitch(int32_t QueueId); // Function KillstreakUINew.KSQueueDataFactory.HandleShelteredMMQueueSwitch // (Final|Native|Public) // @ game+0x221bca0
	int32_t GetSelectedShelteredQueueId(); // Function KillstreakUINew.KSQueueDataFactory.GetSelectedShelteredQueueId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x221b9a0
	int32_t GetSelectedQueueId(); // Function KillstreakUINew.KSQueueDataFactory.GetSelectedQueueId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x221b970
	bool GetQueueInfoById(int32_t QueueId, struct FClientQueueInfo InClientQueueInfo); // Function KillstreakUINew.KSQueueDataFactory.GetQueueInfoById // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x221b1d0
	int32_t GetPenaltyTime(); // Function KillstreakUINew.KSQueueDataFactory.GetPenaltyTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x221b140
	bool GetMapRotationsByQueueId(int32_t QueueId, struct TArray<int32_t> MapIds); // Function KillstreakUINew.KSQueueDataFactory.GetMapRotationsByQueueId // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x221af40
	bool GetMapInfoById(int32_t MapId, struct FMapDetail MapDetail); // Function KillstreakUINew.KSQueueDataFactory.GetMapInfoById // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x221adf0
	struct TArray<struct FClientQueueInfo> GetCustomQueues(); // Function KillstreakUINew.KSQueueDataFactory.GetCustomQueues // (Final|Native|Public|BlueprintCallable) // @ game+0x221ad30
	bool GetCurrentCustomMatchInfo(struct FClientQueueInfo InClientQueueInfo); // Function KillstreakUINew.KSQueueDataFactory.GetCurrentCustomMatchInfo // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x221aab0
	bool FormatQueueJoinErrorMessage(struct FClientQueueInfo Queue, enum class EKSQueueJoinError Error, struct FText OutErrorMessage); // Function KillstreakUINew.KSQueueDataFactory.FormatQueueJoinErrorMessage // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x221a870
	int32_t DetermineQueueIdForShelteredMM(int32_t QueueId, struct FClientQueueInfo QueueInfo); // Function KillstreakUINew.KSQueueDataFactory.DetermineQueueIdForShelteredMM // (Final|Native|Protected|HasOutParms) // @ game+0x221a6b0
	enum class EKSQueueJoinError CheckQueueJoinableById(int32_t QueueId); // Function KillstreakUINew.KSQueueDataFactory.CheckQueueJoinableById // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x221a620
	enum class EKSQueueJoinError CheckQueueJoinable(struct FClientQueueInfo Queue); // Function KillstreakUINew.KSQueueDataFactory.CheckQueueJoinable // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x221a4c0
};

// Class KillstreakUINew.KSQueuedMessageWidget
// Size: 0x4f0 (Inherited: 0x4e0)
struct UKSQueuedMessageWidget : UKSWidget {
	char UnknownData_4E0[0x10]; // 0x4e0(0x10)

	void QueueMessage(struct FText Message); // Function KillstreakUINew.KSQueuedMessageWidget.QueueMessage // (Final|Native|Protected|BlueprintCallable) // @ game+0x221c760
	bool GetNextMessage(struct FText Message); // Function KillstreakUINew.KSQueuedMessageWidget.GetNextMessage // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x221b030
};

// Class KillstreakUINew.KSQueueWidgetBase
// Size: 0x4e0 (Inherited: 0x4e0)
struct UKSQueueWidgetBase : UKSWidget {

	void UpdateQueueSelection(); // Function KillstreakUINew.KSQueueWidgetBase.UpdateQueueSelection // (Native|Protected) // @ game+0x21f4090
	void UpdateQueuePermissions(); // Function KillstreakUINew.KSQueueWidgetBase.UpdateQueuePermissions // (Final|Native|Protected) // @ game+0x221cff0
	bool UIX_AttemptRejoinMatch(); // Function KillstreakUINew.KSQueueWidgetBase.UIX_AttemptRejoinMatch // (Final|Native|Public|BlueprintCallable) // @ game+0x221cfc0
	bool UIX_AttemptLeaveMatch(); // Function KillstreakUINew.KSQueueWidgetBase.UIX_AttemptLeaveMatch // (Final|Native|Public|BlueprintCallable) // @ game+0x221cf90
	bool UIX_AttemptJoinSelectedQueue(); // Function KillstreakUINew.KSQueueWidgetBase.UIX_AttemptJoinSelectedQueue // (Final|Native|Public|BlueprintCallable) // @ game+0x221cf60
	bool UIX_AttemptCancelQueue(); // Function KillstreakUINew.KSQueueWidgetBase.UIX_AttemptCancelQueue // (Final|Native|Public|BlueprintCallable) // @ game+0x221cf30
	void SetupReadyForQueueing(); // Function KillstreakUINew.KSQueueWidgetBase.SetupReadyForQueueing // (Final|Native|Protected) // @ game+0x221cca0
	void SetupBindings(); // Function KillstreakUINew.KSQueueWidgetBase.SetupBindings // (Final|Native|Public|BlueprintCallable) // @ game+0x221cc80
	bool SetCurrentlySelectedQueue(int32_t QueueId); // Function KillstreakUINew.KSQueueWidgetBase.SetCurrentlySelectedQueue // (Final|Native|Public|BlueprintCallable) // @ game+0x221c940
	void ReceiveMatchStatusUpdate(enum class EPUMG_MatchStatus CurrentMatchStatus); // Function KillstreakUINew.KSQueueWidgetBase.ReceiveMatchStatusUpdate // (Final|Native|Protected) // @ game+0x221c840
	void OnSelectedQueueUpdate(struct FClientQueueInfo CurrentSelectedQueue); // Function KillstreakUINew.KSQueueWidgetBase.OnSelectedQueueUpdate // (Native|Event|Protected|BlueprintEvent) // @ game+0x221c550
	void OnQueueStateUpdate(enum class EPUMG_MatchStatus CurrentMatchStatus); // Function KillstreakUINew.KSQueueWidgetBase.OnQueueStateUpdate // (Native|Event|Protected|BlueprintEvent) // @ game+0x221c4d0
	void OnQueuePermissionUpdate(bool CanQueue); // Function KillstreakUINew.KSQueueWidgetBase.OnQueuePermissionUpdate // (Native|Event|Protected|BlueprintEvent) // @ game+0x221c440
	void OnControlQueuePermissionUpdate(bool CanControl); // Function KillstreakUINew.KSQueueWidgetBase.OnControlQueuePermissionUpdate // (Native|Event|Protected|BlueprintEvent) // @ game+0x221c160
	bool IsValidQueue(int32_t QueueId); // Function KillstreakUINew.KSQueueWidgetBase.IsValidQueue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x221c090
	void HandleSelectedQueueIdSet(); // Function KillstreakUINew.KSQueueWidgetBase.HandleSelectedQueueIdSet // (Final|Native|Protected) // @ game+0x221bc80
	void HandlePartyMemberRemoved(int64_t PartyMemberId); // Function KillstreakUINew.KSQueueWidgetBase.HandlePartyMemberRemoved // (Final|Native|Protected) // @ game+0x221bc00
	void HandlePartyMemberDataUpdated(struct FPUMG_PartyMemberData PartyMember); // Function KillstreakUINew.KSQueueWidgetBase.HandlePartyMemberDataUpdated // (Final|Native|Protected) // @ game+0x221bad0
	void HandleMatchStatusUpdate(enum class EPUMG_MatchStatus MatchStatus); // Function KillstreakUINew.KSQueueWidgetBase.HandleMatchStatusUpdate // (Final|Native|Protected) // @ game+0x221ba50
	void HandleConfirmLeaveQueue(); // Function KillstreakUINew.KSQueueWidgetBase.HandleConfirmLeaveQueue // (Final|Native|Protected) // @ game+0x221ba30
	struct TArray<struct FQueueSection> GetQueueSections(struct TArray<struct FClientQueueInfo> ClientCachedQueueInfo); // Function KillstreakUINew.KSQueueWidgetBase.GetQueueSections // (Final|Native|Public|BlueprintCallable) // @ game+0x221b5f0
	struct TArray<struct FClientQueueInfo> GetQueues(); // Function KillstreakUINew.KSQueueWidgetBase.GetQueues // (Final|Native|Public|BlueprintCallable) // @ game+0x221b8b0
	void GetQueuePermissions(bool CanControl, bool CanQueue); // Function KillstreakUINew.KSQueueWidgetBase.GetQueuePermissions // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x221b510
	bool GetQueueInfoById(int32_t QueueId, struct FClientQueueInfo QueueInfo); // Function KillstreakUINew.KSQueueWidgetBase.GetQueueInfoById // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x221b370
	struct UKSQueueDataFactory* GetQueueDataFactory(); // Function KillstreakUINew.KSQueueWidgetBase.GetQueueDataFactory // (Final|Native|Protected|Const) // @ game+0x221b1a0
	struct UKSPlayerDataFactory* GetPlayerDataFactory(); // Function KillstreakUINew.KSQueueWidgetBase.GetPlayerDataFactory // (Final|Native|Protected|Const) // @ game+0x221b170
	struct UPUMG_PartyDataFactory* GetPartyDataFactory(); // Function KillstreakUINew.KSQueueWidgetBase.GetPartyDataFactory // (Final|Native|Protected|Const) // @ game+0x221b110
	struct FClientQueueInfo GetCurrentlySelectedQueue(); // Function KillstreakUINew.KSQueueWidgetBase.GetCurrentlySelectedQueue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x221ac30
};

// Class KillstreakUINew.KSQueueTimerWidgetBase
// Size: 0x4f0 (Inherited: 0x4e0)
struct UKSQueueTimerWidgetBase : UKSQueueWidgetBase {
	char UnknownData_4E0[0x10]; // 0x4e0(0x10)

	void OnUpdateQueueTimerState(enum class EQueueTimerState State); // Function KillstreakUINew.KSQueueTimerWidgetBase.OnUpdateQueueTimerState // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnUpdateQueueTime(float TimeSecs); // Function KillstreakUINew.KSQueueTimerWidgetBase.OnUpdateQueueTime // (Event|Public|BlueprintEvent) // @ game+0x2587100
	float GetQueueTime_TotalSecs(); // Function KillstreakUINew.KSQueueTimerWidgetBase.GetQueueTime_TotalSecs // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x221b890
	int32_t GetQueueTime_PartSecs(); // Function KillstreakUINew.KSQueueTimerWidgetBase.GetQueueTime_PartSecs // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x221b850
	int32_t GetQueueTime_PartMins(); // Function KillstreakUINew.KSQueueTimerWidgetBase.GetQueueTime_PartMins // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x221b7f0
	int32_t GetQueueTime_PartHours(); // Function KillstreakUINew.KSQueueTimerWidgetBase.GetQueueTime_PartHours // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x221b7b0
	enum class EQueueTimerState GetCurrentTimerState(); // Function KillstreakUINew.KSQueueTimerWidgetBase.GetCurrentTimerState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x221ac10
};

// Class KillstreakUINew.KSQuickPlay
// Size: 0x5d0 (Inherited: 0x4e0)
struct UKSQuickPlay : UKSWidget {
	struct FMulticastInlineDelegate OnSelectedQueueChanged; // 0x4e0(0x10)
	bool CanCurrentlyJoinQueue; // 0x4f0(0x01)
	bool CanControlQueue; // 0x4f1(0x01)
	char UnknownData_4F2[0x2]; // 0x4f2(0x02)
	int32_t DefaultSelectedQueueId; // 0x4f4(0x04)
	int32_t ChunksInstallingQueueId; // 0x4f8(0x04)
	char UnknownData_4FC[0x14]; // 0x4fc(0x14)
	bool ReadyForQueueing; // 0x510(0x01)
	char UnknownData_511[0x7]; // 0x511(0x07)
	struct FClientQueueInfo CurrentSelectedQueue; // 0x518(0xb8)

	void UpdateQueuePermissions(); // Function KillstreakUINew.KSQuickPlay.UpdateQueuePermissions // (Final|Native|Protected) // @ game+0x2221790
	bool UIX_AttemptJoinSelectedQueue(); // Function KillstreakUINew.KSQuickPlay.UIX_AttemptJoinSelectedQueue // (Final|Native|Public|BlueprintCallable) // @ game+0x22215e0
	bool UIX_AttemptCancelQueue(); // Function KillstreakUINew.KSQuickPlay.UIX_AttemptCancelQueue // (Final|Native|Public|BlueprintCallable) // @ game+0x22215b0
	struct TArray<struct FQueueSection> SortQueueSections(struct TArray<struct FQueueSection> QueueSections); // Function KillstreakUINew.KSQuickPlay.SortQueueSections // (Final|Native|Protected) // @ game+0x2221430
	void SetupReadyForQueueing(); // Function KillstreakUINew.KSQuickPlay.SetupReadyForQueueing // (Final|Native|Protected) // @ game+0x2221410
	void SetupBindings(); // Function KillstreakUINew.KSQuickPlay.SetupBindings // (Final|Native|Public|BlueprintCallable) // @ game+0x2221370
	bool SetDefaultSelectedQueue(struct FClientQueueInfo NewSelectedQueue); // Function KillstreakUINew.KSQuickPlay.SetDefaultSelectedQueue // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2221190
	bool SetCurrentlySelectedQueue(int32_t QueueId); // Function KillstreakUINew.KSQuickPlay.SetCurrentlySelectedQueue // (Final|Native|Public|BlueprintCallable) // @ game+0x2221100
	void ReceiveMatchStatusUpdate(enum class EPUMG_MatchStatus CurrentMatchStatus); // Function KillstreakUINew.KSQuickPlay.ReceiveMatchStatusUpdate // (Final|Native|Protected) // @ game+0x2220f60
	void OnQueuePermissionChanged(bool CanQueue); // Function KillstreakUINew.KSQuickPlay.OnQueuePermissionChanged // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnControlQueuePermissionChanged(bool CanControl); // Function KillstreakUINew.KSQuickPlay.OnControlQueuePermissionChanged // (Event|Public|BlueprintEvent) // @ game+0x2587100
	bool IsValidQueue(int32_t QueueId); // Function KillstreakUINew.KSQuickPlay.IsValidQueue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2220bf0
	void HandlePartyMemberDataUpdated(struct FPUMG_PartyMemberData PartyMember); // Function KillstreakUINew.KSQuickPlay.HandlePartyMemberDataUpdated // (Final|Native|Protected) // @ game+0x22209f0
	enum class EQueueType GetQueueTypeFromName(struct FName QueueType); // Function KillstreakUINew.KSQuickPlay.GetQueueTypeFromName // (Final|Native|Protected) // @ game+0x2220760
	struct TArray<struct FQueueSection> GetQueueSections(struct TArray<struct FClientQueueInfo> ClientCachedQueueInfo); // Function KillstreakUINew.KSQuickPlay.GetQueueSections // (Final|Native|Public|BlueprintCallable) // @ game+0x2220600
	struct TArray<struct FClientQueueInfo> GetQueues(); // Function KillstreakUINew.KSQuickPlay.GetQueues // (Final|Native|Public|BlueprintCallable) // @ game+0x22207f0
	bool GetQueueInfoById(int32_t QueueId, struct FClientQueueInfo QueueInfo); // Function KillstreakUINew.KSQuickPlay.GetQueueInfoById // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2220460
	struct UKSQueueDataFactory* GetQueueDataFactory(); // Function KillstreakUINew.KSQuickPlay.GetQueueDataFactory // (Final|Native|Protected|Const) // @ game+0x2220430
	struct UPUMG_PartyDataFactory* GetPartyDataFactory(); // Function KillstreakUINew.KSQuickPlay.GetPartyDataFactory // (Final|Native|Protected|Const) // @ game+0x2220120
	int32_t GetDefaultSelectedQueueId(); // Function KillstreakUINew.KSQuickPlay.GetDefaultSelectedQueueId // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x221fe50
	struct FClientQueueInfo GetCurrentlySelectedQueue(); // Function KillstreakUINew.KSQuickPlay.GetCurrentlySelectedQueue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x221fd40
	bool CheckForDirtyQueues(struct TArray<struct FClientQueueInfo> NewClientCachedQueueInfo); // Function KillstreakUINew.KSQuickPlay.CheckForDirtyQueues // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x221f720
	bool CheckForCustomQueues(struct TArray<struct FClientQueueInfo> CustomMatchQueueInfo); // Function KillstreakUINew.KSQuickPlay.CheckForCustomQueues // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x221f610
};

// Class KillstreakUINew.KSQuickPlayWidget
// Size: 0x4f8 (Inherited: 0x4e0)
struct UKSQuickPlayWidget : UKSQueueWidgetBase {
	char UnknownData_4E0[0x18]; // 0x4e0(0x18)

	void UpdateState(); // Function KillstreakUINew.KSQuickPlayWidget.UpdateState // (Final|Native|Protected|BlueprintCallable) // @ game+0x22217b0
	void SetIsPendingQueueUpdate(bool IsPending); // Function KillstreakUINew.KSQuickPlayWidget.SetIsPendingQueueUpdate // (Final|Native|Public|BlueprintCallable) // @ game+0x22212f0
	void OnUpdateQuickPlayState(enum class EQuickPlayQueueState QueueState); // Function KillstreakUINew.KSQuickPlayWidget.OnUpdateQuickPlayState // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnUpdateQuickPlayCanPlay(bool CanPlay); // Function KillstreakUINew.KSQuickPlayWidget.OnUpdateQuickPlayCanPlay // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnUpdateQueueTimeElapsed(float TimeElapsed); // Function KillstreakUINew.KSQuickPlayWidget.OnUpdateQueueTimeElapsed // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnUpdatePenaltyTimeLeft(int32_t TimeLeft); // Function KillstreakUINew.KSQuickPlayWidget.OnUpdatePenaltyTimeLeft // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	bool IsPendingQueueUpdate(); // Function KillstreakUINew.KSQuickPlayWidget.IsPendingQueueUpdate // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2220b70
	enum class EQuickPlayQueueState GetSelectedQueueState(); // Function KillstreakUINew.KSQuickPlayWidget.GetSelectedQueueState // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2220940
	bool GetGameModeDisplayName(struct FText GameModeDisplayName); // Function KillstreakUINew.KSQuickPlayWidget.GetGameModeDisplayName // (Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x221fe80
	enum class EQuickPlayQueueState GetCurrentQuickPlayState(); // Function KillstreakUINew.KSQuickPlayWidget.GetCurrentQuickPlayState // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x21f7170
};

// Class KillstreakUINew.KSRadialSelectionWidgetBase
// Size: 0x590 (Inherited: 0x4e0)
struct UKSRadialSelectionWidgetBase : UKSWidget {
	struct TArray<struct FGameplayTag> EmoteSlots; // 0x4e0(0x10)
	struct TArray<struct FGameplayTag> QuipSlots; // 0x4f0(0x10)
	struct TArray<struct FGameplayTag> CommunicationSlots; // 0x500(0x10)
	struct TArray<struct FGameplayTag> SpraySlots; // 0x510(0x10)
	struct TArray<struct FName> AdditionalInputsToDisableOnOpen; // 0x520(0x10)
	struct TArray<enum class EMercCosmeticSlot> RadialMenuCosmeticSlots; // 0x530(0x10)
	bool bCycleBetweenMenusEnabled; // 0x540(0x01)
	char UnknownData_541[0x3f]; // 0x541(0x3f)
	struct UDataTable* ContextualPingTypesDT; // 0x580(0x08)
	struct UDataTable* ContextualPingMessagesDT; // 0x588(0x08)

	void UpdateLastSelectedIndex(int32_t NewIndex); // Function KillstreakUINew.KSRadialSelectionWidgetBase.UpdateLastSelectedIndex // (Final|Native|Protected|BlueprintCallable) // @ game+0x2221690
	void UpdateLastHoveredIndex(int32_t NewHoveredIndex); // Function KillstreakUINew.KSRadialSelectionWidgetBase.UpdateLastHoveredIndex // (Final|Native|Protected) // @ game+0x2221610
	void TraceSelectionCursor(float Radius, float Angle); // Function KillstreakUINew.KSRadialSelectionWidgetBase.TraceSelectionCursor // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void ShowSelector(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.ShowSelector // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void SetupForRadialWheelMode(enum class ERadialWheelMode NewRadialWheelMode); // Function KillstreakUINew.KSRadialSelectionWidgetBase.SetupForRadialWheelMode // (Native|Event|Protected|BlueprintEvent) // @ game+0x2221390
	void RadialOptionUnhover(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.RadialOptionUnhover // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void RadialOptionSelected(int32_t Index); // Function KillstreakUINew.KSRadialSelectionWidgetBase.RadialOptionSelected // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void RadialOptionHovered(int32_t Index); // Function KillstreakUINew.KSRadialSelectionWidgetBase.RadialOptionHovered // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OpenSpecifiedRadialMenu(enum class EMercCosmeticSlot CosmeticSlot); // Function KillstreakUINew.KSRadialSelectionWidgetBase.OpenSpecifiedRadialMenu // (Final|Native|Protected|BlueprintCallable) // @ game+0x2220ee0
	void OnRadialMenuUseLastSelection(enum class EMercCosmeticSlot ButtonCosmeticSlot); // Function KillstreakUINew.KSRadialSelectionWidgetBase.OnRadialMenuUseLastSelection // (Final|Native|Protected) // @ game+0x2220e60
	void OnRadialMenuReleased(enum class EMercCosmeticSlot ButtonCosmeticSlot, bool bIsContextualPingHold); // Function KillstreakUINew.KSRadialSelectionWidgetBase.OnRadialMenuReleased // (Final|Native|Protected|BlueprintCallable) // @ game+0x2220d90
	void OnRadialMenuPressed(enum class EMercCosmeticSlot ButtonCosmeticSlot, bool bIsContextualPingHold); // Function KillstreakUINew.KSRadialSelectionWidgetBase.OnRadialMenuPressed // (Final|Native|Protected|BlueprintCallable) // @ game+0x2220cc0
	void OnRadialMenuForceClosed(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.OnRadialMenuForceClosed // (Final|Native|Protected|BlueprintCallable) // @ game+0x221f530
	void OnCycleMenusRight(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.OnCycleMenusRight // (Final|Native|Protected|BlueprintCallable) // @ game+0x2220ca0
	void OnCycleMenusLeft(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.OnCycleMenusLeft // (Final|Native|Protected|BlueprintCallable) // @ game+0x2220c80
	void OnCycledMenus(bool bCycledRight); // Function KillstreakUINew.KSRadialSelectionWidgetBase.OnCycledMenus // (Native|Event|Protected|BlueprintEvent) // @ game+0x21f8040
	bool IsSelectorVisible(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.IsSelectorVisible // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	bool IsSelectorActive(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.IsSelectorActive // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2220bc0
	bool IsCycleBetweenMenusEnabled(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.IsCycleBetweenMenusEnabled // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2220b40
	void InitializeTracking(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.InitializeTracking // (Final|Native|Protected) // @ game+0x2220b20
	void HideSelector(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.HideSelector // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void HandleInputStateChanged(enum class PGAME_INPUT_STATE NewInputState); // Function KillstreakUINew.KSRadialSelectionWidgetBase.HandleInputStateChanged // (Final|Native|Protected) // @ game+0x2220970
	float GetWheelSize(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.GetWheelSize // (Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	bool GetPingIconByType(enum class EPingType PingType, struct TSoftObjectPtr<struct UTexture2D> PingIcon); // Function KillstreakUINew.KSRadialSelectionWidgetBase.GetPingIconByType // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2220330
	bool GetPingIconByMessage(enum class EPingMessage PingMessage, struct TSoftObjectPtr<struct UTexture2D> PingIcon); // Function KillstreakUINew.KSRadialSelectionWidgetBase.GetPingIconByMessage // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2220230
	bool GetPingColorByType(enum class EPingType PingType, struct FLinearColor PingColor); // Function KillstreakUINew.KSRadialSelectionWidgetBase.GetPingColorByType // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x2220150
	int32_t GetOptionsCount(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.GetOptionsCount // (Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	int32_t GetLastSelectedIndexForCosmeticSlot(enum class EMercCosmeticSlot CosmeticSlot); // Function KillstreakUINew.KSRadialSelectionWidgetBase.GetLastSelectedIndexForCosmeticSlot // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2220090
	int32_t GetLastHoveredIndex(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.GetLastHoveredIndex // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2220060
	enum class EMercCosmeticSlot GetInitialRadialMenu(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.GetInitialRadialMenu // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2220030
	struct TArray<struct FGameplayTag> GetGameplayTagsForCosmeticSlot(enum class EMercCosmeticSlot CosmeticSlot); // Function KillstreakUINew.KSRadialSelectionWidgetBase.GetGameplayTagsForCosmeticSlot // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x221ff60
	float GetDeadZone(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.GetDeadZone // (Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	enum class EMercCosmeticSlot GetContiguousCosmeticSlotMenu(bool bRightSide); // Function KillstreakUINew.KSRadialSelectionWidgetBase.GetContiguousCosmeticSlotMenu // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x221fcb0
	enum class EMercCosmeticSlot GetActiveCosmeticSlotMenu(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.GetActiveCosmeticSlotMenu // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x221fc80
	bool FindRowByType(enum class EPingType PingType, struct FContextualPingTypesRow ContextualPingTypesRow); // Function KillstreakUINew.KSRadialSelectionWidgetBase.FindRowByType // (Final|Native|Protected|HasOutParms|Const) // @ game+0x221f950
	bool FindRowByMessage(enum class EPingMessage PingMessage, struct FContextualPingMessagesRow ContextualPingMessagesRow); // Function KillstreakUINew.KSRadialSelectionWidgetBase.FindRowByMessage // (Final|Native|Protected|HasOutParms|Const) // @ game+0x221f830
	void DummyFunction(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.DummyFunction // (Final|Native|Protected) // @ game+0xbc5780
	void ChangeToNewRadialMenu(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.ChangeToNewRadialMenu // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void ButtonClicked(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.ButtonClicked // (Final|Native|Protected) // @ game+0x221f550
	void BackPressed(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.BackPressed // (Final|Native|Protected) // @ game+0x221f530
	bool ActivateRadialMenuItem(int32_t Index, struct AKSPlayerController* PlayerController); // Function KillstreakUINew.KSRadialSelectionWidgetBase.ActivateRadialMenuItem // (Final|Native|Protected|BlueprintCallable) // @ game+0x221f470
};

// Class KillstreakUINew.KSRankChangeWidget
// Size: 0x4e0 (Inherited: 0x4e0)
struct UKSRankChangeWidget : UKSWidget {

	struct FPlayerProgression FormatProgressionData(struct FPlayerProgression ProgressionData); // Function KillstreakUINew.KSRankChangeWidget.FormatProgressionData // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x221fa70
};

// Class KillstreakUINew.KSRankedUnlockedViewRedirector
// Size: 0x28 (Inherited: 0x28)
struct UKSRankedUnlockedViewRedirector : UPUMG_ViewRedirecter {
};

// Class KillstreakUINew.KSRedeemCodeScreenBase
// Size: 0x4f8 (Inherited: 0x4e0)
struct UKSRedeemCodeScreenBase : UKSWidget {
	char UnknownData_4E0[0x18]; // 0x4e0(0x18)

	void RedeemCode(struct FString Code); // Function KillstreakUINew.KSRedeemCodeScreenBase.RedeemCode // (Final|Native|Public|BlueprintCallable) // @ game+0x2220fe0
	void OnRedeemCodeSubmit(); // Function KillstreakUINew.KSRedeemCodeScreenBase.OnRedeemCodeSubmit // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnRedeemCodeResult(bool Success, struct FText Error); // Function KillstreakUINew.KSRedeemCodeScreenBase.OnRedeemCodeResult // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	bool IsPendingServerReply(); // Function KillstreakUINew.KSRedeemCodeScreenBase.IsPendingServerReply // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2220b90
};

// Class KillstreakUINew.KSRegionSelectModalViewRedirector
// Size: 0x28 (Inherited: 0x28)
struct UKSRegionSelectModalViewRedirector : UPUMG_ViewRedirecter {
};

// Class KillstreakUINew.KSRegionSelectModal
// Size: 0x4e0 (Inherited: 0x4e0)
struct UKSRegionSelectModal : UKSWidget {
};

// Class KillstreakUINew.KSReticleWidgetBase
// Size: 0x518 (Inherited: 0x4f8)
struct UKSReticleWidgetBase : UKSViewedActiveWeaponWidget {
	float ShrinkAnimationTime; // 0x4f8(0x04)
	float BlockedShotIconMaxScale; // 0x4fc(0x04)
	float BlockedShotIconMinScale; // 0x500(0x04)
	float BlockedShotMinScaleSqDist; // 0x504(0x04)
	bool bGrenadeCooking; // 0x508(0x01)
	bool bInADS; // 0x509(0x01)
	bool bCachedBlockIconVisible; // 0x50a(0x01)
	char UnknownData_50B[0x1]; // 0x50b(0x01)
	float CachedWeaponAccuracy; // 0x50c(0x04)
	float CachedReticleOffset; // 0x510(0x04)
	char UnknownData_514[0x4]; // 0x514(0x04)

	void UpdateReticleOffset(float OffsetFromCenterScreen); // Function KillstreakUINew.KSReticleWidgetBase.UpdateReticleOffset // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void UpdateBlockedShotIcon(bool IconVisible, struct FVector2D Translation, struct FVector2D IconScale); // Function KillstreakUINew.KSReticleWidgetBase.UpdateBlockedShotIcon // (Event|Protected|HasDefaults|BlueprintEvent) // @ game+0x2587100
	void CalculateReticleOffset(float DeltaTime); // Function KillstreakUINew.KSReticleWidgetBase.CalculateReticleOffset // (Final|Native|Protected) // @ game+0x221f590
	void CalculateBlockedShotIcon(); // Function KillstreakUINew.KSReticleWidgetBase.CalculateBlockedShotIcon // (Final|Native|Protected) // @ game+0x221f570
};

// Class KillstreakUINew.KSRewardsTrackWidgetBase
// Size: 0x508 (Inherited: 0x4e0)
struct UKSRewardsTrackWidgetBase : UKSWidget {
	int32_t MaxPageCount; // 0x4e0(0x04)
	int32_t CurrentPage; // 0x4e4(0x04)
	struct TArray<struct UKSWidget*> ItemButtons; // 0x4e8(0x10)
	struct UKSActivityInstance* ActivityInstance; // 0x4f8(0x08)
	struct UKSAcquisition* Acquisition; // 0x500(0x08)

	void UpdateMaxPageCount(int32_t RewardCount); // Function KillstreakUINew.KSRewardsTrackWidgetBase.UpdateMaxPageCount // (Final|Native|Protected|BlueprintCallable) // @ game+0x2221710
	void SetCurrentPageFromIndex(int32_t Index); // Function KillstreakUINew.KSRewardsTrackWidgetBase.SetCurrentPageFromIndex // (Final|Native|Protected|BlueprintCallable) // @ game+0x2221080
};

// Class KillstreakUINew.KSRogueDetailsWidget
// Size: 0x4e0 (Inherited: 0x4e0)
struct UKSRogueDetailsWidget : UKSWidget {

	struct UPUMG_StoreItem* GetStoreItemForJob(struct UKSJobItem* JobItem); // Function KillstreakUINew.KSRogueDetailsWidget.GetStoreItemForJob // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2225fc0
	struct UKSStoreItemHelper* GetItemHelper(); // Function KillstreakUINew.KSRogueDetailsWidget.GetItemHelper // (Final|Native|Protected|Const) // @ game+0x21f7360
};

// Class KillstreakUINew.KSRogueMasteryWidget
// Size: 0x4e0 (Inherited: 0x4e0)
struct UKSRogueMasteryWidget : UKSWidget {

	void GetSectionData(struct UKSActivityInstance* ActivityInstance, struct TArray<struct FMasterySectionData> SectionData); // Function KillstreakUINew.KSRogueMasteryWidget.GetSectionData // (Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x22259a0
	void GetMasteryRewardsForTier(struct FActivityTier Tier, struct TArray<struct FMasteryRewardData> Rewards); // Function KillstreakUINew.KSRogueMasteryWidget.GetMasteryRewardsForTier // (Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2225820
};

// Class KillstreakUINew.KSScreenLogWidget
// Size: 0x4f0 (Inherited: 0x4e0)
struct UKSScreenLogWidget : UKSWidget {
	struct UDataTable* ContextualPingTypesDT; // 0x4e0(0x08)
	struct UDataTable* ContextualPingMessagesDT; // 0x4e8(0x08)
};

// Class KillstreakUINew.KSScreenMarkerWidgetBase
// Size: 0x328 (Inherited: 0x318)
struct UKSScreenMarkerWidgetBase : UKSMapIconWidgetBase {
	bool bHideWhenOffscreen; // 0x318(0x01)
	char UnknownData_319[0x3]; // 0x319(0x03)
	struct FVector2D OffscreenMargins; // 0x31c(0x08)
	char UnknownData_324[0x4]; // 0x324(0x04)
};

// Class KillstreakUINew.KSScrollBox
// Size: 0x888 (Inherited: 0x888)
struct UKSScrollBox : UScrollBox {

	float GetViewFraction(); // Function KillstreakUINew.KSScrollBox.GetViewFraction // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2226050
};

// Class KillstreakUINew.KSSettingsContainer
// Size: 0x500 (Inherited: 0x4e0)
struct UKSSettingsContainer : UKSWidget {
	struct TArray<struct UKSSettingsWidget*> SettingsWidgets; // 0x4e0(0x10)
	struct UKSSettingsPreview* AssociatePreviewWidget; // 0x4f0(0x08)
	struct UKSSettingsContainerConfigAsset* ContainerConfigAsset; // 0x4f8(0x08)

	void OnShowSettingsWidget(struct UKSSettingsWidget* SettingsWidget); // Function KillstreakUINew.KSSettingsContainer.OnShowSettingsWidget // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnHideSettingsWidget(struct UKSSettingsWidget* SettingsWidget); // Function KillstreakUINew.KSSettingsContainer.OnHideSettingsWidget // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnContainerConfigSet(); // Function KillstreakUINew.KSSettingsContainer.OnContainerConfigSet // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	struct FText GetWidgetContainerTitle(); // Function KillstreakUINew.KSSettingsContainer.GetWidgetContainerTitle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2226140
	struct UKSSettingsPreview* GetWidgetContainerPreview(); // Function KillstreakUINew.KSSettingsContainer.GetWidgetContainerPreview // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x20ec440
	struct FText GetWidgetContainerDescription(); // Function KillstreakUINew.KSSettingsContainer.GetWidgetContainerDescription // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2226080
	struct TArray<struct UKSSettingsWidget*> GetSettingsWidgets(); // Function KillstreakUINew.KSSettingsContainer.GetSettingsWidgets // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2225f30
	void AddSettingsWidget(struct UKSSettingsWidget* SettingsWidget); // Function KillstreakUINew.KSSettingsContainer.AddSettingsWidget // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void AddPreviewWidget(struct UKSSettingsPreview* PreviewWidget); // Function KillstreakUINew.KSSettingsContainer.AddPreviewWidget // (Event|Protected|BlueprintEvent) // @ game+0x2587100
};

// Class KillstreakUINew.KSSettingsColorOptionsAsset
// Size: 0x40 (Inherited: 0x30)
struct UKSSettingsColorOptionsAsset : UDataAsset {
	struct TArray<struct FColorOptions> ColorOptions; // 0x30(0x10)
};

// Class KillstreakUINew.KSSettingsContainerConfigAsset
// Size: 0x130 (Inherited: 0x30)
struct UKSSettingsContainerConfigAsset : UDataAsset {
	struct FText SettingName; // 0x30(0x18)
	struct TMap<struct FString, struct FText> SettingNameByPlatform; // 0x48(0x50)
	struct FText SettingDescription; // 0x98(0x18)
	struct TMap<struct FString, struct FText> SettingDescriptionByPlatform; // 0xb0(0x50)
	bool bIsAvailableOffline; // 0x100(0x01)
	bool bRequires120HzDisplay; // 0x101(0x01)
	struct FKSAllowedPlatformTypes AllowedPlatformTypes; // 0x102(0x0a)
	struct FKSRequiredInputTypes RequiredInputTypes; // 0x10c(0x02)
	struct FKSSwitchDockedModeSetting SwitchDockedModeSetting; // 0x10e(0x02)
	bool bUsePreview; // 0x110(0x01)
	char UnknownData_111[0x7]; // 0x111(0x07)
	struct UKSSettingsPreview* PreviewWidget; // 0x118(0x08)
	struct TArray<struct FKSSettingsWidgetConfig> WidgetConfigs; // 0x120(0x10)
};

// Class KillstreakUINew.KSSettingsSectionConfigAsset
// Size: 0xa8 (Inherited: 0x30)
struct UKSSettingsSectionConfigAsset : UDataAsset {
	struct FText Heading; // 0x30(0x18)
	struct TMap<struct FString, struct FText> HeadingByPlatform; // 0x48(0x50)
	struct TArray<struct FKSSettingsGroupConfig> SettingsGroups; // 0x98(0x10)
};

// Class KillstreakUINew.KSSettingsPageConfigAsset
// Size: 0xa8 (Inherited: 0x30)
struct UKSSettingsPageConfigAsset : UDataAsset {
	struct FText PageName; // 0x30(0x18)
	struct TMap<struct FString, struct FText> HeadingByPlatform; // 0x48(0x50)
	struct TArray<struct UKSSettingsSectionConfigAsset*> SettingsSectionConfigs; // 0x98(0x10)
};

// Class KillstreakUINew.KSSettingsMenuConfigAsset
// Size: 0x40 (Inherited: 0x30)
struct UKSSettingsMenuConfigAsset : UDataAsset {
	struct TArray<struct UKSSettingsPageConfigAsset*> SettingsPageConfigs; // 0x30(0x10)
};

// Class KillstreakUINew.KSSettingsDataFactory
// Size: 0x3d0 (Inherited: 0xd8)
struct UKSSettingsDataFactory : UPUMG_SettingsDataFactory {
	char UnknownData_D8[0x8]; // 0xd8(0x08)
	struct FMulticastInlineDelegate OnSettingsReceivedFromPlayerAccount; // 0xe0(0x10)
	char UnknownData_F0[0xa0]; // 0xf0(0xa0)
	struct FMulticastInlineDelegate OnKeyBindSettingsApplied; // 0x190(0x10)
	struct FMulticastInlineDelegate OnKeyBindSettingsSaved; // 0x1a0(0x10)
	struct TArray<struct FKSSettingPropertyId> BoolSettingPropertyIds; // 0x1b0(0x10)
	char UnknownData_1C0[0x50]; // 0x1c0(0x50)
	struct TArray<struct FKSSettingPropertyId> IntSettingPropertyIds; // 0x210(0x10)
	char UnknownData_220[0x50]; // 0x220(0x50)
	struct TArray<struct FKSSettingPropertyId> FloatSettingPropertyIds; // 0x270(0x10)
	char UnknownData_280[0xb0]; // 0x280(0xb0)
	struct TSoftObjectPtr<struct UKSSettingsMenuConfigAsset> KSSettingsMenuConfigAssetSoftObjectPtr; // 0x330(0x28)
	struct UKSSettingsMenuConfigAsset* KSSettingsMenuConfigAsset; // 0x358(0x08)
	char UnknownData_360[0x10]; // 0x360(0x10)
	struct FMulticastInlineDelegate OnDisplayLanguageApplied; // 0x370(0x10)
	struct FMulticastInlineDelegate OnDisplayLanguageSaved; // 0x380(0x10)
	struct FMulticastInlineDelegate OnScreenResolutionApplied; // 0x390(0x10)
	struct FMulticastInlineDelegate OnScreenResolutionSaved; // 0x3a0(0x10)
	struct FMulticastInlineDelegate OnCrosshairColorSaved; // 0x3b0(0x10)
	char UnknownData_3C0[0x10]; // 0x3c0(0x10)

	bool SetSelectedRegion(int32_t SiteId); // Function KillstreakUINew.KSSettingsDataFactory.SetSelectedRegion // (Final|Native|Public|BlueprintCallable) // @ game+0x2226760
	bool SetCrosshairColor(int32_t CrosshairColorIndex); // Function KillstreakUINew.KSSettingsDataFactory.SetCrosshairColor // (Final|Native|Public|BlueprintCallable) // @ game+0x22266d0
	void SetColorOptionValues(struct UKSSettingsColorOptionsAsset* ColorOptionAsset); // Function KillstreakUINew.KSSettingsDataFactory.SetColorOptionValues // (Final|Native|Public) // @ game+0x2226650
	void SaveSettings(); // Function KillstreakUINew.KSSettingsDataFactory.SaveSettings // (Final|Native|Public|BlueprintCallable) // @ game+0x2226630
	void SaveSettingAsInt(struct FString Name); // Function KillstreakUINew.KSSettingsDataFactory.SaveSettingAsInt // (Final|Native|Public|BlueprintCallable) // @ game+0x2226550
	void SaveSettingAsFloat(struct FString Name); // Function KillstreakUINew.KSSettingsDataFactory.SaveSettingAsFloat // (Final|Native|Public|BlueprintCallable) // @ game+0x2226470
	void SaveSettingAsBool(struct FString Name); // Function KillstreakUINew.KSSettingsDataFactory.SaveSettingAsBool // (Final|Native|Public|BlueprintCallable) // @ game+0x2226390
	void SaveScreenResolution(); // Function KillstreakUINew.KSSettingsDataFactory.SaveScreenResolution // (Final|Native|Public|BlueprintCallable) // @ game+0x2226370
	void SaveLanguage(); // Function KillstreakUINew.KSSettingsDataFactory.SaveLanguage // (Final|Native|Public|BlueprintCallable) // @ game+0x2226350
	void SaveKeyBindings(); // Function KillstreakUINew.KSSettingsDataFactory.SaveKeyBindings // (Final|Native|Public|BlueprintCallable) // @ game+0x2226330
	bool SaveCrosshairColor(int32_t CrosshairColorIndex); // Function KillstreakUINew.KSSettingsDataFactory.SaveCrosshairColor // (Final|Native|Public|BlueprintCallable) // @ game+0x22262a0
	void RevertScreenResolution(); // Function KillstreakUINew.KSSettingsDataFactory.RevertScreenResolution // (Final|Native|Public|BlueprintCallable) // @ game+0x2226280
	void RevertPlayerPreferences(); // Function KillstreakUINew.KSSettingsDataFactory.RevertPlayerPreferences // (Final|Native|Public|BlueprintCallable) // @ game+0x2226260
	void RevertLanguageToDefault(); // Function KillstreakUINew.KSSettingsDataFactory.RevertLanguageToDefault // (Final|Native|Public|BlueprintCallable) // @ game+0x2226240
	void RevertKeyBindings(); // Function KillstreakUINew.KSSettingsDataFactory.RevertKeyBindings // (Final|Native|Public|BlueprintCallable) // @ game+0x2226220
	bool IsUserLoggedIn(); // Function KillstreakUINew.KSSettingsDataFactory.IsUserLoggedIn // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x22261f0
	bool GetSettingAsInt_Legacy(struct FString Name, int32_t OutInt); // Function KillstreakUINew.KSSettingsDataFactory.GetSettingAsInt_Legacy // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2225dc0
	bool GetSettingAsFloat_Legacy(struct FString Name, float OutFloat); // Function KillstreakUINew.KSSettingsDataFactory.GetSettingAsFloat_Legacy // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2225c50
	bool GetSettingAsBool_Legacy(struct FString Name, bool OutBool); // Function KillstreakUINew.KSSettingsDataFactory.GetSettingAsBool_Legacy // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2225ae0
	int32_t GetSelectedRegion(); // Function KillstreakUINew.KSSettingsDataFactory.GetSelectedRegion // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2225ab0
	struct FIntPoint GetScreenResolution(); // Function KillstreakUINew.KSSettingsDataFactory.GetScreenResolution // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x2225960
	struct UKSPlayerInput* GetKSPlayerInput(); // Function KillstreakUINew.KSSettingsDataFactory.GetKSPlayerInput // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x22257f0
	void GetDefaultKSInputActionKeys(struct FName Name, enum class EKSInputType InputType, struct TArray<struct FKSInputActionKey> OutKeys); // Function KillstreakUINew.KSSettingsDataFactory.GetDefaultKSInputActionKeys // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2225670
	void GetDefaultInputAxisKeys(struct FName Name, enum class EKSInputType InputType, float Scale, struct TArray<struct FKey> OutKeys); // Function KillstreakUINew.KSSettingsDataFactory.GetDefaultInputAxisKeys // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x22254a0
	void GetDefaultInputActionKeys(struct FName Name, enum class EKSInputType InputType, struct TArray<struct FKey> OutKeys); // Function KillstreakUINew.KSSettingsDataFactory.GetDefaultInputActionKeys // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2225320
	void GetCustomKSInputActionKeys(struct FName Name, enum class EKSInputType InputType, struct TArray<struct FKSInputActionKey> OutKeys); // Function KillstreakUINew.KSSettingsDataFactory.GetCustomKSInputActionKeys // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x22251b0
	void GetCustomInputAxisKeys(struct FName Name, enum class EKSInputType InputType, float Scale, struct TArray<struct FKey> OutKeys); // Function KillstreakUINew.KSSettingsDataFactory.GetCustomInputAxisKeys // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2224ff0
	void GetCustomInputActionKeys(struct FName Name, enum class EKSInputType InputType, struct TArray<struct FKey> OutKeys); // Function KillstreakUINew.KSSettingsDataFactory.GetCustomInputActionKeys // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2224e80
	struct FString GetCurrentLanguage(); // Function KillstreakUINew.KSSettingsDataFactory.GetCurrentLanguage // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2224e00
	struct FLinearColor GetCrosshairColorValue(int32_t CrosshairColorIndex); // Function KillstreakUINew.KSSettingsDataFactory.GetCrosshairColorValue // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x2224d60
	int32_t GetCrosshairColor(); // Function KillstreakUINew.KSSettingsDataFactory.GetCrosshairColor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2224d30
	struct TArray<struct FString> GetAvailableLanguages(); // Function KillstreakUINew.KSSettingsDataFactory.GetAvailableLanguages // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2224c50
	void BindSettingCallbacks_Legacy(struct FString Name, struct FSettingDelegateStruct SettingDelegateStruct); // Function KillstreakUINew.KSSettingsDataFactory.BindSettingCallbacks_Legacy // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2224ae0
	void ApplySettingAsInt(struct FString Name, int32_t Value); // Function KillstreakUINew.KSSettingsDataFactory.ApplySettingAsInt // (Final|Native|Public|BlueprintCallable) // @ game+0x22249c0
	void ApplySettingAsFloat(struct FString Name, float Value); // Function KillstreakUINew.KSSettingsDataFactory.ApplySettingAsFloat // (Final|Native|Public|BlueprintCallable) // @ game+0x2224890
	void ApplySettingAsBool(struct FString Name, bool Value); // Function KillstreakUINew.KSSettingsDataFactory.ApplySettingAsBool // (Final|Native|Public|BlueprintCallable) // @ game+0x2224760
	void ApplyScreenResolution(struct FIntPoint ScreenResolution); // Function KillstreakUINew.KSSettingsDataFactory.ApplyScreenResolution // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x22246e0
	void ApplyLanguage(struct FString LanguageCulture); // Function KillstreakUINew.KSSettingsDataFactory.ApplyLanguage // (Final|Native|Public|BlueprintCallable) // @ game+0x2224600
	void AddColorOptionValues(struct FLinearColor ColorValue); // Function KillstreakUINew.KSSettingsDataFactory.AddColorOptionValues // (Final|Native|Public|HasDefaults) // @ game+0x2224580
};

// Class KillstreakUINew.KSSettingsGroup
// Size: 0x510 (Inherited: 0x4e0)
struct UKSSettingsGroup : UKSWidget {
	struct TArray<struct UKSSettingsContainer*> SettingsContainers; // 0x4e0(0x10)
	struct UKSSettingsContainer* SettingsContainerClass; // 0x4f0(0x08)
	struct FKSSettingsGroupConfig GroupConfig; // 0x4f8(0x18)

	void OnShowContainer(struct UKSSettingsContainer* SettingsContainer); // Function KillstreakUINew.KSSettingsGroup.OnShowContainer // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnHideContainer(struct UKSSettingsContainer* SettingsContainer); // Function KillstreakUINew.KSSettingsGroup.OnHideContainer // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnGroupConfigSet(); // Function KillstreakUINew.KSSettingsGroup.OnGroupConfigSet // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	struct TArray<struct UKSSettingsContainer*> GetSettingsContainers(); // Function KillstreakUINew.KSSettingsGroup.GetSettingsContainers // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2225f30
	void AddSubSettingsContainerWidget(struct UKSSettingsContainer* SettingsContainer); // Function KillstreakUINew.KSSettingsGroup.AddSubSettingsContainerWidget // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void AddMainSettingsContainerWidget(struct UKSSettingsContainer* SettingsContainer); // Function KillstreakUINew.KSSettingsGroup.AddMainSettingsContainerWidget // (Event|Protected|BlueprintEvent) // @ game+0x2587100
};

// Class KillstreakUINew.KSSettingsInfoBase
// Size: 0x108 (Inherited: 0x28)
struct UKSSettingsInfoBase : UObject {
	struct FMulticastInlineDelegate OnSettingValueChanged; // 0x28(0x10)
	struct FMulticastInlineDelegate OnSettingPreviewChanged; // 0x38(0x10)
	bool bIsAutoApplied; // 0x48(0x01)
	bool bIsAutoSaved; // 0x49(0x01)
	char UnknownData_4A[0x86]; // 0x4a(0x86)
	struct TArray<struct FText> TextOptions; // 0xd0(0x10)
	struct FMulticastInlineDelegate OnTextOptionsChanged; // 0xe0(0x10)
	float MinValue; // 0xf0(0x04)
	float MaxValue; // 0xf4(0x04)
	float StepValue; // 0xf8(0x04)
	bool bRoundValue; // 0xfc(0x01)
	char UnknownData_FD[0x3]; // 0xfd(0x03)
	float RoundToNearest; // 0x100(0x04)
	bool bIsPercent; // 0x104(0x01)
	char UnknownData_105[0x3]; // 0x105(0x03)

	void UpdateTextOptions(struct TArray<struct FText> NewOptions); // Function KillstreakUINew.KSSettingsInfoBase.UpdateTextOptions // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x222bc70
	bool SetPreviewValueInt(int32_t inInt); // Function KillstreakUINew.KSSettingsInfoBase.SetPreviewValueInt // (Final|Native|Public|BlueprintCallable) // @ game+0x222bbe0
	bool SetPreviewValueFloat(float InFloat); // Function KillstreakUINew.KSSettingsInfoBase.SetPreviewValueFloat // (Final|Native|Public|BlueprintCallable) // @ game+0x222bb50
	bool SetPreviewValueBool(bool InBool); // Function KillstreakUINew.KSSettingsInfoBase.SetPreviewValueBool // (Final|Native|Public|BlueprintCallable) // @ game+0x222bac0
	bool SetDesiredValueKeyBind(struct FKSKeyBind InKeyBind); // Function KillstreakUINew.KSSettingsInfoBase.SetDesiredValueKeyBind // (Final|Native|Public|BlueprintCallable) // @ game+0x222b970
	bool SetDesiredValueInt(int32_t inInt); // Function KillstreakUINew.KSSettingsInfoBase.SetDesiredValueInt // (Final|Native|Public|BlueprintCallable) // @ game+0x222b8e0
	bool SetDesiredValueFloat(float InFloat); // Function KillstreakUINew.KSSettingsInfoBase.SetDesiredValueFloat // (Final|Native|Public|BlueprintCallable) // @ game+0x222b850
	bool SetDesiredValueBool(bool InBool); // Function KillstreakUINew.KSSettingsInfoBase.SetDesiredValueBool // (Final|Native|Public|BlueprintCallable) // @ game+0x222b7c0
	bool SaveKeyBindValue(struct FKSKeyBind InKeyBind); // Function KillstreakUINew.KSSettingsInfoBase.SaveKeyBindValue // (Native|Event|Protected|BlueprintEvent) // @ game+0x222b670
	bool SaveIntValue(int32_t inInt); // Function KillstreakUINew.KSSettingsInfoBase.SaveIntValue // (Native|Event|Protected|BlueprintEvent) // @ game+0x222b5d0
	bool SaveFloatValue(float InFloat); // Function KillstreakUINew.KSSettingsInfoBase.SaveFloatValue // (Native|Event|Protected|BlueprintEvent) // @ game+0x222b540
	bool SaveBoolValue(bool InBool); // Function KillstreakUINew.KSSettingsInfoBase.SaveBoolValue // (Native|Event|Protected|BlueprintEvent) // @ game+0x222b4a0
	void Save(); // Function KillstreakUINew.KSSettingsInfoBase.Save // (Final|Native|Public|BlueprintCallable) // @ game+0x222b480
	float RoundToNearestValueFloat(float ValueToRound); // Function KillstreakUINew.KSSettingsInfoBase.RoundToNearestValueFloat // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x222b3f0
	void RevertSettingToDefault(); // Function KillstreakUINew.KSSettingsInfoBase.RevertSettingToDefault // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2107f20
	void Revert(); // Function KillstreakUINew.KSSettingsInfoBase.Revert // (Final|Native|Public|BlueprintCallable) // @ game+0x222b3d0
	void ResetPreview(); // Function KillstreakUINew.KSSettingsInfoBase.ResetPreview // (Final|Native|Public|BlueprintCallable) // @ game+0x222b3b0
	void OnValueKeyBindSaved(struct FKSKeyBind SavedKeyBind); // Function KillstreakUINew.KSSettingsInfoBase.OnValueKeyBindSaved // (Final|Native|Protected|BlueprintCallable) // @ game+0x222b230
	void OnValueKeyBindApplied(struct FKSKeyBind AppliedKeyBind); // Function KillstreakUINew.KSSettingsInfoBase.OnValueKeyBindApplied // (Final|Native|Protected|BlueprintCallable) // @ game+0x222b0b0
	void OnValueIntSaved(int32_t SavedInt); // Function KillstreakUINew.KSSettingsInfoBase.OnValueIntSaved // (Final|Native|Protected|BlueprintCallable) // @ game+0x222b020
	void OnValueIntApplied(int32_t AppliedInt); // Function KillstreakUINew.KSSettingsInfoBase.OnValueIntApplied // (Final|Native|Protected|BlueprintCallable) // @ game+0x222af90
	void OnValueFloatSaved(float SavedFloat); // Function KillstreakUINew.KSSettingsInfoBase.OnValueFloatSaved // (Final|Native|Protected|BlueprintCallable) // @ game+0x222af00
	void OnValueFloatApplied(float AppliedFloat); // Function KillstreakUINew.KSSettingsInfoBase.OnValueFloatApplied // (Final|Native|Protected|BlueprintCallable) // @ game+0x222ae70
	void OnValueBoolSaved(bool SavedBool); // Function KillstreakUINew.KSSettingsInfoBase.OnValueBoolSaved // (Final|Native|Protected|BlueprintCallable) // @ game+0x222ade0
	void OnValueBoolApplied(bool AppliedBool); // Function KillstreakUINew.KSSettingsInfoBase.OnValueBoolApplied // (Final|Native|Protected|BlueprintCallable) // @ game+0x222ad50
	bool IsValidValueKeyBind(struct FKSKeyBind InKey); // Function KillstreakUINew.KSSettingsInfoBase.IsValidValueKeyBind // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x222a880
	bool IsValidValueInt(int32_t inInt); // Function KillstreakUINew.KSSettingsInfoBase.IsValidValueInt // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x222a7e0
	bool IsValidValueFloat(float InFloat); // Function KillstreakUINew.KSSettingsInfoBase.IsValidValueFloat // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x222a750
	bool IsValidValueBool(bool InBool); // Function KillstreakUINew.KSSettingsInfoBase.IsValidValueBool // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x222a6b0
	bool IsDirty(); // Function KillstreakUINew.KSSettingsInfoBase.IsDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x222a670
	void InitializeValue(); // Function KillstreakUINew.KSSettingsInfoBase.InitializeValue // (Native|Event|Protected|BlueprintEvent) // @ game+0x1fdef60
	struct FKSKeyBind GetValueKeyBind(); // Function KillstreakUINew.KSSettingsInfoBase.GetValueKeyBind // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x222a4e0
	int32_t GetValueInt(); // Function KillstreakUINew.KSSettingsInfoBase.GetValueInt // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x222a4b0
	float GetValueFloat(); // Function KillstreakUINew.KSSettingsInfoBase.GetValueFloat // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x222a480
	bool GetValueBool(); // Function KillstreakUINew.KSSettingsInfoBase.GetValueBool // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x222a450
	struct TArray<struct FText> GetTextOptions(); // Function KillstreakUINew.KSSettingsInfoBase.GetTextOptions // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x222a340
	struct FText GetTextOption(int32_t Index); // Function KillstreakUINew.KSSettingsInfoBase.GetTextOption // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x222a150
	float GetStep(); // Function KillstreakUINew.KSSettingsInfoBase.GetStep // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x222a130
	enum class EKSSettingType GetSettingType(); // Function KillstreakUINew.KSSettingsInfoBase.GetSettingType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x222a100
	float GetRoundToNearest(); // Function KillstreakUINew.KSSettingsInfoBase.GetRoundToNearest // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x222a0e0
	bool GetRound(); // Function KillstreakUINew.KSSettingsInfoBase.GetRound // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x222a0c0
	int32_t GetPreviewValueInt(); // Function KillstreakUINew.KSSettingsInfoBase.GetPreviewValueInt // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x222a090
	float GetPreviewValueFloat(); // Function KillstreakUINew.KSSettingsInfoBase.GetPreviewValueFloat // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x222a050
	bool GetPreviewValueBool(); // Function KillstreakUINew.KSSettingsInfoBase.GetPreviewValueBool // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x222a020
	int32_t GetNumTextOptions(); // Function KillstreakUINew.KSSettingsInfoBase.GetNumTextOptions // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21fd010
	float GetMin(); // Function KillstreakUINew.KSSettingsInfoBase.GetMin // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x222a000
	float GetMax(); // Function KillstreakUINew.KSSettingsInfoBase.GetMax // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2229fe0
	struct AKSHUDCommon* GetKSHUD(); // Function KillstreakUINew.KSSettingsInfoBase.GetKSHUD // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2229f80
	bool GetIsPercent(); // Function KillstreakUINew.KSSettingsInfoBase.GetIsPercent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2229f60
	struct FKSKeyBind GetDirtyValueKeyBind(); // Function KillstreakUINew.KSSettingsInfoBase.GetDirtyValueKeyBind // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2229dc0
	int32_t GetDirtyValueInt(); // Function KillstreakUINew.KSSettingsInfoBase.GetDirtyValueInt // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2229d90
	float GetDirtyValueFloat(); // Function KillstreakUINew.KSSettingsInfoBase.GetDirtyValueFloat // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2229d50
	bool GetDirtyValueBool(); // Function KillstreakUINew.KSSettingsInfoBase.GetDirtyValueBool // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2229d20
	struct FKSKeyBind FixupInvalidKeyBind(struct FKSKeyBind InKey); // Function KillstreakUINew.KSSettingsInfoBase.FixupInvalidKeyBind // (Native|Event|Protected|BlueprintEvent|Const) // @ game+0x2229b70
	int32_t FixupInvalidInt(int32_t inInt); // Function KillstreakUINew.KSSettingsInfoBase.FixupInvalidInt // (Native|Event|Protected|BlueprintEvent|Const) // @ game+0x2229ad0
	float FixupInvalidFloat(float InFloat); // Function KillstreakUINew.KSSettingsInfoBase.FixupInvalidFloat // (Native|Event|Protected|BlueprintEvent|Const) // @ game+0x2229a40
	bool FixupInvalidBool(bool InBool); // Function KillstreakUINew.KSSettingsInfoBase.FixupInvalidBool // (Native|Event|Protected|BlueprintEvent|Const) // @ game+0x22299a0
	bool CanRevert(); // Function KillstreakUINew.KSSettingsInfoBase.CanRevert // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2229960
	bool ApplyPreviewIntValue(int32_t inInt); // Function KillstreakUINew.KSSettingsInfoBase.ApplyPreviewIntValue // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x22298c0
	bool ApplyPreviewFloatValue(float InFloat); // Function KillstreakUINew.KSSettingsInfoBase.ApplyPreviewFloatValue // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2229830
	bool ApplyPreviewBoolValue(bool InBool); // Function KillstreakUINew.KSSettingsInfoBase.ApplyPreviewBoolValue // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2229790
	void ApplyPreview(); // Function KillstreakUINew.KSSettingsInfoBase.ApplyPreview // (Final|Native|Public|BlueprintCallable) // @ game+0x2229770
	bool ApplyKeyBindValue(struct FKSKeyBind InKeyBind); // Function KillstreakUINew.KSSettingsInfoBase.ApplyKeyBindValue // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2229620
	bool ApplyIntValue(int32_t inInt); // Function KillstreakUINew.KSSettingsInfoBase.ApplyIntValue // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x896480
	bool ApplyFloatValue(float InFloat); // Function KillstreakUINew.KSSettingsInfoBase.ApplyFloatValue // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2229590
	bool ApplyBoolValue(bool InBool); // Function KillstreakUINew.KSSettingsInfoBase.ApplyBoolValue // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x22294f0
	void Apply(); // Function KillstreakUINew.KSSettingsInfoBase.Apply // (Final|Native|Public|BlueprintCallable) // @ game+0x22294d0
};

// Class KillstreakUINew.KSSettingsInfo_Binding
// Size: 0x128 (Inherited: 0x108)
struct UKSSettingsInfo_Binding : UKSSettingsInfoBase {
	struct FKSKeyBindInfo PrimaryKeyBindInfo; // 0x108(0x10)
	struct FKSKeyBindInfo GamepadKeyBindInfo; // 0x118(0x10)

	void OnSettingsReceivedFromPlayerAccount(); // Function KillstreakUINew.KSSettingsInfo_Binding.OnSettingsReceivedFromPlayerAccount // (Final|Native|Private) // @ game+0x222ad30
	void OnKeyBindingsSaved(struct FName Name); // Function KillstreakUINew.KSSettingsInfo_Binding.OnKeyBindingsSaved // (Final|Native|Private) // @ game+0x222aad0
	void OnKeyBindingsApplied(struct FName Name); // Function KillstreakUINew.KSSettingsInfo_Binding.OnKeyBindingsApplied // (Final|Native|Private) // @ game+0x222aa50
};

// Class KillstreakUINew.KSSettingsInfo_Brightness
// Size: 0x108 (Inherited: 0x108)
struct UKSSettingsInfo_Brightness : UKSSettingsInfoBase {

	void OnSettingSaved(); // Function KillstreakUINew.KSSettingsInfo_Brightness.OnSettingSaved // (Final|Native|Protected|BlueprintCallable) // @ game+0x222acd0
	void OnSettingApplied(); // Function KillstreakUINew.KSSettingsInfo_Brightness.OnSettingApplied // (Final|Native|Protected|BlueprintCallable) // @ game+0x222ac70
	struct UKSSettingsDataFactory* GetKSSettingsDataFactory(); // Function KillstreakUINew.KSSettingsInfo_Brightness.GetKSSettingsDataFactory // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2229fb0
};

// Class KillstreakUINew.KSSettingsInfo_ConsolePerformanceMode
// Size: 0x108 (Inherited: 0x108)
struct UKSSettingsInfo_ConsolePerformanceMode : UKSSettingsInfoBase {

	void OnSettingSaved(); // Function KillstreakUINew.KSSettingsInfo_ConsolePerformanceMode.OnSettingSaved // (Final|Native|Protected|BlueprintCallable) // @ game+0x222acf0
	void OnSettingApplied(); // Function KillstreakUINew.KSSettingsInfo_ConsolePerformanceMode.OnSettingApplied // (Final|Native|Protected|BlueprintCallable) // @ game+0x222ac90
	struct UKSSettingsDataFactory* GetKSSettingsDataFactory(); // Function KillstreakUINew.KSSettingsInfo_ConsolePerformanceMode.GetKSSettingsDataFactory // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2229fb0
};

// Class KillstreakUINew.KSSettingsInfo_CrosshairColor
// Size: 0x110 (Inherited: 0x108)
struct UKSSettingsInfo_CrosshairColor : UKSSettingsInfoBase {
	struct UKSSettingsColorOptionsAsset* ColorOptions; // 0x108(0x08)

	void OnCrosshairColorSaved(int32_t SavedIndex); // Function KillstreakUINew.KSSettingsInfo_CrosshairColor.OnCrosshairColorSaved // (Final|Native|Private) // @ game+0x222a9d0
};

// Class KillstreakUINew.KSSettingsInfo_Generic
// Size: 0x120 (Inherited: 0x108)
struct UKSSettingsInfo_Generic : UKSSettingsInfoBase {
	enum class EKSSettingType KSSettingType; // 0x108(0x01)
	char UnknownData_109[0x7]; // 0x109(0x07)
	struct FString Name; // 0x110(0x10)

	void OnSettingSaved(); // Function KillstreakUINew.KSSettingsInfo_Generic.OnSettingSaved // (Final|Native|Protected|BlueprintCallable) // @ game+0x222ad10
	void OnSettingApplied(); // Function KillstreakUINew.KSSettingsInfo_Generic.OnSettingApplied // (Final|Native|Protected|BlueprintCallable) // @ game+0x222acb0
	struct UKSSettingsDataFactory* GetKSSettingsDataFactory(); // Function KillstreakUINew.KSSettingsInfo_Generic.GetKSSettingsDataFactory // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2229fb0
};

// Class KillstreakUINew.KSSettingsInfo_MuteAudio
// Size: 0x108 (Inherited: 0x108)
struct UKSSettingsInfo_MuteAudio : UKSSettingsInfoBase {
};

// Class KillstreakUINew.KSSettingsInfo_Region
// Size: 0x108 (Inherited: 0x108)
struct UKSSettingsInfo_Region : UKSSettingsInfoBase {

	void OnPreferredSiteUpdated(); // Function KillstreakUINew.KSSettingsInfo_Region.OnPreferredSiteUpdated // (Final|Native|Protected) // @ game+0x222ab50
};

// Class KillstreakUINew.KSSettingsInfo_Resolution
// Size: 0x118 (Inherited: 0x108)
struct UKSSettingsInfo_Resolution : UKSSettingsInfoBase {
	char UnknownData_108[0x10]; // 0x108(0x10)

	void OnScreenResolutionSaved(struct FIntPoint SavedScreenResolution); // Function KillstreakUINew.KSSettingsInfo_Resolution.OnScreenResolutionSaved // (Final|Native|Private|HasDefaults) // @ game+0x222abf0
	void OnScreenResolutionApplied(struct FIntPoint AppliedScreenResolution); // Function KillstreakUINew.KSSettingsInfo_Resolution.OnScreenResolutionApplied // (Final|Native|Private|HasDefaults) // @ game+0x222ab70
};

// Class KillstreakUINew.KSSettingsMenu
// Size: 0x508 (Inherited: 0x4e0)
struct UKSSettingsMenu : UKSWidget {
	char UnknownData_4E0[0x8]; // 0x4e0(0x08)
	struct TArray<struct UKSSettingsPage*> SettingsPages; // 0x4e8(0x10)
	struct UKSSettingsPage* SettingsPageClass; // 0x4f8(0x08)
	struct UKSSettingsMenuConfigAsset* MenuConfigAsset; // 0x500(0x08)

	void RebuildNavigation(); // Function KillstreakUINew.KSSettingsMenu.RebuildNavigation // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnShowPage(struct UKSSettingsPage* SettingsPage); // Function KillstreakUINew.KSSettingsMenu.OnShowPage // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnSaveSettings(); // Function KillstreakUINew.KSSettingsMenu.OnSaveSettings // (Final|Native|Protected) // @ game+0x222fb30
	void OnRevertSettings(); // Function KillstreakUINew.KSSettingsMenu.OnRevertSettings // (Final|Native|Protected) // @ game+0x222fb10
	void OnMenuConfigSet(); // Function KillstreakUINew.KSSettingsMenu.OnMenuConfigSet // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnHidePage(struct UKSSettingsPage* SettingsPage); // Function KillstreakUINew.KSSettingsMenu.OnHidePage // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnConfirmExit(bool ShouldSaveSettings); // Function KillstreakUINew.KSSettingsMenu.OnConfirmExit // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	struct TArray<struct UKSSettingsPage*> GetSettingsPages(); // Function KillstreakUINew.KSSettingsMenu.GetSettingsPages // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x222f520
	void CheckSavePendingChanges(); // Function KillstreakUINew.KSSettingsMenu.CheckSavePendingChanges // (Final|Native|Protected|BlueprintCallable) // @ game+0x222f050
	void AddSettingsPageWidget(struct UKSSettingsPage* SettingsPage); // Function KillstreakUINew.KSSettingsMenu.AddSettingsPageWidget // (Event|Protected|BlueprintEvent) // @ game+0x2587100
};

// Class KillstreakUINew.KSSettingsPage
// Size: 0x500 (Inherited: 0x4e0)
struct UKSSettingsPage : UKSWidget {
	struct TArray<struct UKSSettingsSection*> SettingsSections; // 0x4e0(0x10)
	struct UKSSettingsSection* SettingsSectionClass; // 0x4f0(0x08)
	struct UKSSettingsPageConfigAsset* PageConfigAsset; // 0x4f8(0x08)

	void OnShowSection(struct UKSSettingsSection* SettingsSection); // Function KillstreakUINew.KSSettingsPage.OnShowSection // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnPageConfigSet(); // Function KillstreakUINew.KSSettingsPage.OnPageConfigSet // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnHideSection(struct UKSSettingsSection* SettingsSection); // Function KillstreakUINew.KSSettingsPage.OnHideSection // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	struct TArray<struct UKSSettingsSection*> GetSettingsSections(); // Function KillstreakUINew.KSSettingsPage.GetSettingsSections // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2225f30
	struct UScrollBox* GetScrollBox(); // Function KillstreakUINew.KSSettingsPage.GetScrollBox // (Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void AddSettingsSectionWidget(struct UKSSettingsSection* SettingsSection); // Function KillstreakUINew.KSSettingsPage.AddSettingsSectionWidget // (Event|Protected|BlueprintEvent) // @ game+0x2587100
};

// Class KillstreakUINew.KSSettingsPreview
// Size: 0x4f8 (Inherited: 0x4e0)
struct UKSSettingsPreview : UKSWidget {
	struct FMulticastInlineDelegate OnPreviewValueChanged; // 0x4e0(0x10)
	struct UKSSettingsInfoBase* SettingsInfo; // 0x4f0(0x08)

	void HandleOnValueChanged(bool ChangedExternally); // Function KillstreakUINew.KSSettingsPreview.HandleOnValueChanged // (Final|Native|Private) // @ game+0x222f880
	void HandleOnPreviewValueChanged(); // Function KillstreakUINew.KSSettingsPreview.HandleOnPreviewValueChanged // (Final|Native|Private) // @ game+0x222f860
};

// Class KillstreakUINew.KSSettingsSection
// Size: 0x500 (Inherited: 0x4e0)
struct UKSSettingsSection : UKSWidget {
	struct TArray<struct UKSSettingsGroup*> SettingsGroups; // 0x4e0(0x10)
	struct UKSSettingsGroup* SettingsGroupClass; // 0x4f0(0x08)
	struct UKSSettingsSectionConfigAsset* SectionConfigAsset; // 0x4f8(0x08)

	void OnShowGroup(struct UKSSettingsGroup* SettingsGroup); // Function KillstreakUINew.KSSettingsSection.OnShowGroup // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnSectionConfigSet(); // Function KillstreakUINew.KSSettingsSection.OnSectionConfigSet // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnHideGroup(struct UKSSettingsGroup* SettingsGroup); // Function KillstreakUINew.KSSettingsSection.OnHideGroup // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	struct TArray<struct UKSSettingsGroup*> GetSettingsGroups(); // Function KillstreakUINew.KSSettingsSection.GetSettingsGroups // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2225f30
	void AddSettingsGroupWidget(struct UKSSettingsGroup* SettingsGroup); // Function KillstreakUINew.KSSettingsSection.AddSettingsGroupWidget // (Event|Protected|BlueprintEvent) // @ game+0x2587100
};

// Class KillstreakUINew.KSSettingsWidget
// Size: 0x538 (Inherited: 0x4e0)
struct UKSSettingsWidget : UKSWidget {
	struct FKSSettingsWidgetConfig WidgetConfig; // 0x4e0(0x10)
	struct FText WidgetContainerTitle; // 0x4f0(0x18)
	struct FText WidgetContainerDescription; // 0x508(0x18)
	bool bHasPreview; // 0x520(0x01)
	char UnknownData_521[0x7]; // 0x521(0x07)
	struct UKSSettingsPreview* WidgetContainerPreviewWidget; // 0x528(0x08)
	struct UKSSettingsInfoBase* SettingsInfo; // 0x530(0x08)

	void SaveSetting(); // Function KillstreakUINew.KSSettingsWidget.SaveSetting // (Final|Native|Public|BlueprintCallable) // @ game+0x222fc80
	void RevertSetting(); // Function KillstreakUINew.KSSettingsWidget.RevertSetting // (Final|Native|Public|BlueprintCallable) // @ game+0x222fc60
	void OnWidgetSettingsInfoSet(); // Function KillstreakUINew.KSSettingsWidget.OnWidgetSettingsInfoSet // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnWidgetContainerTitleSet(); // Function KillstreakUINew.KSSettingsWidget.OnWidgetContainerTitleSet // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnWidgetContainerPreviewSet(); // Function KillstreakUINew.KSSettingsWidget.OnWidgetContainerPreviewSet // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnWidgetContainerDescriptionSet(); // Function KillstreakUINew.KSSettingsWidget.OnWidgetContainerDescriptionSet // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnWidgetConfigSet(); // Function KillstreakUINew.KSSettingsWidget.OnWidgetConfigSet // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnSettingsInfoValueChanged(bool bChangedExternally); // Function KillstreakUINew.KSSettingsWidget.OnSettingsInfoValueChanged // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnInputAttached(bool bGamepadAttached, bool bMouseAttached); // Function KillstreakUINew.KSSettingsWidget.OnInputAttached // (Event|Public|BlueprintEvent) // @ game+0x2587100
	bool IsSaved(); // Function KillstreakUINew.KSSettingsWidget.IsSaved // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x222f980
	bool IsApplied(); // Function KillstreakUINew.KSSettingsWidget.IsApplied // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x222f950
	bool HasPreview(); // Function KillstreakUINew.KSSettingsWidget.HasPreview // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x222f930
	bool CanGamepadNavigate(); // Function KillstreakUINew.KSSettingsWidget.CanGamepadNavigate // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x222f020
	void ApplySetting(); // Function KillstreakUINew.KSSettingsWidget.ApplySetting // (Final|Native|Public|BlueprintCallable) // @ game+0x222f000
};

// Class KillstreakUINew.KSShopItemButtonBase
// Size: 0x508 (Inherited: 0x4e0)
struct UKSShopItemButtonBase : UKSWidget {
	struct FMulticastInlineDelegate OnShopSelection; // 0x4e0(0x10)
	struct FMulticastInlineDelegate OnShopViewItemDetails; // 0x4f0(0x10)
	enum class EShopItemType ActiveShopSlot; // 0x500(0x01)
	char UnknownData_501[0x7]; // 0x501(0x07)

	struct UButton* GetHitTarget(); // Function KillstreakUINew.KSShopItemButtonBase.GetHitTarget // (Event|Protected|BlueprintEvent|Const) // @ game+0x2587100
	void DisplayShopItem(struct FShopItem ShopItem, bool IsAffordable, bool IsToggleSlot); // Function KillstreakUINew.KSShopItemButtonBase.DisplayShopItem // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ButtonUnhovered(); // Function KillstreakUINew.KSShopItemButtonBase.ButtonUnhovered // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void ButtonReleased(); // Function KillstreakUINew.KSShopItemButtonBase.ButtonReleased // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void ButtonPressed(); // Function KillstreakUINew.KSShopItemButtonBase.ButtonPressed // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void ButtonHovered(); // Function KillstreakUINew.KSShopItemButtonBase.ButtonHovered // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void ButtonClicked(); // Function KillstreakUINew.KSShopItemButtonBase.ButtonClicked // (Event|Protected|BlueprintEvent) // @ game+0x2587100
};

// Class KillstreakUINew.KSSocialPanelBase
// Size: 0x530 (Inherited: 0x4e0)
struct UKSSocialPanelBase : UKSWidget {
	struct FMulticastInlineDelegate OnDataReady; // 0x4e0(0x10)
	struct FMulticastInlineDelegate OnPlayerCardClicked; // 0x4f0(0x10)
	struct UTreeView* TreeView; // 0x500(0x08)
	struct UKSSocialOverlay* DataSource; // 0x508(0x08)
	char UnknownData_510[0x10]; // 0x510(0x10)
	struct TArray<struct UKSDataSocialCategory*> CategoriesList; // 0x520(0x10)

	void UpdateListData(); // Function KillstreakUINew.KSSocialPanelBase.UpdateListData // (Native|Protected) // @ game+0x19dbee0
	void SetupTreeView(struct UTreeView* List); // Function KillstreakUINew.KSSocialPanelBase.SetupTreeView // (Final|Native|Public|BlueprintCallable) // @ game+0x222fdc0
	void SetDataSource(struct UKSSocialOverlay* Source); // Function KillstreakUINew.KSSocialPanelBase.SetDataSource // (Final|Native|Public|BlueprintCallable) // @ game+0x222fd40
	void OnDataChange(struct TArray<enum class EKSSocialOverlaySection> Sections); // Function KillstreakUINew.KSSocialPanelBase.OnDataChange // (Native|Protected|HasOutParms) // @ game+0x222f9e0
	struct UTreeView* GetTreeView(); // Function KillstreakUINew.KSSocialPanelBase.GetTreeView // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x222f720
	void GetSubListFromData(struct UObject* Source, struct TArray<struct UObject*> Out_List); // Function KillstreakUINew.KSSocialPanelBase.GetSubListFromData // (Final|Native|Protected|HasOutParms) // @ game+0x222f630
	struct UKSSocialOverlay* GetDataSource(); // Function KillstreakUINew.KSSocialPanelBase.GetDataSource // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2060930
};

// Class KillstreakUINew.KSSocialFriendsPanel
// Size: 0x548 (Inherited: 0x530)
struct UKSSocialFriendsPanel : UKSSocialPanelBase {
	struct TArray<struct UKSDataSocialCategory*> CategoryData; // 0x530(0x10)
	struct UKSSocialOverlay* Parent; // 0x540(0x08)
};

// Class KillstreakUINew.KSSocialOverlay
// Size: 0x580 (Inherited: 0x4e0)
struct UKSSocialOverlay : UKSWidget {
	struct FMulticastInlineDelegate OnDataChanged; // 0x4e0(0x10)
	struct TArray<struct UKSDataSocialCategory*> CategoriesList; // 0x4f0(0x10)
	char UnknownData_500[0x8]; // 0x500(0x08)
	struct TMap<struct FWeakObjectPtr<struct UKSPlayerInfo>, enum class EKSSocialOverlaySection> PlayerCategoryMap; // 0x508(0x50)
	struct TArray<struct FWeakObjectPtr<struct UKSPlayerInfo>> PlayersToUpdate; // 0x558(0x10)
	char UnknownData_568[0x8]; // 0x568(0x08)
	struct TArray<struct UKSDataSocialPlayer*> UnusedEntries; // 0x570(0x10)

	void RepopulateAll(); // Function KillstreakUINew.KSSocialOverlay.RepopulateAll // (Final|Native|Private|BlueprintCallable) // @ game+0x222fc40
	void PlayTransition(struct UWidgetAnimation* Animation, bool TransitionOut); // Function KillstreakUINew.KSSocialOverlay.PlayTransition // (Final|Native|Public|BlueprintCallable) // @ game+0x222fb70
	void OnRecentlyPlayedChange(struct UKSFriendDataFactory* Source); // Function KillstreakUINew.KSSocialOverlay.OnRecentlyPlayedChange // (Final|Native|Public) // @ game+0x222fa90
	void HandleUpdatePlayers(); // Function KillstreakUINew.KSSocialOverlay.HandleUpdatePlayers // (Final|Native|Public) // @ game+0x222f910
	struct TArray<struct UKSDataSocialCategory*> GetData(); // Function KillstreakUINew.KSSocialOverlay.GetData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x222f3e0
	struct UKSDataSocialCategory* GetCategory(enum class EKSSocialOverlaySection Category); // Function KillstreakUINew.KSSocialOverlay.GetCategory // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x222f350
	struct TArray<struct UKSDataSocialCategory*> GetCategories(struct TArray<enum class EKSSocialOverlaySection> Categories); // Function KillstreakUINew.KSSocialOverlay.GetCategories // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x222f220
};

// Class KillstreakUINew.KSSocialSearchPanel
// Size: 0x578 (Inherited: 0x530)
struct UKSSocialSearchPanel : UKSSocialPanelBase {
	struct FMulticastInlineDelegate OnOpen; // 0x530(0x10)
	struct FMulticastInlineDelegate OnClose; // 0x540(0x10)
	char UnknownData_550[0x28]; // 0x550(0x28)

	void OnSearchTimeout(); // Function KillstreakUINew.KSSocialSearchPanel.OnSearchTimeout // (Final|Native|Private) // @ game+0x222fb50
	void OnSearchStart(struct FText SearchTerm); // Function KillstreakUINew.KSSocialSearchPanel.OnSearchStart // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x2587100
	void OnSearchComplete(struct FText SearchTerm, struct FText Error, struct TArray<struct UKSDataSocialPlayer*> Results); // Function KillstreakUINew.KSSocialSearchPanel.OnSearchComplete // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x2587100
	bool IsSearching(); // Function KillstreakUINew.KSSocialSearchPanel.IsSearching // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x222f9b0
	struct FText GetActiveSearchTerm(); // Function KillstreakUINew.KSSocialSearchPanel.GetActiveSearchTerm // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x222f170
	void DoSearch(struct FText SearchTerm); // Function KillstreakUINew.KSSocialSearchPanel.DoSearch // (Final|Native|Public|BlueprintCallable) // @ game+0x222f090
};

// Class KillstreakUINew.KSSocialWidgetBase
// Size: 0x4e8 (Inherited: 0x4e0)
struct UKSSocialWidgetBase : UKSWidget {
	struct UKSPartyDataFactory* CachedPartyDataFactory; // 0x4e0(0x08)

	void SortFriendData(struct TArray<struct UPUMG_PlayerInfo*> Friends); // Function KillstreakUINew.KSSocialWidgetBase.SortFriendData // (Final|Native|Protected|HasOutParms) // @ game+0x222fe80
	void SearchPlayerName(struct FString PlayerName); // Function KillstreakUINew.KSSocialWidgetBase.SearchPlayerName // (Final|Native|Protected|BlueprintCallable) // @ game+0x222fca0
	void OnFriendRequestsUpdated(); // Function KillstreakUINew.KSSocialWidgetBase.OnFriendRequestsUpdated // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void HandleSearchByNameResultsUpdated(); // Function KillstreakUINew.KSSocialWidgetBase.HandleSearchByNameResultsUpdated // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void HandlePartyDataUpdated(); // Function KillstreakUINew.KSSocialWidgetBase.HandlePartyDataUpdated // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void HandleFriendInviteReceived(struct FPUMG_FriendData PlayerData); // Function KillstreakUINew.KSSocialWidgetBase.HandleFriendInviteReceived // (Final|Native|Protected) // @ game+0x222f740
	void HandleFriendDataUpdated(); // Function KillstreakUINew.KSSocialWidgetBase.HandleFriendDataUpdated // (Event|Public|BlueprintEvent) // @ game+0x2587100
	struct TArray<struct UPUMG_PlayerInfo*> GetSortedFriends(); // Function KillstreakUINew.KSSocialWidgetBase.GetSortedFriends // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x222f5b0
	struct TArray<struct UPUMG_PlayerInfo*> GetSearchResults(); // Function KillstreakUINew.KSSocialWidgetBase.GetSearchResults // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x222f4a0
	struct UKSPlayerWhoDataFactory* GetPlayerWhoDataFactory(); // Function KillstreakUINew.KSSocialWidgetBase.GetPlayerWhoDataFactory // (Final|Native|Protected) // @ game+0x222f470
	struct UKSPartyDataFactory* GetPartyDataFactory(); // Function KillstreakUINew.KSSocialWidgetBase.GetPartyDataFactory // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x222f440
	struct UKSFriendDataFactory* GetFriendDataFactory(); // Function KillstreakUINew.KSSocialWidgetBase.GetFriendDataFactory // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x222f410
	void ClearSearchResults(); // Function KillstreakUINew.KSSocialWidgetBase.ClearSearchResults // (Final|Native|Protected|BlueprintCallable) // @ game+0x222f070
};

// Class KillstreakUINew.KSSortableGridPanel
// Size: 0x170 (Inherited: 0x158)
struct UKSSortableGridPanel : UGridPanel {
	enum class EOrientation Orientation; // 0x158(0x01)
	char UnknownData_159[0x3]; // 0x159(0x03)
	struct FDelegate OnSortCompareChildrenEvent; // 0x15c(0x10)
	char UnknownData_16C[0x4]; // 0x16c(0x04)

	bool SortChildrenComparator__DelegateSignature(struct UWidget* LHS, struct UWidget* RHS); // DelegateFunction KillstreakUINew.KSSortableGridPanel.SortChildrenComparator__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void SortChildren(); // Function KillstreakUINew.KSSortableGridPanel.SortChildren // (Final|Native|Public|BlueprintCallable) // @ game+0x222fe40
	struct UGridSlot* AddChildAutoLayout(struct UWidget* Content); // Function KillstreakUINew.KSSortableGridPanel.AddChildAutoLayout // (Final|Native|Public|BlueprintCallable) // @ game+0x222ef70
};

// Class KillstreakUINew.KSSortableVerticalBox
// Size: 0x148 (Inherited: 0x138)
struct UKSSortableVerticalBox : UVerticalBox {
	struct FDelegate OnSortCompareChildrenEvent; // 0x138(0x10)

	bool SortChildrenComparator__DelegateSignature(struct UWidget* LHS, struct UWidget* RHS); // DelegateFunction KillstreakUINew.KSSortableVerticalBox.SortChildrenComparator__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void SortChildren(); // Function KillstreakUINew.KSSortableVerticalBox.SortChildren // (Final|Native|Public|BlueprintCallable) // @ game+0x222fe60
};

// Class KillstreakUINew.KSStorePanelItem
// Size: 0x50 (Inherited: 0x28)
struct UKSStorePanelItem : UObject {
	struct UPUMG_StoreItem* StoreItem; // 0x28(0x08)
	bool IsNew; // 0x30(0x01)
	bool DisplaySaleTag; // 0x31(0x01)
	bool HasBeenSeen; // 0x32(0x01)
	char UnknownData_33[0x5]; // 0x33(0x05)
	struct FText CustomBannerText; // 0x38(0x18)

	bool IsOnSale(); // Function KillstreakUINew.KSStorePanelItem.IsOnSale // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2234530
};

// Class KillstreakUINew.KSStoreSectionItem
// Size: 0x50 (Inherited: 0x28)
struct UKSStoreSectionItem : UObject {
	struct TArray<struct UKSStorePanelItem*> StorePanelItems; // 0x28(0x10)
	int32_t column; // 0x38(0x04)
	int32_t Row; // 0x3c(0x04)
	enum class EStoreItemWidgetType WidgetType; // 0x40(0x01)
	char UnknownData_41[0x7]; // 0x41(0x07)
	struct UKSStorePanelItem* CurrentlyViewedItem; // 0x48(0x08)

	bool HasUnseenItems(); // Function KillstreakUINew.KSStoreSectionItem.HasUnseenItems // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2234470
};

// Class KillstreakUINew.KSStoreSection
// Size: 0x78 (Inherited: 0x28)
struct UKSStoreSection : UObject {
	struct TArray<struct UKSStoreSectionItem*> SectionItems; // 0x28(0x10)
	enum class EStoreSectionTypes SectionType; // 0x38(0x01)
	char UnknownData_39[0x3f]; // 0x39(0x3f)

	bool HasUnseenItems(); // Function KillstreakUINew.KSStoreSection.HasUnseenItems // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2234440
	struct FText GetSectionHeader(); // Function KillstreakUINew.KSStoreSection.GetSectionHeader // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2233830
	int32_t GetSecondsRemaining(); // Function KillstreakUINew.KSStoreSection.GetSecondsRemaining // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2233800
};

// Class KillstreakUINew.KSStoreWidget
// Size: 0x4e8 (Inherited: 0x4e0)
struct UKSStoreWidget : UKSWidget {
	char UnknownData_4E0[0x8]; // 0x4e0(0x08)

	void OnVendorsReceived(int32_t GroupId, struct TArray<int32_t> VendorIds); // Function KillstreakUINew.KSStoreWidget.OnVendorsReceived // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x2587100
	void OnPricePointsReveived(); // Function KillstreakUINew.KSStoreWidget.OnPricePointsReveived // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnPortalOffersReceived(); // Function KillstreakUINew.KSStoreWidget.OnPortalOffersReceived // (Event|Public|BlueprintEvent) // @ game+0x2587100
	bool HasAllRequiredStoreInformation(); // Function KillstreakUINew.KSStoreWidget.HasAllRequiredStoreInformation // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2234410
	int32_t GetStoreRotationSecondsRemaining(); // Function KillstreakUINew.KSStoreWidget.GetStoreRotationSecondsRemaining // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2233950
	struct TArray<struct UKSStoreSection*> GetStoreLayout(); // Function KillstreakUINew.KSStoreWidget.GetStoreLayout // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x22338d0
	struct UKSStoreItemHelper* GetStoreItemHelper(); // Function KillstreakUINew.KSStoreWidget.GetStoreItemHelper // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x221b9d0
};

// Class KillstreakUINew.KSTargetMarkerWidget
// Size: 0x370 (Inherited: 0x328)
struct UKSTargetMarkerWidget : UKSScreenMarkerWidgetBase {
	struct FMulticastInlineDelegate OnTargetChanged; // 0x328(0x10)
	struct FMulticastInlineDelegate OnModUsed; // 0x338(0x10)
	struct AActor* CurrentTarget; // 0x348(0x08)
	struct UKSModInst_Activated* TargetModInst; // 0x350(0x08)
	struct TScriptInterface<None> Targeter; // 0x358(0x10)
	char UnknownData_368[0x8]; // 0x368(0x08)

	void UpdateCharge(struct UKSModInst_Activated* ModInst); // Function KillstreakUINew.KSTargetMarkerWidget.UpdateCharge // (Final|Native|Public) // @ game+0x22351a0
	void TryApplyViewState(enum class ETargetMarkerViewState ViewState, bool bForce); // Function KillstreakUINew.KSTargetMarkerWidget.TryApplyViewState // (Final|Native|Protected|BlueprintCallable) // @ game+0x2234d50
	void ReceiveNewTarget(struct TScriptInterface<None> InTargeter, struct AActor* NewTarget); // Function KillstreakUINew.KSTargetMarkerWidget.ReceiveNewTarget // (Final|Native|Public) // @ game+0x22348b0
	void OnGamepadSelectedChanged(int32_t NewSelectionIndex); // Function KillstreakUINew.KSTargetMarkerWidget.OnGamepadSelectedChanged // (Event|Public|BlueprintEvent) // @ game+0x2587100
	enum class ETargetMarkerViewState GetCurrentViewState(); // Function KillstreakUINew.KSTargetMarkerWidget.GetCurrentViewState // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x2233450
	void BindTargetModInst(); // Function KillstreakUINew.KSTargetMarkerWidget.BindTargetModInst // (Native|Event|Protected|BlueprintEvent) // @ game+0x89ee40
	void ApplyViewState(enum class ETargetMarkerViewState ViewState); // Function KillstreakUINew.KSTargetMarkerWidget.ApplyViewState // (Event|Protected|BlueprintEvent) // @ game+0x2587100
};

// Class KillstreakUINew.KSTextChatWidget
// Size: 0x520 (Inherited: 0x4e0)
struct UKSTextChatWidget : UKSWidget {
	struct TArray<enum class EMercCosmeticSlot> RadialMenuItemsToShowInChat; // 0x4e0(0x10)
	bool ActiveChatChannelsDirty; // 0x4f0(0x01)
	char UnknownData_4F1[0x7]; // 0x4f1(0x07)
	struct TArray<struct FPUMG_ActiveChatChannelData> ActiveChatChannels; // 0x4f8(0x10)
	int32_t CurrentChatChannelIndex; // 0x508(0x04)
	char UnknownData_50C[0x4]; // 0x50c(0x04)
	struct FMulticastInlineDelegate OnCurrentChatChannelChanged; // 0x510(0x10)

	void Whisper(struct FString PlayerName, struct FString Message); // Function KillstreakUINew.KSTextChatWidget.Whisper // (Final|Native|Protected) // @ game+0x2235220
	void Unblock(struct FString PlayerName); // Function KillstreakUINew.KSTextChatWidget.Unblock // (Final|Native|Protected) // @ game+0x2232d60
	void UIX_SubmitTextInput(struct FString Message); // Function KillstreakUINew.KSTextChatWidget.UIX_SubmitTextInput // (Final|Native|Protected|BlueprintCallable) // @ game+0x2235100
	void UIX_SendMessageToPlayer(struct FString Message, int64_t PlayerId); // Function KillstreakUINew.KSTextChatWidget.UIX_SendMessageToPlayer // (Final|Native|Protected|BlueprintCallable) // @ game+0x2235020
	void UIX_SendMessageToChannel(struct FString Message, enum class EPUMG_ChatChannel Channel); // Function KillstreakUINew.KSTextChatWidget.UIX_SendMessageToChannel // (Final|Native|Protected|BlueprintCallable) // @ game+0x2234f40
	void UIX_MarkMessageAsRead(int32_t MessageIndex); // Function KillstreakUINew.KSTextChatWidget.UIX_MarkMessageAsRead // (Final|Native|Protected|BlueprintCallable) // @ game+0x2234ec0
	void UIX_ExecuteChatCommandLine(struct FString CommandLine); // Function KillstreakUINew.KSTextChatWidget.UIX_ExecuteChatCommandLine // (Final|Native|Protected|BlueprintCallable) // @ game+0x2234e20
	void ToggleDND(); // Function KillstreakUINew.KSTextChatWidget.ToggleDND // (Final|Native|Protected) // @ game+0x2234d30
	void ShowTextChat(); // Function KillstreakUINew.KSTextChatWidget.ShowTextChat // (Native|Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x21fcff0
	bool SetChatChannelToPlayer(int64_t PlayerId); // Function KillstreakUINew.KSTextChatWidget.SetChatChannelToPlayer // (Final|Native|Protected|BlueprintCallable) // @ game+0x2234af0
	bool SetChatChannel(enum class EPUMG_ChatChannel Channel, int64_t PersonalChannelPlayerId); // Function KillstreakUINew.KSTextChatWidget.SetChatChannel // (Final|Native|Protected|BlueprintCallable) // @ game+0x2234a30
	void Reply(struct FString Message); // Function KillstreakUINew.KSTextChatWidget.Reply // (Final|Native|Protected) // @ game+0x2234990
	void ProcessMessageOnClient(struct FText Message, enum class EPUMG_ChatChannel Channel); // Function KillstreakUINew.KSTextChatWidget.ProcessMessageOnClient // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x2234790
	void PreviousChatChannel(); // Function KillstreakUINew.KSTextChatWidget.PreviousChatChannel // (Final|Native|Protected|BlueprintCallable) // @ game+0x2234770
	void OpenTextChatToPlayer(struct UPUMG_PlayerInfo* Player); // Function KillstreakUINew.KSTextChatWidget.OpenTextChatToPlayer // (Native|Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x22113c0
	void OpenTextChat(bool BeginChatCommand); // Function KillstreakUINew.KSTextChatWidget.OpenTextChat // (Native|Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x22346e0
	void NextChatChannel(); // Function KillstreakUINew.KSTextChatWidget.NextChatChannel // (Final|Native|Protected|BlueprintCallable) // @ game+0x2234580
	bool IsActiveChatChannel(enum class EPUMG_ChatChannel Channel); // Function KillstreakUINew.KSTextChatWidget.IsActiveChatChannel // (Final|Native|Protected|BlueprintCallable) // @ game+0x22344a0
	void HandleChatMessageReceived(struct FPUMG_ChatData ReceivedMessage); // Function KillstreakUINew.KSTextChatWidget.HandleChatMessageReceived // (Native|Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x2233a70
	void HandleChatMessageRead(struct FPUMG_ChatData ReadMessage); // Function KillstreakUINew.KSTextChatWidget.HandleChatMessageRead // (Native|Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x2233980
	void HandleChatChannelLeft(enum class EPUMG_ChatChannel Channel); // Function KillstreakUINew.KSTextChatWidget.HandleChatChannelLeft // (Native|Event|Protected|BlueprintEvent) // @ game+0x221c4d0
	void HandleChatChannelJoined(enum class EPUMG_ChatChannel Channel); // Function KillstreakUINew.KSTextChatWidget.HandleChatChannelJoined // (Native|Event|Protected|BlueprintEvent) // @ game+0x2221390
	struct FPUMG_ActiveChatChannelData GetCurrentChatChannel(); // Function KillstreakUINew.KSTextChatWidget.GetCurrentChatChannel // (Final|Native|Protected|BlueprintCallable) // @ game+0x2233420
	struct UKSChatDataFactory* GetChatDataFactory(); // Function KillstreakUINew.KSTextChatWidget.GetChatDataFactory // (Final|Native|Protected|BlueprintCallable) // @ game+0x22333f0
	struct TArray<struct FPUMG_ActiveChatChannelData> GetActiveChatChannels(); // Function KillstreakUINew.KSTextChatWidget.GetActiveChatChannels // (Final|Native|Protected|BlueprintCallable) // @ game+0x2233330
	bool CanChatInChannel(enum class EPUMG_ChatChannel Channel); // Function KillstreakUINew.KSTextChatWidget.CanChatInChannel // (Native|Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x2232e00
	void Block(struct FString PlayerName); // Function KillstreakUINew.KSTextChatWidget.Block // (Final|Native|Protected) // @ game+0x2232d60
};

// Class KillstreakUINew.KSToastNotificationWidgetBase
// Size: 0x520 (Inherited: 0x4e0)
struct UKSToastNotificationWidgetBase : UKSWidget {
	struct FMulticastInlineDelegate OnToastReceived; // 0x4e0(0x10)
	int32_t MaxToastNotification; // 0x4f0(0x04)
	int32_t CurrentToastCount; // 0x4f4(0x04)
	bool IsBusy; // 0x4f8(0x01)
	char UnknownData_4F9[0x7]; // 0x4f9(0x07)
	struct TArray<struct FToastData> ToastQueue; // 0x500(0x10)
	struct TArray<struct FToastData> PostMatchToasts; // 0x510(0x10)

	void TestDisplayChallengeNotification(); // Function KillstreakUINew.KSToastNotificationWidgetBase.TestDisplayChallengeNotification // (Final|Native|Protected) // @ game+0xbc5780
	void StoreToastQueue(struct FToastData ToastNotification); // Function KillstreakUINew.KSToastNotificationWidgetBase.StoreToastQueue // (Final|Native|Protected|BlueprintCallable) // @ game+0x2234ba0
	void ShowToastNotification(); // Function KillstreakUINew.KSToastNotificationWidgetBase.ShowToastNotification // (Final|Native|Protected|BlueprintCallable) // @ game+0x2234b80
	void OnToastNotificationReceived(struct FToastData ToastData); // Function KillstreakUINew.KSToastNotificationWidgetBase.OnToastNotificationReceived // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnChallengeCompleted(struct UKSActivityInstance* Activity); // Function KillstreakUINew.KSToastNotificationWidgetBase.OnChallengeCompleted // (Final|Native|Protected) // @ game+0x2234660
	void OnAwardsCompleted(struct UKSActivityInstance* Activity); // Function KillstreakUINew.KSToastNotificationWidgetBase.OnAwardsCompleted // (Final|Native|Protected) // @ game+0x22345e0
	void NotifyToastShown(); // Function KillstreakUINew.KSToastNotificationWidgetBase.NotifyToastShown // (Final|Native|Protected|BlueprintCallable) // @ game+0x22345c0
	void NotifyToastHidden(); // Function KillstreakUINew.KSToastNotificationWidgetBase.NotifyToastHidden // (Final|Native|Protected|BlueprintCallable) // @ game+0x22345a0
	void HandlePartyMemberPromoted(int64_t PlayerId); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandlePartyMemberPromoted // (Final|Native|Protected) // @ game+0x2234390
	void HandlePartyMemberLeftGeneric(); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandlePartyMemberLeftGeneric // (Final|Native|Protected) // @ game+0x2234370
	void HandlePartyMemberKick(int64_t PlayerId); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandlePartyMemberKick // (Final|Native|Protected) // @ game+0x22342f0
	void HandlePartyMemberAdded(struct FPUMG_PartyMemberData PartyMemberData); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandlePartyMemberAdded // (Final|Native|Protected) // @ game+0x22341c0
	void HandlePartyLocalPlayerLeft(); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandlePartyLocalPlayerLeft // (Final|Native|Protected) // @ game+0x22341a0
	void HandlePartyInviteSent(struct FText PlayerName); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandlePartyInviteSent // (Final|Native|Protected) // @ game+0x22340c0
	void HandlePartyInviteRejected(); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandlePartyInviteRejected // (Final|Native|Protected) // @ game+0x22340a0
	void HandlePartyInviteReceived(struct UPUMG_PlayerInfo* PartyInviter); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandlePartyInviteReceived // (Final|Native|Protected) // @ game+0x2234020
	void HandlePartyInviteError(struct FText PlayerName); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandlePartyInviteError // (Final|Native|Protected) // @ game+0x2233f40
	void HandlePartyInviteAccepted(); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandlePartyInviteAccepted // (Final|Native|Protected) // @ game+0x2233f20
	void HandleFriendRejected(struct FText PlayerName); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandleFriendRejected // (Final|Native|Protected) // @ game+0x2233e40
	void HandleFriendInviteReceived(struct FPUMG_FriendData PlayerData); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandleFriendInviteReceived // (Final|Native|Protected) // @ game+0x2233d20
	void HandleFriendAddSuccess(struct FString PlayerName); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandleFriendAddSuccess // (Final|Native|Protected) // @ game+0x2233b60
	void HandleFriendAdded(struct FText PlayerName); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandleFriendAdded // (Final|Native|Protected) // @ game+0x2233c40
	struct TArray<struct FToastData> GetPostMatchToasts(); // Function KillstreakUINew.KSToastNotificationWidgetBase.GetPostMatchToasts // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2233610
	struct UKSPlayerChallengesManager* GetPlayerChallengesManager(); // Function KillstreakUINew.KSToastNotificationWidgetBase.GetPlayerChallengesManager // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x22335e0
	struct UKSAwardsManager* GetPlayerAwardsManager(); // Function KillstreakUINew.KSToastNotificationWidgetBase.GetPlayerAwardsManager // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x22335b0
	struct UKSPartyDataFactory* GetPartyDataFactory(); // Function KillstreakUINew.KSToastNotificationWidgetBase.GetPartyDataFactory // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x2211a90
	bool GetNext(struct FToastData NextToastNotification); // Function KillstreakUINew.KSToastNotificationWidgetBase.GetNext // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x2233470
	struct UKSFriendDataFactory* GetFriendDataFactory(); // Function KillstreakUINew.KSToastNotificationWidgetBase.GetFriendDataFactory // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x222f410
	struct UKSBattlePassProgressionManager* GetBattlePassProgressionManager(); // Function KillstreakUINew.KSToastNotificationWidgetBase.GetBattlePassProgressionManager // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x22333c0
	void CreatePlayerLevelUpToasts(struct UKSActivityInstance* PlayerLevelActivityInstance, struct FActivityTier TierObtained); // Function KillstreakUINew.KSToastNotificationWidgetBase.CreatePlayerLevelUpToasts // (Final|Native|Protected|BlueprintCallable) // @ game+0x2233210
	void CreateMiniBattlePassTierUnlockToasts(struct UKSActivityInstance* MiniBattlePassActivityInstance, struct FActivityTier TierObtained); // Function KillstreakUINew.KSToastNotificationWidgetBase.CreateMiniBattlePassTierUnlockToasts // (Final|Native|Protected|BlueprintCallable) // @ game+0x22330f0
	void CreateMercMasteryLevelUpToasts(struct UKSActivityInstance* MercMasteryActivityInstance, struct FActivityTier TierObtained); // Function KillstreakUINew.KSToastNotificationWidgetBase.CreateMercMasteryLevelUpToasts // (Final|Native|Protected|BlueprintCallable) // @ game+0x2232fd0
	void CreateBoostActivationToastBySpentItem(struct UPlatformInventoryItem* SpentItem); // Function KillstreakUINew.KSToastNotificationWidgetBase.CreateBoostActivationToastBySpentItem // (Final|Native|Protected|BlueprintCallable) // @ game+0x2232f50
	void CreateBoostActivationToastByAcquisition(struct UPUMG_StoreItem* AcquisitionItem); // Function KillstreakUINew.KSToastNotificationWidgetBase.CreateBoostActivationToastByAcquisition // (Final|Native|Protected|BlueprintCallable) // @ game+0x2232ed0
	void ClearPostMatchQueue(); // Function KillstreakUINew.KSToastNotificationWidgetBase.ClearPostMatchQueue // (Final|Native|Protected|BlueprintCallable) // @ game+0x2232eb0
	void ClearNotificationQueue(); // Function KillstreakUINew.KSToastNotificationWidgetBase.ClearNotificationQueue // (Final|Native|Protected|BlueprintCallable) // @ game+0x2232e90
};

// Class KillstreakUINew.KSTopBarStatusIconInterface
// Size: 0x28 (Inherited: 0x28)
struct UKSTopBarStatusIconInterface : UInterface {

	void UnbindEventFromTopBarStatusIconShowingChanged(struct FDelegate Callback); // Function KillstreakUINew.KSTopBarStatusIconInterface.UnbindEventFromTopBarStatusIconShowingChanged // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	bool IsInTopBarStatusIconShowingState(); // Function KillstreakUINew.KSTopBarStatusIconInterface.IsInTopBarStatusIconShowingState // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	struct UTexture2D* GetTopBarStatusIconTexture(); // Function KillstreakUINew.KSTopBarStatusIconInterface.GetTopBarStatusIconTexture // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BindEventToTopBarStatusIconShowingChanged(struct FDelegate Callback); // Function KillstreakUINew.KSTopBarStatusIconInterface.BindEventToTopBarStatusIconShowingChanged // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

// Class KillstreakUINew.KSTreeView
// Size: 0x3e0 (Inherited: 0x3d8)
struct UKSTreeView : UTreeView {
	struct FWeakObjectPtr<struct APUMG_HUD> MyHud; // 0x3d8(0x08)

	void UninitializeWidget(); // Function KillstreakUINew.KSTreeView.UninitializeWidget // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x223a420
	void NavigateSelectItem(struct UObject* Item); // Function KillstreakUINew.KSTreeView.NavigateSelectItem // (Final|Native|Public|BlueprintCallable) // @ game+0x2239cc0
	bool IsItemExpanded(struct UObject* Item); // Function KillstreakUINew.KSTreeView.IsItemExpanded // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x22399c0
	void InitializeWidget(); // Function KillstreakUINew.KSTreeView.InitializeWidget // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x22396e0
	int32_t GetNumItemsInLayout(); // Function KillstreakUINew.KSTreeView.GetNumItemsInLayout // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2238ac0
	bool BP_GetEntryWidgetFromItem(struct UObject* Item, struct UUserWidget* OutWidget); // Function KillstreakUINew.KSTreeView.BP_GetEntryWidgetFromItem // (Final|Native|Private|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2237b20
};

// Class KillstreakUINew.KSUIBlueprintFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UKSUIBlueprintFunctionLibrary : UBlueprintFunctionLibrary {

	bool UIX_ReportPlayer(struct FReportPlayerParams Params); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.UIX_ReportPlayer // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x223a340
	struct FReportPlayerParams SetupReportPlayerFromScoreboardStats(int64_t PlayerId, struct FScoreboardStats State); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.SetupReportPlayerFromScoreboardStats // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x223a1f0
	struct FReportPlayerParams SetupReportPlayerFromGameState(int64_t PlayerId, struct AKSGameState* State); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.SetupReportPlayerFromGameState // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x223a0f0
	void SetHiddenCursorMode(struct UObject* WorldContextObject, struct APlayerController* PlayerController, bool ShouldHide); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.SetHiddenCursorMode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2239ff0
	void ResetHiddenCursorMode(struct UObject* WorldContextObject, struct APlayerController* PlayerController); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.ResetHiddenCursorMode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2239f40
	void RegisterGridNavigation(struct UPUMG_Widget* ParentWidget, int32_t FocusGroup, struct TArray<struct UWidget*> NavWidgets, int32_t GridWidth, bool NavToLastElementOnDown); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.RegisterGridNavigation // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2239d70
	struct FText Key_GetShortDisplayName(struct FKey Key); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.Key_GetShortDisplayName // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x2239ba0
	bool IsPlayerRelevant(struct FJobSelectionEntry Entry, struct AKSPlayerState* InPlayerState, bool bLockedInOnly); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.IsPlayerRelevant // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x2239a70
	bool IsInsideMargins(struct UObject* WorldContextObject, struct FVector2D Translation, struct FVector2D Margins); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.IsInsideMargins // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x22398d0
	bool IsInCenteredScreenRect(float PositionX, float PositionY, float MarginX, float MarginY); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.IsInCenteredScreenRect // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2239780
	bool IsExperimentActive(enum class EExperimentalFeatureName Feature); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.IsExperimentActive // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2239700
	struct UKSStoreItemHelper* GetStoreItemHelper(struct UObject* WorldContextObject); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetStoreItemHelper // (Final|Native|Static|Public) // @ game+0x22394e0
	enum class EJobSelectionState GetSelectionStateForPlayer(struct FJobSelectionEntry Entry, struct AKSPlayerState* InPlayerState); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetSelectionStateForPlayer // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x22393e0
	bool GetQueueName(struct FText DisplayNameText); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetQueueName // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x2239310
	bool GetQueueDisplayName(struct FText DisplayNameText, struct UObject* WorldContextObject); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetQueueDisplayName // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x22391f0
	bool GetPlayerSelectInfo(struct FJobSelectionEntry Entry, struct AKSPlayerState* InPlayerState, struct FPlayerJobSelectInfo PlayerSelectInfo); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetPlayerSelectInfo // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x2239090
	struct UPUMG_PlayerInfo* GetPlayerInfoById(struct APUMG_HUD* HUD, int64_t PlayerId); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetPlayerInfoById // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2238fd0
	bool GetPingIconByType(struct UDataTable* ContextualPingTypesDT, enum class EPingType PingType, struct TSoftObjectPtr<struct UTexture2D> PingIcon); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetPingIconByType // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x2238e90
	bool GetPingIconByMessage(struct UDataTable* ContextualPingMessagesDT, enum class EPingMessage PingMessage, struct TSoftObjectPtr<struct UTexture2D> PingIcon); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetPingIconByMessage // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x2238d50
	bool GetPingColorByType(struct UDataTable* ContextualPingTypesDT, enum class EPingType PingType, struct FLinearColor PingColor); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetPingColorByType // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x2238c40
	struct UPUMG_PlayerInfo* GetLocalPlayerInfo(struct APUMG_HUD* HUD); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetLocalPlayerInfo // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2238a40
	bool GetKSJobItemByLootId(struct UObject* WorldContextObject, int32_t LootTableItemId, bool RequireActive, struct UKSJobItem* JobItem); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetKSJobItemByLootId // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x22388c0
	bool GetKSJobItemByItemId(struct UObject* WorldContextObject, int32_t ItemId, bool RequireActive, struct UKSJobItem* JobItem); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetKSJobItemByItemId // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x2238770
	struct TArray<int32_t> GetDigitsFromInt(int32_t Value); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetDigitsFromInt // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x22386b0
	void GetCurrentRogueMasteryLevel(struct UKSActivityInstance* ActivityInstance, int32_t MasteryLevel, int32_t CurrentXPProgress, int32_t XPRequiredForLevel); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetCurrentRogueMasteryLevel // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x2238540
	bool FindContextualPingTypesRowByType(struct UDataTable* ContextualPingTypesDT, enum class EPingType PingType, struct FContextualPingTypesRow ContextualPingTypesRow); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.FindContextualPingTypesRowByType // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x2238400
	bool FindContextualPingMessagesRowByMessage(struct UDataTable* ContextualPingMessagesDT, enum class EPingMessage PingMessage, struct FContextualPingMessagesRow ContextualPingMessagesRow); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.FindContextualPingMessagesRowByMessage // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x22382c0
	bool DistanceToClosestScreenEdge(struct UObject* WorldContextObject, struct FVector2D Location, float OutDistX, float OutDistY); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.DistanceToClosestScreenEdge // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x2238160
	enum class EJobSelectionState DetermineEntryLocalSelectionState(struct FJobSelectionEntry Entry); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.DetermineEntryLocalSelectionState // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x22380b0
	struct UKSSettingsWidget* CreateSettingsWidgetWithConfig(struct APUMG_HUD* HUD, struct FKSSettingsWidgetConfig SettingsWidgetConfig); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.CreateSettingsWidgetWithConfig // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2237fe0
	struct UKSSettingsWidget* CreateSettingsWidget(struct APUMG_HUD* HUD, struct UKSSettingsWidget* SettingsWidgetClass); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.CreateSettingsWidget // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x2237f10
	struct UKSSettingsPreview* CreateSettingsPreview(struct APUMG_HUD* HUD, struct UKSSettingsPreview* SettingsPreviewClass); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.CreateSettingsPreview // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x2237e40
	int32_t CompareStrings(struct FString LeftString, struct FString RightString); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.CompareStrings // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2237d50
	void ClearKeyboardFocus(); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.ClearKeyboardFocus // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2237d30
	bool CanPlayerSelectEntry(struct FJobSelectionEntry Entry, struct AKSPlayerState* InPlayerState); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.CanPlayerSelectEntry // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x2237c30
};

// Class KillstreakUINew.KSUISoundLibrary
// Size: 0x28 (Inherited: 0x28)
struct UKSUISoundLibrary : UObject {
};

// Class KillstreakUINew.KSGenericSoundLibrary
// Size: 0x40 (Inherited: 0x28)
struct UKSGenericSoundLibrary : UKSUISoundLibrary {
	struct UAkAudioEvent* BackToScreenSound; // 0x28(0x08)
	struct UAkAudioEvent* ErrorSound; // 0x30(0x08)
	struct UAkAudioEvent* ScreenTransitionSound; // 0x38(0x08)
};

// Class KillstreakUINew.KSButtonSoundLibrary
// Size: 0x40 (Inherited: 0x28)
struct UKSButtonSoundLibrary : UKSUISoundLibrary {
	struct UAkAudioEvent* ButtonClicked; // 0x28(0x08)
	struct UAkAudioEvent* ButtonHovered; // 0x30(0x08)
	struct UAkAudioEvent* ButtonUnhovered; // 0x38(0x08)
};

// Class KillstreakUINew.KSScrollButtonSoundLibrary
// Size: 0x48 (Inherited: 0x28)
struct UKSScrollButtonSoundLibrary : UKSUISoundLibrary {
	struct UAkAudioEvent* ScrollClicked; // 0x28(0x08)
	struct UAkAudioEvent* ScrollHovered; // 0x30(0x08)
	struct UAkAudioEvent* ScrollUnhovered; // 0x38(0x08)
	struct UAkAudioEvent* ScrollingSound; // 0x40(0x08)
};

// Class KillstreakUINew.KSShopSoundLibrary
// Size: 0x48 (Inherited: 0x28)
struct UKSShopSoundLibrary : UKSUISoundLibrary {
	struct UAkAudioEvent* ShopOpen; // 0x28(0x08)
	struct UAkAudioEvent* ShopClose; // 0x30(0x08)
	struct UAkAudioEvent* PurchaseSucceeded; // 0x38(0x08)
	struct UAkAudioEvent* PurchaseFailed; // 0x40(0x08)
};

// Class KillstreakUINew.KSToastSoundLibrary
// Size: 0x48 (Inherited: 0x28)
struct UKSToastSoundLibrary : UKSUISoundLibrary {
	struct UAkAudioEvent* FriendToast; // 0x28(0x08)
	struct UAkAudioEvent* PartyToast; // 0x30(0x08)
	struct UAkAudioEvent* ErrorToast; // 0x38(0x08)
	struct UAkAudioEvent* InfoToast; // 0x40(0x08)
};

// Class KillstreakUINew.CommonVendorHelper
// Size: 0x28 (Inherited: 0x28)
struct UCommonVendorHelper : UObject {

	int32_t GetVendorIDFromEnum(enum class EKSVendorTypes VendorType); // Function KillstreakUINew.CommonVendorHelper.GetVendorIDFromEnum // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2239560
};

// Class KillstreakUINew.KSViewedActiveWeaponCompWidget
// Size: 0x5b8 (Inherited: 0x5a8)
struct UKSViewedActiveWeaponCompWidget : UKSActiveWeaponComponentWidget {
	char UnknownData_5A8[0x10]; // 0x5a8(0x10)
};

// Class KillstreakUINew.KSViewedActiveGadgetWidget
// Size: 0x4f8 (Inherited: 0x4e8)
struct UKSViewedActiveGadgetWidget : UKSWeaponWidget {
	char UnknownData_4E8[0x10]; // 0x4e8(0x10)
};

// Class KillstreakUINew.KSViewedActiveMedPackWidget
// Size: 0x4f8 (Inherited: 0x4e8)
struct UKSViewedActiveMedPackWidget : UKSWeaponWidget {
	char UnknownData_4E8[0x10]; // 0x4e8(0x10)
};

// Class KillstreakUINew.KSViewedItemLabel
// Size: 0x528 (Inherited: 0x510)
struct UKSViewedItemLabel : UKSViewedPawnWidget {
	char UnknownData_510[0x8]; // 0x510(0x08)
	bool UpdateViewLimitPosition; // 0x518(0x01)
	char UnknownData_519[0x3]; // 0x519(0x03)
	struct FVector2D ViewLimitPosition; // 0x51c(0x08)
	char UnknownData_524[0x4]; // 0x524(0x04)

	void UpdateLabelPosition(); // Function KillstreakUINew.KSViewedItemLabel.UpdateLabelPosition // (Final|Native|Protected|BlueprintCallable) // @ game+0x223a440
	void UnbindToViewportResizeEvent(); // Function KillstreakUINew.KSViewedItemLabel.UnbindToViewportResizeEvent // (Final|Native|Protected|BlueprintCallable) // @ game+0x223a400
	void TriggerLabelPositionUpdate(); // Function KillstreakUINew.KSViewedItemLabel.TriggerLabelPositionUpdate // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnLabelShow(); // Function KillstreakUINew.KSViewedItemLabel.OnLabelShow // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnLabelHide(); // Function KillstreakUINew.KSViewedItemLabel.OnLabelHide // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	struct UImage* GetViewLimitImage(); // Function KillstreakUINew.KSViewedItemLabel.GetViewLimitImage // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x22396b0
	struct AActor* GetTrackedActor(); // Function KillstreakUINew.KSViewedItemLabel.GetTrackedActor // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x22114e0
	struct UCanvasPanel* GetOutermostCanvasPanel(); // Function KillstreakUINew.KSViewedItemLabel.GetOutermostCanvasPanel // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2238c10
	bool GetOnScreenPositionForLabel(struct APlayerController* Player, struct AActor* InActor, struct FBox2D OutBounds); // Function KillstreakUINew.KSViewedItemLabel.GetOnScreenPositionForLabel // (Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x2238b00
	struct UCanvasPanel* GetLabelCanvasPanel(); // Function KillstreakUINew.KSViewedItemLabel.GetLabelCanvasPanel // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2238a10
	void BindToViewportResizeEvent(); // Function KillstreakUINew.KSViewedItemLabel.BindToViewportResizeEvent // (Final|Native|Protected|BlueprintCallable) // @ game+0x2237c10
};

// Class KillstreakUINew.KSViewedPawnDamageDisplay
// Size: 0x5a0 (Inherited: 0x510)
struct UKSViewedPawnDamageDisplay : UKSViewedPawnWidget {
	float StackingWait; // 0x510(0x04)
	bool TetherToEventLocation; // 0x514(0x01)
	char UnknownData_515[0x3]; // 0x515(0x03)
	int32_t MaxNumDamageWidgetsOnScreen; // 0x518(0x04)
	char UnknownData_51C[0x4]; // 0x51c(0x04)
	struct UCanvasPanel* DamageNumberContainer; // 0x520(0x08)
	struct TMap<struct UDamageType*, struct FSpecialDamageColors> SpecialDamageTypes; // 0x528(0x50)
	struct TArray<struct UDamageNumberDisplayWidget*> CurrentDamageNumbersOnScreen; // 0x578(0x10)
	struct TArray<struct UDamageNumberDisplayWidget*> DamageNumbersPool; // 0x588(0x10)
	char UnknownData_598[0x8]; // 0x598(0x08)

	void PrimeDamageNumbersWidgetPool(); // Function KillstreakUINew.KSViewedPawnDamageDisplay.PrimeDamageNumbersWidgetPool // (Final|Native|Protected|BlueprintCallable) // @ game+0x223e8d0
	void HandlePhaseChange(struct FName NewPhaseName, struct FName PreviousPhaseName); // Function KillstreakUINew.KSViewedPawnDamageDisplay.HandlePhaseChange // (Final|Native|Protected) // @ game+0x223e160
	void HandleInstigateDamageNotify(struct FCombatEventInfo DamageInfo); // Function KillstreakUINew.KSViewedPawnDamageDisplay.HandleInstigateDamageNotify // (Final|Native|Protected|HasOutParms) // @ game+0x223e050
	void HandleAnimationCompleted(struct UDamageNumberDisplayWidget* DamageNumberWidget); // Function KillstreakUINew.KSViewedPawnDamageDisplay.HandleAnimationCompleted // (Final|Native|Protected) // @ game+0x223dfd0
	struct UDamageNumberDisplayWidget* GetDamageNumberWidgetInstance(); // Function KillstreakUINew.KSViewedPawnDamageDisplay.GetDamageNumberWidgetInstance // (Native|Event|Protected|BlueprintEvent) // @ game+0x22114e0
	void ClearDamageNumbersOnScreen(); // Function KillstreakUINew.KSViewedPawnDamageDisplay.ClearDamageNumbersOnScreen // (Final|Native|Protected) // @ game+0x223d8e0
};

// Class KillstreakUINew.DamageNumberDisplayWidget
// Size: 0x280 (Inherited: 0x238)
struct UDamageNumberDisplayWidget : UUserWidget {
	struct FMulticastInlineDelegate OnNumberAnimationComplete; // 0x238(0x10)
	struct AActor* DamageTarget; // 0x248(0x08)
	struct FVector InitialDamageLocation; // 0x250(0x0c)
	bool TetherToEventLocation; // 0x25c(0x01)
	char UnknownData_25D[0x3]; // 0x25d(0x03)
	float DamageAmount; // 0x260(0x04)
	enum class EDamageBaseType DamageBaseType; // 0x264(0x01)
	enum class EDamageFlourishType DamageFlourishType; // 0x265(0x01)
	enum class EDamageModifier DamageModifier; // 0x266(0x01)
	enum class EDamageTargetType DamageTargetType; // 0x267(0x01)
	float DelayBeforeAnimation; // 0x268(0x04)
	float StackWaitTime; // 0x26c(0x04)
	bool PlayingNumberAnimation; // 0x270(0x01)
	char UnknownData_271[0x3]; // 0x271(0x03)
	float VerticalWorldOffset; // 0x274(0x04)
	bool ChangePosition; // 0x278(0x01)
	char UnknownData_279[0x7]; // 0x279(0x07)

	void SetDisplayInformation(struct AActor* InTargetActor, bool InTetherToEventLocation, float InDamageAmount, bool InIsSpecialDamage, struct FSpecialDamageColors InDamageColors, bool InIsLethal, bool InIsHeadshot, float InDelayWindow, float InStackWait, bool InArmorHit, bool InDamageReduced, bool InDamageResisted, bool InDamageShielded); // Function KillstreakUINew.DamageNumberDisplayWidget.SetDisplayInformation // (Final|Native|Public) // @ game+0x223eb60
	void SetContentVisibility(bool IsVisible); // Function KillstreakUINew.DamageNumberDisplayWidget.SetContentVisibility // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void PlayNumberAnimation(); // Function KillstreakUINew.DamageNumberDisplayWidget.PlayNumberAnimation // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1a0f700
	bool PlayerIsBlinded(); // Function KillstreakUINew.DamageNumberDisplayWidget.PlayerIsBlinded // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnDisplaySpecialDamageInfo(float CurrentDamageAmount, struct FSpecialDamageColors DamageColors, bool bChangePosition); // Function KillstreakUINew.DamageNumberDisplayWidget.OnDisplaySpecialDamageInfo // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnDisplayInformationReset(); // Function KillstreakUINew.DamageNumberDisplayWidget.OnDisplayInformationReset // (Event|Public|BlueprintEvent) // @ game+0x2587100
	bool IsDisplayStacking(); // Function KillstreakUINew.DamageNumberDisplayWidget.IsDisplayStacking // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x223e220
};

// Class KillstreakUINew.KSViewedPawnInventoryWidget
// Size: 0x5a8 (Inherited: 0x570)
struct UKSViewedPawnInventoryWidget : UKSPawnInventoryWidget {
	struct FPlayerInventorySlot ActiveInventoryItem; // 0x570(0x18)
	char UnknownData_588[0x20]; // 0x588(0x20)

	void OnUpdatedPawnInventorySlot(struct FPlayerInventorySlot InventorySlot); // Function KillstreakUINew.KSViewedPawnInventoryWidget.OnUpdatedPawnInventorySlot // (Native|Event|Public|BlueprintEvent) // @ game+0x223e660
	void OnRemovedPawnInventorySlot(struct FPlayerInventorySlot InventorySlot); // Function KillstreakUINew.KSViewedPawnInventoryWidget.OnRemovedPawnInventorySlot // (Native|Event|Public|BlueprintEvent) // @ game+0x223e5b0
	void OnActivePawnInventorySlot(struct FPlayerInventorySlot InventorySlot); // Function KillstreakUINew.KSViewedPawnInventoryWidget.OnActivePawnInventorySlot // (Native|Event|Public|BlueprintEvent) // @ game+0x223e2d0
	int32_t GetSlotIndex(struct FGameplayTag EquipPoint); // Function KillstreakUINew.KSViewedPawnInventoryWidget.GetSlotIndex // (Final|Native|Protected|BlueprintCallable) // @ game+0x223dbf0
};

// Class KillstreakUINew.KSViewedPawnModsWidget
// Size: 0x528 (Inherited: 0x510)
struct UKSViewedPawnModsWidget : UKSViewedPawnWidget {
	char UnknownData_510[0x18]; // 0x510(0x18)

	void OnViewedPawnModAdded(struct UKSPlayerMod* Mod, struct UKSPlayerModInstance* ModInstance); // Function KillstreakUINew.KSViewedPawnModsWidget.OnViewedPawnModAdded // (Final|Native|Private) // @ game+0x223e710
	struct UOverlay* GetOverlay(); // Function KillstreakUINew.KSViewedPawnModsWidget.GetOverlay // (Event|Public|BlueprintEvent) // @ game+0x2587100
};

// Class KillstreakUINew.KSViewRedirector_LocalSetting
// Size: 0x30 (Inherited: 0x28)
struct UKSViewRedirector_LocalSetting : UPUMG_ViewRedirecter {
	struct FName LocalActionName; // 0x28(0x08)

	bool DoesLocalSettingApply(struct APUMG_HUD* HUD); // Function KillstreakUINew.KSViewRedirector_LocalSetting.DoesLocalSettingApply // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2082f90
};

// Class KillstreakUINew.KSVoiceActivityWidget
// Size: 0x550 (Inherited: 0x4e0)
struct UKSVoiceActivityWidget : UKSWidget {
	struct FMulticastInlineDelegate VoiceAccountNamePairsUpdated; // 0x4e0(0x10)
	struct FMulticastInlineDelegate VoiceParticipantAdded; // 0x4f0(0x10)
	struct FMulticastInlineDelegate VoiceParticipantRemoved; // 0x500(0x10)
	struct FMulticastInlineDelegate VoiceParticipantUpdated; // 0x510(0x10)
	struct FMulticastInlineDelegate VoiceAudioStateChange; // 0x520(0x10)
	char UnknownData_530[0x20]; // 0x530(0x20)

	void OnVoiceParticipantUpdated(struct FString AccountId, bool bIsTalking, bool bIsMuted); // Function KillstreakUINew.KSVoiceActivityWidget.OnVoiceParticipantUpdated // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnVoiceParticipantRemoved(struct FString AccountId); // Function KillstreakUINew.KSVoiceActivityWidget.OnVoiceParticipantRemoved // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnVoiceParticipantAdded(struct FString AccountId); // Function KillstreakUINew.KSVoiceActivityWidget.OnVoiceParticipantAdded // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	struct FString GetVoiceIdByPlayerId(int64_t PlayerId); // Function KillstreakUINew.KSVoiceActivityWidget.GetVoiceIdByPlayerId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x223dd90
	struct AKSPlayerState* GetPlayerStateByVoiceId(struct FString VoiceId); // Function KillstreakUINew.KSVoiceActivityWidget.GetPlayerStateByVoiceId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x223db40
	int64_t GetPlayerIdByVoiceId(struct FString VoiceId); // Function KillstreakUINew.KSVoiceActivityWidget.GetPlayerIdByVoiceId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x223da90
};

// Class KillstreakUINew.KSVoucherAcquisition
// Size: 0x4e0 (Inherited: 0x4e0)
struct UKSVoucherAcquisition : UKSWidget {

	bool RedeemVouchers(struct TArray<struct UPUMG_StoreItem*> VoucherItems); // Function KillstreakUINew.KSVoucherAcquisition.RedeemVouchers // (Final|Native|Public|BlueprintCallable) // @ game+0x223e8f0
	void GetVoucherAcquisitions(struct TArray<struct UPUMG_StoreItem*> VoucherItems, struct TArray<struct UPUMG_StoreItem*> PurchaseItems); // Function KillstreakUINew.KSVoucherAcquisition.GetVoucherAcquisitions // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x223de70
	void DisplayVoucherRedemptionFailed(); // Function KillstreakUINew.KSVoucherAcquisition.DisplayVoucherRedemptionFailed // (Final|Native|Public|BlueprintCallable) // @ game+0x223d900
};

// Class KillstreakUINew.KSWeaponComponentWidget
// Size: 0x500 (Inherited: 0x4e0)
struct UKSWeaponComponentWidget : UKSWidget {
	struct FWeakObjectPtr<struct UKSWeaponComponent> WeaponComponent; // 0x4e0(0x08)
	struct FKSEquipmentId EquipmentId; // 0x4e8(0x04)
	char UnknownData_4EC[0x14]; // 0x4ec(0x14)

	void SetOwningWeaponComponent(struct UKSWeaponComponent* InWeaponComponent); // Function KillstreakUINew.KSWeaponComponentWidget.SetOwningWeaponComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x223efb0
	void PreClearWeaponComponent(); // Function KillstreakUINew.KSWeaponComponentWidget.PreClearWeaponComponent // (Native|Event|Protected|BlueprintEvent) // @ game+0x21f40b0
	void PostSetWeaponComponent(); // Function KillstreakUINew.KSWeaponComponentWidget.PostSetWeaponComponent // (Native|Event|Protected|BlueprintEvent) // @ game+0x220e280
	void OnEndActiveWeaponComponent(); // Function KillstreakUINew.KSWeaponComponentWidget.OnEndActiveWeaponComponent // (Native|Event|Protected|BlueprintEvent) // @ game+0x20a1de0
	void OnBecomeActiveWeaponComponent(); // Function KillstreakUINew.KSWeaponComponentWidget.OnBecomeActiveWeaponComponent // (Native|Event|Protected|BlueprintEvent) // @ game+0x19dbee0
	bool IsWeaponComponentActive(); // Function KillstreakUINew.KSWeaponComponentWidget.IsWeaponComponentActive // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x223e2a0
	struct UKSWeaponComponent* GetWeaponComponent(); // Function KillstreakUINew.KSWeaponComponentWidget.GetWeaponComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x223df90
};

// Class KillstreakUINew.KSWeaponComponentAmmoWidget
// Size: 0x520 (Inherited: 0x500)
struct UKSWeaponComponentAmmoWidget : UKSWeaponComponentWidget {
	int32_t CachedAmmoInClip; // 0x500(0x04)
	int32_t CachedClipSize; // 0x504(0x04)
	int32_t CachedInReserve; // 0x508(0x04)
	bool CachedIsReloading; // 0x50c(0x01)
	char UnknownData_50D[0x13]; // 0x50d(0x13)

	void StopReloading(); // Function KillstreakUINew.KSWeaponComponentAmmoWidget.StopReloading // (Native|Event|Protected|BlueprintEvent) // @ game+0x21f4090
	void StartReloading(); // Function KillstreakUINew.KSWeaponComponentAmmoWidget.StartReloading // (Native|Event|Protected|BlueprintEvent) // @ game+0x21fcff0
	void OnAmmoChanged(int32_t OldInClip, int32_t OldClipSize, int32_t OldReserve, int32_t NewInClip, int32_t NewClipSize, int32_t NewReserve); // Function KillstreakUINew.KSWeaponComponentAmmoWidget.OnAmmoChanged // (Native|Event|Protected|BlueprintEvent) // @ game+0x223e380
	bool IsReloading(); // Function KillstreakUINew.KSWeaponComponentAmmoWidget.IsReloading // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x223e280
	int32_t GetClipSize(); // Function KillstreakUINew.KSWeaponComponentAmmoWidget.GetClipSize // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x223d970
	int32_t GetAmmoInReserve(); // Function KillstreakUINew.KSWeaponComponentAmmoWidget.GetAmmoInReserve // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2128360
	int32_t GetAmmoInClip(); // Function KillstreakUINew.KSWeaponComponentAmmoWidget.GetAmmoInClip // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x223d950
};

// Class KillstreakUINew.KSWhatsNewModalViewRedirector
// Size: 0x28 (Inherited: 0x28)
struct UKSWhatsNewModalViewRedirector : UPUMG_ViewRedirecter {
};

// Class KillstreakUINew.KSWhatsNewPanel
// Size: 0xd8 (Inherited: 0x70)
struct UKSWhatsNewPanel : UKSJsonData {
	struct FText Header; // 0x70(0x18)
	struct FText SubHeader; // 0x88(0x18)
	struct FText Description; // 0xa0(0x18)
	struct UTexture2DDynamic* Image; // 0xb8(0x08)
	struct FString URL; // 0xc0(0x10)
	bool IsFullScreen; // 0xd0(0x01)
	char UnknownData_D1[0x7]; // 0xd1(0x07)
};

// Class KillstreakUINew.KSWhatsNewModal
// Size: 0x4f8 (Inherited: 0x4e0)
struct UKSWhatsNewModal : UKSWidget {
	int32_t maxPanelCount; // 0x4e0(0x04)
	char UnknownData_4E4[0x4]; // 0x4e4(0x04)
	struct TArray<struct UKSWhatsNewPanel*> StoredPanels; // 0x4e8(0x10)

	void UpdateWhatsNewPanels(); // Function KillstreakUINew.KSWhatsNewModal.UpdateWhatsNewPanels // (Final|Native|Protected) // @ game+0x223f170
	void OnJsonChanged(); // Function KillstreakUINew.KSWhatsNewModal.OnJsonChanged // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	struct TArray<struct UKSWhatsNewPanel*> GetPanelData(); // Function KillstreakUINew.KSWhatsNewModal.GetPanelData // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x223da10
	int32_t GetMaxPanelCount(); // Function KillstreakUINew.KSWhatsNewModal.GetMaxPanelCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x223d9c0
	struct UKSJsonDataFactory* GetJsonDataFactory(); // Function KillstreakUINew.KSWhatsNewModal.GetJsonDataFactory // (Final|Native|Private|BlueprintCallable|BlueprintPure) // @ game+0x223d990
};

// Class KillstreakUINew.TickAnimationManager
// Size: 0x78 (Inherited: 0x28)
struct UTickAnimationManager : UObject {
	struct TMap<struct FName, struct FTickAnimationParams> AnimsByName; // 0x28(0x50)

	void StopAnimation(struct FName AnimName); // Function KillstreakUINew.TickAnimationManager.StopAnimation // (Final|Native|Public) // @ game+0x223fc10
	void SkipToEndAnimation(struct FName AnimName); // Function KillstreakUINew.TickAnimationManager.SkipToEndAnimation // (Final|Native|Public) // @ game+0x223fb90
	void ResumeAnimation(struct FName AnimName); // Function KillstreakUINew.TickAnimationManager.ResumeAnimation // (Final|Native|Public) // @ game+0x223fb10
	void RemoveAnimation(struct FName AnimName); // Function KillstreakUINew.TickAnimationManager.RemoveAnimation // (Final|Native|Public) // @ game+0x223fa90
	void PlayAnimation(struct FName AnimName); // Function KillstreakUINew.TickAnimationManager.PlayAnimation // (Final|Native|Public) // @ game+0x223fa10
	void PauseAnimation(struct FName AnimName); // Function KillstreakUINew.TickAnimationManager.PauseAnimation // (Final|Native|Public) // @ game+0x223f990
	bool GetAnimationInfo(struct FName AnimName, struct FTickAnimationParams OutAnimParams); // Function KillstreakUINew.TickAnimationManager.GetAnimationInfo // (Final|Native|Public|HasOutParms) // @ game+0x223f880
	void ApplyTick(float DeltaTime); // Function KillstreakUINew.TickAnimationManager.ApplyTick // (Final|Native|Public) // @ game+0x223f800
	void AddAnimation(struct FName AnimName, float Duration, struct FDelegate UpdateEvent, struct FDelegate FinishedEvent); // Function KillstreakUINew.TickAnimationManager.AddAnimation // (Final|Native|Public|HasOutParms) // @ game+0x223f670
};

