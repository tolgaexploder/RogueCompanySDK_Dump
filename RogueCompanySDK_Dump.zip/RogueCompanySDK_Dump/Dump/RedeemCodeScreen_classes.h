// WidgetBlueprintGeneratedClass RedeemCodeScreen.RedeemCodeScreen_C
// Size: 0x558 (Inherited: 0x4f8)
struct URedeemCodeScreen_C : UKSRedeemCodeScreenBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4f8(0x08)
	struct UWBP_RedeemCodeField_C* CodeEntry; // 0x500(0x08)
	struct UHorizontalBox* CodeRedemption; // 0x508(0x08)
	struct UTextBlock* ErrorLabel; // 0x510(0x08)
	struct UBorder* PendingOverlay; // 0x518(0x08)
	struct UImage* SelectPrompt; // 0x520(0x08)
	struct UWBP_StandardButtonMedium_C* SubmitButton; // 0x528(0x08)
	struct UWBP_Header1_C* WBP_Header1; // 0x530(0x08)
	struct UWBP_ModalPopupContainer_C* WBP_ModalPopupContainer; // 0x538(0x08)
	struct UDataTable* ColorPalette; // 0x540(0x08)
	struct FTimerHandle SpamPreventTimer; // 0x548(0x08)
	int32_t FocusGroup_NoInteraction; // 0x550(0x04)
	int32_t FocusGroup_Input; // 0x554(0x04)

	void UpdateSubmitButtonState(); // Function RedeemCodeScreen.RedeemCodeScreen_C.UpdateSubmitButtonState // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetErrorMessage(struct FText ErrorMessage); // Function RedeemCodeScreen.RedeemCodeScreen_C.SetErrorMessage // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnSpamPreventTimeout(); // Function RedeemCodeScreen.RedeemCodeScreen_C.OnSpamPreventTimeout // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GetPaletteColor(struct FName Color Name, struct FSlateColor Color); // Function RedeemCodeScreen.RedeemCodeScreen_C.GetPaletteColor // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void ShowPending(); // Function RedeemCodeScreen.RedeemCodeScreen_C.ShowPending // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void EndPending(); // Function RedeemCodeScreen.RedeemCodeScreen_C.EndPending // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	bool NavigateBack(); // Function RedeemCodeScreen.RedeemCodeScreen_C.NavigateBack // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void StartShowAnim(); // Function RedeemCodeScreen.RedeemCodeScreen_C.StartShowAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeTickAnimations(); // Function RedeemCodeScreen.RedeemCodeScreen_C.InitializeTickAnimations // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void ShowCodeRedeemFinished(); // Function RedeemCodeScreen.RedeemCodeScreen_C.ShowCodeRedeemFinished // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ShowCodeRedeemAnim(float ElapsedTime, float ElapsedAlpha); // Function RedeemCodeScreen.RedeemCodeScreen_C.ShowCodeRedeemAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitHideAnimation(); // Function RedeemCodeScreen.RedeemCodeScreen_C.InitHideAnimation // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HideCodeRedeemFinished(); // Function RedeemCodeScreen.RedeemCodeScreen_C.HideCodeRedeemFinished // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HideCodeRedeemAnim(float ElapsedTime, float ElapsedAlpha); // Function RedeemCodeScreen.RedeemCodeScreen_C.HideCodeRedeemAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void StartHideAnim(); // Function RedeemCodeScreen.RedeemCodeScreen_C.StartHideAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function RedeemCodeScreen.RedeemCodeScreen_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidgetNavigation(); // Function RedeemCodeScreen.RedeemCodeScreen_C.InitializeWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function RedeemCodeScreen.RedeemCodeScreen_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeWidgetButtonListeners(); // Function RedeemCodeScreen.RedeemCodeScreen_C.InitializeWidgetButtonListeners // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void SubmitCode(); // Function RedeemCodeScreen.RedeemCodeScreen_C.SubmitCode // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void StartShowSequence(struct FName FromRoute, struct FName ToRoute); // Function RedeemCodeScreen.RedeemCodeScreen_C.StartShowSequence // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void StartHideSequence(struct FName FromRoute, struct FName ToRoute); // Function RedeemCodeScreen.RedeemCodeScreen_C.StartHideSequence // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnShown(); // Function RedeemCodeScreen.RedeemCodeScreen_C.OnShown // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnHide(); // Function RedeemCodeScreen.RedeemCodeScreen_C.OnHide // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnCloseButtonClicked(); // Function RedeemCodeScreen.RedeemCodeScreen_C.OnCloseButtonClicked // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BndEvt__WBP_StandardButtonMedium_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature(struct UWidget* Widget); // Function RedeemCodeScreen.RedeemCodeScreen_C.BndEvt__WBP_StandardButtonMedium_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void OnRedeemCodeSubmit(); // Function RedeemCodeScreen.RedeemCodeScreen_C.OnRedeemCodeSubmit // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnRedeemCodeResult(bool Success, struct FText Error); // Function RedeemCodeScreen.RedeemCodeScreen_C.OnRedeemCodeResult // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleInputStateChanged(enum class PGAME_INPUT_STATE InputState); // Function RedeemCodeScreen.RedeemCodeScreen_C.HandleInputStateChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnCodeTextChanged(struct FText Text); // Function RedeemCodeScreen.RedeemCodeScreen_C.OnCodeTextChanged // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnCodeTextCommit(struct FText Text, enum class ETextCommit CommitMethod); // Function RedeemCodeScreen.RedeemCodeScreen_C.OnCodeTextCommit // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_RedeemCodeScreen(int32_t EntryPoint); // Function RedeemCodeScreen.RedeemCodeScreen_C.ExecuteUbergraph_RedeemCodeScreen // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

