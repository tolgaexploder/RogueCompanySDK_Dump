// Enum PlatformInventoryItem.EExternalSkuSource
enum class EExternalSkuSource : uint8 {
	ESS_No_Souce,
	ESS_Sony,
	ESS_Nintendo,
	ESS_Microsoft_Xbox,
	ESS_Microsoft_Xbox_GDK,
	ESS_Epic,
	ESS_Valve,
	ESS_MAX,
};

// ScriptStruct PlatformInventoryItem.IconReference
// Size: 0x30 (Inherited: 0x00)
struct FIconReference {
	struct FName IconType; // 0x00(0x08)
	struct TSoftObjectPtr<struct UTexture2D> Icon; // 0x08(0x28)
};

