// WidgetBlueprintGeneratedClass TeammateHealth.TeammateHealth_C
// Size: 0x278 (Inherited: 0x238)
struct UTeammateHealth_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UProgressBar* HealthBar; // 0x240(0x08)
	struct UImage* HealthBarBackground; // 0x248(0x08)
	struct UOverlay* HealthWrapper; // 0x250(0x08)
	struct UImage* IndicatorIcon; // 0x258(0x08)
	struct UBorder* PlayerHealthWrapper; // 0x260(0x08)
	struct UTextBlock* PlayerName; // 0x268(0x08)
	struct APlayerState* PlayerState; // 0x270(0x08)

	void Construct(); // Function TeammateHealth.TeammateHealth_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void HandleHealthChanged(struct AKSCharacterBase* KSCharacter); // Function TeammateHealth.TeammateHealth_C.HandleHealthChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleOnDowned(struct AKSPlayerState* Player State); // Function TeammateHealth.TeammateHealth_C.HandleOnDowned // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleOnElimated(struct AKSPlayerState* PlayerState); // Function TeammateHealth.TeammateHealth_C.HandleOnElimated // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleOnPlayerSet(struct AKSPlayerState* Player State); // Function TeammateHealth.TeammateHealth_C.HandleOnPlayerSet // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ResetPlayerHealth(); // Function TeammateHealth.TeammateHealth_C.ResetPlayerHealth // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_TeammateHealth(int32_t EntryPoint); // Function TeammateHealth.TeammateHealth_C.ExecuteUbergraph_TeammateHealth // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

