// WidgetBlueprintGeneratedClass CashEarnedElement.CashEarnedElement_C
// Size: 0x2da (Inherited: 0x238)
struct UCashEarnedElement_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UWidgetAnimation* HideReason; // 0x240(0x08)
	struct UWidgetAnimation* ShowReason; // 0x248(0x08)
	struct UWidgetAnimation* HideValue; // 0x250(0x08)
	struct UWidgetAnimation* ShowValue; // 0x258(0x08)
	struct UWidgetAnimation* FadeOut; // 0x260(0x08)
	struct UWidgetAnimation* SlideIn; // 0x268(0x08)
	struct UImage* Divider; // 0x270(0x08)
	struct USizeBox* ExpElementWrapper; // 0x278(0x08)
	struct UImage* Image_161; // 0x280(0x08)
	struct UTextBlock* ReasonText; // 0x288(0x08)
	struct UTextBlock* ValueText; // 0x290(0x08)
	float SitTime; // 0x298(0x04)
	char UnknownData_29C[0x4]; // 0x29c(0x04)
	struct FKSScoreChangeEvent Event; // 0x2a0(0x30)
	int32_t CashAmout; // 0x2d0(0x04)
	float DelayClearTime; // 0x2d4(0x04)
	bool IsPlayingAnim; // 0x2d8(0x01)
	bool HasBonus; // 0x2d9(0x01)

	void ShowRewardEarned(struct FKSScoreChangeEvent ScoreEvent); // Function CashEarnedElement.CashEarnedElement_C.ShowRewardEarned // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function CashEarnedElement.CashEarnedElement_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void HandleShowValueAnimFinished(); // Function CashEarnedElement.CashEarnedElement_C.HandleShowValueAnimFinished // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleHideValueAnimFinished(); // Function CashEarnedElement.CashEarnedElement_C.HandleHideValueAnimFinished // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_CashEarnedElement(int32_t EntryPoint); // Function CashEarnedElement.CashEarnedElement_C.ExecuteUbergraph_CashEarnedElement // (Final|UbergraphFunction) // @ game+0x2587100
};

