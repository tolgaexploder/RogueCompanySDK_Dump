// WidgetBlueprintGeneratedClass NewWeaponInventory.NewWeaponInventory_C
// Size: 0x609 (Inherited: 0x5a8)
struct UNewWeaponInventory_C : UKSViewedPawnInventoryWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5a8(0x08)
	struct UWBP_ActiveWeaponComponent_C* ActiveWeaponComponent; // 0x5b0(0x08)
	struct UWBP_OutOfAmmoAlert_C* AmmoWarning; // 0x5b8(0x08)
	struct UCanvasPanel* MainWeaponInventoryPanel; // 0x5c0(0x08)
	struct UReticuleMoving_C* ReticuleMoving; // 0x5c8(0x08)
	struct UWBP_ItemPickup_C* WBP_ItemPickup; // 0x5d0(0x08)
	struct UWeaponComponentAmmoWarning_C* WeaponComponentAmmoWarning; // 0x5d8(0x08)
	struct UOverlay* WeaponInventory; // 0x5e0(0x08)
	struct UInvalidationBox* WeaponInventoryInvalidationBox; // 0x5e8(0x08)
	struct UWBP_WeaponSlotsContainer_C* WeaponSlotsContainer; // 0x5f0(0x08)
	struct FString WeaponInventoryString; // 0x5f8(0x10)
	bool CachedIsDead; // 0x608(0x01)

	void HandleDeathStateChanged(); // Function NewWeaponInventory.NewWeaponInventory_C.HandleDeathStateChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UnbindKSCharacter(); // Function NewWeaponInventory.NewWeaponInventory_C.UnbindKSCharacter // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BindKSCharacter(); // Function NewWeaponInventory.NewWeaponInventory_C.BindKSCharacter // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void AddGameRuleWidget(struct UUserWidget* Game Rule Widget, struct FString Parent Widget); // Function NewWeaponInventory.NewWeaponInventory_C.AddGameRuleWidget // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function NewWeaponInventory.NewWeaponInventory_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void EquipmentAdded(struct UKSWeaponComponent* AddedEquipment); // Function NewWeaponInventory.NewWeaponInventory_C.EquipmentAdded // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void EquipmentRemoved(struct UKSWeaponComponent* RemovedEquipment); // Function NewWeaponInventory.NewWeaponInventory_C.EquipmentRemoved // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function NewWeaponInventory.NewWeaponInventory_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PostSetPawn(); // Function NewWeaponInventory.NewWeaponInventory_C.PostSetPawn // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void PreClearPawn(); // Function NewWeaponInventory.NewWeaponInventory_C.PreClearPawn // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void Handle Swap Gamepad Pressed(); // Function NewWeaponInventory.NewWeaponInventory_C.Handle Swap Gamepad Pressed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Swap Gamepad Released(); // Function NewWeaponInventory.NewWeaponInventory_C.Handle Swap Gamepad Released // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetKillCamWeapon(struct APawn* ViewPawn); // Function NewWeaponInventory.NewWeaponInventory_C.SetKillCamWeapon // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_NewWeaponInventory(int32_t EntryPoint); // Function NewWeaponInventory.NewWeaponInventory_C.ExecuteUbergraph_NewWeaponInventory // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

