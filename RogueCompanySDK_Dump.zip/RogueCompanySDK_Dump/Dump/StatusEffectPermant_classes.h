// WidgetBlueprintGeneratedClass StatusEffectPermant.StatusEffectPermant_C
// Size: 0x521 (Inherited: 0x510)
struct UStatusEffectPermant_C : UKSViewedPawnWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x510(0x08)
	struct UTextBlock* StatusText; // 0x518(0x08)
	bool IsSpectating; // 0x520(0x01)

	void CustomEvent_1(struct AKSPlayerController* Controller, struct AActor* OldViewTarget, struct AActor* NewViewTarget); // Function StatusEffectPermant.StatusEffectPermant_C.CustomEvent_1 // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PreClearPawn(); // Function StatusEffectPermant.StatusEffectPermant_C.PreClearPawn // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void RevealStatus(bool Revealed, bool Permanent); // Function StatusEffectPermant.StatusEffectPermant_C.RevealStatus // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PostSetPawn(); // Function StatusEffectPermant.StatusEffectPermant_C.PostSetPawn // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void CustomEvent_2(bool IsSpectating); // Function StatusEffectPermant.StatusEffectPermant_C.CustomEvent_2 // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function StatusEffectPermant.StatusEffectPermant_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_StatusEffectPermant(int32_t EntryPoint); // Function StatusEffectPermant.StatusEffectPermant_C.ExecuteUbergraph_StatusEffectPermant // (Final|UbergraphFunction) // @ game+0x2587100
};

