// WidgetBlueprintGeneratedClass WBP_AppliedEvents.WBP_AppliedEvents_C
// Size: 0x4f8 (Inherited: 0x4e8)
struct UWBP_AppliedEvents_C : UKSActiveBonusesWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e8(0x08)
	struct UVerticalBox* ActiveEvents; // 0x4f0(0x08)

	void PopulateActiveEvents(); // Function WBP_AppliedEvents.WBP_AppliedEvents_C.PopulateActiveEvents // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PreConstruct(bool IsDesignTime); // Function WBP_AppliedEvents.WBP_AppliedEvents_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_AppliedEvents(int32_t EntryPoint); // Function WBP_AppliedEvents.WBP_AppliedEvents_C.ExecuteUbergraph_WBP_AppliedEvents // (Final|UbergraphFunction) // @ game+0x2587100
};

