// WidgetBlueprintGeneratedClass PointObjectiveFullMapIcon.PointObjectiveFullMapIcon_C
// Size: 0x398 (Inherited: 0x318)
struct UPointObjectiveFullMapIcon_C : UKSMapIconWidgetBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x318(0x08)
	struct UWidgetAnimation* Capture Anim; // 0x320(0x08)
	struct UGameTimer_C* GameTimer; // 0x328(0x08)
	struct UImage* Icon; // 0x330(0x08)
	struct UImage* Image_1; // 0x338(0x08)
	struct UImage* Image_2; // 0x340(0x08)
	struct UImage* Image_3; // 0x348(0x08)
	struct UImage* Image_4; // 0x350(0x08)
	struct UImage* Inset; // 0x358(0x08)
	struct UImage* InsetCover; // 0x360(0x08)
	struct UTextBlock* NameText; // 0x368(0x08)
	struct URetainerBox* RetainerBox_1; // 0x370(0x08)
	struct UTextBlock* StatusText; // 0x378(0x08)
	struct AKSObjectiveBase* TrackedObjective; // 0x380(0x08)
	struct FName PreviousObjectiveState; // 0x388(0x08)
	float CachedMeterProgress; // 0x390(0x04)
	float InferredProgressTime; // 0x394(0x04)

	bool ShouldUpdate(); // Function PointObjectiveFullMapIcon.PointObjectiveFullMapIcon_C.ShouldUpdate // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void DoCaptureAnimation(); // Function PointObjectiveFullMapIcon.PointObjectiveFullMapIcon_C.DoCaptureAnimation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetProgressValue(float Progress); // Function PointObjectiveFullMapIcon.PointObjectiveFullMapIcon_C.SetProgressValue // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetProgressColors(struct FLinearColor OffColor, struct FLinearColor OnColor); // Function PointObjectiveFullMapIcon.PointObjectiveFullMapIcon_C.SetProgressColors // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function PointObjectiveFullMapIcon.PointObjectiveFullMapIcon_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Objective State Change(struct AKSObjectiveBase* Objective); // Function PointObjectiveFullMapIcon.PointObjectiveFullMapIcon_C.Objective State Change // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function PointObjectiveFullMapIcon.PointObjectiveFullMapIcon_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnCaptureAnimFinished(); // Function PointObjectiveFullMapIcon.PointObjectiveFullMapIcon_C.OnCaptureAnimFinished // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_PointObjectiveFullMapIcon(int32_t EntryPoint); // Function PointObjectiveFullMapIcon.PointObjectiveFullMapIcon_C.ExecuteUbergraph_PointObjectiveFullMapIcon // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

