// BlueprintGeneratedClass ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C
// Size: 0x4c8 (Inherited: 0x458)
struct UReviveSelfOnActivateModInst_C : UKSModInst_ReviveSelfOnActivation {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x458(0x08)
	struct UKSFXCurveComponent* AppliedCurveComponent; // 0x460(0x08)
	struct FKSSpecialEffect ImmunityPPEffect; // 0x468(0x50)
	struct FTimerHandle Outro Timer; // 0x4b8(0x08)
	struct UAnimMontage* BruteStrengthMontage; // 0x4c0(0x08)

	void Get outro timer(struct UAnimMontage* Montage, float Outro Duration timer); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.Get outro timer // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	bool StopAnimationFromEvent(struct FName AnimEventName, struct UKSCharacterAnimInst* CharAnimInstance); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.StopAnimationFromEvent // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	bool ReactsToAnimationEvent(struct FName AnimEventName, int32_t Priority); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.ReactsToAnimationEvent // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnNotifyEnd_9E1EC10C43864E26E4E9E1B703588426(struct FName NotifyName, int32_t MontageInstanceID); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.OnNotifyEnd_9E1EC10C43864E26E4E9E1B703588426 // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnNotifyBegin_9E1EC10C43864E26E4E9E1B703588426(struct FName NotifyName, int32_t MontageInstanceID); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.OnNotifyBegin_9E1EC10C43864E26E4E9E1B703588426 // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnInterrupted_9E1EC10C43864E26E4E9E1B703588426(struct FName NotifyName, int32_t MontageInstanceID); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.OnInterrupted_9E1EC10C43864E26E4E9E1B703588426 // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnBlendOut_9E1EC10C43864E26E4E9E1B703588426(struct FName NotifyName, int32_t MontageInstanceID); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.OnBlendOut_9E1EC10C43864E26E4E9E1B703588426 // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnCompleted_9E1EC10C43864E26E4E9E1B703588426(struct FName NotifyName, int32_t MontageInstanceID); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.OnCompleted_9E1EC10C43864E26E4E9E1B703588426 // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void VO_Revive_Activate(); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.VO_Revive_Activate // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void StimPackDownedEndSFX(); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.StimPackDownedEndSFX // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void StimPackActivateStandingSFX(); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.StimPackActivateStandingSFX // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void StimPackActivateDownedSFX(); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.StimPackActivateDownedSFX // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SFX_Revive_Activate(); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.SFX_Revive_Activate // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SFX_Revive_Complete(); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.SFX_Revive_Complete // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void StimPackReviveCompleteSFX(); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.StimPackReviveCompleteSFX // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PlayAnimationFromEvent(struct FName AnimEventName, struct UKSCharacterAnimInst* CharAnimInstance); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.PlayAnimationFromEvent // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ReceiveBeginPlay(); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnActivated(bool bActive); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.OnActivated // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.ReceiveEndPlay // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void AdjustImmunityEffect(bool Active); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.AdjustImmunityEffect // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnSetup(); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.OnSetup // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void Brute Strength Effect Stop(); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.Brute Strength Effect Stop // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Play Outro(); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.Play Outro // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Brute Strength Effect Play(); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.Brute Strength Effect Play // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnNewCharacter(); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.OnNewCharacter // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnDeathStateChanged(); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.OnDeathStateChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_ReviveSelfOnActivateModInst(int32_t EntryPoint); // Function ReviveSelfOnActivateModInst.ReviveSelfOnActivateModInst_C.ExecuteUbergraph_ReviveSelfOnActivateModInst // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

