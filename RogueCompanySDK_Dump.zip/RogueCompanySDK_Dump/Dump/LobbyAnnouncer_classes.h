// BlueprintGeneratedClass LobbyAnnouncer.LobbyAnnouncer_C
// Size: 0x498 (Inherited: 0x458)
struct ALobbyAnnouncer_C : AKSAnnouncer {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x458(0x08)
	struct UAkAudioEvent* Play Music Event; // 0x460(0x08)
	struct UAkAudioEvent* Stop Music Event; // 0x468(0x08)
	struct UAkAudioEvent* Lobby Music Start Event; // 0x470(0x08)
	struct UAkAudioEvent* Lobby Match Found Event; // 0x478(0x08)
	struct UAkAudioEvent* Lobby To Loading Screen Event; // 0x480(0x08)
	struct UAkAudioEvent* Lobby End of Match; // 0x488(0x08)
	struct UKSGameInstance* GameInstance; // 0x490(0x08)

	void OnLoadingScreenEnded(); // Function LobbyAnnouncer.LobbyAnnouncer_C.OnLoadingScreenEnded // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnLobbyWidgetReady(); // Function LobbyAnnouncer.LobbyAnnouncer_C.OnLobbyWidgetReady // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ReceiveBeginPlay(); // Function LobbyAnnouncer.LobbyAnnouncer_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnViewStateChangedStarted(struct FName CurrentRoute, struct FName NextRoute, enum class EViewManagerLayer Layer); // Function LobbyAnnouncer.LobbyAnnouncer_C.OnViewStateChangedStarted // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function LobbyAnnouncer.LobbyAnnouncer_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void EventQueueInGame(); // Function LobbyAnnouncer.LobbyAnnouncer_C.EventQueueInGame // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_LobbyAnnouncer(int32_t EntryPoint); // Function LobbyAnnouncer.LobbyAnnouncer_C.ExecuteUbergraph_LobbyAnnouncer // (Final|UbergraphFunction) // @ game+0x2587100
};

