// WidgetBlueprintGeneratedClass ReticuleMoving.ReticuleMoving_C
// Size: 0x6c0 (Inherited: 0x5c8)
struct UReticuleMoving_C : UKSComponentReticleWidgetBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5c8(0x08)
	struct UWidgetAnimation* BrokenGadgetIconAnim; // 0x5d0(0x08)
	struct UWidgetAnimation* DamagedGadgetIconAnim; // 0x5d8(0x08)
	struct UWidgetAnimation* ResistIconAnim; // 0x5e0(0x08)
	struct UImage* AimBlockedIcon; // 0x5e8(0x08)
	struct UImage* BrokenGadgetIcon; // 0x5f0(0x08)
	struct UImage* DamagedGadgetIcon; // 0x5f8(0x08)
	struct UHorizontalBox* DamageIcons; // 0x600(0x08)
	struct UDualARReticle_C* DualARReticle; // 0x608(0x08)
	struct UCanvasPanel* HitMarkersContainer; // 0x610(0x08)
	struct UHitReticle_C* HitReticle; // 0x618(0x08)
	struct UCanvasPanel* MainCanvas; // 0x620(0x08)
	struct UReticleBase_C* NullReticle; // 0x628(0x08)
	struct UPistolReticle_C* PistolReticle; // 0x630(0x08)
	struct UReloadReticle_C* ReloadReticle; // 0x638(0x08)
	struct UImage* ResistIcon; // 0x640(0x08)
	struct USizeBox* ResistIconWrapper; // 0x648(0x08)
	struct UWidgetSwitcher* ReticleSwitcher; // 0x650(0x08)
	struct URifleReticle_C* RifleReticle; // 0x658(0x08)
	struct UShotgunReticle_C* ShotgunReticle; // 0x660(0x08)
	float CachedAccuracy; // 0x668(0x04)
	float Offset; // 0x66c(0x04)
	float CurrentADSTime; // 0x670(0x04)
	char UnknownData_674[0x4]; // 0x674(0x04)
	struct AKSWeapon* Grenade; // 0x678(0x08)
	float GrenadeTickPeriod; // 0x680(0x04)
	char UnknownData_684[0x4]; // 0x684(0x04)
	struct AKSWeapon_Aimed* ActiveWeapon; // 0x688(0x08)
	struct AKSPlayerState* BoundPlayer; // 0x690(0x08)
	struct AKSCharacter* BoundChar; // 0x698(0x08)
	bool CachedOutOfBounds; // 0x6a0(0x01)
	bool CachedCrosshairHidden; // 0x6a1(0x01)
	char UnknownData_6A2[0x2]; // 0x6a2(0x02)
	struct FVector2D TargetTranslation; // 0x6a4(0x08)
	float TargetOpacity; // 0x6ac(0x04)
	bool CachedIsDead; // 0x6b0(0x01)
	bool CachedDownedInPlay; // 0x6b1(0x01)
	bool CachedIsPlayingEmote; // 0x6b2(0x01)
	char UnknownData_6B3[0x5]; // 0x6b3(0x05)
	struct UKSSettingsDataFactory* SettingDataFactory; // 0x6b8(0x08)

	void ResetADS(); // Function ReticuleMoving.ReticuleMoving_C.ResetADS // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateBlockedShotDisplay(bool IsVisible, struct FVector2D Translation, struct FVector2D IconScale); // Function ReticuleMoving.ReticuleMoving_C.UpdateBlockedShotDisplay // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateVisibility(); // Function ReticuleMoving.ReticuleMoving_C.UpdateVisibility // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UnBindReticleAmmoGauge(); // Function ReticuleMoving.ReticuleMoving_C.UnBindReticleAmmoGauge // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleShotgunElimination(); // Function ReticuleMoving.ReticuleMoving_C.HandleShotgunElimination // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ProcessShotgunHitDisplay(struct FShotgunHitData InShotgunHitData); // Function ReticuleMoving.ReticuleMoving_C.ProcessShotgunHitDisplay // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UnbindShotgunNotify(); // Function ReticuleMoving.ReticuleMoving_C.UnbindShotgunNotify // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BindToShotgunNotify(); // Function ReticuleMoving.ReticuleMoving_C.BindToShotgunNotify // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void IsShotgunReticleType(bool Return, struct UReticleBase_C* Reticle); // Function ReticuleMoving.ReticuleMoving_C.IsShotgunReticleType // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void BindReticleAmmoGauge(); // Function ReticuleMoving.ReticuleMoving_C.BindReticleAmmoGauge // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void CheckShotgunReload(bool IsShotgunReload); // Function ReticuleMoving.ReticuleMoving_C.CheckShotgunReload // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GetActiveReticle(struct UReticleBase_C* Reticle); // Function ReticuleMoving.ReticuleMoving_C.GetActiveReticle // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void SetActiveReticle(); // Function ReticuleMoving.ReticuleMoving_C.SetActiveReticle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeTickAnimations(); // Function ReticuleMoving.ReticuleMoving_C.InitializeTickAnimations // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void HandleBlockedShotLerpUpdate(float ElapsedTime, float ElapsedAlpha); // Function ReticuleMoving.ReticuleMoving_C.HandleBlockedShotLerpUpdate // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleBlockedShotLerpFinished(); // Function ReticuleMoving.ReticuleMoving_C.HandleBlockedShotLerpFinished // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function ReticuleMoving.ReticuleMoving_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void AimStateChange(enum class EKSCharacterAimMode NewAimMode); // Function ReticuleMoving.ReticuleMoving_C.AimStateChange // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Kill(struct FCombatEventInfo Victim); // Function ReticuleMoving.ReticuleMoving_C.Kill // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnInstigatedDamage(float DamageAmount, bool IsHeadshot, bool IsDown, bool isLethal, bool isShielded, struct UDamageType* DamageTypeClass, struct AActor* Target, struct AActor* DamageCauser, bool Damage Resisted); // Function ReticuleMoving.ReticuleMoving_C.OnInstigatedDamage // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateReticleOffset(float OffsetFromCenterScreen); // Function ReticuleMoving.ReticuleMoving_C.UpdateReticleOffset // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void UpdateBlockedShotIcon(bool IconVisible, struct FVector2D Translation, struct FVector2D IconScale); // Function ReticuleMoving.ReticuleMoving_C.UpdateBlockedShotIcon // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void PostSetActiveWeaponComponent(); // Function ReticuleMoving.ReticuleMoving_C.PostSetActiveWeaponComponent // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void PreClearActiveWeaponComponent(); // Function ReticuleMoving.ReticuleMoving_C.PreClearActiveWeaponComponent // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void HandleOnKillCamViewProjectile(struct AKSProjectile* ViewProjectile); // Function ReticuleMoving.ReticuleMoving_C.HandleOnKillCamViewProjectile // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleKillCamEnabled(bool bEnabled); // Function ReticuleMoving.ReticuleMoving_C.HandleKillCamEnabled // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PreClearPawn(); // Function ReticuleMoving.ReticuleMoving_C.PreClearPawn // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void ViewedPawnInstigatedDamageNotify(struct FCombatEventInfo DamageInfo); // Function ReticuleMoving.ReticuleMoving_C.ViewedPawnInstigatedDamageNotify // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x2587100
	void OnPlayerKilled(struct AKSCharacterBase* KillerCharacter, struct AKSCharacterBase* KilledCharacter); // Function ReticuleMoving.ReticuleMoving_C.OnPlayerKilled // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleReload (New)(struct UKSWeaponComponent* WeaponComponent, enum class EWeaponStateNew OldState, enum class EWeaponStateNew NewState); // Function ReticuleMoving.ReticuleMoving_C.HandleReload (New) // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GrenadeStateChange (New)(struct UKSWeaponComponent* Weapon, enum class EWeaponStateNew Old State, enum class EWeaponStateNew New State); // Function ReticuleMoving.ReticuleMoving_C.GrenadeStateChange (New) // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleShotgunNotify(struct AKSCharacter* KSCharacter, struct FShotgunHitData InShotgunHitData); // Function ReticuleMoving.ReticuleMoving_C.HandleShotgunNotify // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PostSetPawn(); // Function ReticuleMoving.ReticuleMoving_C.PostSetPawn // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void PostSetPlayerState(); // Function ReticuleMoving.ReticuleMoving_C.PostSetPlayerState // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void PreClearPlayerState(); // Function ReticuleMoving.ReticuleMoving_C.PreClearPlayerState // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnInitialized(); // Function ReticuleMoving.ReticuleMoving_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void SetReticleColor(int32_t SettingValue); // Function ReticuleMoving.ReticuleMoving_C.SetReticleColor // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HideResistIcon(); // Function ReticuleMoving.ReticuleMoving_C.HideResistIcon // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HideDamagedGadgetIcon(); // Function ReticuleMoving.ReticuleMoving_C.HideDamagedGadgetIcon // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HideBrokenGadgetIcon(); // Function ReticuleMoving.ReticuleMoving_C.HideBrokenGadgetIcon // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Player Down or Elim Changed(struct AKSPlayerState* PlayerState); // Function ReticuleMoving.ReticuleMoving_C.Handle Player Down or Elim Changed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleEmoteStoppedPlaying(); // Function ReticuleMoving.ReticuleMoving_C.HandleEmoteStoppedPlaying // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleOnEmoteStartedPlaying(); // Function ReticuleMoving.ReticuleMoving_C.HandleOnEmoteStartedPlaying // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleDeathStateChange(); // Function ReticuleMoving.ReticuleMoving_C.HandleDeathStateChange // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleCrosshairHidden(struct AKSCharacter* Character, bool Hidden); // Function ReticuleMoving.ReticuleMoving_C.HandleCrosshairHidden // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Out Of Bounds End(); // Function ReticuleMoving.ReticuleMoving_C.Handle Out Of Bounds End // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Out Of Bounds Begin(); // Function ReticuleMoving.ReticuleMoving_C.Handle Out Of Bounds Begin // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_ReticuleMoving(int32_t EntryPoint); // Function ReticuleMoving.ReticuleMoving_C.ExecuteUbergraph_ReticuleMoving // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

