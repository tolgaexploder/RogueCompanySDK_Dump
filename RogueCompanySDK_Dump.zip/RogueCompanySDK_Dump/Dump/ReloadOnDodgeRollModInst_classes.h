// BlueprintGeneratedClass ReloadOnDodgeRollModInst.ReloadOnDodgeRollModInst_C
// Size: 0x19c (Inherited: 0x190)
struct UReloadOnDodgeRollModInst_C : UKSModInst_OnDodgeRoll {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x190(0x08)
	int32_t Previous ammo in clip; // 0x198(0x04)

	void MagDropForDodgeReload(struct UKSWeaponComponent* Master Weapon Ref); // Function ReloadOnDodgeRollModInst.ReloadOnDodgeRollModInst_C.MagDropForDodgeReload // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	bool StopAnimationFromEvent(struct FName AnimEventName, struct UKSCharacterAnimInst* CharAnimInstance); // Function ReloadOnDodgeRollModInst.ReloadOnDodgeRollModInst_C.StopAnimationFromEvent // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	bool ReactsToAnimationEvent(struct FName AnimEventName, int32_t Priority); // Function ReloadOnDodgeRollModInst.ReloadOnDodgeRollModInst_C.ReactsToAnimationEvent // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnDodgeRoll(float RollDuration); // Function ReloadOnDodgeRollModInst.ReloadOnDodgeRollModInst_C.OnDodgeRoll // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void RemotePlayerAudio(); // Function ReloadOnDodgeRollModInst.ReloadOnDodgeRollModInst_C.RemotePlayerAudio // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Dodge Reload Mod Notified(); // Function ReloadOnDodgeRollModInst.ReloadOnDodgeRollModInst_C.Dodge Reload Mod Notified // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_ReloadOnDodgeRollModInst(int32_t EntryPoint); // Function ReloadOnDodgeRollModInst.ReloadOnDodgeRollModInst_C.ExecuteUbergraph_ReloadOnDodgeRollModInst // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

