// WidgetBlueprintGeneratedClass Dropdown.Dropdown_C
// Size: 0x5b0 (Inherited: 0x4e0)
struct UDropdown_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UWidgetAnimation* hoveranim; // 0x4e8(0x08)
	struct UImage* DropArrow; // 0x4f0(0x08)
	struct UMenuAnchor* DropdownAnchor; // 0x4f8(0x08)
	struct UImage* DropDownBkg; // 0x500(0x08)
	struct UButton* HitTarget; // 0x508(0x08)
	struct UTextBlock* SelectionText; // 0x510(0x08)
	struct FMulticastInlineDelegate OnSelectionChanged; // 0x518(0x10)
	struct TArray<struct FText> Options; // 0x528(0x10)
	struct FText DefaultSelection; // 0x538(0x18)
	int32_t HoverIndex; // 0x550(0x04)
	int32_t SelectionIndex; // 0x554(0x04)
	struct FText HintText; // 0x558(0x18)
	bool IgnoreFirst; // 0x570(0x01)
	bool IgnoreCanceled; // 0x571(0x01)
	char UnknownData_572[0x6]; // 0x572(0x06)
	struct UDropdownList_C* DropdownList; // 0x578(0x08)
	struct UAkAudioEvent* ClickDropdownSFX; // 0x580(0x08)
	struct UAkAudioEvent* HoverDropdownSFX; // 0x588(0x08)
	struct FMulticastInlineDelegate OnHoverPreview; // 0x590(0x10)
	struct FMulticastInlineDelegate OnSelectionCanceled; // 0x5a0(0x10)

	void IsSelecting(bool IsSelecting); // Function Dropdown.Dropdown_C.IsSelecting // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	bool NavigateConfirm(); // Function Dropdown.Dropdown_C.NavigateConfirm // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void AppendOptions(struct TArray<struct FText> OptionsToAppend); // Function Dropdown.Dropdown_C.AppendOptions // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ForceClose(); // Function Dropdown.Dropdown_C.ForceClose // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ForceToggle(); // Function Dropdown.Dropdown_C.ForceToggle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ForceOpen(); // Function Dropdown.Dropdown_C.ForceOpen // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	struct UWidget* InitializeDropdownList(); // Function Dropdown.Dropdown_C.InitializeDropdownList // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetSelectedOptionByIndex(int32_t Index, bool Success); // Function Dropdown.Dropdown_C.SetSelectedOptionByIndex // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetSelectedOptionByText(struct FText Text, bool Success); // Function Dropdown.Dropdown_C.SetSelectedOptionByText // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void RemoveOptionByIndex(int32_t Index, bool Success); // Function Dropdown.Dropdown_C.RemoveOptionByIndex // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void RemoveOptionByText(struct FText Option, bool Success); // Function Dropdown.Dropdown_C.RemoveOptionByText // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GetSelectedOption(struct FText Selection, int32_t Index); // Function Dropdown.Dropdown_C.GetSelectedOption // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void GetOptionCount(int32_t Count); // Function Dropdown.Dropdown_C.GetOptionCount // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void FindIndexForOption(struct FText Option, bool Success, int32_t Index); // Function Dropdown.Dropdown_C.FindIndexForOption // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void FindOptionByIndex(int32_t Index, bool Success, struct FText Option); // Function Dropdown.Dropdown_C.FindOptionByIndex // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ClearSelection(); // Function Dropdown.Dropdown_C.ClearSelection // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ClearOptions(); // Function Dropdown.Dropdown_C.ClearOptions // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void AddOption(struct FText OptionText); // Function Dropdown.Dropdown_C.AddOption // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature(); // Function Dropdown.Dropdown_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void SelectionMade(int32_t Index, struct FText Selection); // Function Dropdown.Dropdown_C.SelectionMade // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_8_OnButtonClickedEvent__DelegateSignature(); // Function Dropdown.Dropdown_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_8_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void SelectionCancel(); // Function Dropdown.Dropdown_C.SelectionCancel // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BndEvt__DropdownAnchor_K2Node_ComponentBoundEvent_0_OnMenuOpenChangedEvent__DelegateSignature(bool bIsOpen); // Function Dropdown.Dropdown_C.BndEvt__DropdownAnchor_K2Node_ComponentBoundEvent_0_OnMenuOpenChangedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void HandleSetCurrentHoverIndex(int32_t CurrentHoverIndex); // Function Dropdown.Dropdown_C.HandleSetCurrentHoverIndex // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature(); // Function Dropdown.Dropdown_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void GamepadHover(); // Function Dropdown.Dropdown_C.GamepadHover // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void GamepadUnhover(); // Function Dropdown.Dropdown_C.GamepadUnhover // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void On Selected(); // Function Dropdown.Dropdown_C.On Selected // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Hover(); // Function Dropdown.Dropdown_C.Hover // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Unhover(); // Function Dropdown.Dropdown_C.Unhover // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HoverPreview(int32_t Index); // Function Dropdown.Dropdown_C.HoverPreview // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_Dropdown(int32_t EntryPoint); // Function Dropdown.Dropdown_C.ExecuteUbergraph_Dropdown // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void OnSelectionCanceled__DelegateSignature(); // Function Dropdown.Dropdown_C.OnSelectionCanceled__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnHoverPreview__DelegateSignature(int32_t Index); // Function Dropdown.Dropdown_C.OnHoverPreview__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnSelectionChanged__DelegateSignature(struct FText SelectionText, int32_t SelectionIndex); // Function Dropdown.Dropdown_C.OnSelectionChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

