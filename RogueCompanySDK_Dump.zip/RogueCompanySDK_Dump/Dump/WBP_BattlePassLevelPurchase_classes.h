// WidgetBlueprintGeneratedClass WBP_BattlePassLevelPurchase.WBP_BattlePassLevelPurchase_C
// Size: 0x518 (Inherited: 0x4e0)
struct UWBP_BattlePassLevelPurchase_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UTextBlock* TitleText; // 0x4e8(0x08)
	struct UWBP_PanelDefault_C* WBP_PanelDefault; // 0x4f0(0x08)
	struct UWBP_YellowButton_C* WBP_YellowButton; // 0x4f8(0x08)
	int32_t NumUnlockTiers; // 0x500(0x04)
	char UnknownData_504[0x4]; // 0x504(0x04)
	struct FMulticastInlineDelegate OnButtonClicked; // 0x508(0x10)

	void DisplayUnlockTier(int32_t Tier); // Function WBP_BattlePassLevelPurchase.WBP_BattlePassLevelPurchase_C.DisplayUnlockTier // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BndEvt__WBP_YellowButton_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature(struct UWidget* Widget); // Function WBP_BattlePassLevelPurchase.WBP_BattlePassLevelPurchase_C.BndEvt__WBP_YellowButton_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function WBP_BattlePassLevelPurchase.WBP_BattlePassLevelPurchase_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_BattlePassLevelPurchase(int32_t EntryPoint); // Function WBP_BattlePassLevelPurchase.WBP_BattlePassLevelPurchase_C.ExecuteUbergraph_WBP_BattlePassLevelPurchase // (Final|UbergraphFunction) // @ game+0x2587100
	void OnButtonClicked__DelegateSignature(); // Function WBP_BattlePassLevelPurchase.WBP_BattlePassLevelPurchase_C.OnButtonClicked__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

