// BlueprintGeneratedClass IKSContextMenuTarget.IKSContextMenuTarget_C
// Size: 0x28 (Inherited: 0x28)
struct UIKSContextMenuTarget_C : UInterface {

	void OnContextMenuOpen(enum class EViewSide side); // Function IKSContextMenuTarget.IKSContextMenuTarget_C.OnContextMenuOpen // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnContextMenuClose(); // Function IKSContextMenuTarget.IKSContextMenuTarget_C.OnContextMenuClose // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

