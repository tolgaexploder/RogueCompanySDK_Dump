// WidgetBlueprintGeneratedClass PointObjectiveMarker.PointObjectiveMarker_C
// Size: 0x4d1 (Inherited: 0x3a8)
struct UPointObjectiveMarker_C : UKSPointObjectiveMarkerWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3a8(0x08)
	struct UWidgetAnimation* attention_anim; // 0x3b0(0x08)
	struct UWidgetAnimation* active_anim; // 0x3b8(0x08)
	struct UWidgetAnimation* chevron_anim; // 0x3c0(0x08)
	struct UCanvasPanel* CanvasPanel_2; // 0x3c8(0x08)
	struct UImage* ChevronBottomLeft; // 0x3d0(0x08)
	struct UImage* ChevronBottomRight; // 0x3d8(0x08)
	struct UOverlay* ChevronGroup; // 0x3e0(0x08)
	struct USizeBox* Chevrons; // 0x3e8(0x08)
	struct UImage* ChevronTopLeft; // 0x3f0(0x08)
	struct UImage* ChevronTopRight; // 0x3f8(0x08)
	struct UTextBlock* DebugText_Misc; // 0x400(0x08)
	struct UTextBlock* DebugText_State; // 0x408(0x08)
	struct UTextBlock* DebugText_Team; // 0x410(0x08)
	struct UOverlay* Diamond; // 0x418(0x08)
	struct UTextBlock* DistanceText; // 0x420(0x08)
	struct UImage* Fill; // 0x428(0x08)
	struct UImage* FillInner; // 0x430(0x08)
	struct UImage* FillOuter; // 0x438(0x08)
	struct UImage* Lock; // 0x440(0x08)
	struct UOverlay* LockedGroup; // 0x448(0x08)
	struct UWidgetSwitcher* LockedSwitcher; // 0x450(0x08)
	struct UImage* ObjBackShade; // 0x458(0x08)
	struct UImage* ObjColoredFill; // 0x460(0x08)
	struct UImage* ObjInteriorEdge; // 0x468(0x08)
	struct UImage* ObjInteriorEdge_2; // 0x470(0x08)
	struct UTextBlock* ObjName; // 0x478(0x08)
	struct UImage* PulseGradient; // 0x480(0x08)
	struct UImage* PulseWave; // 0x488(0x08)
	struct UImage* PulseWave2; // 0x490(0x08)
	struct UImage* PulseWave3; // 0x498(0x08)
	struct UImage* Swords; // 0x4a0(0x08)
	struct UTextBlock* TimerText; // 0x4a8(0x08)
	struct UHorizontalBox* UnlockedGroup; // 0x4b0(0x08)
	struct FName CurrentObjectiveState; // 0x4b8(0x08)
	struct FLinearColor Neutral Color; // 0x4c0(0x10)
	enum class EIconMarkerScreenRegion CurrentScreenRegion; // 0x4d0(0x01)

	void PlayerIsBlinded(bool IsBlinded); // Function PointObjectiveMarker.PointObjectiveMarker_C.PlayerIsBlinded // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void UpdateControlPointScoreProgress(struct AKSControlPoint* Objective); // Function PointObjectiveMarker.PointObjectiveMarker_C.UpdateControlPointScoreProgress // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateControlPointCaptureProgress(struct AKSControlPoint* Objective); // Function PointObjectiveMarker.PointObjectiveMarker_C.UpdateControlPointCaptureProgress // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateControlPointState(struct AKSObjectiveBase* Objective); // Function PointObjectiveMarker.PointObjectiveMarker_C.UpdateControlPointState // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetContestedColor(enum class EPointObjectiveMarkerTeamState ObjectiveState); // Function PointObjectiveMarker.PointObjectiveMarker_C.SetContestedColor // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GetOwningTeamColor(struct AKSObjectiveBase* Objective, struct FLinearColor OwningTeamColor, struct FLinearColor OpposingTeamColor); // Function PointObjectiveMarker.PointObjectiveMarker_C.GetOwningTeamColor // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	enum class ESlateVisibility Update(); // Function PointObjectiveMarker.PointObjectiveMarker_C.Update // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Get Neutral Color(float Opacity, struct FLinearColor Return Value); // Function PointObjectiveMarker.PointObjectiveMarker_C.Get Neutral Color // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x2587100
	void ViewSetCaptureProgress(float ProgressPercent); // Function PointObjectiveMarker.PointObjectiveMarker_C.ViewSetCaptureProgress // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void SetView(struct FKSPointObjectiveMarkerViewState ViewState); // Function PointObjectiveMarker.PointObjectiveMarker_C.SetView // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void SetScreenRegion(enum class EIconMarkerScreenRegion ScreenRegion); // Function PointObjectiveMarker.PointObjectiveMarker_C.SetScreenRegion // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void SetArrowAngle(float Angle); // Function PointObjectiveMarker.PointObjectiveMarker_C.SetArrowAngle // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ViewApplyTimerValue(float TimerSeconds, float TotalTimerSeconds); // Function PointObjectiveMarker.PointObjectiveMarker_C.ViewApplyTimerValue // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void UpdateMetersAway(int32_t Meters); // Function PointObjectiveMarker.PointObjectiveMarker_C.UpdateMetersAway // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function PointObjectiveMarker.PointObjectiveMarker_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void ControlPointStateUpdated(struct AKSControlPoint* Objective); // Function PointObjectiveMarker.PointObjectiveMarker_C.ControlPointStateUpdated // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnControlTeamScoreUpdated(struct AKSTeamState* TeamState); // Function PointObjectiveMarker.PointObjectiveMarker_C.OnControlTeamScoreUpdated // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void UpdateOpacityWhenAiming(); // Function PointObjectiveMarker.PointObjectiveMarker_C.UpdateOpacityWhenAiming // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_PointObjectiveMarker(int32_t EntryPoint); // Function PointObjectiveMarker.PointObjectiveMarker_C.ExecuteUbergraph_PointObjectiveMarker // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

