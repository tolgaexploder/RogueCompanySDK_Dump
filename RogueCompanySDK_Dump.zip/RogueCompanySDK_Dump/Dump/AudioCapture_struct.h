// ScriptStruct AudioCapture.AudioCaptureDeviceInfo
// Size: 0x10 (Inherited: 0x00)
struct FAudioCaptureDeviceInfo {
	struct FName DeviceName; // 0x00(0x08)
	int32_t NumInputChannels; // 0x08(0x04)
	int32_t SampleRate; // 0x0c(0x04)
};

