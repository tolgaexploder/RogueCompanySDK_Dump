// BlueprintGeneratedClass WaypointBeacon.WaypointBeacon_C
// Size: 0x248 (Inherited: 0x238)
struct AWaypointBeacon_C : AKSPingBeaconBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UParticleSystemComponent* ParticleSystem; // 0x240(0x08)

	void UserConstructionScript(); // Function WaypointBeacon.WaypointBeacon_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ReceiveBeginPlay(); // Function WaypointBeacon.WaypointBeacon_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void SetupBeaconDisplay(); // Function WaypointBeacon.WaypointBeacon_C.SetupBeaconDisplay // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WaypointBeacon(int32_t EntryPoint); // Function WaypointBeacon.WaypointBeacon_C.ExecuteUbergraph_WaypointBeacon // (Final|UbergraphFunction) // @ game+0x2587100
};

