// WidgetBlueprintGeneratedClass AccuracyDebug.AccuracyDebug_C
// Size: 0x5b0 (Inherited: 0x4e0)
struct UAccuracyDebug_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UCanvasPanel* MainCanvas; // 0x4e8(0x08)
	struct UTextBlock* TextBlock_5; // 0x4f0(0x08)
	struct UTextBlock* TextBlock_6; // 0x4f8(0x08)
	struct UTextBlock* TextBlock_7; // 0x500(0x08)
	struct UTextBlock* TextBlock_8; // 0x508(0x08)
	struct UTextBlock* TextBlock_9; // 0x510(0x08)
	struct UTextBlock* TextBlock_10; // 0x518(0x08)
	struct UTextBlock* TextBlock_11; // 0x520(0x08)
	struct UTextBlock* TextBlock_12; // 0x528(0x08)
	struct UTextBlock* TextBlock_13; // 0x530(0x08)
	struct UTextBlock* TextBlock_14; // 0x538(0x08)
	struct UTextBlock* TextBlock_15; // 0x540(0x08)
	struct UTextBlock* TextBlock_16; // 0x548(0x08)
	struct UTextBlock* TextBlock_17; // 0x550(0x08)
	struct UTextBlock* TextBlock_18; // 0x558(0x08)
	struct UTextBlock* TextBlock_19; // 0x560(0x08)
	struct UTextBlock* TextBlock_20; // 0x568(0x08)
	struct UTextBlock* TextBlock_59; // 0x570(0x08)
	struct UTextBlock* TextBlock_60; // 0x578(0x08)
	struct UTextBlock* TextBlock_61; // 0x580(0x08)
	struct UTextBlock* TextBlock_62; // 0x588(0x08)
	struct TArray<struct UTextBlock*> VertArray; // 0x590(0x10)
	struct TArray<struct UTextBlock*> HoriArray; // 0x5a0(0x10)

	void Construct(); // Function AccuracyDebug.AccuracyDebug_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function AccuracyDebug.AccuracyDebug_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_AccuracyDebug(int32_t EntryPoint); // Function AccuracyDebug.AccuracyDebug_C.ExecuteUbergraph_AccuracyDebug // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

