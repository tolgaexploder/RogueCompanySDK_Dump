// WidgetBlueprintGeneratedClass GameHUDWidget.GameHUDWidget_C
// Size: 0x6f8 (Inherited: 0x4e0)
struct UGameHUDWidget_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UCanvasPanel* AlwaysPersistant; // 0x4e8(0x08)
	struct UCanvasPanel* AlwaysVisible; // 0x4f0(0x08)
	struct UBlocker_C* Blocker; // 0x4f8(0x08)
	struct UCanvasPanel* Content; // 0x500(0x08)
	struct UDamageModifierDisplay_C* DamageModifierDisplay; // 0x508(0x08)
	struct UDeathSpectateOverlay_C* DeathSpectateOverlay; // 0x510(0x08)
	struct UDownedHealthRemaining_C* DownedHealthRemaining; // 0x518(0x08)
	struct UWBP_EliminationMessageOverlay_C* ElimNotify; // 0x520(0x08)
	struct UExpDisplay_C* ExpDisplay; // 0x528(0x08)
	struct UFontPreloader_C* FontPreloader; // 0x530(0x08)
	struct UFontPreloader_C* FontPreloader_2; // 0x538(0x08)
	struct UCanvasPanel* GameModeWidgetContainer; // 0x540(0x08)
	struct UCanvasPanel* GameRuleWidgets; // 0x548(0x08)
	struct UGameTouchHUDWidget_C* GameTouchHUDWidget; // 0x550(0x08)
	struct UHitIndictor_C* HitIndictor; // 0x558(0x08)
	struct UCanvasPanel* HUDCanvas; // 0x560(0x08)
	struct UPUMG_CanvasPanel* HUDContent; // 0x568(0x08)
	struct UInvalidationBox* InvalidationBox_2; // 0x570(0x08)
	struct UWBP_InGameJobSelectManager_C* JobSelectionManager; // 0x578(0x08)
	struct UKillCam_C* KillCam; // 0x580(0x08)
	struct UPUMG_CanvasPanel* MainCanvas; // 0x588(0x08)
	struct UMarkerDisplay_C* MarkerDisplay; // 0x590(0x08)
	struct UModsWidget_C* ModsWidget; // 0x598(0x08)
	struct UOutBound_C* OutBound; // 0x5a0(0x08)
	struct UPickupNotify_C* PickupNotify_103; // 0x5a8(0x08)
	struct UPlayerActivePerks_C* PlayerActivePerks; // 0x5b0(0x08)
	struct UCanvasPanel* PopupContent; // 0x5b8(0x08)
	struct UPopupManager_C* PopupManager; // 0x5c0(0x08)
	struct UWBP_RespawnTimer_C* RespawnTimer; // 0x5c8(0x08)
	struct UResultScreen_C* ResultScreen; // 0x5d0(0x08)
	struct UImage* SafeFrameBorderBottom; // 0x5d8(0x08)
	struct UImage* SafeFrameBorderLeft; // 0x5e0(0x08)
	struct UImage* SafeFrameBorderRight; // 0x5e8(0x08)
	struct UImage* SafeFrameBorderTop; // 0x5f0(0x08)
	struct UGridPanel* SafeFrameGrid; // 0x5f8(0x08)
	struct UScopeMagnifier_C* ScopeMagnifier; // 0x600(0x08)
	struct UStatusEffect_C* StatusEffect; // 0x608(0x08)
	struct UStatusEffectPermant_C* StatusEffectPermant; // 0x610(0x08)
	struct USwimmingHUD_C* SwimmingHUD; // 0x618(0x08)
	struct UWBP_TextChat_C* TextChat; // 0x620(0x08)
	struct UVehicleOverlay_C* VehicleOverlay; // 0x628(0x08)
	struct UWBP_WaitForPlayers_C* WaitingForPlayers; // 0x630(0x08)
	struct UWBP_Context_Bar_C* WBP_Context_Bar; // 0x638(0x08)
	struct UWBP_DamageNumberMgr_C* WBP_DamageNumberMgr; // 0x640(0x08)
	struct UWBP_InstanceFUBARNotification_C* WBP_InstanceFUBARNotification; // 0x648(0x08)
	struct UWBP_InventoryFullWarning_C* WBP_InventoryFullWarning; // 0x650(0x08)
	struct UWBP_KillstreakDurationBars_C* WBP_KillstreakDurationBars_116; // 0x658(0x08)
	struct UWBP_NoGadgetWarning_C* WBP_NoGadgetWarning_869; // 0x660(0x08)
	struct UWBP_ObjectiveMilestoneMessageQueue_C* WBP_ObjectiveMilestoneMessages_1; // 0x668(0x08)
	struct UWBP_PlayerAccolades_C* WBP_PlayerAccolades; // 0x670(0x08)
	struct UWBP_RadialSelect_C* WBP_RadialSelect_84; // 0x678(0x08)
	struct UWBP_SystemNotify_NetworkDisconnect_C* WBP_SystemNotify_NetworkDisconnect; // 0x680(0x08)
	struct UWBP_TeamMessage_C* WBP_TeamMessages; // 0x688(0x08)
	struct UWBP_ToastNotification_Manager_C* WBP_ToastNotification_Manager; // 0x690(0x08)
	struct UWBP_VoiceActivity_C* WBP_VoiceActivity; // 0x698(0x08)
	struct UWeaponMenuManager_C* WeaponMenuManager; // 0x6a0(0x08)
	struct UWorldMessages_C* WorldMessages; // 0x6a8(0x08)
	bool PrimaryNeedReload; // 0x6b0(0x01)
	bool SecondaryNeedReload; // 0x6b1(0x01)
	char UnknownData_6B2[0x6]; // 0x6b2(0x06)
	struct UUserWidget* DefaultGameModeWidgetClass; // 0x6b8(0x08)
	struct TArray<struct UUserWidget*> ForceLoadedAssets; // 0x6c0(0x10)
	struct UPUMG_GenericRouteDataObject* GotoMapData; // 0x6d0(0x08)
	struct UEnemyBombCarrierTracker_C* EnemyBombCarrierTracker; // 0x6d8(0x08)
	struct FMulticastInlineDelegate OnGameModeWidgetSet; // 0x6e0(0x10)
	struct UUserWidget* GameModeWidget; // 0x6f0(0x08)

	void HandleTouchModeChange(bool IsTouchMode); // Function GameHUDWidget.GameHUDWidget_C.HandleTouchModeChange // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeTouchWidget(); // Function GameHUDWidget.GameHUDWidget_C.InitializeTouchWidget // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ShouldVoteBlockMenu(bool ShouldBlock); // Function GameHUDWidget.GameHUDWidget_C.ShouldVoteBlockMenu // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void FlushVoteInput(); // Function GameHUDWidget.GameHUDWidget_C.FlushVoteInput // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ReleasePlayerInputs(enum class EInputReleaseType ReleaseType); // Function GameHUDWidget.GameHUDWidget_C.ReleasePlayerInputs // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GetFocusableWidgets(struct TArray<struct UPUMG_Widget*> OutWIdgets); // Function GameHUDWidget.GameHUDWidget_C.GetFocusableWidgets // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeHUDContent(); // Function GameHUDWidget.GameHUDWidget_C.InitializeHUDContent // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetSafeFrame(float Scale); // Function GameHUDWidget.GameHUDWidget_C.SetSafeFrame // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Add Game Rule Widget(struct UUserWidget* Game Rule Widget, struct FString Parent Widget); // Function GameHUDWidget.GameHUDWidget_C.Add Game Rule Widget // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeKillCam(); // Function GameHUDWidget.GameHUDWidget_C.InitializeKillCam // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeHudWidgets(); // Function GameHUDWidget.GameHUDWidget_C.InitializeHudWidgets // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeMapWidgets(); // Function GameHUDWidget.GameHUDWidget_C.InitializeMapWidgets // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function GameHUDWidget.GameHUDWidget_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Map(); // Function GameHUDWidget.GameHUDWidget_C.Map // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InputListeners(); // Function GameHUDWidget.GameHUDWidget_C.InputListeners // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Menu(); // Function GameHUDWidget.GameHUDWidget_C.Menu // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function GameHUDWidget.GameHUDWidget_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void SetListenersActive(bool Active); // Function GameHUDWidget.GameHUDWidget_C.SetListenersActive // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleKillCamEnabled(bool IsEnabled); // Function GameHUDWidget.GameHUDWidget_C.HandleKillCamEnabled // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ShowHUD(); // Function GameHUDWidget.GameHUDWidget_C.ShowHUD // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HideHUD(); // Function GameHUDWidget.GameHUDWidget_C.HideHUD // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ToggleTopBarHUD(bool ShouldShow); // Function GameHUDWidget.GameHUDWidget_C.ToggleTopBarHUD // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeJobSelectionManager(); // Function GameHUDWidget.GameHUDWidget_C.InitializeJobSelectionManager // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleOpenTextChat(bool BeginChatCommand); // Function GameHUDWidget.GameHUDWidget_C.HandleOpenTextChat // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OpenTextChatToPlayer(struct UPUMG_PlayerInfo* Player); // Function GameHUDWidget.GameHUDWidget_C.OpenTextChatToPlayer // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Viewport Size Changed(struct FIntPoint ViewportSize); // Function GameHUDWidget.GameHUDWidget_C.Handle Viewport Size Changed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function GameHUDWidget.GameHUDWidget_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ToggleTabScreen(); // Function GameHUDWidget.GameHUDWidget_C.ToggleTabScreen // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void DebugOnePress(); // Function GameHUDWidget.GameHUDWidget_C.DebugOnePress // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void DebugOneRelease(); // Function GameHUDWidget.GameHUDWidget_C.DebugOneRelease // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void DebugTwoPress(); // Function GameHUDWidget.GameHUDWidget_C.DebugTwoPress // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void DebugTwoRelease(); // Function GameHUDWidget.GameHUDWidget_C.DebugTwoRelease // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnChangedInput(enum class PGAME_INPUT_STATE InputState); // Function GameHUDWidget.GameHUDWidget_C.OnChangedInput // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnInitialized(); // Function GameHUDWidget.GameHUDWidget_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_GameHUDWidget(int32_t EntryPoint); // Function GameHUDWidget.GameHUDWidget_C.ExecuteUbergraph_GameHUDWidget // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void OnGameModeWidgetSet__DelegateSignature(struct UUserWidget* GameModeWidget); // Function GameHUDWidget.GameHUDWidget_C.OnGameModeWidgetSet__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

