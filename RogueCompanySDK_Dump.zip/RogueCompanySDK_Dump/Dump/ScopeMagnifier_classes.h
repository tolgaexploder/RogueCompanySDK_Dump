// WidgetBlueprintGeneratedClass ScopeMagnifier.ScopeMagnifier_C
// Size: 0x544 (Inherited: 0x4f8)
struct UScopeMagnifier_C : UKSViewedActiveWeaponWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4f8(0x08)
	struct UImage* GamepadPrompt; // 0x500(0x08)
	struct UImage* Image_3; // 0x508(0x08)
	struct UImage* MKBPrompt; // 0x510(0x08)
	struct UTextBlock* PostPromptText; // 0x518(0x08)
	struct UTextBlock* PrePromptText; // 0x520(0x08)
	struct UWidgetSwitcher* PromptSwitcher; // 0x528(0x08)
	struct UTextBlock* ZoomAmount; // 0x530(0x08)
	struct UHorizontalBox* ZoomPrompt; // 0x538(0x08)
	float 4xFOV; // 0x540(0x04)

	void OnPlayerHealthChanged(struct AKSCharacterBase* CharacterBase); // Function ScopeMagnifier.ScopeMagnifier_C.OnPlayerHealthChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnAimStateChanged(enum class EKSCharacterAimMode AimState); // Function ScopeMagnifier.ScopeMagnifier_C.OnAimStateChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void DetermineScope(float FOV); // Function ScopeMagnifier.ScopeMagnifier_C.DetermineScope // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleInputModeChanged(enum class PGAME_INPUT_STATE InputMode); // Function ScopeMagnifier.ScopeMagnifier_C.HandleInputModeChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetPromptImage(); // Function ScopeMagnifier.ScopeMagnifier_C.SetPromptImage // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	struct FText Get_PostPromptText_Text_1(); // Function ScopeMagnifier.ScopeMagnifier_C.Get_PostPromptText_Text_1 // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	struct FText Get_PrePromptText_Text_1(); // Function ScopeMagnifier.ScopeMagnifier_C.Get_PrePromptText_Text_1 // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void SplitPrompt(struct FString PreText, struct FString PosText); // Function ScopeMagnifier.ScopeMagnifier_C.SplitPrompt // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PostSetWeapon(); // Function ScopeMagnifier.ScopeMagnifier_C.PostSetWeapon // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void PreClearWeapon(); // Function ScopeMagnifier.ScopeMagnifier_C.PreClearWeapon // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function ScopeMagnifier.ScopeMagnifier_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function ScopeMagnifier.ScopeMagnifier_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_ScopeMagnifier(int32_t EntryPoint); // Function ScopeMagnifier.ScopeMagnifier_C.ExecuteUbergraph_ScopeMagnifier // (Final|UbergraphFunction) // @ game+0x2587100
};

