// WidgetBlueprintGeneratedClass WBP_CosmeticItem_Banner.WBP_CosmeticItem_Banner_C
// Size: 0x548 (Inherited: 0x4e0)
struct UWBP_CosmeticItem_Banner_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UWBP_ButtonSlot_Cosmetic_C* Button; // 0x4e8(0x08)
	struct UWBP_AsyncIcon_C* WBP_AsyncIcon; // 0x4f0(0x08)
	struct FMulticastInlineDelegate OnItemHovered; // 0x4f8(0x10)
	struct FMulticastInlineDelegate OnItemUnhovered; // 0x508(0x10)
	struct FMulticastInlineDelegate OnItemClicked; // 0x518(0x10)
	struct UKSItem* KSItem; // 0x528(0x08)
	struct UPUMG_StoreItem* StoreItem; // 0x530(0x08)
	struct UAkAudioEvent* HoverBannerItemSFX; // 0x538(0x08)
	struct UAkAudioEvent* ClickBannerItemSFX; // 0x540(0x08)

	bool NavigateConfirm(); // Function WBP_CosmeticItem_Banner.WBP_CosmeticItem_Banner_C.NavigateConfirm // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetBannerItemSlot(); // Function WBP_CosmeticItem_Banner.WBP_CosmeticItem_Banner_C.SetBannerItemSlot // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnHoverSound(); // Function WBP_CosmeticItem_Banner.WBP_CosmeticItem_Banner_C.OnHoverSound // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnClickSound(); // Function WBP_CosmeticItem_Banner.WBP_CosmeticItem_Banner_C.OnClickSound // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function WBP_CosmeticItem_Banner.WBP_CosmeticItem_Banner_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void PopulateSlot(); // Function WBP_CosmeticItem_Banner.WBP_CosmeticItem_Banner_C.PopulateSlot // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnBannerHover(bool IsGamepad); // Function WBP_CosmeticItem_Banner.WBP_CosmeticItem_Banner_C.OnBannerHover // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnBannerUnhover(); // Function WBP_CosmeticItem_Banner.WBP_CosmeticItem_Banner_C.OnBannerUnhover // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnBannerClick(); // Function WBP_CosmeticItem_Banner.WBP_CosmeticItem_Banner_C.OnBannerClick // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GamepadHover(); // Function WBP_CosmeticItem_Banner.WBP_CosmeticItem_Banner_C.GamepadHover // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void GamepadUnhover(); // Function WBP_CosmeticItem_Banner.WBP_CosmeticItem_Banner_C.GamepadUnhover // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void SetBannerActive(bool IsActive); // Function WBP_CosmeticItem_Banner.WBP_CosmeticItem_Banner_C.SetBannerActive // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function WBP_CosmeticItem_Banner.WBP_CosmeticItem_Banner_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_CosmeticItem_Banner(int32_t EntryPoint); // Function WBP_CosmeticItem_Banner.WBP_CosmeticItem_Banner_C.ExecuteUbergraph_WBP_CosmeticItem_Banner // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void OnItemClicked__DelegateSignature(struct UKSItem* KSItem, struct UWidget* Widget); // Function WBP_CosmeticItem_Banner.WBP_CosmeticItem_Banner_C.OnItemClicked__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnItemUnhovered__DelegateSignature(); // Function WBP_CosmeticItem_Banner.WBP_CosmeticItem_Banner_C.OnItemUnhovered__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnItemHovered__DelegateSignature(struct UKSItem* KSItem); // Function WBP_CosmeticItem_Banner.WBP_CosmeticItem_Banner_C.OnItemHovered__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

