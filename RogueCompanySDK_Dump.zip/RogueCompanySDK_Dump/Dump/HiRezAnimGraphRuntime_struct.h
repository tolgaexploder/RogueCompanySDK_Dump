// ScriptStruct HiRezAnimGraphRuntime.AnimNode_BlendByDedicatedServer
// Size: 0x40 (Inherited: 0x18)
struct FAnimNode_BlendByDedicatedServer : FAnimNode_Base {
	struct FPoseLink NotDedicatedServer; // 0x18(0x10)
	struct FPoseLink DedicatedServer; // 0x28(0x10)
	char UnknownData_38[0x8]; // 0x38(0x08)
};

// ScriptStruct HiRezAnimGraphRuntime.AnimNode_BlendByLOD
// Size: 0xa8 (Inherited: 0xa0)
struct FAnimNode_BlendByLOD : FAnimNode_BlendListBase {
	int32_t LOD; // 0xa0(0x04)
	char UnknownData_A4[0x4]; // 0xa4(0x04)
};

// ScriptStruct HiRezAnimGraphRuntime.AnimNode_RigidBodySkipServer
// Size: 0x5a0 (Inherited: 0x5a0)
struct FAnimNode_RigidBodySkipServer : FAnimNode_RigidBody {
	bool bIsDedicatedServer; // 0x598(0x01)
};

