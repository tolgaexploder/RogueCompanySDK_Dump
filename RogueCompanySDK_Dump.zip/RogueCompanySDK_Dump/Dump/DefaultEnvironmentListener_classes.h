// BlueprintGeneratedClass DefaultEnvironmentListener.DefaultEnvironmentListener_C
// Size: 0x128 (Inherited: 0xc8)
struct UDefaultEnvironmentListener_C : UEnvironmentListenerComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc8(0x08)
	struct FName LevelStateGroup; // 0xd0(0x08)
	struct TMap<struct FString, struct FName> LevelToStateGroupMap; // 0xd8(0x50)

	void OnEnvironmentChanged(struct FName OldEnvironmentTag); // Function DefaultEnvironmentListener.DefaultEnvironmentListener_C.OnEnvironmentChanged // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void Print State(bool Print to Screen, bool Print to Log, struct FLinearColor Text Color, float Duration); // Function DefaultEnvironmentListener.DefaultEnvironmentListener_C.Print State // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ReceiveBeginPlay(); // Function DefaultEnvironmentListener.DefaultEnvironmentListener_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_DefaultEnvironmentListener(int32_t EntryPoint); // Function DefaultEnvironmentListener.DefaultEnvironmentListener_C.ExecuteUbergraph_DefaultEnvironmentListener // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

