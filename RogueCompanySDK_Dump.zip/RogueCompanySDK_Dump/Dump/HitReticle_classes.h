// WidgetBlueprintGeneratedClass HitReticle.HitReticle_C
// Size: 0x2e3 (Inherited: 0x238)
struct UHitReticle_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UWidgetAnimation* Hit; // 0x240(0x08)
	struct UWidgetAnimation* Hit_KillConfirm; // 0x248(0x08)
	struct UWidgetAnimation* Hit_Triangle; // 0x250(0x08)
	struct UWidgetAnimation* Hit_KillConfirm_Triangle; // 0x258(0x08)
	struct UImage* elimimage_upperleft; // 0x260(0x08)
	struct UImage* elimimage_upperleft_2; // 0x268(0x08)
	struct UImage* elimimage_upperright; // 0x270(0x08)
	struct UImage* elimimage_upperright_2; // 0x278(0x08)
	struct UImage* flinchimage_lowerleft; // 0x280(0x08)
	struct UImage* flinchimage_lowerright; // 0x288(0x08)
	struct UImage* flinchimage_upperleft; // 0x290(0x08)
	struct UImage* flinchimage_upperright; // 0x298(0x08)
	struct UImage* Image; // 0x2a0(0x08)
	struct UImage* Image_2; // 0x2a8(0x08)
	struct UImage* Image_3; // 0x2b0(0x08)
	struct UImage* Image_11; // 0x2b8(0x08)
	struct UWidgetSwitcher* SwitcherNE; // 0x2c0(0x08)
	struct UWidgetSwitcher* SwitcherNW; // 0x2c8(0x08)
	struct UWidgetSwitcher* SwitcherSE; // 0x2d0(0x08)
	struct UWidgetSwitcher* SwitcherSW; // 0x2d8(0x08)
	bool IsHeadshot; // 0x2e0(0x01)
	bool isLethal; // 0x2e1(0x01)
	bool IsDown; // 0x2e2(0x01)

	void OnHitAnimationFinished(); // Function HitReticle.HitReticle_C.OnHitAnimationFinished // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ResetHitReticle(bool Headshot, bool Lethal, bool Down, bool Shielded); // Function HitReticle.HitReticle_C.ResetHitReticle // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_HitReticle(int32_t EntryPoint); // Function HitReticle.HitReticle_C.ExecuteUbergraph_HitReticle // (Final|UbergraphFunction) // @ game+0x2587100
};

