// WidgetBlueprintGeneratedClass MinimapIcon.MinimapIcon_C
// Size: 0x2b1 (Inherited: 0x238)
struct UMinimapIcon_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UWidgetAnimation* SecondaryToggle; // 0x240(0x08)
	struct UWidgetAnimation* PingFade; // 0x248(0x08)
	struct UImage* AboveIndicator; // 0x250(0x08)
	struct UImage* BelowIndicator; // 0x258(0x08)
	struct UWidgetSwitcher* IconSwitcher; // 0x260(0x08)
	struct UImage* ImageIcon; // 0x268(0x08)
	struct UScaleBox* ScaleBox_1; // 0x270(0x08)
	struct UTextBlock* SecondaryTextIcon; // 0x278(0x08)
	struct UTextBlock* TextIcon; // 0x280(0x08)
	enum class None IconType; // 0x288(0x01)
	char UnknownData_289[0x3]; // 0x289(0x03)
	int32_t UniqueId; // 0x28c(0x04)
	struct FMulticastInlineDelegate PingExpired; // 0x290(0x10)
	struct AActor* RepresentedActor; // 0x2a0(0x08)
	struct AKSObjectiveBase* ObjectiveActor; // 0x2a8(0x08)
	enum class MiniMapRelativeHeight CurrentRelativeHeight; // 0x2b0(0x01)

	void SetupEnemyPing(); // Function MinimapIcon.MinimapIcon_C.SetupEnemyPing // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetupAlly(); // Function MinimapIcon.MinimapIcon_C.SetupAlly // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetupLocalPlayer(); // Function MinimapIcon.MinimapIcon_C.SetupLocalPlayer // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetObjectiveIcon(); // Function MinimapIcon.MinimapIcon_C.SetObjectiveIcon // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void AllyStateChange(struct AKSPlayerState* PlayerState); // Function MinimapIcon.MinimapIcon_C.AllyStateChange // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ObjectiveUpdated(struct AKSObjectiveBase* Objective); // Function MinimapIcon.MinimapIcon_C.ObjectiveUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetRelativeHeight(enum class MiniMapRelativeHeight RelativeHeight); // Function MinimapIcon.MinimapIcon_C.SetRelativeHeight // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ResetHeightIndicators(); // Function MinimapIcon.MinimapIcon_C.ResetHeightIndicators // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnLootSiteStateChanged(struct FLootSiteState State); // Function MinimapIcon.MinimapIcon_C.OnLootSiteStateChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetupObjective(); // Function MinimapIcon.MinimapIcon_C.SetupObjective // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetupLootSite(); // Function MinimapIcon.MinimapIcon_C.SetupLootSite // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Update(); // Function MinimapIcon.MinimapIcon_C.Update // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function MinimapIcon.MinimapIcon_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_MinimapIcon(int32_t EntryPoint); // Function MinimapIcon.MinimapIcon_C.ExecuteUbergraph_MinimapIcon // (Final|UbergraphFunction) // @ game+0x2587100
	void PingExpired__DelegateSignature(int32_t UniqueId); // Function MinimapIcon.MinimapIcon_C.PingExpired__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

