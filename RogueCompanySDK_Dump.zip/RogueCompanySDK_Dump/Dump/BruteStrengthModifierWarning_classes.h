// WidgetBlueprintGeneratedClass BruteStrengthModifierWarning.BruteStrengthModifierWarning_C
// Size: 0x4f0 (Inherited: 0x4e0)
struct UBruteStrengthModifierWarning_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UImage* PerkIcon; // 0x4e8(0x08)

	void InitializeWidget(struct APUMG_HUD* HUD); // Function BruteStrengthModifierWarning.BruteStrengthModifierWarning_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnHide(); // Function BruteStrengthModifierWarning.BruteStrengthModifierWarning_C.OnHide // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnFade(); // Function BruteStrengthModifierWarning.BruteStrengthModifierWarning_C.OnFade // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_BruteStrengthModifierWarning(int32_t EntryPoint); // Function BruteStrengthModifierWarning.BruteStrengthModifierWarning_C.ExecuteUbergraph_BruteStrengthModifierWarning // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

