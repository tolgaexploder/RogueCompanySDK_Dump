// BlueprintGeneratedClass VehicleDiagram.VehicleDiagram_C
// Size: 0x28 (Inherited: 0x28)
struct UVehicleDiagram_C : UInterface {

	void SetSeating(int32_t Seat Index, struct AKSCharacter* Occupant); // Function VehicleDiagram.VehicleDiagram_C.SetSeating // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

