// AnimBlueprintGeneratedClass ABP_GAD_ZiplineDevice.ABP_GAD_ZiplineDevice_C
// Size: 0x2054 (Inherited: 0x10d0)
struct UABP_GAD_ZiplineDevice_C : UKSZiplineAnimInst {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x10d0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x10d8(0x38)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_6; // 0x1110(0x110)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_5; // 0x1220(0x110)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_4; // 0x1330(0x110)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_4; // 0x1440(0x28)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_4; // 0x1468(0x28)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_3; // 0x1490(0xa8)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4; // 0x1538(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0x15b8(0x38)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0x15f0(0xb8)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_3; // 0x16a8(0x28)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_3; // 0x16d0(0x28)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose; // 0x16f8(0xc0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose; // 0x17b8(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // 0x17e8(0x80)
	char UnknownData_1868[0x8]; // 0x1868(0x08)
	struct FAnimNode_CCDIK AnimGraphNode_CCDIK; // 0x1870(0x180)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3; // 0x19f0(0x110)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2; // 0x1b00(0xa8)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_2; // 0x1ba8(0x28)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_2; // 0x1bd0(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x1bf8(0x80)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2; // 0x1c78(0x110)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool; // 0x1d88(0xa8)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0x1e30(0x28)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // 0x1e58(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x1e80(0x80)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone; // 0x1f00(0x110)
	struct UPCM_Hero_ABP_C* HeroABP; // 0x2010(0x08)
	struct FVector Zipline IK Target Location; // 0x2018(0x0c)
	struct FVector Zipline Device Rope Pivot; // 0x2024(0x0c)
	struct FRotator Zipline IK Target Rotation; // 0x2030(0x0c)
	struct FVector L_ZiplineDevice Location; // 0x203c(0x0c)
	struct FVector R_ZiplineDevice Location; // 0x2048(0x0c)

	void AnimGraph(struct FPoseLink AnimGraph); // Function ABP_GAD_ZiplineDevice.ABP_GAD_ZiplineDevice_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_GAD_ZiplineDevice.ABP_GAD_ZiplineDevice_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_ABP_GAD_ZiplineDevice(int32_t EntryPoint); // Function ABP_GAD_ZiplineDevice.ABP_GAD_ZiplineDevice_C.ExecuteUbergraph_ABP_GAD_ZiplineDevice // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

