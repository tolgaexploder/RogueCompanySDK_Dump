// WidgetBlueprintGeneratedClass CoopTimer.CoopTimer_C
// Size: 0x58c (Inherited: 0x4e0)
struct UCoopTimer_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UWidgetAnimation* Alarm; // 0x4e8(0x08)
	struct UTextBlock* AlarmText; // 0x4f0(0x08)
	struct UImage* AllyIcon; // 0x4f8(0x08)
	struct UTextBlock* AllyScoreText; // 0x500(0x08)
	struct UHorizontalBox* HorizontalBox_1; // 0x508(0x08)
	struct UInvalidationBox* InvalidationBox_1; // 0x510(0x08)
	struct UTextBlock* Status; // 0x518(0x08)
	struct UTextBlock* Timer; // 0x520(0x08)
	bool Colors Set; // 0x528(0x01)
	char UnknownData_529[0x7]; // 0x529(0x07)
	struct TMap<int32_t, int32_t> TeamAliveCount; // 0x530(0x50)
	bool IsDisplayDirty; // 0x580(0x01)
	char UnknownData_581[0x3]; // 0x581(0x03)
	float SecondTimeout; // 0x584(0x04)
	float CurrentSecond; // 0x588(0x04)

	void UpdateMatchPointDisplay(); // Function CoopTimer.CoopTimer_C.UpdateMatchPointDisplay // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateTeamCountDisplay(); // Function CoopTimer.CoopTimer_C.UpdateTeamCountDisplay // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetRoundTimerSize(int32_t NewSize); // Function CoopTimer.CoopTimer_C.SetRoundTimerSize // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function CoopTimer.CoopTimer_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void HackInProgress(struct AKSExtractionComputer* Computer); // Function CoopTimer.CoopTimer_C.HackInProgress // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void RoundEnd(struct AKSGameState* GameState, struct FRoundResult RoundResult); // Function CoopTimer.CoopTimer_C.RoundEnd // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void RoundWarmup(struct FRoundInitState RoundInitState); // Function CoopTimer.CoopTimer_C.RoundWarmup // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void RoundStart(struct FRoundInitState RoundInitState); // Function CoopTimer.CoopTimer_C.RoundStart // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ComputersUnlock(); // Function CoopTimer.CoopTimer_C.ComputersUnlock // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function CoopTimer.CoopTimer_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Player Eliminated(struct AKSPlayerState* PlayerState); // Function CoopTimer.CoopTimer_C.Player Eliminated // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OpenRetryGameStateBind(); // Function CoopTimer.CoopTimer_C.OpenRetryGameStateBind // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void CloseRetryGameStateBind(); // Function CoopTimer.CoopTimer_C.CloseRetryGameStateBind // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void RetryGameStateBind(); // Function CoopTimer.CoopTimer_C.RetryGameStateBind // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnUIRelevantPlayerStateChanged(struct AKSPlayerState* PlayerState); // Function CoopTimer.CoopTimer_C.OnUIRelevantPlayerStateChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnGameTimerUpdate(float NewTruncatedSeconds); // Function CoopTimer.CoopTimer_C.OnGameTimerUpdate // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeTimer(); // Function CoopTimer.CoopTimer_C.InitializeTimer // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleKillCamEnabled(bool bEnabled); // Function CoopTimer.CoopTimer_C.HandleKillCamEnabled // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Unbind OnGameTimerUpdate(); // Function CoopTimer.CoopTimer_C.Unbind OnGameTimerUpdate // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleKillCamViewPawn(struct APawn* ViewedPawn); // Function CoopTimer.CoopTimer_C.HandleKillCamViewPawn // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Alarm State Changed(bool bAlarmState); // Function CoopTimer.CoopTimer_C.Handle Alarm State Changed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_CoopTimer(int32_t EntryPoint); // Function CoopTimer.CoopTimer_C.ExecuteUbergraph_CoopTimer // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

