// WidgetBlueprintGeneratedClass WBP_CosmeticItem_Title.WBP_CosmeticItem_Title_C
// Size: 0x560 (Inherited: 0x4e0)
struct UWBP_CosmeticItem_Title_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UWBP_ButtonSlot_Cosmetic_C* Button; // 0x4e8(0x08)
	struct UImage* Gradient; // 0x4f0(0x08)
	struct UBorder* RarityElementWrapper; // 0x4f8(0x08)
	struct UImage* Scanlines; // 0x500(0x08)
	struct UTextBlock* Title; // 0x508(0x08)
	struct UKSItem* KSItem; // 0x510(0x08)
	struct UPUMG_StoreItem* StoreItem; // 0x518(0x08)
	struct FMulticastInlineDelegate OnItemHovered; // 0x520(0x10)
	struct FMulticastInlineDelegate OnItemUnhovered; // 0x530(0x10)
	struct FMulticastInlineDelegate OnItemClicked; // 0x540(0x10)
	struct UAkAudioEvent* HoverTitleItemSFX; // 0x550(0x08)
	struct UAkAudioEvent* ClickTitleItemSFX; // 0x558(0x08)

	void SetTitleItemSlot(); // Function WBP_CosmeticItem_Title.WBP_CosmeticItem_Title_C.SetTitleItemSlot // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	bool NavigateConfirm(); // Function WBP_CosmeticItem_Title.WBP_CosmeticItem_Title_C.NavigateConfirm // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnHoverSound(); // Function WBP_CosmeticItem_Title.WBP_CosmeticItem_Title_C.OnHoverSound // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnClickSound(); // Function WBP_CosmeticItem_Title.WBP_CosmeticItem_Title_C.OnClickSound // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function WBP_CosmeticItem_Title.WBP_CosmeticItem_Title_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void PopulateSlot(); // Function WBP_CosmeticItem_Title.WBP_CosmeticItem_Title_C.PopulateSlot // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnTitleHover(bool IsGamepad); // Function WBP_CosmeticItem_Title.WBP_CosmeticItem_Title_C.OnTitleHover // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnTitleUnhover(); // Function WBP_CosmeticItem_Title.WBP_CosmeticItem_Title_C.OnTitleUnhover // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnTitleClick(); // Function WBP_CosmeticItem_Title.WBP_CosmeticItem_Title_C.OnTitleClick // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GamepadHover(); // Function WBP_CosmeticItem_Title.WBP_CosmeticItem_Title_C.GamepadHover // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void GamepadUnhover(); // Function WBP_CosmeticItem_Title.WBP_CosmeticItem_Title_C.GamepadUnhover // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void SetTitleActive(bool IsActive); // Function WBP_CosmeticItem_Title.WBP_CosmeticItem_Title_C.SetTitleActive // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function WBP_CosmeticItem_Title.WBP_CosmeticItem_Title_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_CosmeticItem_Title(int32_t EntryPoint); // Function WBP_CosmeticItem_Title.WBP_CosmeticItem_Title_C.ExecuteUbergraph_WBP_CosmeticItem_Title // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void OnItemClicked__DelegateSignature(struct UKSItem* KSItem, struct UWidget* Widget); // Function WBP_CosmeticItem_Title.WBP_CosmeticItem_Title_C.OnItemClicked__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnItemUnhovered__DelegateSignature(); // Function WBP_CosmeticItem_Title.WBP_CosmeticItem_Title_C.OnItemUnhovered__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnItemHovered__DelegateSignature(struct UKSItem* KSItem); // Function WBP_CosmeticItem_Title.WBP_CosmeticItem_Title_C.OnItemHovered__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

