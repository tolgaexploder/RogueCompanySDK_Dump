// WidgetBlueprintGeneratedClass ResultScreen.ResultScreen_C
// Size: 0x6d8 (Inherited: 0x528)
struct UResultScreen_C : UKSMatchResult {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x528(0x08)
	struct UWidgetAnimation* ShowScore; // 0x530(0x08)
	struct UWidgetAnimation* ShowRoundSummary; // 0x538(0x08)
	struct UImage* backshade; // 0x540(0x08)
	struct UImage* backshade_2; // 0x548(0x08)
	struct UImage* Black_7; // 0x550(0x08)
	struct UImage* Black_8; // 0x558(0x08)
	struct UImage* blackdiamond; // 0x560(0x08)
	struct UImage* blackdiamond_2; // 0x568(0x08)
	struct UImage* BlockerOverlay; // 0x570(0x08)
	struct UImage* BottomGlow; // 0x578(0x08)
	struct USizeBox* ConditionBox; // 0x580(0x08)
	struct UImage* DecoPan2; // 0x588(0x08)
	struct UImage* DecoPan2_3; // 0x590(0x08)
	struct UTextBlock* ResultCondition; // 0x598(0x08)
	struct UImage* ResultGradientBack; // 0x5a0(0x08)
	struct UOverlay* RoundScoreTracker; // 0x5a8(0x08)
	struct UOverlay* RoundStartingWrapper; // 0x5b0(0x08)
	struct UTextBlock* RoundStatusText; // 0x5b8(0x08)
	struct UVerticalBox* RoundSummary; // 0x5c0(0x08)
	struct UOverlay* RoundSummaryWrapper; // 0x5c8(0x08)
	struct UHorizontalBox* ScoreTrackerWrapper; // 0x5d0(0x08)
	struct UImage* SurrenderIcon; // 0x5d8(0x08)
	struct UTextBlock* Team1Name; // 0x5e0(0x08)
	struct UTextBlock* Team1Score; // 0x5e8(0x08)
	struct UImage* Team1ScoreBkg; // 0x5f0(0x08)
	struct USizeBox* Team1ScoreBox; // 0x5f8(0x08)
	struct UTextBlock* Team2Name; // 0x600(0x08)
	struct UTextBlock* Team2Score; // 0x608(0x08)
	struct UImage* Team2ScoreBkg; // 0x610(0x08)
	struct USizeBox* Team2ScoreBox; // 0x618(0x08)
	struct UImage* teamAdiamond; // 0x620(0x08)
	struct UImage* teamAgradient; // 0x628(0x08)
	struct UImage* teamBdiamond; // 0x630(0x08)
	struct UImage* teamBgradient; // 0x638(0x08)
	struct UTextBlock* TextBlock_1; // 0x640(0x08)
	struct UImage* TopGlow; // 0x648(0x08)
	struct UWBP_PanelDefault_C* WBP_PanelDefault; // 0x650(0x08)
	struct FMulticastInlineDelegate ReturnToHome; // 0x658(0x10)
	struct FMulticastInlineDelegate ShowHUD; // 0x668(0x10)
	struct FMulticastInlineDelegate HideHUD; // 0x678(0x10)
	struct FLinearColor pTeamColor; // 0x688(0x10)
	struct FLinearColor pOpposingTeamColor; // 0x698(0x10)
	float ShowScoreDelay; // 0x6a8(0x04)
	float ReturnToLobbyDelay; // 0x6ac(0x04)
	struct FMulticastInlineDelegate ToggleTopBar; // 0x6b0(0x10)
	bool IsPlayingRoundSummary; // 0x6c0(0x01)
	char UnknownData_6C1[0x7]; // 0x6c1(0x07)
	struct TArray<struct FName> EndRoundPhases; // 0x6c8(0x10)

	void ResetAndHandleEndOfMatch(); // Function ResultScreen.ResultScreen_C.ResetAndHandleEndOfMatch // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetColors(struct FRoundResultAnnoucement RoundResult); // Function ResultScreen.ResultScreen_C.SetColors // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ResetAnims(); // Function ResultScreen.ResultScreen_C.ResetAnims // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnRoundCycle(struct FRoundInitState RoundInitState); // Function ResultScreen.ResultScreen_C.OnRoundCycle // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ShowScreen(float DelayAmount); // Function ResultScreen.ResultScreen_C.ShowScreen // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Auto Return To Lobby(); // Function ResultScreen.ResultScreen_C.Auto Return To Lobby // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function ResultScreen.ResultScreen_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void ShowKillCamHUD(bool bEnabled); // Function ResultScreen.ResultScreen_C.ShowKillCamHUD // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ShowScoreAnim(); // Function ResultScreen.ResultScreen_C.ShowScoreAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void FailSafeReturnToLobby(); // Function ResultScreen.ResultScreen_C.FailSafeReturnToLobby // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnInitRoundSetup(); // Function ResultScreen.ResultScreen_C.OnInitRoundSetup // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandlePhaseChanged(struct FName NewPhaseName, struct FName PreviousPhaseName); // Function ResultScreen.ResultScreen_C.HandlePhaseChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleRoundInfoChanged(); // Function ResultScreen.ResultScreen_C.HandleRoundInfoChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleResultReceived(struct FRoundResultAnnoucement ResultAnnoucement); // Function ResultScreen.ResultScreen_C.HandleResultReceived // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ShowSurrenderUI(); // Function ResultScreen.ResultScreen_C.ShowSurrenderUI // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_ResultScreen(int32_t EntryPoint); // Function ResultScreen.ResultScreen_C.ExecuteUbergraph_ResultScreen // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void ToggleTopBar__DelegateSignature(bool ShouldShow); // Function ResultScreen.ResultScreen_C.ToggleTopBar__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HideHUD__DelegateSignature(); // Function ResultScreen.ResultScreen_C.HideHUD__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ShowHUD__DelegateSignature(); // Function ResultScreen.ResultScreen_C.ShowHUD__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ReturnToHome__DelegateSignature(); // Function ResultScreen.ResultScreen_C.ReturnToHome__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

