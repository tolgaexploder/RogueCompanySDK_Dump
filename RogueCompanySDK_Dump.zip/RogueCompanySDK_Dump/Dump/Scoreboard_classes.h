// WidgetBlueprintGeneratedClass Scoreboard.Scoreboard_C
// Size: 0x668 (Inherited: 0x550)
struct UScoreboard_C : UKSVoiceActivityWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x550(0x08)
	struct UTextBlock* AbilityDesc; // 0x558(0x08)
	struct UWBP_AsyncIcon_C* AbilityIcon; // 0x560(0x08)
	struct UTextBlock* AbilityName; // 0x568(0x08)
	struct UHorizontalBox* AbilityWrapper; // 0x570(0x08)
	struct UHorizontalBox* BackPrompt; // 0x578(0x08)
	struct UWBP_InputCallout_C* BackPromptCallout; // 0x580(0x08)
	struct UHorizontalBox* FocusPlayersPrompt; // 0x588(0x08)
	struct UWBP_InputCallout_C* FocusPlayersPromptCallout; // 0x590(0x08)
	struct UOverlay* FriendlySlot; // 0x598(0x08)
	struct UHorizontalBox* GamepadCalloutsHorizontalBox; // 0x5a0(0x08)
	struct UTextBlock* PassiveDesc; // 0x5a8(0x08)
	struct UWBP_AsyncIcon_C* PassiveIcon; // 0x5b0(0x08)
	struct UTextBlock* PassiveName; // 0x5b8(0x08)
	struct UHorizontalBox* PassiveWrapper; // 0x5c0(0x08)
	struct UBorder* PortraitStroke; // 0x5c8(0x08)
	struct UBorder* PortraitStroke_2; // 0x5d0(0x08)
	struct UOverlay* RogueInfo; // 0x5d8(0x08)
	struct UHorizontalBox* RogueInfoWrapper; // 0x5e0(0x08)
	struct UTextBlock* RogueName; // 0x5e8(0x08)
	struct UWBP_AsyncIcon_C* RoguePortrait; // 0x5f0(0x08)
	struct UVerticalBox* ScoreBox; // 0x5f8(0x08)
	struct UHorizontalBox* SelectPrompt; // 0x600(0x08)
	struct UWBP_InputCallout_C* SelectPromptCallout; // 0x608(0x08)
	struct TArray<struct UScoreboardTeamSection_C*> TeamSections; // 0x610(0x10)
	struct FMulticastInlineDelegate Opened; // 0x620(0x10)
	struct FMulticastInlineDelegate Closed; // 0x630(0x10)
	bool NewPlayersLoaded; // 0x640(0x01)
	char UnknownData_641[0x7]; // 0x641(0x07)
	struct FMulticastInlineDelegate ScoreboardTabPress; // 0x648(0x10)
	struct FMulticastInlineDelegate OnScoreboardEntryAdded; // 0x658(0x10)

	void Set Gamepad Focus Group(bool Focused); // Function Scoreboard.Scoreboard_C.Set Gamepad Focus Group // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UnhoverPlayerEntries(); // Function Scoreboard.Scoreboard_C.UnhoverPlayerEntries // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleInputModeChanged(enum class PGAME_INPUT_STATE InputState); // Function Scoreboard.Scoreboard_C.HandleInputModeChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GetLocalPlayerJobInfo(bool JobFound, struct UKSJobItem* JobItem); // Function Scoreboard.Scoreboard_C.GetLocalPlayerJobInfo // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void UpdateRogueInfo(); // Function Scoreboard.Scoreboard_C.UpdateRogueInfo // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GetPlayerData(struct TArray<struct UKSPersistentPlayerData*> OutPlayerData); // Function Scoreboard.Scoreboard_C.GetPlayerData // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GetPlayersForTeamSection(struct UScoreboardTeamSection_C* TeamSection, struct TArray<struct UScoreboardPlayerEntry_C*> PlayerButtons); // Function Scoreboard.Scoreboard_C.GetPlayersForTeamSection // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	bool NavigateBack(); // Function Scoreboard.Scoreboard_C.NavigateBack // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GetPlayers(bool PrioritizeAllyTeam, struct TArray<struct UScoreboardPlayerEntry_C*> Players); // Function Scoreboard.Scoreboard_C.GetPlayers // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void UpdateTeamColors(); // Function Scoreboard.Scoreboard_C.UpdateTeamColors // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SortKSPlayerStatesByMoney(struct TArray<struct UKSPersistentPlayerData*> InKSPlayerData, bool DescOrder, struct TArray<struct UKSPersistentPlayerData*> OutKSPlayerData); // Function Scoreboard.Scoreboard_C.SortKSPlayerStatesByMoney // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Get KSPlayer Data(struct TArray<struct UKSPersistentPlayerData*> KSPlayerData); // Function Scoreboard.Scoreboard_C.Get KSPlayer Data // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ComparePlayerScore(struct AKSPlayerState* PlayerStateA, struct AKSPlayerState* PlayerStateB, bool After); // Function Scoreboard.Scoreboard_C.ComparePlayerScore // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateScores(); // Function Scoreboard.Scoreboard_C.UpdateScores // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnLoaded_4848F73A412C50823EB015A4F7EF3736(struct UObject* Loaded); // Function Scoreboard.Scoreboard_C.OnLoaded_4848F73A412C50823EB015A4F7EF3736 // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function Scoreboard.Scoreboard_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void UpdateScoreboard(); // Function Scoreboard.Scoreboard_C.UpdateScoreboard // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleOnScoreboardEntryAdded(); // Function Scoreboard.Scoreboard_C.HandleOnScoreboardEntryAdded // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function Scoreboard.Scoreboard_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnShown(); // Function Scoreboard.Scoreboard_C.OnShown // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void LoadAndPopulateFirstPassive(struct TSoftObjectPtr<struct UObject> Asset); // Function Scoreboard.Scoreboard_C.LoadAndPopulateFirstPassive // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_Scoreboard(int32_t EntryPoint); // Function Scoreboard.Scoreboard_C.ExecuteUbergraph_Scoreboard // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void OnScoreboardEntryAdded__DelegateSignature(); // Function Scoreboard.Scoreboard_C.OnScoreboardEntryAdded__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ScoreboardTabPress__DelegateSignature(); // Function Scoreboard.Scoreboard_C.ScoreboardTabPress__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Closed__DelegateSignature(); // Function Scoreboard.Scoreboard_C.Closed__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Opened__DelegateSignature(); // Function Scoreboard.Scoreboard_C.Opened__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

