// WidgetBlueprintGeneratedClass WBP_BoosterInventoryItem.WBP_BoosterInventoryItem_C
// Size: 0x548 (Inherited: 0x4f0)
struct UWBP_BoosterInventoryItem_C : UKSBoostInventoryItemWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4f0(0x08)
	struct UWBP_AsyncIcon_C* BoostItemIcon; // 0x4f8(0x08)
	struct UImage* DecroLine; // 0x500(0x08)
	struct UTextBlock* DescText; // 0x508(0x08)
	struct UImage* DescTextBg; // 0x510(0x08)
	struct UTextBlock* QuantityText; // 0x518(0x08)
	struct UTextBlock* TitleText; // 0x520(0x08)
	struct UImage* TitleTextBg; // 0x528(0x08)
	struct UWBP_ButtonSlot_Cosmetic_C* WBP_ButtonSlot_Cosmetic; // 0x530(0x08)
	struct UKSItem* Current Item Old; // 0x538(0x08)
	struct UAkAudioEvent* BoostConfirmSound; // 0x540(0x08)

	bool NavigateConfirm(); // Function WBP_BoosterInventoryItem.WBP_BoosterInventoryItem_C.NavigateConfirm // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function WBP_BoosterInventoryItem.WBP_BoosterInventoryItem_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void GamepadHover(); // Function WBP_BoosterInventoryItem.WBP_BoosterInventoryItem_C.GamepadHover // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void GamepadUnhover(); // Function WBP_BoosterInventoryItem.WBP_BoosterInventoryItem_C.GamepadUnhover // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void BndEvt__WBP_ButtonSlot_Cosmetic_K2Node_ComponentBoundEvent_0_OnBtnClicked__DelegateSignature(); // Function WBP_BoosterInventoryItem.WBP_BoosterInventoryItem_C.BndEvt__WBP_ButtonSlot_Cosmetic_K2Node_ComponentBoundEvent_0_OnBtnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void View_SetFromItem(struct FAccountConsumableDetails ItemDetails); // Function WBP_BoosterInventoryItem.WBP_BoosterInventoryItem_C.View_SetFromItem // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void PlayBoostConfirmationSound(); // Function WBP_BoosterInventoryItem.WBP_BoosterInventoryItem_C.PlayBoostConfirmationSound // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_BoosterInventoryItem(int32_t EntryPoint); // Function WBP_BoosterInventoryItem.WBP_BoosterInventoryItem_C.ExecuteUbergraph_WBP_BoosterInventoryItem // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

