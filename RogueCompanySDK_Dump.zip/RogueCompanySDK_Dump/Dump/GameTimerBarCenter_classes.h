// WidgetBlueprintGeneratedClass GameTimerBarCenter.GameTimerBarCenter_C
// Size: 0x5d9 (Inherited: 0x4e0)
struct UGameTimerBarCenter_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UWidgetAnimation* attention_anim; // 0x4e8(0x08)
	struct UWidgetAnimation* GameClockWarning; // 0x4f0(0x08)
	struct UWidgetAnimation* GameClockUrgent; // 0x4f8(0x08)
	struct UWidgetAnimation* GameClockPulse; // 0x500(0x08)
	struct UWidgetAnimation* FlipAnim; // 0x508(0x08)
	struct UImage* BombIcon; // 0x510(0x08)
	struct UWidgetSwitcher* CenterTimer; // 0x518(0x08)
	struct UImage* ChevronBottomLeft_2; // 0x520(0x08)
	struct UImage* ChevronBottomRight_2; // 0x528(0x08)
	struct UOverlay* ChevronGroup_2; // 0x530(0x08)
	struct USizeBox* Chevrons_2; // 0x538(0x08)
	struct UImage* ChevronTopLeft_2; // 0x540(0x08)
	struct UImage* ChevronTopRight_2; // 0x548(0x08)
	struct UTextBlock* CircleText; // 0x550(0x08)
	struct UImage* FillInner; // 0x558(0x08)
	struct UImage* FillOuter; // 0x560(0x08)
	struct UImage* InnerStroke; // 0x568(0x08)
	struct UWidgetSwitcher* LabelSwitcher; // 0x570(0x08)
	struct UTextBlock* LowerText; // 0x578(0x08)
	struct UNamedSlot* MiddleSlot; // 0x580(0x08)
	struct UImage* ObjBackShade_2; // 0x588(0x08)
	struct UTextBlock* ObjectiveTimer; // 0x590(0x08)
	struct USizeBox* ObjectiveTimerGroup; // 0x598(0x08)
	struct UBorder* ObjectiveTimerGroup_InnerContainer; // 0x5a0(0x08)
	struct UImage* Swords_2; // 0x5a8(0x08)
	struct UImage* TeamColorBG; // 0x5b0(0x08)
	float CountdownTimeLeft; // 0x5b8(0x04)
	float CountdownTimeLeftMax; // 0x5bc(0x04)
	float HackTimeLeft; // 0x5c0(0x04)
	float HackTimeLeftMax; // 0x5c4(0x04)
	enum class GameTimerBarCenterState Current Objective State; // 0x5c8(0x01)
	bool Bomb Timer is Reset; // 0x5c9(0x01)
	char UnknownData_5CA[0x2]; // 0x5ca(0x02)
	float Bomb Timer Max; // 0x5cc(0x04)
	struct FName CurrentPhase; // 0x5d0(0x08)
	bool UseObjectiveTimer; // 0x5d8(0x01)

	void HandleGameObjectiveUnregistered(struct TScriptInterface<None> GameObjective); // Function GameTimerBarCenter.GameTimerBarCenter_C.HandleGameObjectiveUnregistered // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleGameObjectiveRegistered(struct TScriptInterface<None> GameObjective); // Function GameTimerBarCenter.GameTimerBarCenter_C.HandleGameObjectiveRegistered // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleObjectiveTimerTick(struct TScriptInterface<None> GameObjective, float Time); // Function GameTimerBarCenter.GameTimerBarCenter_C.HandleObjectiveTimerTick // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleGameObjectiveStateChanged(struct TScriptInterface<None> GameObjective); // Function GameTimerBarCenter.GameTimerBarCenter_C.HandleGameObjectiveStateChanged // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleBombStateTimerTick(float Seconds); // Function GameTimerBarCenter.GameTimerBarCenter_C.HandleBombStateTimerTick // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleBombStateTimerActive(bool Active); // Function GameTimerBarCenter.GameTimerBarCenter_C.HandleBombStateTimerActive // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BindGameStateEvents(); // Function GameTimerBarCenter.GameTimerBarCenter_C.BindGameStateEvents // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetShouldUseBombTimer(bool UseBombTimer); // Function GameTimerBarCenter.GameTimerBarCenter_C.SetShouldUseBombTimer // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetContestedState(bool bIsContested); // Function GameTimerBarCenter.GameTimerBarCenter_C.SetContestedState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PlayScoreAnim(); // Function GameTimerBarCenter.GameTimerBarCenter_C.PlayScoreAnim // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetCurrentPhase(struct FName PhaseName); // Function GameTimerBarCenter.GameTimerBarCenter_C.SetCurrentPhase // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ResetCenterTextStyle(); // Function GameTimerBarCenter.GameTimerBarCenter_C.ResetCenterTextStyle // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ResetCenter(); // Function GameTimerBarCenter.GameTimerBarCenter_C.ResetCenter // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetRoundTimers(float Time); // Function GameTimerBarCenter.GameTimerBarCenter_C.SetRoundTimers // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Update Bomb Timer Seconds(float Seconds); // Function GameTimerBarCenter.GameTimerBarCenter_C.Update Bomb Timer Seconds // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Reset Bomb Timer(); // Function GameTimerBarCenter.GameTimerBarCenter_C.Reset Bomb Timer // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Set Hack Seconds(float HackTimeLeft); // Function GameTimerBarCenter.GameTimerBarCenter_C.Set Hack Seconds // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Set Countdown Seconds(float CountdownTimeLeft, float CountdownTimeTotal); // Function GameTimerBarCenter.GameTimerBarCenter_C.Set Countdown Seconds // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Set View By Objective State(enum class GameTimerBarCenterState Center State); // Function GameTimerBarCenter.GameTimerBarCenter_C.Set View By Objective State // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PreConstruct(bool IsDesignTime); // Function GameTimerBarCenter.GameTimerBarCenter_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function GameTimerBarCenter.GameTimerBarCenter_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void PlayFlipTime(); // Function GameTimerBarCenter.GameTimerBarCenter_C.PlayFlipTime // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetProgress(float Progress); // Function GameTimerBarCenter.GameTimerBarCenter_C.SetProgress // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetTeamProgress(float Progress); // Function GameTimerBarCenter.GameTimerBarCenter_C.SetTeamProgress // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function GameTimerBarCenter.GameTimerBarCenter_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Tick Countdown Time(float DeltaTime); // Function GameTimerBarCenter.GameTimerBarCenter_C.Tick Countdown Time // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Circle Progress Close(); // Function GameTimerBarCenter.GameTimerBarCenter_C.Circle Progress Close // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Circle Progress Open(); // Function GameTimerBarCenter.GameTimerBarCenter_C.Circle Progress Open // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_GameTimerBarCenter(int32_t EntryPoint); // Function GameTimerBarCenter.GameTimerBarCenter_C.ExecuteUbergraph_GameTimerBarCenter // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

