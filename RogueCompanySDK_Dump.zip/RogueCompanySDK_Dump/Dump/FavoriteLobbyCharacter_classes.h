// BlueprintGeneratedClass FavoriteLobbyCharacter.FavoriteLobbyCharacter_C
// Size: 0x3768 (Inherited: 0x3741)
struct AFavoriteLobbyCharacter_C : ALobbyMainCharacter_C {
	char UnknownData_3741[0x7]; // 0x3741(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3748(0x08)
	struct UWidgetComponent* WidgetNameplate; // 0x3750(0x08)
	bool NeedsToSetNameplate; // 0x3758(0x01)
	char UnknownData_3759[0x7]; // 0x3759(0x07)
	struct UKSPlayerInfo* PendingPlayerInfo; // 0x3760(0x08)

	void SetLobbyNameplate(struct UKSPlayerInfo* playerinfo); // Function FavoriteLobbyCharacter.FavoriteLobbyCharacter_C.SetLobbyNameplate // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void HideLobbyNameplate(); // Function FavoriteLobbyCharacter.FavoriteLobbyCharacter_C.HideLobbyNameplate // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ShowLobbyNameplate(); // Function FavoriteLobbyCharacter.FavoriteLobbyCharacter_C.ShowLobbyNameplate // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ReceiveTick(float DeltaSeconds); // Function FavoriteLobbyCharacter.FavoriteLobbyCharacter_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_FavoriteLobbyCharacter(int32_t EntryPoint); // Function FavoriteLobbyCharacter.FavoriteLobbyCharacter_C.ExecuteUbergraph_FavoriteLobbyCharacter // (Final|UbergraphFunction) // @ game+0x2587100
};

