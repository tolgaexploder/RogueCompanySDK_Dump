// WidgetBlueprintGeneratedClass WBP_Context_Bar.WBP_Context_Bar_C
// Size: 0x590 (Inherited: 0x558)
struct UWBP_Context_Bar_C : UKSContextBarWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x558(0x08)
	struct UHorizontalBox* CenterPromptsContainer; // 0x560(0x08)
	struct UImage* FooterBG; // 0x568(0x08)
	struct UHorizontalBox* LeftPromptsContainer; // 0x570(0x08)
	struct UHorizontalBox* RightPromptsContainer; // 0x578(0x08)
	enum class PGAME_INPUT_STATE CurrentInputState; // 0x580(0x01)
	char UnknownData_581[0x7]; // 0x581(0x07)
	struct UDataTable* ViewTable; // 0x588(0x08)

	void RefreshContextButtons(struct TArray<struct UContextActionData*> ContextActions, bool AlwaysShow); // Function WBP_Context_Bar.WBP_Context_Bar_C.RefreshContextButtons // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleInputStateChange(enum class PGAME_INPUT_STATE CurrentInputState); // Function WBP_Context_Bar.WBP_Context_Bar_C.HandleInputStateChange // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	bool CanCloseOnLogout(); // Function WBP_Context_Bar.WBP_Context_Bar_C.CanCloseOnLogout // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function WBP_Context_Bar.WBP_Context_Bar_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateContextActions(struct TArray<struct UContextActionData*> ContextActions, struct FName CurrentRoute); // Function WBP_Context_Bar.WBP_Context_Bar_C.UpdateContextActions // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_Context_Bar(int32_t EntryPoint); // Function WBP_Context_Bar.WBP_Context_Bar_C.ExecuteUbergraph_WBP_Context_Bar // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

