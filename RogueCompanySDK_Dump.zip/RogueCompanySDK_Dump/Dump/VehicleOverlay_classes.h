// WidgetBlueprintGeneratedClass VehicleOverlay.VehicleOverlay_C
// Size: 0x5b8 (Inherited: 0x510)
struct UVehicleOverlay_C : UKSViewedPawnWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x510(0x08)
	struct UOverlay* DiagramContainer; // 0x518(0x08)
	struct UImage* RevealCone; // 0x520(0x08)
	struct UVehicleHealth_C* VehicleHealth; // 0x528(0x08)
	struct UVehicleSpeedometer_C* VehicleSpeedometer; // 0x530(0x08)
	struct AKSVehicle* Vehicle; // 0x538(0x08)
	struct TScriptInterface<None> Diagram; // 0x540(0x10)
	struct TMap<struct UKSVehicleSeatComponent*, struct AKSCharacter*> VehicleSeatMap; // 0x550(0x50)
	bool VehicleSeats; // 0x5a0(0x01)
	char UnknownData_5A1[0x7]; // 0x5a1(0x07)
	struct FMulticastInlineDelegate Vehicle State Changed; // 0x5a8(0x10)

	void UpdateRevealConeReticle(); // Function VehicleOverlay.VehicleOverlay_C.UpdateRevealConeReticle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetVehicle(struct AKSVehicle* Vehicle); // Function VehicleOverlay.VehicleOverlay_C.SetVehicle // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UnsetVehicle(); // Function VehicleOverlay.VehicleOverlay_C.UnsetVehicle // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function VehicleOverlay.VehicleOverlay_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function VehicleOverlay.VehicleOverlay_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ModeChange(enum class PGAME_INPUT_STATE InputState); // Function VehicleOverlay.VehicleOverlay_C.ModeChange // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PostSetPawn(); // Function VehicleOverlay.VehicleOverlay_C.PostSetPawn // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void PreClearPawn(); // Function VehicleOverlay.VehicleOverlay_C.PreClearPawn // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void Handle Vehicle State Changed(); // Function VehicleOverlay.VehicleOverlay_C.Handle Vehicle State Changed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleVehicleHealthChanged(float CurrentHealth); // Function VehicleOverlay.VehicleOverlay_C.HandleVehicleHealthChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleVehicleSeatingChanged(); // Function VehicleOverlay.VehicleOverlay_C.HandleVehicleSeatingChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_VehicleOverlay(int32_t EntryPoint); // Function VehicleOverlay.VehicleOverlay_C.ExecuteUbergraph_VehicleOverlay // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void Vehicle State Changed__DelegateSignature(bool InVehicle); // Function VehicleOverlay.VehicleOverlay_C.Vehicle State Changed__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

