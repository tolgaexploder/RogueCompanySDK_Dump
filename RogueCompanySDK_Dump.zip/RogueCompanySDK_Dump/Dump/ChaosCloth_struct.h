// Enum ChaosCloth.EChaosWeightMapTarget
enum class EChaosWeightMapTarget : uint8 {
	None,
	MaxDistance,
	BackstopDistance,
	BackstopRadius,
	AnimDriveMultiplier,
	EChaosWeightMapTarget_MAX,
};

