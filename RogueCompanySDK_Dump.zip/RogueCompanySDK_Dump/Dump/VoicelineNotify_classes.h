// BlueprintGeneratedClass VoicelineNotify.VoicelineNotify_C
// Size: 0x68 (Inherited: 0x38)
struct UVoicelineNotify_C : UAnimNotify {
	struct FKSVoicelineEvent Voiceline; // 0x38(0x30)

	struct FString GetNotifyName(); // Function VoicelineNotify.VoicelineNotify_C.GetNotifyName // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x2587100
	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function VoicelineNotify.VoicelineNotify_C.Received_Notify // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x2587100
};

