// WidgetBlueprintGeneratedClass ExpElement.ExpElement_C
// Size: 0x2a8 (Inherited: 0x238)
struct UExpElement_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UWidgetAnimation* FadeOut; // 0x240(0x08)
	struct UWidgetAnimation* SlideIn; // 0x248(0x08)
	struct UTextBlock* Amount; // 0x250(0x08)
	struct USizeBox* ExpElementWrapper; // 0x258(0x08)
	struct UImage* Image_119; // 0x260(0x08)
	struct UTextBlock* Reason; // 0x268(0x08)
	int32_t XP; // 0x270(0x04)
	char UnknownData_274[0x4]; // 0x274(0x04)
	struct FText Text; // 0x278(0x18)
	float SitTime; // 0x290(0x04)
	bool IsBonusXP; // 0x294(0x01)
	char UnknownData_295[0x3]; // 0x295(0x03)
	struct FMulticastInlineDelegate OnAnimFinished; // 0x298(0x10)

	void Construct(); // Function ExpElement.ExpElement_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void WidgetAnimationEvt_SlideIn_K2Node_WidgetAnimationEvent_1(); // Function ExpElement.ExpElement_C.WidgetAnimationEvt_SlideIn_K2Node_WidgetAnimationEvent_1 // (BlueprintEvent) // @ game+0x2587100
	void WidgetAnimationEvt_FadeOut_K2Node_WidgetAnimationEvent_2(); // Function ExpElement.ExpElement_C.WidgetAnimationEvt_FadeOut_K2Node_WidgetAnimationEvent_2 // (BlueprintEvent) // @ game+0x2587100
	void HandleAnimFinished(); // Function ExpElement.ExpElement_C.HandleAnimFinished // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_ExpElement(int32_t EntryPoint); // Function ExpElement.ExpElement_C.ExecuteUbergraph_ExpElement // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void OnAnimFinished__DelegateSignature(); // Function ExpElement.ExpElement_C.OnAnimFinished__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

