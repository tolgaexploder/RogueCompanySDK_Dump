// WidgetBlueprintGeneratedClass WBP_Challenge_Panel.WBP_Challenge_Panel_C
// Size: 0x528 (Inherited: 0x4e0)
struct UWBP_Challenge_Panel_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UWBP_Challenge_Renderer_C* Challenge0; // 0x4e8(0x08)
	struct UWBP_Challenge_Renderer_C* Challenge1; // 0x4f0(0x08)
	struct UWBP_Challenge_Renderer_C* Challenge2; // 0x4f8(0x08)
	struct UVerticalBox* ContractsDisplay; // 0x500(0x08)
	struct UCanvasPanel* WaitingForChallenges; // 0x508(0x08)
	struct TArray<struct UWBP_Challenge_Renderer_C*> ChallengeRenderers; // 0x510(0x10)
	struct FName SceneOwner; // 0x520(0x08)

	void DisplayRerollPrompt(bool Show); // Function WBP_Challenge_Panel.WBP_Challenge_Panel_C.DisplayRerollPrompt // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GetNavigationWidgets(struct TArray<struct UPUMG_Widget*> Widgets); // Function WBP_Challenge_Panel.WBP_Challenge_Panel_C.GetNavigationWidgets // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PopulateChallenges(); // Function WBP_Challenge_Panel.WBP_Challenge_Panel_C.PopulateChallenges // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PreConstruct(bool IsDesignTime); // Function WBP_Challenge_Panel.WBP_Challenge_Panel_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function WBP_Challenge_Panel.WBP_Challenge_Panel_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_Challenge_Panel(int32_t EntryPoint); // Function WBP_Challenge_Panel.WBP_Challenge_Panel_C.ExecuteUbergraph_WBP_Challenge_Panel // (Final|UbergraphFunction) // @ game+0x2587100
};

