// WidgetBlueprintGeneratedClass CINE_Walkin_Widget.CINE_Walkin_Widget_C
// Size: 0x2e0 (Inherited: 0x238)
struct UCINE_Walkin_Widget_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UWidgetAnimation* DisplayPlayerInformation_SlamIn_Player02; // 0x240(0x08)
	struct UWidgetAnimation* DisplayPlayerInformation_SlamIn_Short; // 0x248(0x08)
	struct UWidgetAnimation* SetAnchors_BottomRight; // 0x250(0x08)
	struct UWidgetAnimation* SetAnchors_BottomLeft; // 0x258(0x08)
	struct UWidgetAnimation* SetAnchors_TopRight; // 0x260(0x08)
	struct UWidgetAnimation* SetAnchors_TopLeft; // 0x268(0x08)
	struct UWidgetAnimation* DisplayPlayerInformation_SlamIn_Player01; // 0x270(0x08)
	struct UImage* Image_413; // 0x278(0x08)
	struct UWBP_AsyncIcon_C* JobFlatIcon; // 0x280(0x08)
	struct UWBP_AsyncIcon_C* JobFlatIconShadow; // 0x288(0x08)
	struct UTextBlock* JobName; // 0x290(0x08)
	struct UTextBlock* PlayerName; // 0x298(0x08)
	struct UImage* SheenWipe; // 0x2a0(0x08)
	struct UCanvasPanel* WalkinDisplay; // 0x2a8(0x08)
	struct UWBP_PlayerIdentity_Full_C* WBP_PlayerIdentity_Full; // 0x2b0(0x08)
	struct UWBP_RogueMasteryPortrait_C* WBP_RogueMasteryPortrait; // 0x2b8(0x08)
	struct AKSJobSelectPreviewActor* Player01; // 0x2c0(0x08)
	struct AKSJobSelectPreviewActor* Player02; // 0x2c8(0x08)
	struct AKSJobSelectPreviewActor* Player03; // 0x2d0(0x08)
	struct AKSJobSelectPreviewActor* Player04; // 0x2d8(0x08)

	void SetPlayerData(struct UKSPersistentPlayerData* PlayerData, bool IsValid); // Function CINE_Walkin_Widget.CINE_Walkin_Widget_C.SetPlayerData // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Set Player Blueprint References(struct AKSJobSelectPreviewActor* Player01, struct AKSJobSelectPreviewActor* Player02, struct AKSJobSelectPreviewActor* Player03, struct AKSJobSelectPreviewActor* Player04); // Function CINE_Walkin_Widget.CINE_Walkin_Widget_C.Set Player Blueprint References // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function CINE_Walkin_Widget.CINE_Walkin_Widget_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Anim_Player01(); // Function CINE_Walkin_Widget.CINE_Walkin_Widget_C.Anim_Player01 // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Anim_Player02(); // Function CINE_Walkin_Widget.CINE_Walkin_Widget_C.Anim_Player02 // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Anim_Player03(); // Function CINE_Walkin_Widget.CINE_Walkin_Widget_C.Anim_Player03 // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Anim_Player04(); // Function CINE_Walkin_Widget.CINE_Walkin_Widget_C.Anim_Player04 // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_CINE_Walkin_Widget(int32_t EntryPoint); // Function CINE_Walkin_Widget.CINE_Walkin_Widget_C.ExecuteUbergraph_CINE_Walkin_Widget // (Final|UbergraphFunction) // @ game+0x2587100
};

