// WidgetBlueprintGeneratedClass GameTouchHUDWidget.GameTouchHUDWidget_C
// Size: 0x53a (Inherited: 0x4e0)
struct UGameTouchHUDWidget_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UButton* BtnAbility; // 0x4e8(0x08)
	struct UButton* BtnGrenade; // 0x4f0(0x08)
	struct UButton* BtnInteract; // 0x4f8(0x08)
	struct UButton* BtnScoreboard; // 0x500(0x08)
	struct UButton* BtnStore; // 0x508(0x08)
	struct UButton* BtnWeaponSwap; // 0x510(0x08)
	struct UTextBlock* LblGrenadeRelease; // 0x518(0x08)
	struct UImage* LeftStickDir; // 0x520(0x08)
	struct UImage* LeftStickOrigin; // 0x528(0x08)
	struct UButton* OpenMapButton; // 0x530(0x08)
	bool IsGrenadeActive; // 0x538(0x01)
	bool IsReviveTextSet; // 0x539(0x01)

	void TriggerInputAction(struct FName InActionName, enum class EInputEvent InInputEvent); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.TriggerInputAction // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GetWidgetBounds(struct UWidget* Widget, struct FVector2D TopLeft, struct FVector2D BottomRight); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.GetWidgetBounds // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void IsPointOverWidget(struct FVector2D ScreenPoint, struct UWidget* Widget, bool IsPointOverWidget); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.IsPointOverWidget // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void BndEvt__BtnAbility_K2Node_ComponentBoundEvent_2_OnButtonPressedEvent__DelegateSignature(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.BndEvt__BtnAbility_K2Node_ComponentBoundEvent_2_OnButtonPressedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__BtnAbility_K2Node_ComponentBoundEvent_3_OnButtonReleasedEvent__DelegateSignature(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.BndEvt__BtnAbility_K2Node_ComponentBoundEvent_3_OnButtonReleasedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__BtnWeaponSwap_K2Node_ComponentBoundEvent_4_OnButtonPressedEvent__DelegateSignature(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.BndEvt__BtnWeaponSwap_K2Node_ComponentBoundEvent_4_OnButtonPressedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__BtnWeaponSwap_K2Node_ComponentBoundEvent_5_OnButtonReleasedEvent__DelegateSignature(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.BndEvt__BtnWeaponSwap_K2Node_ComponentBoundEvent_5_OnButtonReleasedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__BtnStore_K2Node_ComponentBoundEvent_12_OnButtonPressedEvent__DelegateSignature(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.BndEvt__BtnStore_K2Node_ComponentBoundEvent_12_OnButtonPressedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__BtnStore_K2Node_ComponentBoundEvent_13_OnButtonReleasedEvent__DelegateSignature(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.BndEvt__BtnStore_K2Node_ComponentBoundEvent_13_OnButtonReleasedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__BtnScoreboard_K2Node_ComponentBoundEvent_14_OnButtonPressedEvent__DelegateSignature(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.BndEvt__BtnScoreboard_K2Node_ComponentBoundEvent_14_OnButtonPressedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__BtnMenu_K2Node_ComponentBoundEvent_16_OnButtonPressedEvent__DelegateSignature(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.BndEvt__BtnMenu_K2Node_ComponentBoundEvent_16_OnButtonPressedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__BtnMenu_K2Node_ComponentBoundEvent_17_OnButtonReleasedEvent__DelegateSignature(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.BndEvt__BtnMenu_K2Node_ComponentBoundEvent_17_OnButtonReleasedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void OnHoveredInteractableChanged_Event_1(struct AActor* HoverTarget); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.OnHoveredInteractableChanged_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BndEvt__BtnInteract_K2Node_ComponentBoundEvent_6_OnButtonPressedEvent__DelegateSignature(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.BndEvt__BtnInteract_K2Node_ComponentBoundEvent_6_OnButtonPressedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__BtnInteract_K2Node_ComponentBoundEvent_7_OnButtonReleasedEvent__DelegateSignature(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.BndEvt__BtnInteract_K2Node_ComponentBoundEvent_7_OnButtonReleasedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void OnInputStateChanged_Event_1(enum class PGAME_INPUT_STATE InputState); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.OnInputStateChanged_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BndEvt__OpenMapButton_K2Node_ComponentBoundEvent_0_OnButtonPressedEvent__DelegateSignature(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.BndEvt__OpenMapButton_K2Node_ComponentBoundEvent_0_OnButtonPressedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_GameTouchHUDWidget(int32_t EntryPoint); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.ExecuteUbergraph_GameTouchHUDWidget // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

