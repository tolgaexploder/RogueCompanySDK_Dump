// WidgetBlueprintGeneratedClass WBP_ButtonArrow.WBP_ButtonArrow_C
// Size: 0x53a (Inherited: 0x4e0)
struct UWBP_ButtonArrow_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UWidgetAnimation* hoveranim; // 0x4e8(0x08)
	struct UImage* background; // 0x4f0(0x08)
	struct UImage* Highlight; // 0x4f8(0x08)
	struct UButton* HitTarget; // 0x500(0x08)
	struct FMulticastInlineDelegate OnBtnClicked; // 0x508(0x10)
	struct FMulticastInlineDelegate OnBtnHovered; // 0x518(0x10)
	struct FMulticastInlineDelegate OnBtnUnhovered; // 0x528(0x10)
	bool bIsDisable; // 0x538(0x01)
	bool bIsActive; // 0x539(0x01)

	void OnHoveredLogic(bool IsGamepad); // Function WBP_ButtonArrow.WBP_ButtonArrow_C.OnHoveredLogic // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	bool NavigateConfirm(); // Function WBP_ButtonArrow.WBP_ButtonArrow_C.NavigateConfirm // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnClickSound(); // Function WBP_ButtonArrow.WBP_ButtonArrow_C.OnClickSound // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnHoverSound(); // Function WBP_ButtonArrow.WBP_ButtonArrow_C.OnHoverSound // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function WBP_ButtonArrow.WBP_ButtonArrow_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnGamepadConfirmed(); // Function WBP_ButtonArrow.WBP_ButtonArrow_C.OnGamepadConfirmed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_ButtonArrow.WBP_ButtonArrow_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function WBP_ButtonArrow.WBP_ButtonArrow_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature(); // Function WBP_ButtonArrow.WBP_ButtonArrow_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void GamepadHover(); // Function WBP_ButtonArrow.WBP_ButtonArrow_C.GamepadHover // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void GamepadUnhover(); // Function WBP_ButtonArrow.WBP_ButtonArrow_C.GamepadUnhover // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void DisableButton(bool bShouldDisable); // Function WBP_ButtonArrow.WBP_ButtonArrow_C.DisableButton // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void CallButtonHover(); // Function WBP_ButtonArrow.WBP_ButtonArrow_C.CallButtonHover // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void CallButtonUnhover(); // Function WBP_ButtonArrow.WBP_ButtonArrow_C.CallButtonUnhover // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PreConstruct(bool IsDesignTime); // Function WBP_ButtonArrow.WBP_ButtonArrow_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_ButtonArrow(int32_t EntryPoint); // Function WBP_ButtonArrow.WBP_ButtonArrow_C.ExecuteUbergraph_WBP_ButtonArrow // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void OnBtnUnhovered__DelegateSignature(); // Function WBP_ButtonArrow.WBP_ButtonArrow_C.OnBtnUnhovered__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnBtnHovered__DelegateSignature(bool IsGamepad); // Function WBP_ButtonArrow.WBP_ButtonArrow_C.OnBtnHovered__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnBtnClicked__DelegateSignature(); // Function WBP_ButtonArrow.WBP_ButtonArrow_C.OnBtnClicked__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

