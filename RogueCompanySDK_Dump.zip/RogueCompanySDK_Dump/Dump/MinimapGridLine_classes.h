// WidgetBlueprintGeneratedClass MinimapGridLine.MinimapGridLine_C
// Size: 0x268 (Inherited: 0x238)
struct UMinimapGridLine_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct USizeBox* ImageSize; // 0x240(0x08)
	struct UImage* LineImage; // 0x248(0x08)
	int32_t OffsetIndex; // 0x250(0x04)
	bool VerticalLine; // 0x254(0x01)
	char UnknownData_255[0x3]; // 0x255(0x03)
	float MinimapScreenRadius; // 0x258(0x04)
	float MinimapWorldRadius; // 0x25c(0x04)
	float GridWorldSize; // 0x260(0x04)
	float GridScreenSize; // 0x264(0x04)

	void UpdateOnAxis(float Position); // Function MinimapGridLine.MinimapGridLine_C.UpdateOnAxis // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function MinimapGridLine.MinimapGridLine_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Update(struct FVector2D PlayerRelativePosition); // Function MinimapGridLine.MinimapGridLine_C.Update // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_MinimapGridLine(int32_t EntryPoint); // Function MinimapGridLine.MinimapGridLine_C.ExecuteUbergraph_MinimapGridLine // (Final|UbergraphFunction) // @ game+0x2587100
};

