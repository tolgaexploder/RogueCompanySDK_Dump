// BlueprintGeneratedClass GamePlayerController.GamePlayerController_C
// Size: 0xdb1 (Inherited: 0xda8)
struct AGamePlayerController_C : AGamePlayerControllerNoHUD_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xda8(0x08)
	bool NewVar_1; // 0xdb0(0x01)

	void ReceiveBeginPlay(); // Function GamePlayerController.GamePlayerController_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_GamePlayerController(int32_t EntryPoint); // Function GamePlayerController.GamePlayerController_C.ExecuteUbergraph_GamePlayerController // (Final|UbergraphFunction) // @ game+0x2587100
};

