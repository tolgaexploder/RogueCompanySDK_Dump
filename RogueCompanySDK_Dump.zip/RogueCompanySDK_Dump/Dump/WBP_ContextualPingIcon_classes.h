// WidgetBlueprintGeneratedClass WBP_ContextualPingIcon.WBP_ContextualPingIcon_C
// Size: 0x3b1 (Inherited: 0x3a0)
struct UWBP_ContextualPingIcon_C : UKSContextualPingMarkerWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3a0(0x08)
	struct UWBP_AsyncIcon_C* PingIcon; // 0x3a8(0x08)
	bool WasRemoved; // 0x3b0(0x01)

	void Construct(); // Function WBP_ContextualPingIcon.WBP_ContextualPingIcon_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void HandlePingRemoved(); // Function WBP_ContextualPingIcon.WBP_ContextualPingIcon_C.HandlePingRemoved // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetupPingOnReady(); // Function WBP_ContextualPingIcon.WBP_ContextualPingIcon_C.SetupPingOnReady // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_ContextualPingIcon(int32_t EntryPoint); // Function WBP_ContextualPingIcon.WBP_ContextualPingIcon_C.ExecuteUbergraph_WBP_ContextualPingIcon // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

