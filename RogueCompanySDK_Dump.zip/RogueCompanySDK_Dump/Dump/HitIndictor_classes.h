// WidgetBlueprintGeneratedClass HitIndictor.HitIndictor_C
// Size: 0x530 (Inherited: 0x510)
struct UHitIndictor_C : UKSViewedPawnWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x510(0x08)
	struct UCanvasPanel* HitCanvas; // 0x518(0x08)
	struct TArray<struct UHitIndicatorSub_C*> HitIndicatorPool; // 0x520(0x10)

	void ReturnToPool(struct UHitIndicatorSub_C* HitIndicatorSub); // Function HitIndictor.HitIndictor_C.ReturnToPool // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Init Indicator Pool(); // Function HitIndictor.HitIndictor_C.Init Indicator Pool // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void CreateHitIndicator(struct UObject* DamageType, struct FVector DamageOrigin, bool HitArmor); // Function HitIndictor.HitIndictor_C.CreateHitIndicator // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function HitIndictor.HitIndictor_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void On Viewed Pawn Take Damage(float DamageAmount, struct UDamageType* DamageTypeClass, struct AActor* DamageCauser, struct FVector DamageOrigin); // Function HitIndictor.HitIndictor_C.On Viewed Pawn Take Damage // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleViewedPawnTakeArmorDamage(float DamageAmount, struct UDamageType* DamageTypeClass, struct AActor* DamageCauser, struct FVector DamageOrigin); // Function HitIndictor.HitIndictor_C.HandleViewedPawnTakeArmorDamage // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_HitIndictor(int32_t EntryPoint); // Function HitIndictor.HitIndictor_C.ExecuteUbergraph_HitIndictor // (Final|UbergraphFunction) // @ game+0x2587100
};

