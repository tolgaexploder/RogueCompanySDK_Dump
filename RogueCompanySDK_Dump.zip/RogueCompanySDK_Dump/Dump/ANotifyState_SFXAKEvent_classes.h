// BlueprintGeneratedClass ANotifyState_SFXAKEvent.ANotifyState_SFXAKEvent_C
// Size: 0x5d (Inherited: 0x30)
struct UANotifyState_SFXAKEvent_C : UAnimNotifyState {
	struct UAkAudioEvent* AK Event Start; // 0x30(0x08)
	struct UAkAudioEvent* AK Event Stop; // 0x38(0x08)
	struct FName StartRowName; // 0x40(0x08)
	struct FName StopRowName; // 0x48(0x08)
	bool SpawnNewComponentAttachedToMesh; // 0x50(0x01)
	char UnknownData_51[0x3]; // 0x51(0x03)
	struct FName AttachPointName; // 0x54(0x08)
	bool Grab Emote Semaphore; // 0x5c(0x01)

	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function ANotifyState_SFXAKEvent.ANotifyState_SFXAKEvent_C.Received_NotifyEnd // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x2587100
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function ANotifyState_SFXAKEvent.ANotifyState_SFXAKEvent_C.Received_NotifyBegin // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x2587100
};

