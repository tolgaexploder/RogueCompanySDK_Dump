// DynamicClass AllyMinimapIcon.AllyMinimapIcon_C
// Size: 0x4c0 (Inherited: 0x318)
struct UAllyMinimapIcon_C : UKSMapIconWidgetBase {
	struct UImage* AboveIndicator; // 0x318(0x08)
	struct UBorder* AllyMinimapOverlay; // 0x320(0x08)
	struct UImage* BelowIndicator; // 0x328(0x08)
	struct UImage* BombIcon; // 0x330(0x08)
	struct UImage* ImageIcon; // 0x338(0x08)
	struct AKSPlayerState* Represented Player State; // 0x340(0x08)
	bool IsBombHolder; // 0x348(0x01)
	char UnknownData_349[0x7]; // 0x349(0x07)
	struct UTexture2D* Bomb Texture; // 0x350(0x08)
	enum class ESlateVisibility Temp_byte_Variable; // 0x358(0x01)
	enum class ESlateVisibility Temp_byte_Variable_2; // 0x359(0x01)
	bool Temp_bool_Variable; // 0x35a(0x01)
	enum class ESlateVisibility Temp_byte_Variable_3; // 0x35b(0x01)
	enum class ESlateVisibility Temp_byte_Variable_4; // 0x35c(0x01)
	char UnknownData_35D[0x3]; // 0x35d(0x03)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate; // 0x360(0x10)
	struct FLinearColor CallFunc_GetFriendlyColor_Return_Value; // 0x370(0x10)
	bool Temp_bool_Variable_2; // 0x380(0x01)
	char UnknownData_381[0x3]; // 0x381(0x03)
	struct FLinearColor Temp_struct_Variable; // 0x384(0x10)
	struct FGeometry K2Node_Event_MyGeometry; // 0x394(0x58)
	float K2Node_Event_InDeltaTime; // 0x3ec(0x04)
	struct AKSGameState_NeutralBomb* K2Node_DynamicCast_AsKSGame_State_Neutral_Bomb; // 0x3f0(0x08)
	bool K2Node_DynamicCast_bSuccess; // 0x3f8(0x01)
	char UnknownData_3F9[0x3]; // 0x3f9(0x03)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2; // 0x3fc(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3; // 0x40c(0x10)
	char UnknownData_41C[0x4]; // 0x41c(0x04)
	struct UTexture2D* Temp_object_Variable; // 0x420(0x08)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4; // 0x428(0x10)
	bool K2Node_Event_bHeight; // 0x438(0x01)
	bool K2Node_Event_bDepth; // 0x439(0x01)
	char UnknownData_43A[0x6]; // 0x43a(0x06)
	struct AKSPlayerState* K2Node_DynamicCast_AsKSPlayer_State; // 0x440(0x08)
	bool K2Node_DynamicCast_bSuccess_2; // 0x448(0x01)
	enum class ESlateVisibility K2Node_Select_Default; // 0x449(0x01)
	enum class ESlateVisibility K2Node_Select_Default_2; // 0x44a(0x01)
	char UnknownData_44B[0x5]; // 0x44b(0x05)
	struct FKSNeutralBombState K2Node_CustomEvent_BombState; // 0x450(0x18)
	bool Temp_bool_Variable_3; // 0x468(0x01)
	char UnknownData_469[0x3]; // 0x469(0x03)
	struct FLinearColor K2Node_Select_Default_3; // 0x46c(0x10)
	char UnknownData_47C[0x4]; // 0x47c(0x04)
	struct UTexture2D* Temp_object_Variable_2; // 0x480(0x08)
	struct AKSPlayerState* K2Node_CustomEvent_PlayerState; // 0x488(0x08)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5; // 0x490(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6; // 0x4a0(0x10)
	bool Temp_bool_Variable_4; // 0x4b0(0x01)
	char UnknownData_4B1[0x7]; // 0x4b1(0x07)
	struct UTexture2D* K2Node_Select_Default_4; // 0x4b8(0x08)

	void UIRelevantChanged(struct AKSPlayerState* bpp__PlayerState__pf); // Function AllyMinimapIcon.AllyMinimapIcon_C.UIRelevantChanged // (Native|Public|BlueprintCallable) // @ game+0x19dc0e0
	void Tick(struct FGeometry bpp__MyGeometry__pf, float bpp__InDeltaTime__pf); // Function AllyMinimapIcon.AllyMinimapIcon_C.Tick // (BlueprintCosmetic|Native|Event|Public) // @ game+0x19dbf90
	void OnSetupStart(); // Function AllyMinimapIcon.AllyMinimapIcon_C.OnSetupStart // (Native|Public|BlueprintCallable) // @ game+0x19db8a0
	void OnPlayerRevived(struct AKSPlayerState* bpp__Revivee__pf, struct AKSPlayerState* bpp__Reviver__pf, int32_t bpp__ExpBonus__pf); // Function AllyMinimapIcon.AllyMinimapIcon_C.OnPlayerRevived // (Native|Public|BlueprintCallable) // @ game+0x19dbd50
	void OnPlayerDown(struct FCombatEventInfo bpp__CombatEventInfo__pf, int32_t bpp__ExpBonus__pf); // Function AllyMinimapIcon.AllyMinimapIcon_C.OnPlayerDown // (Native|Public|BlueprintCallable) // @ game+0x19dbb40
	void Handle Bomb State Changed(struct FKSNeutralBombState bpp__BombState__pf); // Function AllyMinimapIcon.AllyMinimapIcon_C.Handle Bomb State Changed // (Native|Public|BlueprintCallable) // @ game+0x19dba90
	void HandleMapIconWidgetReady(); // Function AllyMinimapIcon.AllyMinimapIcon_C.HandleMapIconWidgetReady // (Native|Public|BlueprintCallable) // @ game+0x89ee40
	void Construct(); // Function AllyMinimapIcon.AllyMinimapIcon_C.Construct // (BlueprintCosmetic|Native|Event|Public) // @ game+0x19db8c0
	void PlayerReviveDelegate__DelegateSignature(struct AKSPlayerState* bpp__Revivee__pf, struct AKSPlayerState* bpp__Reviver__pf, int32_t bpp__ExpBonus__pf); // DelegateFunction AllyMinimapIcon.AllyMinimapIcon_C.PlayerReviveDelegate__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void PlayerDownInfo__DelegateSignature(struct FCombatEventInfo bpp__EventInfo__pf, int32_t bpp__ExpBonus__pf); // DelegateFunction AllyMinimapIcon.AllyMinimapIcon_C.PlayerDownInfo__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnUIRelevantPlayerStateChanged__DelegateSignature(struct AKSPlayerState* bpp__PlayerState__pf); // DelegateFunction AllyMinimapIcon.AllyMinimapIcon_C.OnUIRelevantPlayerStateChanged__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnSetupPhaseStart__DelegateSignature(); // DelegateFunction AllyMinimapIcon.AllyMinimapIcon_C.OnSetupPhaseStart__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnNeutralBombStateChanged__DelegateSignature(struct FKSNeutralBombState bpp__BombState__pf); // DelegateFunction AllyMinimapIcon.AllyMinimapIcon_C.OnNeutralBombStateChanged__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnMapIconWidgetReady__DelegateSignature(); // DelegateFunction AllyMinimapIcon.AllyMinimapIcon_C.OnMapIconWidgetReady__DelegateSignature // (Public|Delegate) // @ game+0x2587100
};

