// BlueprintGeneratedClass SettingsInfo_GlobalQuality.SettingsInfo_GlobalQuality_C
// Size: 0x138 (Inherited: 0x120)
struct USettingsInfo_GlobalQuality_C : UKSSettingsInfo_Generic {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x120(0x08)
	struct TArray<struct FString> QualityNames; // 0x128(0x10)

	void InitializeValue(); // Function SettingsInfo_GlobalQuality.SettingsInfo_GlobalQuality_C.InitializeValue // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_SettingsInfo_GlobalQuality(int32_t EntryPoint); // Function SettingsInfo_GlobalQuality.SettingsInfo_GlobalQuality_C.ExecuteUbergraph_SettingsInfo_GlobalQuality // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

