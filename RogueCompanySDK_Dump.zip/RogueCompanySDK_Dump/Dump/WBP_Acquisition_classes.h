// WidgetBlueprintGeneratedClass WBP_Acquisition.WBP_Acquisition_C
// Size: 0x570 (Inherited: 0x4f0)
struct UWBP_Acquisition_C : UKSPurchaseConfirmationWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4f0(0x08)
	struct UWidgetAnimation* OnShow; // 0x4f8(0x08)
	struct UWBP_Header1_C* AcquireTypeHeader; // 0x500(0x08)
	struct UWrapBox* BundleContents; // 0x508(0x08)
	struct UScrollBox* Contents; // 0x510(0x08)
	struct UWBP_ItemInfoContainer_Centered_C* ItemInfoContainer; // 0x518(0x08)
	struct UTextBlock* UnlockedItemText; // 0x520(0x08)
	struct UWBP_ItemPreviewStack_C* WBP_ItemPreviewStack; // 0x528(0x08)
	struct UPUMG_StoreItem* StoreItem; // 0x530(0x08)
	struct TArray<struct UWBP_KSCosmeticItemDisplay_C*> AcquisitionItemWidgets; // 0x538(0x10)
	bool IsBundleAcquisition; // 0x548(0x01)
	char UnknownData_549[0x7]; // 0x549(0x07)
	struct UAkAudioEvent* ShowAcquisitionSFX; // 0x550(0x08)
	struct UKSSkinBundle* CurrentSkin; // 0x558(0x08)
	struct UKSJobItem* CurrentCharacterJob; // 0x560(0x08)
	struct AKSJobSelectPrvwActor_RogueScrn* PreviewActor; // 0x568(0x08)

	void OnGamepadItemHover(struct UPUMG_StoreItem* Item, struct UKSWidget* Widget); // Function WBP_Acquisition.WBP_Acquisition_C.OnGamepadItemHover // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void DisplayStoreItem(struct UPUMG_StoreItem* StoreItem); // Function WBP_Acquisition.WBP_Acquisition_C.DisplayStoreItem // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetAcquisitionDisplay(struct UKSAcquisition* Acquistion); // Function WBP_Acquisition.WBP_Acquisition_C.SetAcquisitionDisplay // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	bool NavigateBack(); // Function WBP_Acquisition.WBP_Acquisition_C.NavigateBack // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PreConstruct(bool IsDesignTime); // Function WBP_Acquisition.WBP_Acquisition_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function WBP_Acquisition.WBP_Acquisition_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnBackPrompt(); // Function WBP_Acquisition.WBP_Acquisition_C.OnBackPrompt // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidgetNavigation(); // Function WBP_Acquisition.WBP_Acquisition_C.InitializeWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnShown(); // Function WBP_Acquisition.WBP_Acquisition_C.OnShown // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnHide(); // Function WBP_Acquisition.WBP_Acquisition_C.OnHide // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_Acquisition(int32_t EntryPoint); // Function WBP_Acquisition.WBP_Acquisition_C.ExecuteUbergraph_WBP_Acquisition // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

