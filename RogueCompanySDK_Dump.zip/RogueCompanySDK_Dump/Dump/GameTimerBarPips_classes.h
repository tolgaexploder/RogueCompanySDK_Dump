// WidgetBlueprintGeneratedClass GameTimerBarPips.GameTimerBarPips_C
// Size: 0x511 (Inherited: 0x4e0)
struct UGameTimerBarPips_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UGameTimerBarScorePip_C* GameTimerBarScorePip; // 0x4e8(0x08)
	struct UGameTimerBarScorePip_C* GameTimerBarScorePip_C_2; // 0x4f0(0x08)
	struct UGameTimerBarScorePip_C* GameTimerBarScorePip_C_3; // 0x4f8(0x08)
	struct UHorizontalBox* PipsContainer; // 0x500(0x08)
	int32_t Current Filled Pips; // 0x508(0x04)
	int32_t LastUpdatedFilledPips; // 0x50c(0x04)
	bool bIsEnemyTeam; // 0x510(0x01)

	void Set Total Pips(int32_t Pips Number); // Function GameTimerBarPips.GameTimerBarPips_C.Set Total Pips // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Set Pips Number(int32_t Pips Number); // Function GameTimerBarPips.GameTimerBarPips_C.Set Pips Number // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PreConstruct(bool IsDesignTime); // Function GameTimerBarPips.GameTimerBarPips_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function GameTimerBarPips.GameTimerBarPips_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_GameTimerBarPips(int32_t EntryPoint); // Function GameTimerBarPips.GameTimerBarPips_C.ExecuteUbergraph_GameTimerBarPips // (Final|UbergraphFunction) // @ game+0x2587100
};

