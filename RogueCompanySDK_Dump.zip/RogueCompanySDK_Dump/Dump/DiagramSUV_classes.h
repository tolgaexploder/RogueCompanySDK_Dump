// WidgetBlueprintGeneratedClass DiagramSUV.DiagramSUV_C
// Size: 0x510 (Inherited: 0x4e0)
struct UDiagramSUV_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UImage* Car; // 0x4e8(0x08)
	struct UImage* Seat1; // 0x4f0(0x08)
	struct UImage* Seat2; // 0x4f8(0x08)
	struct UImage* Seat3; // 0x500(0x08)
	struct UImage* Seat4; // 0x508(0x08)

	void SetSeating(int32_t Seat Index, struct AKSCharacter* Occupant); // Function DiagramSUV.DiagramSUV_C.SetSeating // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_DiagramSUV(int32_t EntryPoint); // Function DiagramSUV.DiagramSUV_C.ExecuteUbergraph_DiagramSUV // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

