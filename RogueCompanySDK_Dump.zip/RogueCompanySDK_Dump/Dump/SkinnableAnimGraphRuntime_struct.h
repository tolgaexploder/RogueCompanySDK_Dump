// ScriptStruct SkinnableAnimGraphRuntime.AnimNode_AimOffsetSkinned
// Size: 0x1b8 (Inherited: 0x190)
struct FAnimNode_AimOffsetSkinned : FAnimNode_RotationOffsetBlendSpace {
	struct FName SkinKeyword; // 0x190(0x08)
	struct UBlendSpaceBase* TargetBlendSpace; // 0x198(0x08)
	struct UBlendSpaceBase* DefaultBlendSpace; // 0x1a0(0x08)
	char UnknownData_1A8[0x10]; // 0x1a8(0x10)
};

// ScriptStruct SkinnableAnimGraphRuntime.AnimNode_BlendPoseNodeSkinned
// Size: 0xd0 (Inherited: 0xa0)
struct FAnimNode_BlendPoseNodeSkinned : FAnimNode_PoseBlendNode {
	struct FName SkinKeyword; // 0xa0(0x08)
	struct UPoseAsset* TargetPose; // 0xa8(0x08)
	bool bUsePoseAssetPinAsFallback; // 0xb0(0x01)
	char UnknownData_B1[0x7]; // 0xb1(0x07)
	struct UPoseAsset* FallbackPose; // 0xb8(0x08)
	char UnknownData_C0[0x10]; // 0xc0(0x10)
};

// ScriptStruct SkinnableAnimGraphRuntime.AnimNode_BlendSpacePlayerSkinned
// Size: 0x1f8 (Inherited: 0xe8)
struct FAnimNode_BlendSpacePlayerSkinned : FAnimNode_BlendSpacePlayer {
	struct FPoseLink Source; // 0xe8(0x10)
	struct FName SkinKeyword; // 0xf8(0x08)
	float BlendFromSourceTime; // 0x100(0x04)
	float BlendToSourceTime; // 0x104(0x04)
	enum class EAlphaBlendOption BlendType; // 0x108(0x01)
	char UnknownData_109[0x7]; // 0x109(0x07)
	struct UCurveFloat* CustomBlendCurve; // 0x110(0x08)
	struct UBlendProfile* BlendProfile; // 0x118(0x08)
	struct FAlphaBlend BlendFromSource; // 0x120(0x30)
	struct FAlphaBlend BlendToSource; // 0x150(0x30)
	struct UBlendSpaceBase* TargetBlendSpace; // 0x180(0x08)
	struct UBlendSpaceBase* LastTargetBlendSpace; // 0x188(0x08)
	bool bLastHadTargetBlendSpace; // 0x190(0x01)
	char UnknownData_191[0x3]; // 0x191(0x03)
	float SourceBlendWeight; // 0x194(0x04)
	float RemainingBlendTime; // 0x198(0x04)
	char UnknownData_19C[0x4]; // 0x19c(0x04)
	struct FBlendSampleData PerBoneSampleData; // 0x1a0(0x40)
	bool bResetSourceOnActivation; // 0x1e0(0x01)
	char UnknownData_1E1[0x17]; // 0x1e1(0x17)
};

// ScriptStruct SkinnableAnimGraphRuntime.AnimNode_BSpaceEvalSkinned
// Size: 0x200 (Inherited: 0xf0)
struct FAnimNode_BSpaceEvalSkinned : FAnimNode_BlendSpaceEvaluator {
	struct FPoseLink Source; // 0xf0(0x10)
	struct FName SkinKeyword; // 0x100(0x08)
	float BlendFromSourceTime; // 0x108(0x04)
	float BlendToSourceTime; // 0x10c(0x04)
	enum class EAlphaBlendOption BlendType; // 0x110(0x01)
	char UnknownData_111[0x7]; // 0x111(0x07)
	struct UCurveFloat* CustomBlendCurve; // 0x118(0x08)
	struct UBlendProfile* BlendProfile; // 0x120(0x08)
	struct FAlphaBlend BlendFromSource; // 0x128(0x30)
	struct FAlphaBlend BlendToSource; // 0x158(0x30)
	struct UBlendSpaceBase* TargetBlendSpace; // 0x188(0x08)
	struct UBlendSpaceBase* LastTargetBlendSpace; // 0x190(0x08)
	bool bLastHadTargetBlendSpace; // 0x198(0x01)
	char UnknownData_199[0x3]; // 0x199(0x03)
	float SourceBlendWeight; // 0x19c(0x04)
	float RemainingBlendTime; // 0x1a0(0x04)
	char UnknownData_1A4[0x4]; // 0x1a4(0x04)
	struct FBlendSampleData PerBoneSampleData; // 0x1a8(0x40)
	bool bResetSourceOnActivation; // 0x1e8(0x01)
	char UnknownData_1E9[0x17]; // 0x1e9(0x17)
};

// ScriptStruct SkinnableAnimGraphRuntime.AnimNode_SeqEvalSkinned
// Size: 0x168 (Inherited: 0x50)
struct FAnimNode_SeqEvalSkinned : FAnimNode_SequenceEvaluator {
	struct FPoseLink Source; // 0x50(0x10)
	struct FName SkinKeyword; // 0x60(0x08)
	float BlendFromSourceTime; // 0x68(0x04)
	float BlendToSourceTime; // 0x6c(0x04)
	enum class EAlphaBlendOption BlendType; // 0x70(0x01)
	char UnknownData_71[0x7]; // 0x71(0x07)
	struct UCurveFloat* CustomBlendCurve; // 0x78(0x08)
	struct UBlendProfile* BlendProfile; // 0x80(0x08)
	struct FAlphaBlend BlendFromSource; // 0x88(0x30)
	struct FAlphaBlend BlendToSource; // 0xb8(0x30)
	struct UAnimSequenceBase* TargetSequence; // 0xe8(0x08)
	struct UAnimSequenceBase* LastTargetSequence; // 0xf0(0x08)
	bool bUseSequencePinAsFallback; // 0xf8(0x01)
	bool bLastHadTargetSequence; // 0xf9(0x01)
	char UnknownData_FA[0x2]; // 0xfa(0x02)
	float SourceBlendWeight; // 0xfc(0x04)
	float RemainingBlendTime; // 0x100(0x04)
	char UnknownData_104[0x4]; // 0x104(0x04)
	struct FBlendSampleData PerBoneSampleData; // 0x108(0x40)
	bool bResetSourceOnActivation; // 0x148(0x01)
	char UnknownData_149[0x7]; // 0x149(0x07)
	struct UAnimSequenceBase* FallbackSequence; // 0x150(0x08)
	char UnknownData_158[0x10]; // 0x158(0x10)
};

// ScriptStruct SkinnableAnimGraphRuntime.AnimNode_SeqCurveEvalSkinned
// Size: 0x178 (Inherited: 0x168)
struct FAnimNode_SeqCurveEvalSkinned : FAnimNode_SeqEvalSkinned {
	struct FName CurveName; // 0x168(0x08)
	char UnknownData_170[0x8]; // 0x170(0x08)
};

// ScriptStruct SkinnableAnimGraphRuntime.AnimNode_SequenceSkinned
// Size: 0x158 (Inherited: 0x38)
struct FAnimNode_SequenceSkinned : FAnimNode_AssetPlayerBase {
	struct FPoseLink Source; // 0x38(0x10)
	struct FName SkinKeyword; // 0x48(0x08)
	bool bLoopAnimation; // 0x50(0x01)
	char UnknownData_51[0x3]; // 0x51(0x03)
	float PlayRate; // 0x54(0x04)
	float PlayRateBasis; // 0x58(0x04)
	float StartPosition; // 0x5c(0x04)
	float BlendFromSourceTime; // 0x60(0x04)
	float BlendToSourceTime; // 0x64(0x04)
	enum class EAlphaBlendOption BlendType; // 0x68(0x01)
	char UnknownData_69[0x7]; // 0x69(0x07)
	struct UCurveFloat* CustomBlendCurve; // 0x70(0x08)
	struct UBlendProfile* BlendProfile; // 0x78(0x08)
	struct FAlphaBlend BlendFromSource; // 0x80(0x30)
	struct FAlphaBlend BlendToSource; // 0xb0(0x30)
	struct UAnimSequenceBase* CurrentSequence; // 0xe0(0x08)
	struct UAnimSequenceBase* LastSequence; // 0xe8(0x08)
	bool bLastHadSequence; // 0xf0(0x01)
	char UnknownData_F1[0x3]; // 0xf1(0x03)
	float SourceBlendWeight; // 0xf4(0x04)
	float RemainingBlendTime; // 0xf8(0x04)
	char UnknownData_FC[0x4]; // 0xfc(0x04)
	struct FBlendSampleData PerBoneSampleData; // 0x100(0x40)
	bool bResetSourceOnActivation; // 0x140(0x01)
	char UnknownData_141[0x17]; // 0x141(0x17)
};

// ScriptStruct SkinnableAnimGraphRuntime.AnimNode_SequenceSkinnedCurvePlay
// Size: 0x160 (Inherited: 0x158)
struct FAnimNode_SequenceSkinnedCurvePlay : FAnimNode_SequenceSkinned {
	struct FName CurveName; // 0x158(0x08)
};

// ScriptStruct SkinnableAnimGraphRuntime.SkinnedAnimInstanceProxy
// Size: 0x730 (Inherited: 0x6e0)
struct FSkinnedAnimInstanceProxy : FAnimInstanceProxy {
	char UnknownData_6E0[0x50]; // 0x6e0(0x50)
};

