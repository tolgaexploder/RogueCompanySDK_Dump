// WidgetBlueprintGeneratedClass WBP_ActiveBoosterShelf.WBP_ActiveBoosterShelf_C
// Size: 0x538 (Inherited: 0x4e0)
struct UWBP_ActiveBoosterShelf_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UWidgetAnimation* Hover; // 0x4e8(0x08)
	struct UHorizontalBox* ActiveBoostContainer; // 0x4f0(0x08)
	struct UImage* Bottom; // 0x4f8(0x08)
	struct UButton* HitTarget; // 0x500(0x08)
	struct UImage* Middle; // 0x508(0x08)
	struct UCanvasPanel* Root; // 0x510(0x08)
	struct UImage* Top; // 0x518(0x08)
	struct UWBP_ActiveBoosterEntry_C* WBP_ActiveBoosterEntry; // 0x520(0x08)
	struct UWBP_ActiveBoosterEntry_C* WBP_ActiveBoosterEntry_2; // 0x528(0x08)
	struct UWBP_ActiveBoosterEntry_C* WBP_ActiveBoosterEntry_3; // 0x530(0x08)

	void RefreshActiveBoosts(); // Function WBP_ActiveBoosterShelf.WBP_ActiveBoosterShelf_C.RefreshActiveBoosts // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_ActiveBoosterShelf.WBP_ActiveBoosterShelf_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void OnShown(); // Function WBP_ActiveBoosterShelf.WBP_ActiveBoosterShelf_C.OnShown // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function WBP_ActiveBoosterShelf.WBP_ActiveBoosterShelf_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnAcquisition(struct UKSAcquisition* Acquisition); // Function WBP_ActiveBoosterShelf.WBP_ActiveBoosterShelf_C.OnAcquisition // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function WBP_ActiveBoosterShelf.WBP_ActiveBoosterShelf_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature(); // Function WBP_ActiveBoosterShelf.WBP_ActiveBoosterShelf_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_ActiveBoosterShelf(int32_t EntryPoint); // Function WBP_ActiveBoosterShelf.WBP_ActiveBoosterShelf_C.ExecuteUbergraph_WBP_ActiveBoosterShelf // (Final|UbergraphFunction) // @ game+0x2587100
};

