// WidgetBlueprintGeneratedClass EscMenu.EscMenu_C
// Size: 0x568 (Inherited: 0x4e0)
struct UEscMenu_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UImage* Image; // 0x4e8(0x08)
	struct UImage* Image_2; // 0x4f0(0x08)
	struct UImage* Image_3; // 0x4f8(0x08)
	struct UImage* Image_4; // 0x500(0x08)
	struct UImage* Image_5; // 0x508(0x08)
	struct UImage* Image_188; // 0x510(0x08)
	struct UImage* Image_292; // 0x518(0x08)
	struct UImage* Image_399; // 0x520(0x08)
	struct UImage* Image_572; // 0x528(0x08)
	struct UPopupButton_C* OptionsButton; // 0x530(0x08)
	struct UPopupButton_C* QuitButton; // 0x538(0x08)
	struct UPopupButton_C* ResumeButton; // 0x540(0x08)
	struct UPopupButton_C* ReturnButton; // 0x548(0x08)
	struct UStandardContainer_C* StandardContainer; // 0x550(0x08)
	struct UPopupButton_C* SurrenderButton; // 0x558(0x08)
	struct UPopupButton_C* ToggleHUDLayers; // 0x560(0x08)

	void ClearVoteInput(); // Function EscMenu.EscMenu_C.ClearVoteInput // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ToggleGameHUDLayers(); // Function EscMenu.EscMenu_C.ToggleGameHUDLayers // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	bool NavigateBack(); // Function EscMenu.EscMenu_C.NavigateBack // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BndEvt__QuitButton_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature(int32_t Index); // Function EscMenu.EscMenu_C.BndEvt__QuitButton_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__OptionsButton_K2Node_ComponentBoundEvent_1_OnClicked__DelegateSignature(int32_t Index); // Function EscMenu.EscMenu_C.BndEvt__OptionsButton_K2Node_ComponentBoundEvent_1_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__ResumeButton_K2Node_ComponentBoundEvent_2_OnClicked__DelegateSignature(int32_t Index); // Function EscMenu.EscMenu_C.BndEvt__ResumeButton_K2Node_ComponentBoundEvent_2_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void InitializeWidgetNavigation(); // Function EscMenu.EscMenu_C.InitializeWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void BndEvt__ReturnButton_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature(int32_t Index); // Function EscMenu.EscMenu_C.BndEvt__ReturnButton_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void InitializeWidgetButtonListeners(); // Function EscMenu.EscMenu_C.InitializeWidgetButtonListeners // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void Handle Menu(); // Function EscMenu.EscMenu_C.Handle Menu // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BndEvt__ToggleHUDLayers_K2Node_ComponentBoundEvent_3_OnClicked__DelegateSignature(int32_t Index); // Function EscMenu.EscMenu_C.BndEvt__ToggleHUDLayers_K2Node_ComponentBoundEvent_3_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void OpenTextChatGamepad(); // Function EscMenu.EscMenu_C.OpenTextChatGamepad // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OpenTextChatForCommand(); // Function EscMenu.EscMenu_C.OpenTextChatForCommand // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OpenTextChat(); // Function EscMenu.EscMenu_C.OpenTextChat // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnShown(); // Function EscMenu.EscMenu_C.OnShown // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void RefreshLeaveOptions(); // Function EscMenu.EscMenu_C.RefreshLeaveOptions // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BndEvt__SurrenderButton_K2Node_ComponentBoundEvent_4_OnClicked__DelegateSignature(int32_t Index); // Function EscMenu.EscMenu_C.BndEvt__SurrenderButton_K2Node_ComponentBoundEvent_4_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void SetupSurrernderButton(); // Function EscMenu.EscMenu_C.SetupSurrernderButton // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Change Surrender Button(bool bCanTeamSurrender); // Function EscMenu.EscMenu_C.Change Surrender Button // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function EscMenu.EscMenu_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnHide(); // Function EscMenu.EscMenu_C.OnHide // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_EscMenu(int32_t EntryPoint); // Function EscMenu.EscMenu_C.ExecuteUbergraph_EscMenu // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

