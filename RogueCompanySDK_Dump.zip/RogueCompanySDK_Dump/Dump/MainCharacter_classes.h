// DynamicClass MainCharacter.MainCharacter_C
// Size: 0x4da0 (Inherited: 0x3510)
struct AMainCharacter_C : AKSCharacter {
	struct UParticleSystemComponent* FX_Blinded; // 0x3510(0x08)
	struct UCharacterHeatSourceComponent_C* CharacterHeatSourceComponent; // 0x3518(0x08)
	struct UKSCharacterSocketComponent* PerformanceAimOrigin; // 0x3520(0x08)
	struct UCharacterEmotionComponent_C* CharacterEmotionComponent; // 0x3528(0x08)
	struct USpringArmComponent* SkyDiveCameraBoom; // 0x3530(0x08)
	struct UWidgetComponent* Nameplate; // 0x3538(0x08)
	struct UMainCharacterThreatComponent_C* MainCharacterThreatComponent; // 0x3540(0x08)
	struct UKSTabletMeshComponent* NewTablet; // 0x3548(0x08)
	struct UMainEnvironmentTracker_C* MainEnvironmentTracker; // 0x3550(0x08)
	struct UKSAimAssistAnchorComponent* BodyAimAssistAnchor; // 0x3558(0x08)
	struct UKSAimAssistAnchorComponent* HeadAimAssistAnchor; // 0x3560(0x08)
	struct UParticleSystemComponent* Free Fall Particle Component; // 0x3568(0x08)
	struct UCameraComponent* SkyDiveCamera; // 0x3570(0x08)
	float EnterFreeFallFOVTimeline_FOV_214483C64B8EF94ABEE010ACC0C82B47; // 0x3578(0x04)
	enum class ETimelineDirection EnterFreeFallFOVTimeline__Direction_214483C64B8EF94ABEE010ACC0C82B47; // 0x357c(0x01)
	char UnknownData_357D[0x3]; // 0x357d(0x03)
	struct UTimelineComponent* EnterFreeFallFOVTimeline; // 0x3580(0x08)
	float NoseDiveFOVTimeline_FOV_B4B28FE84FD9F70D4702AD94CD02429F; // 0x3588(0x04)
	enum class ETimelineDirection NoseDiveFOVTimeline__Direction_B4B28FE84FD9F70D4702AD94CD02429F; // 0x358c(0x01)
	char UnknownData_358D[0x3]; // 0x358d(0x03)
	struct UTimelineComponent* NoseDiveFOVTimeline; // 0x3590(0x08)
	struct FVector Martial_Artist_Target_Front_Camera_Offset_2353812C44E84070E58EA28AC0C39A7A; // 0x3598(0x0c)
	struct FVector Martial_Artist_Target_Front_Camera_Rotation_2353812C44E84070E58EA28AC0C39A7A; // 0x35a4(0x0c)
	enum class ETimelineDirection Martial_Artist_Target_Front__Direction_2353812C44E84070E58EA28AC0C39A7A; // 0x35b0(0x01)
	char UnknownData_35B1[0x7]; // 0x35b1(0x07)
	struct UTimelineComponent* Martial Artist Target Front; // 0x35b8(0x08)
	struct FVector Martial_Artist_Target_Back_Camera_Offset_1BFA9A6E4FC29401CE8D43B8AAD4581C; // 0x35c0(0x0c)
	struct FVector Martial_Artist_Target_Back_Camera_Rotation_1BFA9A6E4FC29401CE8D43B8AAD4581C; // 0x35cc(0x0c)
	enum class ETimelineDirection Martial_Artist_Target_Back__Direction_1BFA9A6E4FC29401CE8D43B8AAD4581C; // 0x35d8(0x01)
	char UnknownData_35D9[0x7]; // 0x35d9(0x07)
	struct UTimelineComponent* Martial Artist Target Back; // 0x35e0(0x08)
	struct FVector Martial_Artist_Instigator_Front_Camera_Offset_F70AEBFB4CDEF611144DE3BBA0C06E0C; // 0x35e8(0x0c)
	struct FVector Martial_Artist_Instigator_Front_Camera_Rotation_F70AEBFB4CDEF611144DE3BBA0C06E0C; // 0x35f4(0x0c)
	enum class ETimelineDirection Martial_Artist_Instigator_Front__Direction_F70AEBFB4CDEF611144DE3BBA0C06E0C; // 0x3600(0x01)
	char UnknownData_3601[0x7]; // 0x3601(0x07)
	struct UTimelineComponent* Martial Artist Instigator Front; // 0x3608(0x08)
	struct FVector Martial_Artist_Instigator_Back_Camera_Offset_28F092594C0CD50C0A3EA1BF17E2C5E1; // 0x3610(0x0c)
	struct FVector Martial_Artist_Instigator_Back_Camera_Rotation_28F092594C0CD50C0A3EA1BF17E2C5E1; // 0x361c(0x0c)
	enum class ETimelineDirection Martial_Artist_Instigator_Back__Direction_28F092594C0CD50C0A3EA1BF17E2C5E1; // 0x3628(0x01)
	char UnknownData_3629[0x7]; // 0x3629(0x07)
	struct UTimelineComponent* Martial Artist Instigator Back; // 0x3630(0x08)
	struct FVector CameraDodgeRoll_Relative_Position_4B7EB20A461034BB0B80418AE71BD9F4; // 0x3638(0x0c)
	float CameraDodgeRoll_Camera_Boom_Length_4B7EB20A461034BB0B80418AE71BD9F4; // 0x3644(0x04)
	enum class ETimelineDirection CameraDodgeRoll__Direction_4B7EB20A461034BB0B80418AE71BD9F4; // 0x3648(0x01)
	char UnknownData_3649[0x7]; // 0x3649(0x07)
	struct UTimelineComponent* CameraDodgeRoll; // 0x3650(0x08)
	float SprintFOVTimeline_FOVAlpha_F9A879E74FD1B4D844684CBEE4230863; // 0x3658(0x04)
	enum class ETimelineDirection SprintFOVTimeline__Direction_F9A879E74FD1B4D844684CBEE4230863; // 0x365c(0x01)
	char UnknownData_365D[0x3]; // 0x365d(0x03)
	struct UTimelineComponent* SprintFOVTimeline; // 0x3660(0x08)
	float EndImmunity_Invulnerable_4A69979040C00E80AB6D5687355E98EA; // 0x3668(0x04)
	enum class ETimelineDirection EndImmunity__Direction_4A69979040C00E80AB6D5687355E98EA; // 0x366c(0x01)
	char UnknownData_366D[0x3]; // 0x366d(0x03)
	struct UTimelineComponent* EndImmunity; // 0x3670(0x08)
	float StartImmunity_Invulnerable_F2F49BA44D30D2903638919AFE6C1704; // 0x3678(0x04)
	enum class ETimelineDirection StartImmunity__Direction_F2F49BA44D30D2903638919AFE6C1704; // 0x367c(0x01)
	char UnknownData_367D[0x3]; // 0x367d(0x03)
	struct UTimelineComponent* StartImmunity; // 0x3680(0x08)
	float Camera_Boom_Timeline_Player_Mesh_ADS_Weight_Reverse_7F7960E24E458B7FB9796A9428D9E3C5; // 0x3688(0x04)
	float Camera_Boom_Timeline_Player_Mesh_ADS_Weight_Forward_7F7960E24E458B7FB9796A9428D9E3C5; // 0x368c(0x04)
	float Camera_Boom_Timeline_FOV_Weight_7F7960E24E458B7FB9796A9428D9E3C5; // 0x3690(0x04)
	float Camera_Boom_Timeline_Camera_Boom_Length_7F7960E24E458B7FB9796A9428D9E3C5; // 0x3694(0x04)
	enum class ETimelineDirection Camera_Boom_Timeline__Direction_7F7960E24E458B7FB9796A9428D9E3C5; // 0x3698(0x01)
	char UnknownData_3699[0x7]; // 0x3699(0x07)
	struct UTimelineComponent* Camera Boom Timeline; // 0x36a0(0x08)
	float Elapsed; // 0x36a8(0x04)
	bool StopwatchOn; // 0x36ac(0x01)
	char UnknownData_36AD[0x3]; // 0x36ad(0x03)
	struct FVector PlayerLocation; // 0x36b0(0x0c)
	char UnknownData_36BC[0x4]; // 0x36bc(0x04)
	struct UAkAudioEvent* Successful Hit AkEvent; // 0x36c0(0x08)
	bool ADS Test; // 0x36c8(0x01)
	char UnknownData_36C9[0x3]; // 0x36c9(0x03)
	float Camera Boom Arm Max; // 0x36cc(0x04)
	float Cached 1p Field of View; // 0x36d0(0x04)
	float Test Alpha; // 0x36d4(0x04)
	bool InFreeFall; // 0x36d8(0x01)
	bool Turn Right; // 0x36d9(0x01)
	bool Turn Left; // 0x36da(0x01)
	char UnknownData_36DB[0x1]; // 0x36db(0x01)
	float Pitch; // 0x36dc(0x04)
	struct UParticleSystem* Friendly Free Fall; // 0x36e0(0x08)
	struct UParticleSystem* Enemy Free Fall; // 0x36e8(0x08)
	float Yaw; // 0x36f0(0x04)
	float Main Camera Cached FOV; // 0x36f4(0x04)
	int32_t HitDirs; // 0x36f8(0x04)
	enum class HitEnum HitEnum; // 0x36fc(0x01)
	char UnknownData_36FD[0x3]; // 0x36fd(0x03)
	struct FKSSpecialEffect DownedPPEffect; // 0x3700(0x50)
	float Downed PP Transition Duration; // 0x3750(0x04)
	bool IsTrailActive; // 0x3754(0x01)
	char UnknownData_3755[0x3]; // 0x3755(0x03)
	struct UMaterialInterface* FlashBang PP Material; // 0x3758(0x08)
	struct UMaterialInstanceDynamic* FlashBang PP Material Instance; // 0x3760(0x08)
	struct TArray<struct UObject*> SFX Grenade Damage Type; // 0x3768(0x10)
	struct TArray<struct UObject*> SFX Blade Damage Type; // 0x3778(0x10)
	struct AActor* SFX Damage Target; // 0x3788(0x08)
	struct FVector LeftTempLoc; // 0x3790(0x0c)
	float AffectRange; // 0x379c(0x04)
	struct FVector RightTempLoc; // 0x37a0(0x0c)
	char UnknownData_37AC[0x4]; // 0x37ac(0x04)
	struct UMaterialInterface* Out Of Bounds PP Material; // 0x37b0(0x08)
	struct UMaterialInstanceDynamic* Out Of Bounds PP Material Instance; // 0x37b8(0x08)
	float CachedFOV; // 0x37c0(0x04)
	char UnknownData_37C4[0x4]; // 0x37c4(0x04)
	struct FLastHitImpulse LastHitInfo; // 0x37c8(0x40)
	struct FRotator KnockbackRotation; // 0x3808(0x0c)
	float DeltaTime; // 0x3814(0x04)
	bool bIsRagdoll; // 0x3818(0x01)
	bool bIsLaunchedOnDown; // 0x3819(0x01)
	bool bSnapshotPoseFacingUp; // 0x381a(0x01)
	char UnknownData_381B[0x5]; // 0x381b(0x05)
	struct UAnimMontage* GetUpMontage; // 0x3820(0x08)
	bool bIsRagdollOnGround; // 0x3828(0x01)
	char UnknownData_3829[0x3]; // 0x3829(0x03)
	struct FVector RagdollPelvisLocation; // 0x382c(0x0c)
	struct FVector RagdollCapsuleLocation; // 0x3838(0x0c)
	float TimeInRagdoll; // 0x3844(0x04)
	float MaxTimeInRagdoll; // 0x3848(0x04)
	char UnknownData_384C[0x4]; // 0x384c(0x04)
	struct UParticleSystemComponent* FireParticle; // 0x3850(0x08)
	struct UMaterialInstanceDynamic* GrenadeImpactPointMID; // 0x3858(0x08)
	bool ZiplineActive1; // 0x3860(0x01)
	char UnknownData_3861[0x3]; // 0x3861(0x03)
	float SprintFov; // 0x3864(0x04)
	float SprintFOVChangeDuration; // 0x3868(0x04)
	float ZiplineFov; // 0x386c(0x04)
	float PreviousFov; // 0x3870(0x04)
	char UnknownData_3874[0x4]; // 0x3874(0x04)
	struct FDebugFloatHistory InterpLengthHist; // 0x3878(0x20)
	struct UKSFXCurveComponent* AppliedDownedCurveComponent; // 0x3898(0x08)
	struct FDamageEffect Effect; // 0x38a0(0x50)
	struct FKSSpecialEffect BloodPPEffect; // 0x38f0(0x50)
	struct UMaterial* HealthPostProcess; // 0x3940(0x08)
	struct UMaterialInstanceDynamic* Health PP MID; // 0x3948(0x08)
	float HealthPPInterpSpeed; // 0x3950(0x04)
	char UnknownData_3954[0x4]; // 0x3954(0x04)
	struct FKSSpecialEffect SonarPPEffect; // 0x3958(0x50)
	struct FKSSpecialEffect EMPPPEffect; // 0x39a8(0x50)
	bool bEnableDirectionalDowns; // 0x39f8(0x01)
	bool bEnableComplexDirectionalDowns; // 0x39f9(0x01)
	char UnknownData_39FA[0x2]; // 0x39fa(0x02)
	float FreeFallParticleDetachTime; // 0x39fc(0x04)
	struct FKSSpecialEffect OutOfBoundsPPEffect; // 0x3a00(0x50)
	struct UKSFXCurveComponent* OutOfBoundsEffectCurve; // 0x3a50(0x08)
	struct FKSSpecialEffect ConfirmHitPPEffect; // 0x3a58(0x50)
	struct FKSSpecialEffect NearMissPPEffect; // 0x3aa8(0x50)
	int32_t Active Index; // 0x3af8(0x04)
	char UnknownData_3AFC[0x4]; // 0x3afc(0x04)
	struct FKSSpecialEffect FirePostProcess; // 0x3b00(0x50)
	struct TArray<struct FDamageEffect> QueuedDamageEffects; // 0x3b50(0x10)
	bool InLowTreshold; // 0x3b60(0x01)
	char UnknownData_3B61[0x3]; // 0x3b61(0x03)
	float LowHealthTreshold; // 0x3b64(0x04)
	struct FKSSpecialEffect PP_SkyDive; // 0x3b68(0x50)
	struct UAkAudioEvent* GadgetSwapSound; // 0x3bb8(0x08)
	bool ConfirmHitPPEffectEnabled; // 0x3bc0(0x01)
	char UnknownData_3BC1[0x7]; // 0x3bc1(0x07)
	struct FKSSpecialEffect ConfirmPickupPPEffect; // 0x3bc8(0x50)
	struct UAkAudioEvent* SFXSkyDiveStart; // 0x3c18(0x08)
	struct UAkAudioEvent* SFXSkyDiveWind; // 0x3c20(0x08)
	struct UAkAudioEvent* SFXSkyDiveStop; // 0x3c28(0x08)
	int32_t StopLoopingReviveSFX; // 0x3c30(0x04)
	int32_t StopLoopingArmorSFX; // 0x3c34(0x04)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable; // 0x3c38(0x10)
	struct FDelegate Temp_delegate_Variable; // 0x3c48(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_2; // 0x3c58(0x10)
	struct FDelegate Temp_delegate_Variable_2; // 0x3c68(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_3; // 0x3c78(0x10)
	struct FDelegate Temp_delegate_Variable_3; // 0x3c88(0x10)
	struct FName Temp_name_Variable; // 0x3c98(0x08)
	struct FDelegate Temp_delegate_Variable_4; // 0x3ca0(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_4; // 0x3cb0(0x10)
	float K2Node_Event_Damage; // 0x3cc0(0x04)
	char UnknownData_3CC4[0x4]; // 0x3cc4(0x04)
	struct UObject* K2Node_Event_DamageTypeClass_2; // 0x3cc8(0x08)
	float K2Node_Event_DamageImpulse; // 0x3cd0(0x04)
	struct FVector K2Node_Event_RelativeImpactLocation; // 0x3cd4(0x0c)
	struct FName K2Node_Event_BoneName; // 0x3ce0(0x08)
	struct AActor* K2Node_Event_DamageCauser_2; // 0x3ce8(0x08)
	struct FName Temp_name_Variable_2; // 0x3cf0(0x08)
	bool CallFunc_GetRagdollFacingDirection_IsUp; // 0x3cf8(0x01)
	char UnknownData_3CF9[0x3]; // 0x3cf9(0x03)
	struct FName Temp_name_Variable_3; // 0x3cfc(0x08)
	struct FName Temp_name_Variable_4; // 0x3d04(0x08)
	bool K2Node_CustomEvent_IsGrounded; // 0x3d0c(0x01)
	char UnknownData_3D0D[0x3]; // 0x3d0d(0x03)
	struct FName Temp_name_Variable_5; // 0x3d10(0x08)
	struct FHitResult CallFunc_K2_SetWorldLocation_SweepHitResult; // 0x3d18(0x88)
	struct FName Temp_name_Variable_6; // 0x3da0(0x08)
	struct FVector CallFunc_GetPhysicsLinearVelocity_ReturnValue; // 0x3da8(0x0c)
	struct FName Temp_name_Variable_7; // 0x3db4(0x08)
	struct FName Temp_name_Variable_8; // 0x3dbc(0x08)
	struct FName Temp_name_Variable_9; // 0x3dc4(0x08)
	struct FName Temp_name_Variable_10; // 0x3dcc(0x08)
	struct FDelegate Temp_delegate_Variable_5; // 0x3dd4(0x10)
	char UnknownData_3DE4[0x4]; // 0x3de4(0x04)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_5; // 0x3de8(0x10)
	struct FDelegate Temp_delegate_Variable_6; // 0x3df8(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_6; // 0x3e08(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate; // 0x3e18(0x10)
	bool CallFunc_ShouldLastHitLaunchIntoRagdoll_bShouldRagdoll; // 0x3e28(0x01)
	char UnknownData_3E29[0x3]; // 0x3e29(0x03)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2; // 0x3e2c(0x10)
	struct FDelegate Temp_delegate_Variable_7; // 0x3e3c(0x10)
	char UnknownData_3E4C[0x4]; // 0x3e4c(0x04)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_7; // 0x3e50(0x10)
	struct FDelegate Temp_delegate_Variable_8; // 0x3e60(0x10)
	float K2Node_CustomEvent_DeltaSeconds; // 0x3e70(0x04)
	char UnknownData_3E74[0x4]; // 0x3e74(0x04)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_8; // 0x3e78(0x10)
	struct FVector CallFunc_ProcessTakePointHitDamage_WorldHitLocation; // 0x3e88(0x0c)
	struct FVector CallFunc_ProcessTakePointHitDamage_WorldHitNormal; // 0x3e94(0x0c)
	struct FVector CallFunc_ProcessTakePointHitDamage_VectorToHitSource; // 0x3ea0(0x0c)
	enum class EKSMovementDirection CallFunc_ProcessTakePointHitDamage_HitDirection; // 0x3eac(0x01)
	char UnknownData_3EAD[0x3]; // 0x3ead(0x03)
	struct FName K2Node_Event_SequenceName; // 0x3eb0(0x08)
	bool K2Node_SwitchName_CmpSuccess; // 0x3eb8(0x01)
	char UnknownData_3EB9[0x3]; // 0x3eb9(0x03)
	struct FVector K2Node_CustomEvent_Camera_Rotation; // 0x3ebc(0x0c)
	bool K2Node_CustomEvent_Uses_Rotation; // 0x3ec8(0x01)
	char UnknownData_3EC9[0x3]; // 0x3ec9(0x03)
	struct FVector K2Node_CustomEvent_Camera_Offset; // 0x3ecc(0x0c)
	float CallFunc_BreakVector_X; // 0x3ed8(0x04)
	float CallFunc_BreakVector_Y; // 0x3edc(0x04)
	float CallFunc_BreakVector_Z; // 0x3ee0(0x04)
	float CallFunc_BreakVector_X_2; // 0x3ee4(0x04)
	float CallFunc_BreakVector_Y_2; // 0x3ee8(0x04)
	float CallFunc_BreakVector_Z_2; // 0x3eec(0x04)
	struct FDelegate Temp_delegate_Variable_9; // 0x3ef0(0x10)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult; // 0x3f00(0x88)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult; // 0x3f88(0x88)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_9; // 0x4010(0x10)
	struct FDelegate Temp_delegate_Variable_10; // 0x4020(0x10)
	struct USkinnableSkeletalMeshComponent* K2Node_DynamicCast_AsSkinnable_Skeletal_Mesh_Component; // 0x4030(0x08)
	bool K2Node_DynamicCast_bSuccess; // 0x4038(0x01)
	char UnknownData_4039[0x7]; // 0x4039(0x07)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_10; // 0x4040(0x10)
	struct USkinnableSkeletalMeshComponent* K2Node_DynamicCast_AsSkinnable_Skeletal_Mesh_Component_2; // 0x4050(0x08)
	bool K2Node_DynamicCast_bSuccess_2; // 0x4058(0x01)
	char UnknownData_4059[0x7]; // 0x4059(0x07)
	struct FDamageEffect K2Node_CustomEvent_Effect_3; // 0x4060(0x50)
	struct UObject* K2Node_ClassDynamicCast_AsKSDamage_Type_Base; // 0x40b0(0x08)
	bool K2Node_ClassDynamicCast_bSuccess; // 0x40b8(0x01)
	bool Temp_bool_Has_Been_Initd_Variable; // 0x40b9(0x01)
	char UnknownData_40BA[0x2]; // 0x40ba(0x02)
	struct FDelegate Temp_delegate_Variable_11; // 0x40bc(0x10)
	bool Temp_bool_IsClosed_Variable; // 0x40cc(0x01)
	bool K2Node_Event_bVisible; // 0x40cd(0x01)
	char UnknownData_40CE[0x2]; // 0x40ce(0x02)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_11; // 0x40d0(0x10)
	bool Temp_bool_Has_Been_Initd_Variable_2; // 0x40e0(0x01)
	char UnknownData_40E1[0x3]; // 0x40e1(0x03)
	struct FDelegate Temp_delegate_Variable_12; // 0x40e4(0x10)
	char UnknownData_40F4[0x4]; // 0x40f4(0x04)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_12; // 0x40f8(0x10)
	struct FDamageEffect K2Node_CustomEvent_Effect_2; // 0x4108(0x50)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3; // 0x4158(0x10)
	struct UObject* K2Node_ClassDynamicCast_AsKSDamage_Type_Base_2; // 0x4168(0x08)
	bool K2Node_ClassDynamicCast_bSuccess_2; // 0x4170(0x01)
	char UnknownData_4171[0x3]; // 0x4171(0x03)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4; // 0x4174(0x10)
	char UnknownData_4184[0x4]; // 0x4184(0x04)
	struct UKSBloodSplatterComponent* K2Node_DynamicCast_AsKSBlood_Splatter_Component; // 0x4188(0x08)
	bool K2Node_DynamicCast_bSuccess_3; // 0x4190(0x01)
	enum class EKSPowerSlideEndReason K2Node_Event_EndReason; // 0x4191(0x01)
	bool Temp_bool_IsClosed_Variable_2; // 0x4192(0x01)
	bool CallFunc_GetLocalSettingAsBool_OutBool; // 0x4193(0x01)
	char UnknownData_4194[0x4]; // 0x4194(0x04)
	struct FDamageEffect K2Node_CustomEvent_Effect; // 0x4198(0x50)
	struct UObject* K2Node_ClassDynamicCast_AsKSDamage_Type_Base_3; // 0x41e8(0x08)
	bool K2Node_ClassDynamicCast_bSuccess_3; // 0x41f0(0x01)
	char UnknownData_41F1[0x7]; // 0x41f1(0x07)
	struct FCombatEventInfo K2Node_Event_DamageInfo_2; // 0x41f8(0x60)
	float K2Node_Event_DamageAmount; // 0x4258(0x04)
	char UnknownData_425C[0x4]; // 0x425c(0x04)
	struct UObject* K2Node_Event_DamageTypeClass; // 0x4260(0x08)
	struct AActor* K2Node_Event_DamageCauser; // 0x4268(0x08)
	struct FVector K2Node_Event_DamageOrigin; // 0x4270(0x0c)
	char UnknownData_427C[0x4]; // 0x427c(0x04)
	struct FCombatEventInfo K2Node_Event_DamageInfo; // 0x4280(0x60)
	struct FName Temp_name_Variable_11; // 0x42e0(0x08)
	struct FName Temp_name_Variable_12; // 0x42e8(0x08)
	struct FDelegate Temp_delegate_Variable_13; // 0x42f0(0x10)
	struct UParticleSystem* CallFunc_GetHitPawnEffectOverride_ParticleSystem; // 0x4300(0x08)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_13; // 0x4308(0x10)
	struct FDamageEffect K2Node_Event_Effect_2; // 0x4318(0x50)
	struct FDamageEffect K2Node_Event_Effect; // 0x4368(0x50)
	struct FVector CallFunc_ProcessTakePointHitDamage_WorldHitLocation_2; // 0x43b8(0x0c)
	struct FVector CallFunc_ProcessTakePointHitDamage_WorldHitNormal_2; // 0x43c4(0x0c)
	struct FVector CallFunc_ProcessTakePointHitDamage_VectorToHitSource_2; // 0x43d0(0x0c)
	enum class EKSMovementDirection CallFunc_ProcessTakePointHitDamage_HitDirection_2; // 0x43dc(0x01)
	char UnknownData_43DD[0x3]; // 0x43dd(0x03)
	struct UObject* K2Node_ClassDynamicCast_AsKSDamage_Type_Base_4; // 0x43e0(0x08)
	bool K2Node_ClassDynamicCast_bSuccess_4; // 0x43e8(0x01)
	char UnknownData_43E9[0x7]; // 0x43e9(0x07)
	struct AKSCharacterBase* K2Node_CustomEvent_Character_3; // 0x43f0(0x08)
	struct FDelegate Temp_delegate_Variable_14; // 0x43f8(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_14; // 0x4408(0x10)
	struct FDelegate Temp_delegate_Variable_15; // 0x4418(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_15; // 0x4428(0x10)
	struct FDelegate Temp_delegate_Variable_16; // 0x4438(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_16; // 0x4448(0x10)
	struct FDelegate Temp_delegate_Variable_17; // 0x4458(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_17; // 0x4468(0x10)
	struct FDelegate Temp_delegate_Variable_18; // 0x4478(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_18; // 0x4488(0x10)
	struct FDelegate Temp_delegate_Variable_19; // 0x4498(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_19; // 0x44a8(0x10)
	struct APlayerState* K2Node_CustomEvent_Player; // 0x44b8(0x08)
	struct FDelegate Temp_delegate_Variable_20; // 0x44c0(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_20; // 0x44d0(0x10)
	struct TScriptInterface<None> K2Node_DynamicCast_AsINameplate_Widget; // 0x44e0(0x10)
	bool K2Node_DynamicCast_bSuccess_4; // 0x44f0(0x01)
	char UnknownData_44F1[0x3]; // 0x44f1(0x03)
	float K2Node_Event_ExtraTime; // 0x44f4(0x04)
	struct TScriptInterface<None> K2Node_DynamicCast_AsINameplate_Widget_2; // 0x44f8(0x10)
	bool K2Node_DynamicCast_bSuccess_5; // 0x4508(0x01)
	char UnknownData_4509[0x7]; // 0x4509(0x07)
	struct TScriptInterface<None> K2Node_DynamicCast_AsINameplate_Widget_3; // 0x4510(0x10)
	bool K2Node_DynamicCast_bSuccess_6; // 0x4520(0x01)
	bool Temp_bool_Has_Been_Initd_Variable_3; // 0x4521(0x01)
	enum class EMovementMode K2Node_Event_PrevMovementMode; // 0x4522(0x01)
	enum class EMovementMode K2Node_Event_NewMovementMode; // 0x4523(0x01)
	enum class None K2Node_Event_PrevCustomMode; // 0x4524(0x01)
	enum class None K2Node_Event_NewCustomMode; // 0x4525(0x01)
	char UnknownData_4526[0x2]; // 0x4526(0x02)
	struct UKSCharacterMovementComponent* K2Node_DynamicCast_AsKSCharacter_Movement_Component; // 0x4528(0x08)
	bool K2Node_DynamicCast_bSuccess_7; // 0x4530(0x01)
	char UnknownData_4531[0x7]; // 0x4531(0x07)
	struct FCombatEventInfo K2Node_CustomEvent_EventInfo_2; // 0x4538(0x60)
	int32_t K2Node_CustomEvent_ExpBonus_2; // 0x4598(0x04)
	char UnknownData_459C[0x4]; // 0x459c(0x04)
	struct AKSPlayerState* K2Node_CustomEvent_Revivee; // 0x45a0(0x08)
	struct AKSPlayerState* K2Node_CustomEvent_Reviver; // 0x45a8(0x08)
	int32_t K2Node_CustomEvent_ExpBonus; // 0x45b0(0x04)
	char UnknownData_45B4[0x4]; // 0x45b4(0x04)
	struct AKSPlayerState* K2Node_DynamicCast_AsKSPlayer_State; // 0x45b8(0x08)
	bool K2Node_DynamicCast_bSuccess_8; // 0x45c0(0x01)
	char UnknownData_45C1[0x7]; // 0x45c1(0x07)
	struct AKSPlayerState* K2Node_DynamicCast_AsKSPlayer_State_2; // 0x45c8(0x08)
	bool K2Node_DynamicCast_bSuccess_9; // 0x45d0(0x01)
	char UnknownData_45D1[0x3]; // 0x45d1(0x03)
	struct FDelegate Temp_delegate_Variable_21; // 0x45d4(0x10)
	char UnknownData_45E4[0x4]; // 0x45e4(0x04)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_21; // 0x45e8(0x10)
	struct FDelegate Temp_delegate_Variable_22; // 0x45f8(0x10)
	struct FCombatEventInfo K2Node_CustomEvent_EventInfo; // 0x4608(0x60)
	struct AKSPlayerState* K2Node_DynamicCast_AsKSPlayer_State_3; // 0x4668(0x08)
	bool K2Node_DynamicCast_bSuccess_10; // 0x4670(0x01)
	char UnknownData_4671[0x7]; // 0x4671(0x07)
	struct AKSPlayerState* K2Node_DynamicCast_AsKSPlayer_State_4; // 0x4678(0x08)
	bool K2Node_DynamicCast_bSuccess_11; // 0x4680(0x01)
	bool Temp_bool_IsClosed_Variable_3; // 0x4681(0x01)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable; // 0x4682(0x01)
	bool K2Node_Event_Enabled; // 0x4683(0x01)
	char UnknownData_4684[0x4]; // 0x4684(0x04)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_22; // 0x4688(0x10)
	struct FDelegate Temp_delegate_Variable_23; // 0x4698(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_23; // 0x46a8(0x10)
	struct FDelegate Temp_delegate_Variable_24; // 0x46b8(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_24; // 0x46c8(0x10)
	struct AKSCharacter* K2Node_Event_Reviver_3; // 0x46d8(0x08)
	float K2Node_Event_ReviveTime; // 0x46e0(0x04)
	bool K2Node_Event_Remote; // 0x46e4(0x01)
	char UnknownData_46E5[0x3]; // 0x46e5(0x03)
	struct AKSCharacter* K2Node_Event_Reviver_2; // 0x46e8(0x08)
	struct AKSCharacter* K2Node_Event_Reviver; // 0x46f0(0x08)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable_2; // 0x46f8(0x01)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable_3; // 0x46f9(0x01)
	bool Temp_bool_Has_Been_Initd_Variable_4; // 0x46fa(0x01)
	bool Temp_bool_IsClosed_Variable_4; // 0x46fb(0x01)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable_4; // 0x46fc(0x01)
	char UnknownData_46FD[0x3]; // 0x46fd(0x03)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5; // 0x4700(0x10)
	bool K2Node_CustomEvent_IsSprinting; // 0x4710(0x01)
	bool K2Node_CustomEvent_IsDodgeRolling_2; // 0x4711(0x01)
	bool Temp_bool_Has_Been_Initd_Variable_5; // 0x4712(0x01)
	char UnknownData_4713[0x1]; // 0x4713(0x01)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6; // 0x4714(0x10)
	float K2Node_Event_DeltaSeconds; // 0x4724(0x04)
	struct FVector CallFunc_KeepActionCameraAboveWater_OutBoomPosition; // 0x4728(0x0c)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult_2; // 0x4734(0x88)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_7; // 0x47bc(0x10)
	struct FDelegate Temp_delegate_Variable_25; // 0x47cc(0x10)
	bool Temp_bool_Variable; // 0x47dc(0x01)
	char UnknownData_47DD[0x3]; // 0x47dd(0x03)
	struct FVector K2Node_Event_BreakingLocation; // 0x47e0(0x0c)
	struct FVector K2Node_Event_BreakingDirection; // 0x47ec(0x0c)
	struct FVector K2Node_Event_BreakingNormal; // 0x47f8(0x0c)
	char UnknownData_4804[0x4]; // 0x4804(0x04)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_25; // 0x4808(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_8; // 0x4818(0x10)
	bool K2Node_CustomEvent_IsPowerSliding; // 0x4828(0x01)
	char UnknownData_4829[0x3]; // 0x4829(0x03)
	float CallFunc_GetTargetFov_TargetFov; // 0x482c(0x04)
	bool K2Node_CustomEvent_IsZiplining; // 0x4830(0x01)
	char UnknownData_4831[0x7]; // 0x4831(0x07)
	struct UMaster_WeaponComponent_C* K2Node_DynamicCast_AsMaster_Weapon_Component; // 0x4838(0x08)
	bool K2Node_DynamicCast_bSuccess_12; // 0x4840(0x01)
	char UnknownData_4841[0x3]; // 0x4841(0x03)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_9; // 0x4844(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_10; // 0x4854(0x10)
	bool Temp_bool_IsClosed_Variable_5; // 0x4864(0x01)
	bool K2Node_Event_bEnterNoseDive; // 0x4865(0x01)
	char UnknownData_4866[0x2]; // 0x4866(0x02)
	float K2Node_Event_AnimLength; // 0x4868(0x04)
	char UnknownData_486C[0x4]; // 0x486c(0x04)
	struct FString K2Node_Event_SwingMontageSectionName; // 0x4870(0x10)
	struct UMaster_WeaponComponent_C* K2Node_DynamicCast_AsMaster_Weapon_Component_2; // 0x4880(0x08)
	bool K2Node_DynamicCast_bSuccess_13; // 0x4888(0x01)
	char UnknownData_4889[0x3]; // 0x4889(0x03)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_11; // 0x488c(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_12; // 0x489c(0x10)
	char UnknownData_48AC[0x4]; // 0x48ac(0x04)
	struct APlayerController* K2Node_Event_PC_2; // 0x48b0(0x08)
	struct APlayerController* K2Node_Event_PC; // 0x48b8(0x08)
	bool K2Node_Event_UpdateTargetRotation; // 0x48c0(0x01)
	bool K2Node_Event_AffectCapsule; // 0x48c1(0x01)
	char UnknownData_48C2[0x2]; // 0x48c2(0x02)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_13; // 0x48c4(0x10)
	char UnknownData_48D4[0x4]; // 0x48d4(0x04)
	struct FKey K2Node_InputKeyEvent_Key; // 0x48d8(0x18)
	struct FRotator CallFunc_DetermineKnockbackFacing_ActorRotation; // 0x48f0(0x0c)
	char UnknownData_48FC[0x4]; // 0x48fc(0x04)
	struct UParticleSystem* Temp_object_Variable; // 0x4900(0x08)
	bool Temp_bool_Variable_2; // 0x4908(0x01)
	char UnknownData_4909[0x3]; // 0x4909(0x03)
	struct FDelegate Temp_delegate_Variable_26; // 0x490c(0x10)
	struct FHitResult K2Node_Event_Hit; // 0x491c(0x88)
	char UnknownData_49A4[0x4]; // 0x49a4(0x04)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_26; // 0x49a8(0x10)
	struct FDelegate Temp_delegate_Variable_27; // 0x49b8(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_27; // 0x49c8(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_14; // 0x49d8(0x10)
	enum class HitEnum Temp_byte_Variable; // 0x49e8(0x01)
	enum class HitEnum Temp_byte_Variable_2; // 0x49e9(0x01)
	enum class HitEnum Temp_byte_Variable_3; // 0x49ea(0x01)
	enum class HitEnum Temp_byte_Variable_4; // 0x49eb(0x01)
	bool K2Node_CustomEvent_IsDodgeRolling; // 0x49ec(0x01)
	enum class EKSMovementDirection Temp_byte_Variable_5; // 0x49ed(0x01)
	char UnknownData_49EE[0x2]; // 0x49ee(0x02)
	struct FVector Temp_struct_Variable_28; // 0x49f0(0x0c)
	enum class HitEnum K2Node_Select_Default; // 0x49fc(0x01)
	bool Temp_bool_Variable_3; // 0x49fd(0x01)
	bool Temp_bool_Variable_4; // 0x49fe(0x01)
	char UnknownData_49FF[0x1]; // 0x49ff(0x01)
	struct FVector K2Node_Select_Default_2; // 0x4a00(0x0c)
	char UnknownData_4A0C[0x4]; // 0x4a0c(0x04)
	struct UParticleSystem* K2Node_Select_Default_3; // 0x4a10(0x08)
	struct UParticleSystem* K2Node_Select_Default_4; // 0x4a18(0x08)
	struct AKSCharacter* K2Node_CustomEvent_Character_2; // 0x4a20(0x08)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_15; // 0x4a28(0x10)
	struct FSettingDelegateStruct K2Node_MakeStruct_SettingDelegateStruct; // 0x4a38(0x20)
	struct UMaster_WeaponComponent_C* K2Node_DynamicCast_AsMaster_Weapon_Component_3; // 0x4a58(0x08)
	bool K2Node_DynamicCast_bSuccess_14; // 0x4a60(0x01)
	char UnknownData_4A61[0x7]; // 0x4a61(0x07)
	struct UMaster_WeaponComponent_C* K2Node_DynamicCast_AsMaster_Weapon_Component_4; // 0x4a68(0x08)
	bool K2Node_DynamicCast_bSuccess_15; // 0x4a70(0x01)
	char UnknownData_4A71[0x3]; // 0x4a71(0x03)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_16; // 0x4a74(0x10)
	bool Temp_bool_Has_Been_Initd_Variable_6; // 0x4a84(0x01)
	char UnknownData_4A85[0x3]; // 0x4a85(0x03)
	struct FDelegate Temp_delegate_Variable_28; // 0x4a88(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_29; // 0x4a98(0x10)
	struct FDelegate Temp_delegate_Variable_29; // 0x4aa8(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_30; // 0x4ab8(0x10)
	struct FDelegate Temp_delegate_Variable_30; // 0x4ac8(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_31; // 0x4ad8(0x10)
	struct FDelegate Temp_delegate_Variable_31; // 0x4ae8(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_32; // 0x4af8(0x10)
	bool K2Node_Event_bFullyHealed; // 0x4b08(0x01)
	bool Temp_bool_Has_Been_Initd_Variable_7; // 0x4b09(0x01)
	char UnknownData_4B0A[0x2]; // 0x4b0a(0x02)
	struct FDelegate Temp_delegate_Variable_32; // 0x4b0c(0x10)
	char UnknownData_4B1C[0x4]; // 0x4b1c(0x04)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_33; // 0x4b20(0x10)
	struct FDelegate Temp_delegate_Variable_33; // 0x4b30(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_34; // 0x4b40(0x10)
	struct FDelegate Temp_delegate_Variable_34; // 0x4b50(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_35; // 0x4b60(0x10)
	bool Temp_bool_IsClosed_Variable_6; // 0x4b70(0x01)
	char UnknownData_4B71[0x3]; // 0x4b71(0x03)
	struct FDelegate Temp_delegate_Variable_35; // 0x4b74(0x10)
	char UnknownData_4B84[0x4]; // 0x4b84(0x04)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_36; // 0x4b88(0x10)
	struct FDelegate Temp_delegate_Variable_36; // 0x4b98(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_37; // 0x4ba8(0x10)
	struct FDelegate Temp_delegate_Variable_37; // 0x4bb8(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_38; // 0x4bc8(0x10)
	struct UKSZiplineMeshComponent* K2Node_DynamicCast_AsKSZipline_Mesh_Component; // 0x4bd8(0x08)
	bool K2Node_DynamicCast_bSuccess_16; // 0x4be0(0x01)
	char UnknownData_4BE1[0x7]; // 0x4be1(0x07)
	struct UKSZiplineMeshComponent* K2Node_DynamicCast_AsKSZipline_Mesh_Component_2; // 0x4be8(0x08)
	bool K2Node_DynamicCast_bSuccess_17; // 0x4bf0(0x01)
	char UnknownData_4BF1[0x3]; // 0x4bf1(0x03)
	float K2Node_InputAxisKeyEvent_AxisValue_2; // 0x4bf4(0x04)
	float K2Node_InputAxisKeyEvent_AxisValue; // 0x4bf8(0x04)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_17; // 0x4bfc(0x10)
	bool Temp_bool_IsClosed_Variable_7; // 0x4c0c(0x01)
	char UnknownData_4C0D[0x3]; // 0x4c0d(0x03)
	struct UKSZiplineMeshComponent* K2Node_DynamicCast_AsKSZipline_Mesh_Component_3; // 0x4c10(0x08)
	bool K2Node_DynamicCast_bSuccess_18; // 0x4c18(0x01)
	char UnknownData_4C19[0x7]; // 0x4c19(0x07)
	struct UKSZiplineMeshComponent* K2Node_DynamicCast_AsKSZipline_Mesh_Component_4; // 0x4c20(0x08)
	bool K2Node_DynamicCast_bSuccess_19; // 0x4c28(0x01)
	char UnknownData_4C29[0x7]; // 0x4c29(0x07)
	struct AKSCharacter* K2Node_CustomEvent_Character; // 0x4c30(0x08)
	struct AKSItemDrop* K2Node_CustomEvent_ItemDrop; // 0x4c38(0x08)
	struct UKSItem* K2Node_CustomEvent_Item; // 0x4c40(0x08)
	enum class HitEnum Temp_byte_Variable_6; // 0x4c48(0x01)
	enum class HitEnum Temp_byte_Variable_7; // 0x4c49(0x01)
	enum class HitEnum Temp_byte_Variable_8; // 0x4c4a(0x01)
	char UnknownData_4C4B[0x1]; // 0x4c4b(0x01)
	float K2Node_Event_InteractTime; // 0x4c4c(0x04)
	float CallFunc_BreakVector_X_3; // 0x4c50(0x04)
	float CallFunc_BreakVector_Y_3; // 0x4c54(0x04)
	float CallFunc_BreakVector_Z_3; // 0x4c58(0x04)
	char UnknownData_4C5C[0x4]; // 0x4c5c(0x04)
	struct AKSPlayerController* K2Node_DynamicCast_AsKSPlayer_Controller; // 0x4c60(0x08)
	bool K2Node_DynamicCast_bSuccess_20; // 0x4c68(0x01)
	char UnknownData_4C69[0x3]; // 0x4c69(0x03)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult_3; // 0x4c6c(0x88)
	char UnknownData_4CF4[0x4]; // 0x4cf4(0x04)
	struct AKSPlayerController* K2Node_DynamicCast_AsKSPlayer_Controller_2; // 0x4cf8(0x08)
	bool K2Node_DynamicCast_bSuccess_21; // 0x4d00(0x01)
	bool K2Node_SwitchEnum_CmpSuccess; // 0x4d01(0x01)
	char UnknownData_4D02[0x6]; // 0x4d02(0x06)
	struct AKSPlayerController* K2Node_DynamicCast_AsKSPlayer_Controller_3; // 0x4d08(0x08)
	bool K2Node_DynamicCast_bSuccess_22; // 0x4d10(0x01)
	bool K2Node_SwitchEnum_CmpSuccess_2; // 0x4d11(0x01)
	bool K2Node_SwitchEnum_CmpSuccess_3; // 0x4d12(0x01)
	enum class EFlashBangIntensity K2Node_Event_Intensity; // 0x4d13(0x01)
	bool K2Node_SwitchEnum_CmpSuccess_4; // 0x4d14(0x01)
	bool Temp_bool_Has_Been_Initd_Variable_8; // 0x4d15(0x01)
	char UnknownData_4D16[0x2]; // 0x4d16(0x02)
	struct TScriptInterface<None> CallFunc_AddOrUpdateBlendable_InBlendableObject_CastInput; // 0x4d18(0x10)
	struct TScriptInterface<None> CallFunc_AddOrUpdateBlendable_InBlendableObject_CastInput_2; // 0x4d28(0x10)
	enum class HitEnum Temp_byte_Variable_9; // 0x4d38(0x01)
	enum class EKSMovementDirection Temp_byte_Variable_10; // 0x4d39(0x01)
	enum class HitEnum K2Node_Select_Default_5; // 0x4d3a(0x01)
	char UnknownData_4D3B[0x5]; // 0x4d3b(0x05)
	struct UAnimMontage* Temp_object_Variable_2; // 0x4d40(0x08)
	struct UAnimMontage* Temp_object_Variable_3; // 0x4d48(0x08)
	bool Temp_bool_IsClosed_Variable_8; // 0x4d50(0x01)
	bool Temp_bool_Variable_5; // 0x4d51(0x01)
	char UnknownData_4D52[0x6]; // 0x4d52(0x06)
	struct FLastHitImpulse K2Node_MakeStruct_LastHitImpulse; // 0x4d58(0x40)
	struct UAnimMontage* K2Node_Select_Default_6; // 0x4d98(0x08)

	void Zipline Pulley Unhide(); // Function MainCharacter.MainCharacter_C.Zipline Pulley Unhide // (Native|Public|BlueprintCallable) // @ game+0x19f8dd0
	void Zipline Pulley Hide(); // Function MainCharacter.MainCharacter_C.Zipline Pulley Hide // (Native|Public|BlueprintCallable) // @ game+0x19f8db0
	void WasLastHitHeadshot(bool bpp__bHeadshot__pf); // Function MainCharacter.MainCharacter_C.WasLastHitHeadshot // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x19f8d10
	void VerifyLastHitDamageType(struct UObject* bpp__DamageType__pf, bool bpp__IsRelatedToThisType__pf); // Function MainCharacter.MainCharacter_C.VerifyLastHitDamageType // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x19f8c30
	void VerifyLastHitBone(struct FName bpp__ParentBoneName__pf, bool bpp__IsRelatedToThisBone__pf); // Function MainCharacter.MainCharacter_C.VerifyLastHitBone // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x19f8b50
	void UserConstructionScript(); // Function MainCharacter.MainCharacter_C.UserConstructionScript // (Native|Event|Public|BlueprintCallable) // @ game+0x19f8b30
	void Update Flash Bang PP(); // Function MainCharacter.MainCharacter_C.Update Flash Bang PP // (Native|Public|BlueprintCallable) // @ game+0x19f8b10
	void Update Action Camera(struct FVector bpp__CameraxRotation__pfT, bool bpp__UsesxRotation__pfT, struct FVector bpp__CameraxOffset__pfT); // Function MainCharacter.MainCharacter_C.Update Action Camera // (Native|Public|HasDefaults|BlueprintCallable) // @ game+0x19f89d0
	void UpdateRagdollOnGround(bool bpp__IsGrounded__pf); // Function MainCharacter.MainCharacter_C.UpdateRagdollOnGround // (Net|Native|Event|NetMulticast|Public|BlueprintCallable) // @ game+0x19f88c0
	void UpdateRagdollMeshLocation(); // Function MainCharacter.MainCharacter_C.UpdateRagdollMeshLocation // (Native|Public|BlueprintCallable) // @ game+0x19f88a0
	void UpdateRagdoll(float bpp__DeltaSeconds__pf); // Function MainCharacter.MainCharacter_C.UpdateRagdoll // (Native|Public|BlueprintCallable) // @ game+0x19f8950
	void UpdatePlayerState(struct APlayerState* bpp__Player__pf); // Function MainCharacter.MainCharacter_C.UpdatePlayerState // (Native|Public|BlueprintCallable) // @ game+0x19f8810
	void UpdateHealthPP(); // Function MainCharacter.MainCharacter_C.UpdateHealthPP // (Native|Public|BlueprintCallable) // @ game+0x19f87f0
	void UpdateDebugHealthVisibility(); // Function MainCharacter.MainCharacter_C.UpdateDebugHealthVisibility // (Native|Event|Public|BlueprintCallable) // @ game+0x19f87d0
	void UnhideZiplinePulley(); // Function MainCharacter.MainCharacter_C.UnhideZiplinePulley // (Native|Event|Public|BlueprintCallable) // @ game+0x19f87b0
	void UnhideUplineDevice(); // Function MainCharacter.MainCharacter_C.UnhideUplineDevice // (Native|Event|Public|BlueprintCallable) // @ game+0x19f8790
	void TurnOffCapsulePhysics_Server(); // Function MainCharacter.MainCharacter_C.TurnOffCapsulePhysics_Server // (Net|Native|Event|Public|NetServer|BlueprintCallable) // @ game+0x19f8750
	void TurnOffCapsulePhysics(); // Function MainCharacter.MainCharacter_C.TurnOffCapsulePhysics // (Net|Native|Event|NetMulticast|Public|BlueprintCallable) // @ game+0x19f8770
	void Transition To Main Camera(); // Function MainCharacter.MainCharacter_C.Transition To Main Camera // (Native|Public|BlueprintCallable) // @ game+0x19f8730
	void Transition To ADS Camera(); // Function MainCharacter.MainCharacter_C.Transition To ADS Camera // (Native|Public|BlueprintCallable) // @ game+0x19f8710
	void SwitchToSnapshotPose(); // Function MainCharacter.MainCharacter_C.SwitchToSnapshotPose // (Native|Public|BlueprintCallable) // @ game+0x19f86f0
	void StopReviveSFX(); // Function MainCharacter.MainCharacter_C.StopReviveSFX // (Native|Public|BlueprintCallable) // @ game+0x19f86d0
	void StopLowHealthSFX(); // Function MainCharacter.MainCharacter_C.StopLowHealthSFX // (Native|Public|BlueprintCallable) // @ game+0x19f86b0
	void Start Viewed Down Hit(); // Function MainCharacter.MainCharacter_C.Start Viewed Down Hit // (Native|Public|BlueprintCallable) // @ game+0x19f8690
	void StartImmunity__UpdateFunc(); // Function MainCharacter.MainCharacter_C.StartImmunity__UpdateFunc // (Native|Public) // @ game+0x19f8670
	void StartImmunity__FinishedFunc(); // Function MainCharacter.MainCharacter_C.StartImmunity__FinishedFunc // (Native|Public) // @ game+0x19f8650
	void StartHacking(); // Function MainCharacter.MainCharacter_C.StartHacking // (Native|Event|Public|BlueprintCallable) // @ game+0x19f8630
	void SprintFOVTimeline__UpdateFunc(); // Function MainCharacter.MainCharacter_C.SprintFOVTimeline__UpdateFunc // (Native|Public) // @ game+0x19f8610
	void SprintFOVTimeline__FinishedFunc(); // Function MainCharacter.MainCharacter_C.SprintFOVTimeline__FinishedFunc // (Native|Public) // @ game+0x19f85f0
	void ShowDebugLocation(bool bpp__bVisible__pf); // Function MainCharacter.MainCharacter_C.ShowDebugLocation // (Native|Event|Public) // @ game+0x19f8560
	void ShouldLastHitLaunchIntoRagdoll(bool bpp__bShouldRagdoll__pf); // Function MainCharacter.MainCharacter_C.ShouldLastHitLaunchIntoRagdoll // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x19f84c0
	void SFXStateChangeReset(); // Function MainCharacter.MainCharacter_C.SFXStateChangeReset // (Native|Public|BlueprintCallable) // @ game+0x19f82f0
	void SFXStateChangeMax(); // Function MainCharacter.MainCharacter_C.SFXStateChangeMax // (Native|Public|BlueprintCallable) // @ game+0x19f82d0
	void SFXStateChangeHalf(); // Function MainCharacter.MainCharacter_C.SFXStateChangeHalf // (Native|Public|BlueprintCallable) // @ game+0x19f82b0
	void SFXRingHalfSTOP(); // Function MainCharacter.MainCharacter_C.SFXRingHalfSTOP // (Native|Public|BlueprintCallable) // @ game+0x19f8290
	void SFXRingHalfPlay(); // Function MainCharacter.MainCharacter_C.SFXRingHalfPlay // (Native|Public|BlueprintCallable) // @ game+0x19f8270
	void SFXRingFullSTOP(); // Function MainCharacter.MainCharacter_C.SFXRingFullSTOP // (Native|Public|BlueprintCallable) // @ game+0x19f8250
	void SFXRingFullPlay(); // Function MainCharacter.MainCharacter_C.SFXRingFullPlay // (Native|Public|BlueprintCallable) // @ game+0x19f8230
	void Set up ADS Blur Dynamic Material(); // Function MainCharacter.MainCharacter_C.Set up ADS Blur Dynamic Material // (Native|Public|BlueprintCallable) // @ game+0x19f84a0
	void Set Health SFX RTPC(); // Function MainCharacter.MainCharacter_C.Set Health SFX RTPC // (Native|Public|BlueprintCallable) // @ game+0x19f8480
	void Setup Debug Info Widget(); // Function MainCharacter.MainCharacter_C.Setup Debug Info Widget // (Native|Public|BlueprintCallable) // @ game+0x19f8460
	void SetPostProcessHealthValue(float bpp__Health__pf); // Function MainCharacter.MainCharacter_C.SetPostProcessHealthValue // (Native|Public|BlueprintCallable) // @ game+0x19f83e0
	void SetHitTargetArmorLevelRTPC(struct AActor* bpp__HitxTarget__pfT, struct AActor* bpp__RTPCxActor__pfT); // Function MainCharacter.MainCharacter_C.SetHitTargetArmorLevelRTPC // (Native|Public|BlueprintCallable) // @ game+0x19f8310
	void RestoreNormalCamera(); // Function MainCharacter.MainCharacter_C.RestoreNormalCamera // (Native|Public|BlueprintCallable) // @ game+0x19f8210
	void ReevaluateDebugWidgetAttachment(); // Function MainCharacter.MainCharacter_C.ReevaluateDebugWidgetAttachment // (Native|Public|BlueprintCallable) // @ game+0x19f81f0
	void ReceiveTick(float bpp__DeltaSeconds__pf); // Function MainCharacter.MainCharacter_C.ReceiveTick // (Native|Event|Public) // @ game+0x19f8170
	void ReceiveBeginPlay(); // Function MainCharacter.MainCharacter_C.ReceiveBeginPlay // (Native|Event|Public) // @ game+0x19f8150
	void Play Viewed Sonar Hit(struct FDamageEffect bpp__Effect__pf); // Function MainCharacter.MainCharacter_C.Play Viewed Sonar Hit // (Native|Public|BlueprintCallable) // @ game+0x19f8060
	void Play Viewed EMP Hit(struct FDamageEffect bpp__Effect__pf); // Function MainCharacter.MainCharacter_C.Play Viewed EMP Hit // (Native|Public|BlueprintCallable) // @ game+0x19f7f70
	void Play Viewed Blood Hit(struct FDamageEffect bpp__Effect__pf); // Function MainCharacter.MainCharacter_C.Play Viewed Blood Hit // (Native|Public|BlueprintCallable) // @ game+0x19f7e80
	void Play Martial Artist Target Front(); // Function MainCharacter.MainCharacter_C.Play Martial Artist Target Front // (Native|Public|BlueprintCallable) // @ game+0x19f7e60
	void Play Martial Artist Target Back(); // Function MainCharacter.MainCharacter_C.Play Martial Artist Target Back // (Native|Public|BlueprintCallable) // @ game+0x19f7e40
	void Play Martial Artist Instigator Front(); // Function MainCharacter.MainCharacter_C.Play Martial Artist Instigator Front // (Native|Public|BlueprintCallable) // @ game+0x19f7e20
	void Play Martial Artist Instigator Back(); // Function MainCharacter.MainCharacter_C.Play Martial Artist Instigator Back // (Native|Public|BlueprintCallable) // @ game+0x19f7e00
	void PlayReviveSFX(); // Function MainCharacter.MainCharacter_C.PlayReviveSFX // (Native|Public|BlueprintCallable) // @ game+0x19f7a80
	void PlayPickupFX(struct AActor* bpp__ItemActor__pf); // Function MainCharacter.MainCharacter_C.PlayPickupFX // (Native|Public|BlueprintCallable) // @ game+0x19f79f0
	void PlayHitMarkerSFX(struct FCombatEventInfo bpp__CombatEventInfo__pf); // Function MainCharacter.MainCharacter_C.PlayHitMarkerSFX // (Native|Public|BlueprintCallable) // @ game+0x19f78e0
	void PlayHitFromRadialDamage(struct FDamageEffect bpp__Effect__pf__const); // Function MainCharacter.MainCharacter_C.PlayHitFromRadialDamage // (BlueprintCosmetic|Native|Event|Public|HasOutParms) // @ game+0x19f7820
	void PlayHitFromPointDamage(struct FDamageEffect bpp__Effect__pf__const); // Function MainCharacter.MainCharacter_C.PlayHitFromPointDamage // (BlueprintCosmetic|Native|Event|Public|HasOutParms) // @ game+0x19f7760
	void PlayHitBySFX(struct FDamageEffect bpp__DamageEffect__pf); // Function MainCharacter.MainCharacter_C.PlayHitBySFX // (Native|Public|BlueprintCallable) // @ game+0x19f7670
	void PlayerRevived(struct AKSPlayerState* bpp__Revivee__pf, struct AKSPlayerState* bpp__Reviver__pf, int32_t bpp__ExpBonus__pf); // Function MainCharacter.MainCharacter_C.PlayerRevived // (Native|Public|BlueprintCallable) // @ game+0x19f7d00
	void PlayerDown(struct FCombatEventInfo bpp__EventInfo__pf, int32_t bpp__ExpBonus__pf); // Function MainCharacter.MainCharacter_C.PlayerDown // (Native|Public|BlueprintCallable) // @ game+0x19f7bb0
	void PlayerDeath(struct FCombatEventInfo bpp__EventInfo__pf); // Function MainCharacter.MainCharacter_C.PlayerDeath // (Native|Public|BlueprintCallable) // @ game+0x19f7aa0
	void PlayDownPPOnce(); // Function MainCharacter.MainCharacter_C.PlayDownPPOnce // (Native|Public|BlueprintCallable) // @ game+0x19f7650
	void PlayActionCameraSequence(struct FName bpp__SequenceName__pf); // Function MainCharacter.MainCharacter_C.PlayActionCameraSequence // (Native|Event|Public|BlueprintCallable) // @ game+0x19f75c0
	void OnZiplineChangeForFov(bool bpp__IsZiplining__pf); // Function MainCharacter.MainCharacter_C.OnZiplineChangeForFov // (Native|Public|BlueprintCallable) // @ game+0x19f7480
	void On Shoulder Swap Changed Event(struct AKSCharacter* bpp__Character__pf); // Function MainCharacter.MainCharacter_C.On Shoulder Swap Changed Event // (Native|Public|BlueprintCallable) // @ game+0x19f7530
	void On Anim Initialized(); // Function MainCharacter.MainCharacter_C.On Anim Initialized // (Native|Public|BlueprintCallable) // @ game+0x19f7510
	void OnUnhovered(float bpp__ExtraTime__pf); // Function MainCharacter.MainCharacter_C.OnUnhovered // (Native|Event|Public) // @ game+0x19f7400
	void OnStartSkydive(); // Function MainCharacter.MainCharacter_C.OnStartSkydive // (Native|Public|BlueprintCallable) // @ game+0x19f73e0
	void OnSprintChangedCallback(bool bpp__IsSprinting__pf); // Function MainCharacter.MainCharacter_C.OnSprintChangedCallback // (Native|Public|BlueprintCallable) // @ game+0x19f7350
	void OnReviveStart(struct AKSCharacter* bpp__Reviver__pf, float bpp__ReviveTime__pf, bool bpp__Remote__pf); // Function MainCharacter.MainCharacter_C.OnReviveStart // (Native|Event|Public) // @ game+0x19f7250
	void OnReviveInterrupt(struct AKSCharacter* bpp__Reviver__pf); // Function MainCharacter.MainCharacter_C.OnReviveInterrupt // (Native|Event|Public) // @ game+0x19f71c0
	void OnReviveComplete(struct AKSCharacter* bpp__Reviver__pf); // Function MainCharacter.MainCharacter_C.OnReviveComplete // (Native|Event|Public) // @ game+0x19f7130
	void OnPowerSlideChangedCallback(bool bpp__IsPowerSliding__pf); // Function MainCharacter.MainCharacter_C.OnPowerSlideChangedCallback // (Native|Public|BlueprintCallable) // @ game+0x19f70a0
	void OnLanded(struct FHitResult bpp__Hit__pf__const); // Function MainCharacter.MainCharacter_C.OnLanded // (Native|Event|Public|HasOutParms) // @ game+0x19f6fe0
	void OnItemPickedUp_Event_1(struct AKSCharacter* bpp__Character__pf, struct AKSItemDrop* bpp__ItemDrop__pf, struct UKSItem* bpp__Item__pf); // Function MainCharacter.MainCharacter_C.OnItemPickedUp_Event_1 // (Native|Public|BlueprintCallable) // @ game+0x19f6ee0
	void OnImmuneStart(); // Function MainCharacter.MainCharacter_C.OnImmuneStart // (BlueprintCosmetic|Native|Event|Public|BlueprintCallable) // @ game+0x19f6ec0
	void OnImmuneEnd(); // Function MainCharacter.MainCharacter_C.OnImmuneEnd // (BlueprintCosmetic|Native|Event|Public|BlueprintCallable) // @ game+0x19f6ea0
	void OnHovered(); // Function MainCharacter.MainCharacter_C.OnHovered // (Native|Event|Public) // @ game+0x19f6e80
	void OnHealthChanged(struct AKSCharacterBase* bpp__Character__pf__const); // Function MainCharacter.MainCharacter_C.OnHealthChanged // (Native|Public|BlueprintCallable) // @ game+0x19f6df0
	void OnGenderChanged(); // Function MainCharacter.MainCharacter_C.OnGenderChanged // (Native|Event|Public|BlueprintCallable) // @ game+0x19f6dd0
	void OnGadgetSwapped(); // Function MainCharacter.MainCharacter_C.OnGadgetSwapped // (Native|Event|Public) // @ game+0x19f6db0
	void OnFlashEffectStarted(); // Function MainCharacter.MainCharacter_C.OnFlashEffectStarted // (Native|Event|Public) // @ game+0x19f6d90
	void OnFlashEffectEnded(); // Function MainCharacter.MainCharacter_C.OnFlashEffectEnded // (Native|Event|Public) // @ game+0x19f6d70
	void OnFlashBangHit(enum class EFlashBangIntensity bpp__Intensity__pf); // Function MainCharacter.MainCharacter_C.OnFlashBangHit // (Native|Event|Public) // @ game+0x19f6cf0
	void OnFieldOfViewModChange(); // Function MainCharacter.MainCharacter_C.OnFieldOfViewModChange // (Native|Event|Public|BlueprintCallable) // @ game+0x19f6cd0
	void OnEndZiplineRagdoll(); // Function MainCharacter.MainCharacter_C.OnEndZiplineRagdoll // (Native|Public|BlueprintCallable) // @ game+0x19f6cb0
	void OnEndSkydive(); // Function MainCharacter.MainCharacter_C.OnEndSkydive // (Native|Public|BlueprintCallable) // @ game+0x19f6c90
	void OnEndPowerSlide(enum class EKSPowerSlideEndReason bpp__EndReason__pf); // Function MainCharacter.MainCharacter_C.OnEndPowerSlide // (Native|Event|Public) // @ game+0x19f6c10
	void OnEndOutOfBounds(); // Function MainCharacter.MainCharacter_C.OnEndOutOfBounds // (Native|Event|Public) // @ game+0x19f6bf0
	void OnDodgeRollChangedEvent(bool bpp__IsDodgeRolling__pf); // Function MainCharacter.MainCharacter_C.OnDodgeRollChangedEvent // (Native|Public|BlueprintCallable) // @ game+0x19f6b60
	void OnBeginZiplineRagdoll(); // Function MainCharacter.MainCharacter_C.OnBeginZiplineRagdoll // (Native|Public|BlueprintCallable) // @ game+0x19f6b40
	void OnBeginPowerSlide(); // Function MainCharacter.MainCharacter_C.OnBeginPowerSlide // (Native|Event|Public) // @ game+0x19f6b20
	void OnBeginOutOfBounds(); // Function MainCharacter.MainCharacter_C.OnBeginOutOfBounds // (Native|Event|Public) // @ game+0x19f6b00
	void OnArmorInteractStart(float bpp__InteractTime__pf); // Function MainCharacter.MainCharacter_C.OnArmorInteractStart // (Native|Event|Public) // @ game+0x19f6a80
	void OnArmorInteractInterrupt(); // Function MainCharacter.MainCharacter_C.OnArmorInteractInterrupt // (Native|Event|Public) // @ game+0x19f6a60
	void OnArmorInteractComplete(); // Function MainCharacter.MainCharacter_C.OnArmorInteractComplete // (Native|Event|Public) // @ game+0x19f6a40
	void OnADSBlurSettingChanged(); // Function MainCharacter.MainCharacter_C.OnADSBlurSettingChanged // (Native|Public|BlueprintCallable) // @ game+0x19f6a20
	void NoseDiveFOVTimeline__UpdateFunc(); // Function MainCharacter.MainCharacter_C.NoseDiveFOVTimeline__UpdateFunc // (Native|Public) // @ game+0x19f6a00
	void NoseDiveFOVTimeline__FinishedFunc(); // Function MainCharacter.MainCharacter_C.NoseDiveFOVTimeline__FinishedFunc // (Native|Public) // @ game+0x19f69e0
	void NoseDiveCameraTransition(bool bpp__bEnterNoseDive__pf, float bpp__AnimLength__pf); // Function MainCharacter.MainCharacter_C.NoseDiveCameraTransition // (Native|Event|Public|BlueprintCallable) // @ game+0x19f6910
	void Martial Artist Target Front__UpdateFunc(); // Function MainCharacter.MainCharacter_C.Martial Artist Target Front__UpdateFunc // (Native|Public) // @ game+0x19f68f0
	void Martial Artist Target Front__FinishedFunc(); // Function MainCharacter.MainCharacter_C.Martial Artist Target Front__FinishedFunc // (Native|Public) // @ game+0x19f68d0
	void Martial Artist Target Back__UpdateFunc(); // Function MainCharacter.MainCharacter_C.Martial Artist Target Back__UpdateFunc // (Native|Public) // @ game+0x19f68b0
	void Martial Artist Target Back__FinishedFunc(); // Function MainCharacter.MainCharacter_C.Martial Artist Target Back__FinishedFunc // (Native|Public) // @ game+0x19f6890
	void Martial Artist Instigator Front__UpdateFunc(); // Function MainCharacter.MainCharacter_C.Martial Artist Instigator Front__UpdateFunc // (Native|Public) // @ game+0x19f6870
	void Martial Artist Instigator Front__FinishedFunc(); // Function MainCharacter.MainCharacter_C.Martial Artist Instigator Front__FinishedFunc // (Native|Public) // @ game+0x19f6850
	void Martial Artist Instigator Back__UpdateFunc(); // Function MainCharacter.MainCharacter_C.Martial Artist Instigator Back__UpdateFunc // (Native|Public) // @ game+0x19f6830
	void Martial Artist Instigator Back__FinishedFunc(); // Function MainCharacter.MainCharacter_C.Martial Artist Instigator Back__FinishedFunc // (Native|Public) // @ game+0x19f6810
	void LandingRollEvent(bool bpp__IsDodgeRolling__pf); // Function MainCharacter.MainCharacter_C.LandingRollEvent // (Native|Public|BlueprintCallable) // @ game+0x19f6780
	void KeepActionCameraAboveWater(struct FVector bpp__InBoomPosition__pf, struct FVector bpp__OutBoomPosition__pf); // Function MainCharacter.MainCharacter_C.KeepActionCameraAboveWater // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x19f66a0
	void K2_OnMovementModeChanged(enum class EMovementMode bpp__PrevMovementMode__pf, enum class EMovementMode bpp__NewMovementMode__pf, enum class None bpp__PrevCustomMode__pf, enum class None bpp__NewCustomMode__pf); // Function MainCharacter.MainCharacter_C.K2_OnMovementModeChanged // (Native|Event|Public) // @ game+0x19f6550
	void K2_OnEndViewTarget(struct APlayerController* bpp__PC__pf); // Function MainCharacter.MainCharacter_C.K2_OnEndViewTarget // (Native|Event|Public) // @ game+0x19f64c0
	void K2_OnBecomeViewTarget(struct APlayerController* bpp__PC__pf); // Function MainCharacter.MainCharacter_C.K2_OnBecomeViewTarget // (Native|Event|Public) // @ game+0x19f6430
	void InpAxisKeyEvt_Gamepad_LeftY_K2Node_InputAxisKeyEvent_1(float bpp__AxisValue__pf); // Function MainCharacter.MainCharacter_C.InpAxisKeyEvt_Gamepad_LeftY_K2Node_InputAxisKeyEvent_1 // (Native|Public) // @ game+0x19f63b0
	void InpAxisKeyEvt_Gamepad_LeftX_K2Node_InputAxisKeyEvent_2(float bpp__AxisValue__pf); // Function MainCharacter.MainCharacter_C.InpAxisKeyEvt_Gamepad_LeftX_K2Node_InputAxisKeyEvent_2 // (Native|Public) // @ game+0x19f6330
	void InpActEvt_T_K2Node_InputKeyEvent_1(struct FKey bpp__Key__pf); // Function MainCharacter.MainCharacter_C.InpActEvt_T_K2Node_InputKeyEvent_1 // (Native|Public) // @ game+0x19f6250
	void InitializeHealthPP(); // Function MainCharacter.MainCharacter_C.InitializeHealthPP // (Native|Public|BlueprintCallable) // @ game+0x19f6230
	void HideZiplinePulley(); // Function MainCharacter.MainCharacter_C.HideZiplinePulley // (Native|Event|Public|BlueprintCallable) // @ game+0x19f6210
	void HideUplineDevice(); // Function MainCharacter.MainCharacter_C.HideUplineDevice // (Native|Event|Public|BlueprintCallable) // @ game+0x19f61f0
	void HealthRegenerationStopped(bool bpp__bFullyHealed__pf); // Function MainCharacter.MainCharacter_C.HealthRegenerationStopped // (Native|Event|Public) // @ game+0x19f6160
	void HealthRegenerationStarted(); // Function MainCharacter.MainCharacter_C.HealthRegenerationStarted // (Native|Event|Public) // @ game+0x19f6140
	void Handle Downed Ragdoll(); // Function MainCharacter.MainCharacter_C.Handle Downed Ragdoll // (Native|Public|BlueprintCallable) // @ game+0x19f6120
	void Get ADS Camera By Tag(struct FName bpp__Tag__pf, struct UCameraComponent* bpp__CameraxComponent__pfT); // Function MainCharacter.MainCharacter_C.Get ADS Camera By Tag // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x19f6040
	void Get ADS Bend Target Camera Component(struct UCameraComponent* bpp__CameraxComponent__pfT); // Function MainCharacter.MainCharacter_C.Get ADS Bend Target Camera Component // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x19f5fa0
	void GetTargetFov(float bpp__TargetFov__pf); // Function MainCharacter.MainCharacter_C.GetTargetFov // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x19f5f00
	void GetTargetArmorLevel(struct AActor* bpp__HitxTarget__pfT, int32_t bpp__ArmorxLevel__pfT); // Function MainCharacter.MainCharacter_C.GetTargetArmorLevel // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x19f5e20
	void GetRagdollFacingDirection(bool bpp__IsUp__pf); // Function MainCharacter.MainCharacter_C.GetRagdollFacingDirection // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x19f5d80
	void GetLastHitDistance(float bpp__OutDistance__pf); // Function MainCharacter.MainCharacter_C.GetLastHitDistance // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x19f5ce0
	void GetDownedTransitionMontage(struct UAnimMontage* bpp__OutAnimMontage__pf); // Function MainCharacter.MainCharacter_C.GetDownedTransitionMontage // (Native|Event|Public|HasOutParms|BlueprintCallable) // @ game+0x19f5c40
	void GetDeathTransitionAnimation(struct UAnimSequence* bpp__OutAnimSequence__pf); // Function MainCharacter.MainCharacter_C.GetDeathTransitionAnimation // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x19f5ba0
	void FreeFall Camera Burst(); // Function MainCharacter.MainCharacter_C.FreeFall Camera Burst // (Native|Public|BlueprintCallable) // @ game+0x19f5b80
	void Finish Action Camera Update(); // Function MainCharacter.MainCharacter_C.Finish Action Camera Update // (Native|Public|BlueprintCallable) // @ game+0x19f5b60
	void FinishHacking(); // Function MainCharacter.MainCharacter_C.FinishHacking // (Native|Event|Public|BlueprintCallable) // @ game+0x19f5b40
	void ExitDownedRagdoll(); // Function MainCharacter.MainCharacter_C.ExitDownedRagdoll // (Net|Native|Event|NetMulticast|Public|BlueprintCallable) // @ game+0x19f5b20
	void ExecuteUbergraph_MainCharacter_66(int32_t bpp__EntryPoint__pf); // Function MainCharacter.MainCharacter_C.ExecuteUbergraph_MainCharacter_66 // (Final|Native|Public) // @ game+0x19f5aa0
	void ExecuteUbergraph_MainCharacter_60(int32_t bpp__EntryPoint__pf); // Function MainCharacter.MainCharacter_C.ExecuteUbergraph_MainCharacter_60 // (Final|Native|Public) // @ game+0x19f5a20
	void ExecuteUbergraph_MainCharacter_46(int32_t bpp__EntryPoint__pf); // Function MainCharacter.MainCharacter_C.ExecuteUbergraph_MainCharacter_46 // (Final|Native|Public) // @ game+0x19f5920
	void ExecuteUbergraph_MainCharacter_43(int32_t bpp__EntryPoint__pf); // Function MainCharacter.MainCharacter_C.ExecuteUbergraph_MainCharacter_43 // (Final|Native|Public) // @ game+0x19f58a0
	void ExecuteUbergraph_MainCharacter_5(int32_t bpp__EntryPoint__pf); // Function MainCharacter.MainCharacter_C.ExecuteUbergraph_MainCharacter_5 // (Final|Native|Public) // @ game+0x19f59a0
	void ExecuteUbergraph_MainCharacter_137(int32_t bpp__EntryPoint__pf); // Function MainCharacter.MainCharacter_C.ExecuteUbergraph_MainCharacter_137 // (Final|Native|Public) // @ game+0x19f57a0
	void ExecuteUbergraph_MainCharacter_136(int32_t bpp__EntryPoint__pf); // Function MainCharacter.MainCharacter_C.ExecuteUbergraph_MainCharacter_136 // (Final|Native|Public) // @ game+0x19f5720
	void ExecuteUbergraph_MainCharacter_14(int32_t bpp__EntryPoint__pf); // Function MainCharacter.MainCharacter_C.ExecuteUbergraph_MainCharacter_14 // (Final|Native|Public) // @ game+0x19f5820
	void EventSetupCamerasForSpectator(bool bpp__Enabled__pf); // Function MainCharacter.MainCharacter_C.EventSetupCamerasForSpectator // (Native|Event|Public) // @ game+0x19f5690
	void EnterFreeFallFOVTimeline__UpdateFunc(); // Function MainCharacter.MainCharacter_C.EnterFreeFallFOVTimeline__UpdateFunc // (Native|Public) // @ game+0x19f5670
	void EnterFreeFallFOVTimeline__FinishedFunc(); // Function MainCharacter.MainCharacter_C.EnterFreeFallFOVTimeline__FinishedFunc // (Native|Public) // @ game+0x19f5650
	void EnterDownedRagdoll(); // Function MainCharacter.MainCharacter_C.EnterDownedRagdoll // (Native|Public|BlueprintCallable) // @ game+0x19f5630
	void End Down PP(); // Function MainCharacter.MainCharacter_C.End Down PP // (Native|Public|BlueprintCallable) // @ game+0x19f5610
	void EndImmunity__UpdateFunc(); // Function MainCharacter.MainCharacter_C.EndImmunity__UpdateFunc // (Native|Public) // @ game+0x19f55f0
	void EndImmunity__FinishedFunc(); // Function MainCharacter.MainCharacter_C.EndImmunity__FinishedFunc // (Native|Public) // @ game+0x19f55d0
	void DoSetOnFire(); // Function MainCharacter.MainCharacter_C.DoSetOnFire // (Native|Event|Public) // @ game+0x19f55b0
	void DoExtinguishFire(); // Function MainCharacter.MainCharacter_C.DoExtinguishFire // (Native|Event|Public) // @ game+0x19f5590
	void DoBindZiplineEvents(); // Function MainCharacter.MainCharacter_C.DoBindZiplineEvents // (Native|Public|BlueprintCallable) // @ game+0x19f5570
	void DoBindSprintEvents(); // Function MainCharacter.MainCharacter_C.DoBindSprintEvents // (Native|Public|BlueprintCallable) // @ game+0x19f5550
	void DoBindDodgeRollEvents(); // Function MainCharacter.MainCharacter_C.DoBindDodgeRollEvents // (Native|Public|BlueprintCallable) // @ game+0x19f5530
	void DetermineKnockbackFacing(struct FVector bpp__HitDirection__pf, enum class HitEnum bpp__SideHit__pf, struct FRotator bpp__ActorRotation__pf); // Function MainCharacter.MainCharacter_C.DetermineKnockbackFacing // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x19f5410
	void DetachSkydiveParticle(); // Function MainCharacter.MainCharacter_C.DetachSkydiveParticle // (Native|Public|BlueprintCallable) // @ game+0x19f53f0
	void DestructibleSpeedGateOverlappedEvent(struct FVector bpp__BreakingLocation__pf, struct FVector bpp__BreakingDirection__pf, struct FVector bpp__BreakingNormal__pf); // Function MainCharacter.MainCharacter_C.DestructibleSpeedGateOverlappedEvent // (Native|Event|Public|HasDefaults) // @ game+0x19f52c0
	void DeathStateChange(); // Function MainCharacter.MainCharacter_C.DeathStateChange // (Native|Public|BlueprintCallable) // @ game+0x19f52a0
	void Check Low Health(); // Function MainCharacter.MainCharacter_C.Check Low Health // (Native|Public|BlueprintCallable) // @ game+0x19f5280
	void CheckFlashBangOnViewTargetChange(); // Function MainCharacter.MainCharacter_C.CheckFlashBangOnViewTargetChange // (Native|Public|BlueprintCallable) // @ game+0x19f5260
	void Camera Boom Timeline__UpdateFunc(); // Function MainCharacter.MainCharacter_C.Camera Boom Timeline__UpdateFunc // (Native|Public) // @ game+0x19f5240
	void Camera Boom Timeline__Switch To Main Camera__EventFunc(); // Function MainCharacter.MainCharacter_C.Camera Boom Timeline__Switch To Main Camera__EventFunc // (Native|Public) // @ game+0x19f5220
	void Camera Boom Timeline__Switch To ADS Camera__EventFunc(); // Function MainCharacter.MainCharacter_C.Camera Boom Timeline__Switch To ADS Camera__EventFunc // (Native|Public) // @ game+0x19f5200
	void Camera Boom Timeline__FinishedFunc(); // Function MainCharacter.MainCharacter_C.Camera Boom Timeline__FinishedFunc // (Native|Public) // @ game+0x19f51e0
	void CameraDodgeRoll__UpdateFunc(); // Function MainCharacter.MainCharacter_C.CameraDodgeRoll__UpdateFunc // (Native|Public) // @ game+0x19f51c0
	void CameraDodgeRoll__FinishedFunc(); // Function MainCharacter.MainCharacter_C.CameraDodgeRoll__FinishedFunc // (Native|Public) // @ game+0x19f51a0
	void CacheRagdollPelvisLocation(); // Function MainCharacter.MainCharacter_C.CacheRagdollPelvisLocation // (Net|Native|Event|Public|NetServer|BlueprintCallable) // @ game+0x19f5180
	void BlueprintOnStopSwimming(); // Function MainCharacter.MainCharacter_C.BlueprintOnStopSwimming // (Native|Event|Public) // @ game+0x19f5160
	void BlueprintOnStartSwimming(); // Function MainCharacter.MainCharacter_C.BlueprintOnStartSwimming // (Native|Event|Public) // @ game+0x19f5140
	bool BlueprintHandleDeath(); // Function MainCharacter.MainCharacter_C.BlueprintHandleDeath // (Native|Event|Public|BlueprintCallable) // @ game+0x19f5110
	void BindADSBlurSetting(); // Function MainCharacter.MainCharacter_C.BindADSBlurSetting // (Native|Public|BlueprintCallable) // @ game+0x19f50f0
	void Audio_Init(); // Function MainCharacter.MainCharacter_C.Audio_Init // (Native|Public|BlueprintCallable) // @ game+0x19f50d0
	void ApplyLastHitImpulse(bool bpp__UpdateTargetRotation__pf, bool bpp__AffectCapsule__pf); // Function MainCharacter.MainCharacter_C.ApplyLastHitImpulse // (Native|Event|Public|BlueprintCallable) // @ game+0x19f5000
	void PlayerReviveDelegate__DelegateSignature(struct AKSPlayerState* bpp__Revivee__pf, struct AKSPlayerState* bpp__Reviver__pf, int32_t bpp__ExpBonus__pf); // DelegateFunction MainCharacter.MainCharacter_C.PlayerReviveDelegate__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void PlayerDownInfo__DelegateSignature(struct FCombatEventInfo bpp__EventInfo__pf, int32_t bpp__ExpBonus__pf); // DelegateFunction MainCharacter.MainCharacter_C.PlayerDownInfo__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void PlayerDeathInfo__DelegateSignature(struct FCombatEventInfo bpp__EventInfo__pf); // DelegateFunction MainCharacter.MainCharacter_C.PlayerDeathInfo__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnSprintChanged__DelegateSignature(bool bpp__IsSprinting__pf); // DelegateFunction MainCharacter.MainCharacter_C.OnSprintChanged__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnShoulderSwapChanged__DelegateSignature(struct AKSCharacter* bpp__Character__pf); // DelegateFunction MainCharacter.MainCharacter_C.OnShoulderSwapChanged__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnPowerSlideChanged__DelegateSignature(bool bpp__IsPowerSliding__pf); // DelegateFunction MainCharacter.MainCharacter_C.OnPowerSlideChanged__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnPlayerStateChanged__DelegateSignature(struct APlayerState* bpp__PlayerState__pf); // DelegateFunction MainCharacter.MainCharacter_C.OnPlayerStateChanged__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnItemPickedUp__DelegateSignature(struct AKSCharacter* bpp__Character__pf, struct AKSItemDrop* bpp__ItemDrop__pf, struct UKSItem* bpp__Item__pf); // DelegateFunction MainCharacter.MainCharacter_C.OnItemPickedUp__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnHealthChanged__DelegateSignature(struct AKSCharacterBase* bpp__Character__pf); // DelegateFunction MainCharacter.MainCharacter_C.OnHealthChanged__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnGoDown__DelegateSignature(); // DelegateFunction MainCharacter.MainCharacter_C.OnGoDown__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnEndZipline__DelegateSignature(); // DelegateFunction MainCharacter.MainCharacter_C.OnEndZipline__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnDodgeRollChanged__DelegateSignature(bool bpp__IsDodgeRolling__pf); // DelegateFunction MainCharacter.MainCharacter_C.OnDodgeRollChanged__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnDeathStateChanged__DelegateSignature(); // DelegateFunction MainCharacter.MainCharacter_C.OnDeathStateChanged__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnBeginZipline__DelegateSignature(); // DelegateFunction MainCharacter.MainCharacter_C.OnBeginZipline__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnAnimInitialized__DelegateSignature(); // DelegateFunction MainCharacter.MainCharacter_C.OnAnimInitialized__DelegateSignature // (Public|Delegate) // @ game+0x2587100
};

