// WidgetBlueprintGeneratedClass HitIndicatorSub.HitIndicatorSub_C
// Size: 0x568 (Inherited: 0x510)
struct UHitIndicatorSub_C : UKSViewedPawnWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x510(0x08)
	struct UWidgetAnimation* Fade; // 0x518(0x08)
	struct UImage* ArmorArrow; // 0x520(0x08)
	struct UImage* ArmorDamageGlow; // 0x528(0x08)
	struct UWidgetSwitcher* DamageType; // 0x530(0x08)
	struct UImage* HealthDamageGlow; // 0x538(0x08)
	struct UImage* HitArrow; // 0x540(0x08)
	struct FVector HitLocation; // 0x548(0x0c)
	float LifeRemaining; // 0x554(0x04)
	bool IsArmorHit; // 0x558(0x01)
	char UnknownData_559[0x7]; // 0x559(0x07)
	struct UHitIndictor_C* OwnerWidget; // 0x560(0x08)

	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function HitIndicatorSub.HitIndicatorSub_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void WidgetAnimationEvt_Fade_K2Node_WidgetAnimationEvent_1(); // Function HitIndicatorSub.HitIndicatorSub_C.WidgetAnimationEvt_Fade_K2Node_WidgetAnimationEvent_1 // (BlueprintEvent) // @ game+0x2587100
	void StartDamageAnim(struct FVector InHitLocation, bool bInIsArmorHit); // Function HitIndicatorSub.HitIndicatorSub_C.StartDamageAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_HitIndicatorSub(int32_t EntryPoint); // Function HitIndicatorSub.HitIndicatorSub_C.ExecuteUbergraph_HitIndicatorSub // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

