// WidgetBlueprintGeneratedClass EnemyPingFullMapIcon.EnemyPingFullMapIcon_C
// Size: 0x360 (Inherited: 0x318)
struct UEnemyPingFullMapIcon_C : UKSMapIconWidgetBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x318(0x08)
	struct UWidgetAnimation* Ping; // 0x320(0x08)
	struct UImage* ImageIcon; // 0x328(0x08)
	struct UImage* PingImg; // 0x330(0x08)
	struct UScaleBox* ScaleBox_1; // 0x338(0x08)
	struct FMulticastInlineDelegate PingExpired; // 0x340(0x10)
	enum class EKSPingType Ping Type; // 0x350(0x01)
	char UnknownData_351[0x3]; // 0x351(0x03)
	struct FVector ActivePingLoation; // 0x354(0x0c)

	struct FVector GetWorldPosition(); // Function EnemyPingFullMapIcon.EnemyPingFullMapIcon_C.GetWorldPosition // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void GetPingType(enum class EKSPingType NewParam); // Function EnemyPingFullMapIcon.EnemyPingFullMapIcon_C.GetPingType // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void Construct(); // Function EnemyPingFullMapIcon.EnemyPingFullMapIcon_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Start Ping(); // Function EnemyPingFullMapIcon.EnemyPingFullMapIcon_C.Start Ping // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Re Ping(struct FKSClientShotInfo ShotInfo); // Function EnemyPingFullMapIcon.EnemyPingFullMapIcon_C.Re Ping // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_EnemyPingFullMapIcon(int32_t EntryPoint); // Function EnemyPingFullMapIcon.EnemyPingFullMapIcon_C.ExecuteUbergraph_EnemyPingFullMapIcon // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void PingExpired__DelegateSignature(enum class None Icon Type, int32_t UniqueId); // Function EnemyPingFullMapIcon.EnemyPingFullMapIcon_C.PingExpired__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

