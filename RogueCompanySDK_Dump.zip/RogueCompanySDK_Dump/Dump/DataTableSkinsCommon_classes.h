// Class DataTableSkinsCommon.DynamicSkinTable
// Size: 0x298 (Inherited: 0x28)
struct UDynamicSkinTable : UObject {
	struct TArray<struct FDataTableInfo> ActiveDataTables; // 0x28(0x10)
	struct TArray<struct FDataTableInfo> InactiveDataTables; // 0x38(0x10)
	struct FMulticastInlineDelegate OnFinishedAllPendingLoadsDel; // 0x48(0x10)
	char UnknownData_58[0x220]; // 0x58(0x220)
	char bWantsToBeRecycled : 1; // 0x278(0x01)
	char UnknownData_278_1 : 7; // 0x278(0x01)
	char UnknownData_279[0x7]; // 0x279(0x07)
	struct TScriptInterface<None> SkinTagAsset; // 0x280(0x10)
	char UnknownData_290[0x8]; // 0x290(0x08)

	void RemoveDataTables(struct TArray<struct UDataTable*> InTables); // Function DataTableSkinsCommon.DynamicSkinTable.RemoveDataTables // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x997a30
	void RemoveDataTable(struct UDataTable* InTable); // Function DataTableSkinsCommon.DynamicSkinTable.RemoveDataTable // (Final|Native|Public|BlueprintCallable) // @ game+0x9979b0
	bool IsTablePendingAssetLoad(); // Function DataTableSkinsCommon.DynamicSkinTable.IsTablePendingAssetLoad // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x997980
	struct UTexture* GetTexture(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetTexture // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9977e0
	struct UStaticMesh* GetStaticMesh(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetStaticMesh // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x997640
	struct USkeletalMesh* GetSkeletalMesh(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetSkeletalMesh // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x997460
	struct USelectiveAkAudioEvent* GetSelectiveAudioEvent(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetSelectiveAudioEvent // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9972c0
	struct UPoseAsset* GetPoseAsset(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetPoseAsset // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x997120
	struct UPhysicsAsset* GetPhysicsAsset(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetPhysicsAsset // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x996f80
	struct UParticleSystem* GetParticleSystem(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetParticleSystem // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x996de0
	struct FName GetNameField(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetNameField // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x996c20
	struct UMaterialInterface* GetMaterialInterface(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetMaterialInterface // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x996a80
	struct FLinearColor GetLinearColor(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetLinearColor // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x9968c0
	int32_t GetInt(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetInt // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x996720
	float GetFloat(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetFloat // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x996580
	struct UObject* GetClass(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetClass // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9963e0
	bool GetBool(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetBool // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x996240
	struct UAkAudioEvent* GetAudioEvent(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetAudioEvent // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9960a0
	struct UAnimSequence* GetAnimSequence(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetAnimSequence // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x995e30
	struct UAnimMontage* GetAnimMontage(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetAnimMontage // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x995c90
	struct UBlendSpace* GetAnimBlendSpace(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetAnimBlendSpace // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x995af0
	struct UAnimationAsset* GetAnimationAsset(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetAnimationAsset // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x995fd0
	struct UAimOffsetBlendSpace* GetAnimAimOffset(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetAnimAimOffset // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x995950
	void GetAllKeywords(struct TSet<struct FName> InOutKeywords); // Function DataTableSkinsCommon.DynamicSkinTable.GetAllKeywords // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9956f0
	void AddDataTableWithQuery(struct UDataTable* InTable, int32_t InPriority, struct FGameplayTagQuery InQuery); // Function DataTableSkinsCommon.DynamicSkinTable.AddDataTableWithQuery // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x995360
	void AddDataTables(struct TArray<struct FDataTableInfo> InTableInfos); // Function DataTableSkinsCommon.DynamicSkinTable.AddDataTables // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9954c0
	void AddDataTable(struct UDataTable* InTable, int32_t InPriority); // Function DataTableSkinsCommon.DynamicSkinTable.AddDataTable // (Final|Native|Public|BlueprintCallable) // @ game+0x9952a0
};

// Class DataTableSkinsCommon.MultiSkinObject
// Size: 0x1d0 (Inherited: 0x28)
struct UMultiSkinObject : UObject {
	struct TArray<struct UMultiSkinObject*> ParentSkinnedObjects; // 0x28(0x10)
	struct TArray<struct FWeakObjectPtr<struct UMultiSkinObject>> ChildSkinnedObjects; // 0x38(0x10)
	struct TSet<struct FName> SubscribedKeywords; // 0x48(0x50)
	struct TSet<struct FName> SubscribedMaterialPrefixes; // 0x98(0x50)
	char bSubscribeToAllKeywords : 1; // 0xe8(0x01)
	char bWantsToBeRecycled : 1; // 0xe8(0x01)
	char UnknownData_E8_2 : 6; // 0xe8(0x01)
	char UnknownData_E9[0x1f]; // 0xe9(0x1f)
	struct FMulticastInlineDelegate OnFinishedAllPendingLoadsDel; // 0x108(0x10)
	char UnknownData_118[0x18]; // 0x118(0x18)
	struct TMap<int32_t, struct FDynamicSkinTableMapEntry> DynamicSkinTables; // 0x130(0x50)
	struct TMap<struct FName, struct FCachedRowsEntry> CachedRows; // 0x180(0x50)

	void UnsubscribeToKeywords(struct TArray<struct FName> InKeywords); // Function DataTableSkinsCommon.MultiSkinObject.UnsubscribeToKeywords // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x998f50
	void UnsubscribeToKeyword(struct FName InKeyword); // Function DataTableSkinsCommon.MultiSkinObject.UnsubscribeToKeyword // (Final|Native|Public|BlueprintCallable) // @ game+0x998ed0
	void UnsubscribeToAllKeywords(); // Function DataTableSkinsCommon.MultiSkinObject.UnsubscribeToAllKeywords // (Final|Native|Public|BlueprintCallable) // @ game+0x998eb0
	void SubscribeToKeywords(struct TArray<struct FName> InKeywords); // Function DataTableSkinsCommon.MultiSkinObject.SubscribeToKeywords // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x998e00
	void SubscribeToKeyword(struct FName InKeyword); // Function DataTableSkinsCommon.MultiSkinObject.SubscribeToKeyword // (Final|Native|Public|BlueprintCallable) // @ game+0x998d80
	void SubscribeToAllKeywords(); // Function DataTableSkinsCommon.MultiSkinObject.SubscribeToAllKeywords // (Final|Native|Public|BlueprintCallable) // @ game+0x998d60
	void RemoveParent(struct UMultiSkinObject* InParent); // Function DataTableSkinsCommon.MultiSkinObject.RemoveParent // (Final|Native|Public|BlueprintCallable) // @ game+0x997ae0
	struct UTexture* GetTexture(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetTexture // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9978b0
	struct UStaticMesh* GetStaticMesh(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetStaticMesh // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x997710
	struct USkeletalMesh* GetSkeletalMesh(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetSkeletalMesh // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x997530
	struct USelectiveAkAudioEvent* GetSelectiveAudioEvent(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetSelectiveAudioEvent // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x997390
	struct UPoseAsset* GetPoseAsset(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetPoseAsset // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9971f0
	struct UPhysicsAsset* GetPhysicsAsset(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetPhysicsAsset // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x997050
	struct UParticleSystem* GetParticleSystem(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetParticleSystem // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x996eb0
	struct FName GetNameField(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetNameField // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x996d00
	struct UMaterialInterface* GetMaterialInterface(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetMaterialInterface // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x996b50
	struct FLinearColor GetLinearColor(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetLinearColor // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x9969a0
	int32_t GetInt(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetInt // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9967f0
	float GetFloat(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetFloat // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x996650
	struct UObject* GetClass(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetClass // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9964b0
	bool GetBool(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetBool // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x996310
	struct UAkAudioEvent* GetAudioEvent(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetAudioEvent // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x996170
	struct UAnimSequence* GetAnimSequence(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetAnimSequence // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x995f00
	struct UAnimMontage* GetAnimMontage(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetAnimMontage // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x995d60
	struct UBlendSpace* GetAnimBlendSpace(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetAnimBlendSpace // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x995bc0
	struct UAimOffsetBlendSpace* GetAnimAimOffset(struct FName RowName, int32_t Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetAnimAimOffset // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x995a20
	void GetAllSkinKeywords(struct TSet<struct FName> InOutKeywords); // Function DataTableSkinsCommon.MultiSkinObject.GetAllSkinKeywords // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x995820
	void AddParent(struct UMultiSkinObject* InParent); // Function DataTableSkinsCommon.MultiSkinObject.AddParent // (Final|Native|Public|BlueprintCallable) // @ game+0x9955c0
};

// Class DataTableSkinsCommon.SkinnableSkeletalMeshComponent
// Size: 0xce0 (Inherited: 0xb90)
struct USkinnableSkeletalMeshComponent : USkeletalMeshComponentBudgeted {
	bool bDelaySkinUpdatesUntilTick; // 0xb90(0x01)
	bool bSkinUpdateIsQueued; // 0xb91(0x01)
	char UnknownData_B92[0x2]; // 0xb92(0x02)
	struct FName SkeletalMeshKeyword; // 0xb94(0x08)
	char UnknownData_B9C[0x4]; // 0xb9c(0x04)
	struct USkeletalMesh* FailSafeSkeletalMesh; // 0xba0(0x08)
	struct FName PhysicsAssetKeyword; // 0xba8(0x08)
	struct UPhysicsAsset* FailSafePhysicsAsset; // 0xbb0(0x08)
	struct FName AnimInstanceClassKeyword; // 0xbb8(0x08)
	struct UAnimInstance* FailSafeAnimClass; // 0xbc0(0x08)
	struct UAnimInstance* LastSkinnedAnimClass; // 0xbc8(0x08)
	bool bForceAnimationUpdateOnSkinUpdate; // 0xbd0(0x01)
	char UnknownData_BD1[0x7]; // 0xbd1(0x07)
	struct UMultiSkinObject* SkinObject; // 0xbd8(0x08)
	struct FMulticastInlineDelegate OnAnimInitializedOnSkinnableMeshDel; // 0xbe0(0x10)
	char UnknownData_BF0[0x30]; // 0xbf0(0x30)
	bool bAllowMaterialSkinning; // 0xc20(0x01)
	char UnknownData_C21[0x7]; // 0xc21(0x07)
	struct TArray<struct FString> MaterialSkinningPrefixes; // 0xc28(0x10)
	struct TSet<struct FName> MaterialSkinningPrefixes_New; // 0xc38(0x50)
	char UnknownData_C88[0x48]; // 0xc88(0x48)
	int32_t ForcedLodModel_Skinned; // 0xcd0(0x04)
	char UnknownData_CD4[0xc]; // 0xcd4(0x0c)

	void StaticSetForcedLOD(struct USkinnedMeshComponent* InMeshComp, int32_t InForcedLOD); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.StaticSetForcedLOD // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x998cb0
	void SetSkeletalMeshKeyword(struct FName InKeyword, struct USkeletalMesh* InFailSafeSkeletalMesh); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetSkeletalMeshKeyword // (Native|Public|BlueprintCallable) // @ game+0x998a10
	void SetPhysicsAssetKeyword(struct FName InKeyword, struct UPhysicsAsset* InFailSafePhysicsAsset); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetPhysicsAssetKeyword // (Native|Public|BlueprintCallable) // @ game+0x998940
	int32_t SetPersistentVectorParameterOnAllMaterials(struct FName ParameterName, struct FLinearColor ParameterValue); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetPersistentVectorParameterOnAllMaterials // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x998780
	int32_t SetPersistentVectorParameter(int32_t MaterialSlot, struct FName ParameterName, struct FLinearColor ParameterValue); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetPersistentVectorParameter // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x998560
	int32_t SetPersistentTextureParameterOnAllMaterials(struct FName ParameterName, struct UTexture* ParameterValue); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetPersistentTextureParameterOnAllMaterials // (Final|Native|Public|BlueprintCallable) // @ game+0x9983e0
	int32_t SetPersistentTextureParameter(int32_t MaterialSlot, struct FName ParameterName, struct UTexture* ParameterValue); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetPersistentTextureParameter // (Final|Native|Public|BlueprintCallable) // @ game+0x9981e0
	int32_t SetPersistentScalarParameterOnAllMaterials(struct FName ParameterName, float ParameterValue); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetPersistentScalarParameterOnAllMaterials // (Final|Native|Public|BlueprintCallable) // @ game+0x998040
	int32_t SetPersistentScalarParameter(int32_t MaterialSlot, struct FName ParameterName, float ParameterValue); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetPersistentScalarParameter // (Final|Native|Public|BlueprintCallable) // @ game+0x997e40
	void SetForcedLOD_Skinned(int32_t InNewForcedLOD); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetForcedLOD_Skinned // (Final|Native|Public|BlueprintCallable) // @ game+0x997dc0
	void SetAnimClassKeyword(struct FName InKeyword, struct UAnimInstance* InFailSafeAnimClass); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetAnimClassKeyword // (Native|Public|BlueprintCallable) // @ game+0x997cf0
	void RemovePersistentMaterialParameter(int32_t ParameterId); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.RemovePersistentMaterialParameter // (Final|Native|Public|BlueprintCallable) // @ game+0x997b60
	struct UMultiSkinObject* GetSkinObject(); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.GetSkinObject // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x997600
	void ForwardAnimInitialized(); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.ForwardAnimInitialized // (Final|Native|Private) // @ game+0x9956d0
};

// Class DataTableSkinsCommon.SkinnableMergedMeshComponent
// Size: 0xd20 (Inherited: 0xce0)
struct USkinnableMergedMeshComponent : USkinnableSkeletalMeshComponent {
	struct TArray<struct FName> CompositeSkeletalMeshKeywords; // 0xcd8(0x10)
	bool bAlwaysUseTheFailsafeMeshWhileMerging; // 0xce8(0x01)
	bool bDelayFullSkinUpdateUntilMeshMergingIsComplete; // 0xce9(0x01)
	struct USkeletalMesh* BestPlaceHolderMesh; // 0xcf0(0x08)
	bool bMergeMarkedComplete; // 0xcf8(0x01)
	char UnknownData_CFB[0x5]; // 0xcfb(0x05)
	struct USkeletalMesh* CachedMergeResult; // 0xd00(0x08)
	char UnknownData_D08[0x18]; // 0xd08(0x18)

	void SetSkeletalMeshKeywords(struct TArray<struct FName> InKeywords, struct USkeletalMesh* InFailSafeSkeletalMesh); // Function DataTableSkinsCommon.SkinnableMergedMeshComponent.SetSkeletalMeshKeywords // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x998ae0
	void RemoveSkeletalMeshKeyword(struct FName InKeyword); // Function DataTableSkinsCommon.SkinnableMergedMeshComponent.RemoveSkeletalMeshKeyword // (Native|Public|BlueprintCallable) // @ game+0x997c60
	void AddSkeletalMeshKeyword(struct FName InKeyword); // Function DataTableSkinsCommon.SkinnableMergedMeshComponent.AddSkeletalMeshKeyword // (Native|Public|BlueprintCallable) // @ game+0x995640
};

// Class DataTableSkinsCommon.SkinnableStaticMeshComponent
// Size: 0x590 (Inherited: 0x4d0)
struct USkinnableStaticMeshComponent : UStaticMeshComponent {
	bool bDelaySkinUpdatesUntilTick; // 0x4d0(0x01)
	bool bSkinUpdateIsQueued; // 0x4d1(0x01)
	char UnknownData_4D2[0x2]; // 0x4d2(0x02)
	struct FName StaticMeshKeyword; // 0x4d4(0x08)
	char UnknownData_4DC[0x4]; // 0x4dc(0x04)
	struct UStaticMesh* FailSafeStaticMesh; // 0x4e0(0x08)
	struct UMultiSkinObject* SkinObject; // 0x4e8(0x08)
	bool bAllowMaterialSkinning; // 0x4f0(0x01)
	char UnknownData_4F1[0x7]; // 0x4f1(0x07)
	struct TSet<struct FName> MaterialSkinningPrefixes; // 0x4f8(0x50)
	char UnknownData_548[0x48]; // 0x548(0x48)

	void SetStaticMeshKeyword(struct FName InKeyword, struct UStaticMesh* InFailSafeStaticMesh); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetStaticMeshKeyword // (Native|Public|BlueprintCallable) // @ game+0x998be0
	int32_t SetPersistentVectorParameterOnAllMaterials(struct FName ParameterName, struct FLinearColor ParameterValue); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentVectorParameterOnAllMaterials // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x998860
	int32_t SetPersistentVectorParameter(int32_t MaterialSlot, struct FName ParameterName, struct FLinearColor ParameterValue); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentVectorParameter // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x998670
	int32_t SetPersistentTextureParameterOnAllMaterials(struct FName ParameterName, struct UTexture* ParameterValue); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentTextureParameterOnAllMaterials // (Final|Native|Public|BlueprintCallable) // @ game+0x9984a0
	int32_t SetPersistentTextureParameter(int32_t MaterialSlot, struct FName ParameterName, struct UTexture* ParameterValue); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentTextureParameter // (Final|Native|Public|BlueprintCallable) // @ game+0x9982e0
	int32_t SetPersistentScalarParameterOnAllMaterials(struct FName ParameterName, float ParameterValue); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentScalarParameterOnAllMaterials // (Final|Native|Public|BlueprintCallable) // @ game+0x998110
	int32_t SetPersistentScalarParameter(int32_t MaterialSlot, struct FName ParameterName, float ParameterValue); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentScalarParameter // (Final|Native|Public|BlueprintCallable) // @ game+0x997f40
	void RemovePersistentMaterialParameter(int32_t ParameterId); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.RemovePersistentMaterialParameter // (Final|Native|Public|BlueprintCallable) // @ game+0x997be0
	struct UMultiSkinObject* GetSkinObject(); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.GetSkinObject // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x997620
};

// Class DataTableSkinsCommon.SkinObjectManagerComponent
// Size: 0x150 (Inherited: 0xb0)
struct USkinObjectManagerComponent : UActorComponent {
	struct TMap<struct FName, struct UMultiSkinObject*> SkinObjects; // 0xb0(0x50)
	struct TSet<struct UMultiSkinObject*> SkinObjectsSet; // 0x100(0x50)
};

// Class DataTableSkinsCommon.SkinTagAssetInterface
// Size: 0x28 (Inherited: 0x28)
struct USkinTagAssetInterface : UInterface {
};

