// WidgetBlueprintGeneratedClass GameModeWidget_Multiple.GameModeWidget_Multiple_C
// Size: 0x57a (Inherited: 0x4e0)
struct UGameModeWidget_Multiple_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UCoopProgressOverlay_C* CoopProgressOverlay; // 0x4e8(0x08)
	struct UCoopTimer_C* CoopTimer; // 0x4f0(0x08)
	struct UGameTimerBar_C* GameTimerBar; // 0x4f8(0x08)
	struct UCanvasPanel* HUDCanvas; // 0x500(0x08)
	struct UImage* Image_91; // 0x508(0x08)
	struct UInvalidationBox* InvalidationBox_1; // 0x510(0x08)
	struct UMinimap_C* Minimap; // 0x518(0x08)
	struct UNewWeaponInventory_C* NewWeaponInventory; // 0x520(0x08)
	struct ULocalPlayerHealth_C* PlayerResourceMeter_Health; // 0x528(0x08)
	struct UPlayersRemaining_C* PlayersRemaining; // 0x530(0x08)
	struct UTeamHealthContainer_C* TeamHealthContainer; // 0x538(0x08)
	struct UWidgetSwitcher* TimerSwitcher; // 0x540(0x08)
	struct UWBP_KillstreakMeterMgr_C* WBP_KillstreakMeterMgr; // 0x548(0x08)
	struct UWBP_NeutralBombCarrierPrompts_C* WBP_NeutralBombCarrierPrompts; // 0x550(0x08)
	struct UWBP_NeutralBombIndicator_C* WBP_NeutralBombIndicator; // 0x558(0x08)
	struct UWBP_TelemetryWidget_C* WBP_TelemetryWidget; // 0x560(0x08)
	struct UWBP_UniqueWeaponPrompt_C* WBP_UniqueWeaponPrompt; // 0x568(0x08)
	struct UWBP_VoteWidget_C* WBP_VoteWidget; // 0x570(0x08)
	bool PrimaryNeedReload; // 0x578(0x01)
	bool SecondaryNeedReload; // 0x579(0x01)

	void Bind Killcam(); // Function GameModeWidget_Multiple.GameModeWidget_Multiple_C.Bind Killcam // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeHudWidgets(); // Function GameModeWidget_Multiple.GameModeWidget_Multiple_C.InitializeHudWidgets // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeMapWidgets(); // Function GameModeWidget_Multiple.GameModeWidget_Multiple_C.InitializeMapWidgets // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function GameModeWidget_Multiple.GameModeWidget_Multiple_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void SetListenersActive(bool Active); // Function GameModeWidget_Multiple.GameModeWidget_Multiple_C.SetListenersActive // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BndEvt__VehicleOverlay_K2Node_ComponentBoundEvent_0_Vehicle State Changed__DelegateSignature(bool InVehicle); // Function GameModeWidget_Multiple.GameModeWidget_Multiple_C.BndEvt__VehicleOverlay_K2Node_ComponentBoundEvent_0_Vehicle State Changed__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void HandleKillCamEnabled(bool IsEnabled); // Function GameModeWidget_Multiple.GameModeWidget_Multiple_C.HandleKillCamEnabled // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ShowHUD(); // Function GameModeWidget_Multiple.GameModeWidget_Multiple_C.ShowHUD // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HideHUD(); // Function GameModeWidget_Multiple.GameModeWidget_Multiple_C.HideHUD // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ToggleTopBarHUD(bool ShouldShow); // Function GameModeWidget_Multiple.GameModeWidget_Multiple_C.ToggleTopBarHUD // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ToggleMiniMap(); // Function GameModeWidget_Multiple.GameModeWidget_Multiple_C.ToggleMiniMap // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function GameModeWidget_Multiple.GameModeWidget_Multiple_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Swimming Changed(bool IsSwimming); // Function GameModeWidget_Multiple.GameModeWidget_Multiple_C.Handle Swimming Changed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleRoundSetup(struct FRoundInitState RoundInitState); // Function GameModeWidget_Multiple.GameModeWidget_Multiple_C.HandleRoundSetup // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_GameModeWidget_Multiple(int32_t EntryPoint); // Function GameModeWidget_Multiple.GameModeWidget_Multiple_C.ExecuteUbergraph_GameModeWidget_Multiple // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

