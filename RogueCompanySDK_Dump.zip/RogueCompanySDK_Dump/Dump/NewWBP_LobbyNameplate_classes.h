// WidgetBlueprintGeneratedClass NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C
// Size: 0x561 (Inherited: 0x4e0)
struct UNewWBP_LobbyNameplate_C : UKSLobbyNameplateWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UKSAsyncImage* AvatarIcon; // 0x4e8(0x08)
	struct UImage* PartyLeader; // 0x4f0(0x08)
	struct USizeBox* PartyLeaderIcon; // 0x4f8(0x08)
	struct UHorizontalBox* PlayerDisplay; // 0x500(0x08)
	struct UTextBlock* PlayerName; // 0x508(0x08)
	struct UTextBlock* ProgressNum; // 0x510(0x08)
	struct UHorizontalBox* RankedDisplayWrapper; // 0x518(0x08)
	struct UWBP_RankedIcon_C* RankedIcon; // 0x520(0x08)
	struct UVerticalBox* RankedProgress; // 0x528(0x08)
	struct UWBP_ProgressEarnedBar_C* RankedProgressBar; // 0x530(0x08)
	struct UTextBlock* TotalNum; // 0x538(0x08)
	struct UKSPartyDataFactory* PartyDataFactory; // 0x540(0x08)
	int32_t MaxNameLength; // 0x548(0x04)
	char UnknownData_54C[0x4]; // 0x54c(0x04)
	struct UKSPlayerInfo* StoredPlayerInfo; // 0x550(0x08)
	struct UKSQueueDataFactory* QueueDataFactory; // 0x558(0x08)
	bool ShouldShowRankedXp; // 0x560(0x01)

	void UpdateRankedTotal(bool Index, int32_t RequiredPlacementMatches); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.UpdateRankedTotal // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdatePlayerName(); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.UpdatePlayerName // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateRankedData(); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.UpdateRankedData // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnPartyUpdated(); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.OnPartyUpdated // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateSelectedQueue(); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.UpdateSelectedQueue // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetPlayerDisplayVisible(bool IsVisible); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.SetPlayerDisplayVisible // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdatePartyLeaderIcon(); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.UpdatePartyLeaderIcon // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetPlayerInfo(struct UKSPlayerInfo* playerinfo); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.SetPlayerInfo // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnPossession(struct APlayerState* PlayerState, struct AKSCharacter* Character); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.OnPossession // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnHovered(); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.OnHovered // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnUnhovered(); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.OnUnhovered // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void SetName(struct FText InName); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.SetName // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetAvatar(struct UKSItem* AvatarItem); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.SetAvatar // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PreConstruct(bool IsDesignTime); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnInitialized(); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void RefreshRankedData(); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.RefreshRankedData // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_NewWBP_LobbyNameplate(int32_t EntryPoint); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.ExecuteUbergraph_NewWBP_LobbyNameplate // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

