// WidgetBlueprintGeneratedClass ContextualPingMarker.ContextualPingMarker_C
// Size: 0x424 (Inherited: 0x3a0)
struct UContextualPingMarker_C : UKSContextualPingMarkerWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3a0(0x08)
	struct UWidgetAnimation* Location_Acknowledge; // 0x3a8(0x08)
	struct UWidgetAnimation* Location_Active; // 0x3b0(0x08)
	struct UWidgetAnimation* Location_Activation; // 0x3b8(0x08)
	struct UWBP_AdditiveImage_C* Acknowledge; // 0x3c0(0x08)
	struct UImage* Arrow; // 0x3c8(0x08)
	struct UCanvasPanel* CanvasPanelRoot; // 0x3d0(0x08)
	struct UTextBlock* DistanceText; // 0x3d8(0x08)
	struct UImage* location_marker; // 0x3e0(0x08)
	struct UOverlay* Overlay_1; // 0x3e8(0x08)
	struct UWBP_AsyncIcon_C* PingIcon; // 0x3f0(0x08)
	struct UWBP_AsyncIcon_C* PingIcon_Flash; // 0x3f8(0x08)
	struct UImage* t_active_ping; // 0x400(0x08)
	bool WasRemoved; // 0x408(0x01)
	char UnknownData_409[0x7]; // 0x409(0x07)
	struct TArray<enum class EPingType> AnimPingTypes; // 0x410(0x10)
	float DelayActiveAnimTime; // 0x420(0x04)

	void MovePing(enum class EPingType PingType, enum class EPingMessage PingMessage); // Function ContextualPingMarker.ContextualPingMarker_C.MovePing // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function ContextualPingMarker.ContextualPingMarker_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void HandlePingRemoved(); // Function ContextualPingMarker.ContextualPingMarker_C.HandlePingRemoved // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetScreenRegion(enum class EIconMarkerScreenRegion ScreenRegion); // Function ContextualPingMarker.ContextualPingMarker_C.SetScreenRegion // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void SetArrowAngle(float Angle); // Function ContextualPingMarker.ContextualPingMarker_C.SetArrowAngle // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void SetupPingOnReady(); // Function ContextualPingMarker.ContextualPingMarker_C.SetupPingOnReady // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void PlayActivationAnim(bool bPlayActiveAnim); // Function ContextualPingMarker.ContextualPingMarker_C.PlayActivationAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PlayActiveStateAnim(); // Function ContextualPingMarker.ContextualPingMarker_C.PlayActiveStateAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateMetersAway(int32_t Meters); // Function ContextualPingMarker.ContextualPingMarker_C.UpdateMetersAway // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void HandlePingChanged(); // Function ContextualPingMarker.ContextualPingMarker_C.HandlePingChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_ContextualPingMarker(int32_t EntryPoint); // Function ContextualPingMarker.ContextualPingMarker_C.ExecuteUbergraph_ContextualPingMarker // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

