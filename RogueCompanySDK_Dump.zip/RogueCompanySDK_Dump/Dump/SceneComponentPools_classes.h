// Class SceneComponentPools.BasePoolComponent
// Size: 0xd0 (Inherited: 0xb0)
struct UBasePoolComponent : UActorComponent {
	int32_t MaxPoolSize; // 0xb0(0x04)
	int32_t StartingPoolSize; // 0xb4(0x04)
	struct FString ComponentClassName; // 0xb8(0x10)
	enum class EPoolOverflowHandling OverflowType; // 0xc8(0x01)
	char UnknownData_C9[0x7]; // 0xc9(0x07)
};

// Class SceneComponentPools.DecalPoolComponent
// Size: 0x148 (Inherited: 0xd0)
struct UDecalPoolComponent : UBasePoolComponent {
	char UnknownData_D0[0x8]; // 0xd0(0x08)
	struct UPoolableDecalComponent* PooledDecalComponentClass; // 0xd8(0x08)
	struct TArray<struct UPoolableDecalComponent*> UnusedComponentsArray; // 0xe0(0x10)
	struct TSet<struct UPoolableDecalComponent*> UsedComponentsSet; // 0xf0(0x50)
	struct UPoolableDecalComponent* PeekedDecalComponent; // 0x140(0x08)
};

// Class SceneComponentPools.GunshotDecalPoolComponent
// Size: 0x148 (Inherited: 0x148)
struct UGunshotDecalPoolComponent : UDecalPoolComponent {
};

// Class SceneComponentPools.ParticleSystemPoolComponentBase
// Size: 0x150 (Inherited: 0xd0)
struct UParticleSystemPoolComponentBase : UBasePoolComponent {
	char UnknownData_D0[0x8]; // 0xd0(0x08)
	struct UParticleSystemComponent* PooledParticleSystemComponentClass; // 0xd8(0x08)
	struct TArray<struct UParticleSystemComponent*> UnusedComponentsArray; // 0xe0(0x10)
	struct TSet<struct UParticleSystemComponent*> UsedComponentsSet; // 0xf0(0x50)
	struct UParticleSystemComponent* PeekedParticleSystemComponent; // 0x140(0x08)
	bool bClearTemplateWhenReturnedToPool; // 0x148(0x01)
	char UnknownData_149[0x7]; // 0x149(0x07)

	void OnPSCFinished(struct UParticleSystemComponent* InPSC); // Function SceneComponentPools.ParticleSystemPoolComponentBase.OnPSCFinished // (Native|Protected) // @ game+0x9be440
};

// Class SceneComponentPools.ParticleSystemPoolComponent
// Size: 0x150 (Inherited: 0x150)
struct UParticleSystemPoolComponent : UParticleSystemPoolComponentBase {
};

// Class SceneComponentPools.PoolableDecalComponent
// Size: 0x280 (Inherited: 0x250)
struct UPoolableDecalComponent : UDecalComponent {
	char UnknownData_250[0x10]; // 0x250(0x10)
	struct FMulticastInlineDelegate OnDecalReturnedToPoolDelegate; // 0x260(0x10)
	bool bInUse; // 0x270(0x01)
	char UnknownData_271[0xf]; // 0x271(0x0f)

	void ForceReturnToPool(); // Function SceneComponentPools.PoolableDecalComponent.ForceReturnToPool // (Final|Native|Public|BlueprintCallable) // @ game+0x9be420
};

// Class SceneComponentPools.SceneComponentPoolStatics
// Size: 0x28 (Inherited: 0x28)
struct USceneComponentPoolStatics : UBlueprintFunctionLibrary {

	struct UStaticMeshComponent* SpawnStaticMeshAttached(struct UStaticMesh* Mesh, struct USceneComponent* AttachToComponent, struct FPoolAttachmentInfo AttachInfo); // Function SceneComponentPools.SceneComponentPoolStatics.SpawnStaticMeshAttached // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9bf490
	struct USkeletalMeshComponent* SpawnSkeletalMeshAttached(struct USkeletalMesh* Mesh, struct UAnimInstance* AnimClass, struct USceneComponent* AttachToComponent, struct FPoolAttachmentInfo AttachInfo); // Function SceneComponentPools.SceneComponentPoolStatics.SpawnSkeletalMeshAttached // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9bf2f0
	struct UParticleSystemComponent* SpawnEmitterAttached(struct UParticleSystem* EmitterTemplate, struct USceneComponent* AttachToComponent, struct FName AttachPointName, struct FVector Location, struct FRotator Rotation, struct FVector Scale, enum class EAttachLocation LocationType); // Function SceneComponentPools.SceneComponentPoolStatics.SpawnEmitterAttached // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x9bf0d0
	struct UParticleSystemComponent* SpawnEmitterAtLocation(struct UObject* WorldContextObject, struct UParticleSystem* EmitterTemplate, struct FVector Location, struct FRotator Rotation, struct FVector Scale); // Function SceneComponentPools.SceneComponentPoolStatics.SpawnEmitterAtLocation // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x9bef30
	struct UPoolableDecalComponent* SpawnDecalAttached(struct UMaterialInterface* DecalMaterial, struct FVector DecalSize, struct USceneComponent* AttachToComponent, struct FName AttachPointName, struct FVector Location, struct FRotator Rotation, enum class EAttachLocation LocationType, float Lifespan, bool bUseGunshotDecalPool); // Function SceneComponentPools.SceneComponentPoolStatics.SpawnDecalAttached // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x9bec90
	struct UPoolableDecalComponent* SpawnDecalAtLocation(struct UObject* WorldContextObject, struct UMaterialInterface* DecalMaterial, struct FVector DecalSize, struct FVector Location, struct FRotator Rotation, float Lifespan, bool bUseGunshotDecalPool); // Function SceneComponentPools.SceneComponentPoolStatics.SpawnDecalAtLocation // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x9bea70
	void ReleaseSpawnedStaticMeshes(struct UObject* WorldContextObject); // Function SceneComponentPools.SceneComponentPoolStatics.ReleaseSpawnedStaticMeshes // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9bea00
	void ReleaseSpawnedStaticMeshComponent(struct UStaticMeshComponent* StaticMeshComponent); // Function SceneComponentPools.SceneComponentPoolStatics.ReleaseSpawnedStaticMeshComponent // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9be990
	void ReleaseSpawnedStaticMesh(struct UStaticMesh* StaticMeshComponent, struct USceneComponent* AttachToComponent, struct FPoolAttachmentInfo AttachInfo); // Function SceneComponentPools.SceneComponentPoolStatics.ReleaseSpawnedStaticMesh // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9be830
	void ReleaseSpawnedSkeletalMeshes(struct UObject* WorldContextObject); // Function SceneComponentPools.SceneComponentPoolStatics.ReleaseSpawnedSkeletalMeshes // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9be7c0
	void ReleaseSpawnedSkeletalMeshComponent(struct USkeletalMeshComponent* SkeletalMeshComponent); // Function SceneComponentPools.SceneComponentPoolStatics.ReleaseSpawnedSkeletalMeshComponent // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9be750
	void ReleaseSpawnedSkeletalMesh(struct USkeletalMesh* SkeletalMesh, struct UAnimInstance* AnimClass, struct USceneComponent* AttachToComponent, struct FPoolAttachmentInfo AttachInfo); // Function SceneComponentPools.SceneComponentPoolStatics.ReleaseSpawnedSkeletalMesh // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9be5b0
	void ReleaseSpawnedEmitters(struct UObject* WorldContextObject); // Function SceneComponentPools.SceneComponentPoolStatics.ReleaseSpawnedEmitters // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9be540
	void ReleaseSpawnedDecals(struct UObject* WorldContextObject); // Function SceneComponentPools.SceneComponentPoolStatics.ReleaseSpawnedDecals // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9be4d0
};

// Class SceneComponentPools.SkeletalMeshPoolComponent
// Size: 0x148 (Inherited: 0xd0)
struct USkeletalMeshPoolComponent : UBasePoolComponent {
	char UnknownData_D0[0x8]; // 0xd0(0x08)
	struct TArray<struct USkeletalMeshComponent*> UnusedComponentsArray; // 0xd8(0x10)
	struct TSet<struct USkeletalMeshComponent*> UsedComponentsSet; // 0xe8(0x50)
	struct USkeletalMeshComponent* PeekedSkeletalMeshComponent; // 0x138(0x08)
	struct USkeletalMeshComponent* PooledSkeletalMeshComponentClass; // 0x140(0x08)
};

// Class SceneComponentPools.StaticMeshPoolComponent
// Size: 0x148 (Inherited: 0xd0)
struct UStaticMeshPoolComponent : UBasePoolComponent {
	char UnknownData_D0[0x8]; // 0xd0(0x08)
	struct TArray<struct UStaticMeshComponent*> UnusedComponentsArray; // 0xd8(0x10)
	struct TSet<struct UStaticMeshComponent*> UsedComponentsSet; // 0xe8(0x50)
	struct UStaticMeshComponent* PeekedStaticMeshComponent; // 0x138(0x08)
	struct UStaticMeshComponent* PooledStaticMeshComponentClass; // 0x140(0x08)
};

