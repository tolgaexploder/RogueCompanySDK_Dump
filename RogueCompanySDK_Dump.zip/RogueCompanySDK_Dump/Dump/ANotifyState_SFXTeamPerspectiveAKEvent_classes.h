// BlueprintGeneratedClass ANotifyState_SFXTeamPerspectiveAKEvent.ANotifyState_SFXTeamPerspectiveAKEvent_C
// Size: 0x5d (Inherited: 0x5d)
struct UANotifyState_SFXTeamPerspectiveAKEvent_C : UANotifyState_SFXAKEvent_C {

	void SetTeamPerspective(struct USkeletalMeshComponent* MeshComp); // Function ANotifyState_SFXTeamPerspectiveAKEvent.ANotifyState_SFXTeamPerspectiveAKEvent_C.SetTeamPerspective // (Public|BlueprintCallable|BlueprintEvent|Const) // @ game+0x2587100
	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function ANotifyState_SFXTeamPerspectiveAKEvent.ANotifyState_SFXTeamPerspectiveAKEvent_C.Received_NotifyEnd // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x2587100
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function ANotifyState_SFXTeamPerspectiveAKEvent.ANotifyState_SFXTeamPerspectiveAKEvent_C.Received_NotifyBegin // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x2587100
};

