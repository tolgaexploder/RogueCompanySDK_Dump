// WidgetBlueprintGeneratedClass FullMap.FullMap_C
// Size: 0x6a1 (Inherited: 0x630)
struct UFullMap_C : UKSFullMapWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x630(0x08)
	struct UImage* background; // 0x638(0x08)
	struct UCanvasPanel* OverlaidObjects; // 0x640(0x08)
	struct URetainerBox* RetainerBox_1; // 0x648(0x08)
	struct UScaleBox* ScaleBox_1; // 0x650(0x08)
	struct UImage* StaticNoise; // 0x658(0x08)
	struct AMinimapRenderer_C* MinimapRenderer; // 0x660(0x08)
	struct UTexture2D* WorkingTexture; // 0x668(0x08)
	float ZoomLevel; // 0x670(0x04)
	float MinZoom; // 0x674(0x04)
	float MaxZoom; // 0x678(0x04)
	bool Dragging; // 0x67c(0x01)
	char UnknownData_67D[0x3]; // 0x67d(0x03)
	float ZoomExponentialBase; // 0x680(0x04)
	float ScrollZoomFactor; // 0x684(0x04)
	struct UMinimapIcon_C* LocalPlayerIcon; // 0x688(0x08)
	float DefaultZoom; // 0x690(0x04)
	char UnknownData_694[0x4]; // 0x694(0x04)
	struct AKSRoyaleSafeZone* RoyaleZone; // 0x698(0x08)
	bool MapDisabled; // 0x6a0(0x01)

	struct UKSMapIconWidgetBase* CreateNewIconWidget(struct UKSMapIconWidgetBase* WidgetClass, int32_t UniqueId, struct AKSPlayerState* CreatingPlayer, enum class EDisplayType ParentMapDisplayType, struct AActor* AssociatedActor, struct UObject* AssociatedObject, struct FVector DefaultLocation, float Lifespan); // Function FullMap.FullMap_C.CreateNewIconWidget // (Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	bool IsOnMap(struct FVector2D MapCoords); // Function FullMap.FullMap_C.IsOnMap // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	float ToIconRenderAngle(float PlayerAngle); // Function FullMap.FullMap_C.ToIconRenderAngle // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	struct FVector2D ToIconRenderCoords(struct FVector2D MapCoords); // Function FullMap.FullMap_C.ToIconRenderCoords // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	bool NavigateBack(); // Function FullMap.FullMap_C.NavigateBack // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ApplyZoom(float ZoomInput); // Function FullMap.FullMap_C.ApplyZoom // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ConstrainMapScreenPosition(struct FVector2D ProposedPosition, struct FVector2D ConstrainedPosition); // Function FullMap.FullMap_C.ConstrainMapScreenPosition // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	struct FEventReply OnMouseMove(struct FGeometry MyGeometry, struct FPointerEvent MouseEvent); // Function FullMap.FullMap_C.OnMouseMove // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	struct FEventReply OnMouseButtonUp(struct FGeometry MyGeometry, struct FPointerEvent MouseEvent); // Function FullMap.FullMap_C.OnMouseButtonUp // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent MouseEvent); // Function FullMap.FullMap_C.OnMouseButtonDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	struct FEventReply OnMouseWheel(struct FGeometry MyGeometry, struct FPointerEvent MouseEvent); // Function FullMap.FullMap_C.OnMouseWheel // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function FullMap.FullMap_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void FindMinimapRenderer(); // Function FullMap.FullMap_C.FindMinimapRenderer // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GetMapTexture(); // Function FullMap.FullMap_C.GetMapTexture // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnShown(); // Function FullMap.FullMap_C.OnShown // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function FullMap.FullMap_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidgetNavigation(); // Function FullMap.FullMap_C.InitializeWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeWidgetButtonListeners(); // Function FullMap.FullMap_C.InitializeWidgetButtonListeners // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void MapButtonClose(); // Function FullMap.FullMap_C.MapButtonClose // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function FullMap.FullMap_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Handle Zone Wait(float TimeUntilShrink); // Function FullMap.FullMap_C.Handle Zone Wait // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnScrambleStateChanged(bool Scrambled); // Function FullMap.FullMap_C.OnScrambleStateChanged // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void RemoveSelf(); // Function FullMap.FullMap_C.RemoveSelf // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void DisplayToMapWidget(struct UKSMapIconWidgetBase* MapIcon); // Function FullMap.FullMap_C.DisplayToMapWidget // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_FullMap(int32_t EntryPoint); // Function FullMap.FullMap_C.ExecuteUbergraph_FullMap // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

