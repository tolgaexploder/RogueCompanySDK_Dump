// WidgetBlueprintGeneratedClass GrenadeMarker.GrenadeMarker_C
// Size: 0x3c9 (Inherited: 0x318)
struct UGrenadeMarker_C : UKSMapIconWidgetBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x318(0x08)
	struct UWidgetAnimation* Anim_PulseLoop; // 0x320(0x08)
	struct UImage* Arrow; // 0x328(0x08)
	struct UWBP_AsyncIcon_C* Icon; // 0x330(0x08)
	struct UInvalidationBox* InvalidationBox_1; // 0x338(0x08)
	struct UWBP_AsyncIcon_C* PulseIcon; // 0x340(0x08)
	struct UOverlay* PulseWrapper; // 0x348(0x08)
	struct AKSProjectile_Grenade* TrackedGrenade; // 0x350(0x08)
	enum class MarkerDisplayRegion CurrentDisplayRegion; // 0x358(0x01)
	char UnknownData_359[0x3]; // 0x359(0x03)
	float InnerDamageRadius; // 0x35c(0x04)
	float MaxDamageRadius; // 0x360(0x04)
	struct FLinearColor StartingBaseIconColor; // 0x364(0x10)
	struct FLinearColor MaximumBaseIconColor; // 0x374(0x10)
	float MaxBaseIconScale; // 0x384(0x04)
	float MinBaseIconScale; // 0x388(0x04)
	float MaxPulseScale; // 0x38c(0x04)
	float MinPulseScale; // 0x390(0x04)
	float MinPulseOpacity; // 0x394(0x04)
	float MaxPulseOpacity; // 0x398(0x04)
	float MaxPulseAnimPlaybackSpeed; // 0x39c(0x04)
	float MinPulseAnimPlaybackSpeed; // 0x3a0(0x04)
	struct FLinearColor StartingPulseColor; // 0x3a4(0x10)
	struct FLinearColor MaxPulseColor; // 0x3b4(0x10)
	float CautionRadius; // 0x3c4(0x04)
	bool bIsWithinWarningRange; // 0x3c8(0x01)

	bool ShouldUpdate(); // Function GrenadeMarker.GrenadeMarker_C.ShouldUpdate // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	struct UKSWeaponAsset* Get Weapon Asset or Secondary(); // Function GrenadeMarker.GrenadeMarker_C.Get Weapon Asset or Secondary // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	enum class ESlateVisibility Update(); // Function GrenadeMarker.GrenadeMarker_C.Update // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function GrenadeMarker.GrenadeMarker_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void PreConstruct(bool IsDesignTime); // Function GrenadeMarker.GrenadeMarker_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnWeaponAssetSet(struct AKSProjectile* Projectile, struct UKSWeaponAsset* WeaponAsset); // Function GrenadeMarker.GrenadeMarker_C.OnWeaponAssetSet // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function GrenadeMarker.GrenadeMarker_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_GrenadeMarker(int32_t EntryPoint); // Function GrenadeMarker.GrenadeMarker_C.ExecuteUbergraph_GrenadeMarker // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

