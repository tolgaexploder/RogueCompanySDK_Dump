// WidgetBlueprintGeneratedClass PistolReticle.PistolReticle_C
// Size: 0x2b8 (Inherited: 0x248)
struct UPistolReticle_C : UReticleBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x248(0x08)
	struct UWidgetAnimation* GrenadeAnim; // 0x250(0x08)
	struct UWidgetAnimation* KillAnim; // 0x258(0x08)
	struct UWidgetAnimation* HeadshotAnim; // 0x260(0x08)
	struct UWidgetAnimation* HitAnim; // 0x268(0x08)
	struct UWidgetAnimation* ADSFade; // 0x270(0x08)
	struct UImage* CenterDot; // 0x278(0x08)
	struct UImage* FrameLeft; // 0x280(0x08)
	struct UImage* FrameRight; // 0x288(0x08)
	struct UImage* HeadshotMarker; // 0x290(0x08)
	struct UImage* HitMarker; // 0x298(0x08)
	struct UImage* KillMarker; // 0x2a0(0x08)
	struct UImage* reddot; // 0x2a8(0x08)
	struct FTimerHandle GrenadeTickTimer; // 0x2b0(0x08)

	void UpdateOffset(float Offset); // Function PistolReticle.PistolReticle_C.UpdateOffset // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ChangeADS(bool Active); // Function PistolReticle.PistolReticle_C.ChangeADS // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ForceADS(bool Active); // Function PistolReticle.PistolReticle_C.ForceADS // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HitConfirm(); // Function PistolReticle.PistolReticle_C.HitConfirm // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Headshot(); // Function PistolReticle.PistolReticle_C.Headshot // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void KillConfirm(); // Function PistolReticle.PistolReticle_C.KillConfirm // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GrenadeTick(); // Function PistolReticle.PistolReticle_C.GrenadeTick // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GrenadeCook(bool Active, float TickPeriod); // Function PistolReticle.PistolReticle_C.GrenadeCook // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_PistolReticle(int32_t EntryPoint); // Function PistolReticle.PistolReticle_C.ExecuteUbergraph_PistolReticle // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

