// WidgetBlueprintGeneratedClass ModsWidget.ModsWidget_C
// Size: 0x530 (Inherited: 0x528)
struct UModsWidget_C : UKSViewedPawnModsWidget {
	struct UOverlay* Overlay; // 0x528(0x08)

	struct UOverlay* GetOverlay(); // Function ModsWidget.ModsWidget_C.GetOverlay // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

