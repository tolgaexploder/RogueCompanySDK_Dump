// WidgetBlueprintGeneratedClass WBP_CosmeticItem_Avatar.WBP_CosmeticItem_Avatar_C
// Size: 0x548 (Inherited: 0x4e0)
struct UWBP_CosmeticItem_Avatar_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UWBP_ButtonSlot_Cosmetic_C* Button; // 0x4e8(0x08)
	struct UWBP_AsyncIcon_C* WBP_AsyncIcon; // 0x4f0(0x08)
	struct UKSItem* KSItem; // 0x4f8(0x08)
	struct UPUMG_StoreItem* StoreItem; // 0x500(0x08)
	struct FMulticastInlineDelegate OnItemHovered; // 0x508(0x10)
	struct FMulticastInlineDelegate OnItemUnhovered; // 0x518(0x10)
	struct FMulticastInlineDelegate OnItemClicked; // 0x528(0x10)
	struct UAkAudioEvent* HoverAvatarItemSFX; // 0x538(0x08)
	struct UAkAudioEvent* ClickAvatarItemSFX; // 0x540(0x08)

	bool NavigateConfirm(); // Function WBP_CosmeticItem_Avatar.WBP_CosmeticItem_Avatar_C.NavigateConfirm // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetAvatarItemSlot(); // Function WBP_CosmeticItem_Avatar.WBP_CosmeticItem_Avatar_C.SetAvatarItemSlot // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnHoverSound(); // Function WBP_CosmeticItem_Avatar.WBP_CosmeticItem_Avatar_C.OnHoverSound // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnClickSound(); // Function WBP_CosmeticItem_Avatar.WBP_CosmeticItem_Avatar_C.OnClickSound // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function WBP_CosmeticItem_Avatar.WBP_CosmeticItem_Avatar_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function WBP_CosmeticItem_Avatar.WBP_CosmeticItem_Avatar_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PopulateSlot(); // Function WBP_CosmeticItem_Avatar.WBP_CosmeticItem_Avatar_C.PopulateSlot // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnAvatarHover(bool IsGamepad); // Function WBP_CosmeticItem_Avatar.WBP_CosmeticItem_Avatar_C.OnAvatarHover // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnAvatarUnhover(); // Function WBP_CosmeticItem_Avatar.WBP_CosmeticItem_Avatar_C.OnAvatarUnhover // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnAvatarClick(); // Function WBP_CosmeticItem_Avatar.WBP_CosmeticItem_Avatar_C.OnAvatarClick // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GamepadHover(); // Function WBP_CosmeticItem_Avatar.WBP_CosmeticItem_Avatar_C.GamepadHover // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void GamepadUnhover(); // Function WBP_CosmeticItem_Avatar.WBP_CosmeticItem_Avatar_C.GamepadUnhover // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void SetAvatarActive(bool IsActive); // Function WBP_CosmeticItem_Avatar.WBP_CosmeticItem_Avatar_C.SetAvatarActive // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_CosmeticItem_Avatar(int32_t EntryPoint); // Function WBP_CosmeticItem_Avatar.WBP_CosmeticItem_Avatar_C.ExecuteUbergraph_WBP_CosmeticItem_Avatar // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void OnItemClicked__DelegateSignature(struct UKSItem* KSItem, struct UWidget* Widget); // Function WBP_CosmeticItem_Avatar.WBP_CosmeticItem_Avatar_C.OnItemClicked__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnItemUnhovered__DelegateSignature(); // Function WBP_CosmeticItem_Avatar.WBP_CosmeticItem_Avatar_C.OnItemUnhovered__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnItemHovered__DelegateSignature(struct UKSItem* KSItem); // Function WBP_CosmeticItem_Avatar.WBP_CosmeticItem_Avatar_C.OnItemHovered__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

