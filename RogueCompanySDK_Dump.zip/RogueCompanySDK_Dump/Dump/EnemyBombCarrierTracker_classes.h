// BlueprintGeneratedClass EnemyBombCarrierTracker.EnemyBombCarrierTracker_C
// Size: 0x48 (Inherited: 0x28)
struct UEnemyBombCarrierTracker_C : UObject {
	struct AKSGameState_NeutralBomb* Bound Bomb Game State; // 0x28(0x08)
	int32_t Latest Info Id; // 0x30(0x04)
	char UnknownData_34[0x4]; // 0x34(0x04)
	struct APlayerController* Bound Player Controller; // 0x38(0x08)
	struct AKSPlayerState* Current Tracked Enemy Holder; // 0x40(0x08)

	void Try Create Tracking(struct AKSPlayerState* New Bomb Holder); // Function EnemyBombCarrierTracker.EnemyBombCarrierTracker_C.Try Create Tracking // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Try Remove Current Tracking(struct AKSPlayerState* New Bomb Holder); // Function EnemyBombCarrierTracker.EnemyBombCarrierTracker_C.Try Remove Current Tracking // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Bomb State Changed(struct FKSNeutralBombState BombState); // Function EnemyBombCarrierTracker.EnemyBombCarrierTracker_C.Handle Bomb State Changed // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Bind Game And Player(struct AKSGameState_NeutralBomb* Neutral Bomb Game State, struct APlayerController* Player Controller); // Function EnemyBombCarrierTracker.EnemyBombCarrierTracker_C.Bind Game And Player // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

