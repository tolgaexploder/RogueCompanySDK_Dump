// WidgetBlueprintGeneratedClass WBP_BattlePassAcquisitionScreen.WBP_BattlePassAcquisitionScreen_C
// Size: 0x578 (Inherited: 0x4e0)
struct UWBP_BattlePassAcquisitionScreen_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UWidgetAnimation* ShowUpsellAnim; // 0x4e8(0x08)
	struct UWidgetAnimation* Outro; // 0x4f0(0x08)
	struct UWidgetAnimation* Intro; // 0x4f8(0x08)
	struct UCanvasPanel* AcquisitionCanvas; // 0x500(0x08)
	struct UCanvasPanel* AnimCanvas; // 0x508(0x08)
	struct UImage* Image_221; // 0x510(0x08)
	struct UWBP_ItemPreviewStack_C* ItemPreviewStack; // 0x518(0x08)
	struct UImage* ReflectedgradientShade; // 0x520(0x08)
	struct UWBP_BattlePassAcquisitionTitle_C* WBP_BattlePassAcquisitionTitle_C_1; // 0x528(0x08)
	struct UWBP_BattlepassTransitionBanner_C* WBP_BattlepassTransitionBanner; // 0x530(0x08)
	struct UWBP_BattlePassUpsellPanel_C* WBP_BattlePassUpsellPanel; // 0x538(0x08)
	struct UWBP_ItemInfoContainer_Description_C* WBP_ItemInfoContainer_Description; // 0x540(0x08)
	struct UWBP_RewardsTrack_C* WBP_RewardsTrack; // 0x548(0x08)
	struct UKSActivityInstance* ActivityInstance; // 0x550(0x08)
	struct UWBP_RewardListEntry_C* SelectedEntry; // 0x558(0x08)
	struct FMulticastInlineDelegate PlayPremiumTransition; // 0x560(0x10)
	struct UPUMG_StoreItem* SelectedData; // 0x570(0x08)

	void HandleOnUpsellButton(); // Function WBP_BattlePassAcquisitionScreen.WBP_BattlePassAcquisitionScreen_C.HandleOnUpsellButton // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	bool NavigateConfirm(); // Function WBP_BattlePassAcquisitionScreen.WBP_BattlePassAcquisitionScreen_C.NavigateConfirm // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	struct FEventReply OnKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function WBP_BattlePassAcquisitionScreen.WBP_BattlePassAcquisitionScreen_C.OnKeyDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	bool NavigateBack(); // Function WBP_BattlePassAcquisitionScreen.WBP_BattlePassAcquisitionScreen_C.NavigateBack // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleOnRewardButtonClicked(struct UWBP_RewardListEntry_C* Widget, struct FCosmeticSlotDetails RewardSlotDetails, struct UPUMG_StoreItem* StoreItem); // Function WBP_BattlePassAcquisitionScreen.WBP_BattlePassAcquisitionScreen_C.HandleOnRewardButtonClicked // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleOnPageNavigated(int32_t Direction); // Function WBP_BattlePassAcquisitionScreen.WBP_BattlePassAcquisitionScreen_C.HandleOnPageNavigated // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnTransitionFinished(); // Function WBP_BattlePassAcquisitionScreen.WBP_BattlePassAcquisitionScreen_C.OnTransitionFinished // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void DisplayUpsellState(); // Function WBP_BattlePassAcquisitionScreen.WBP_BattlePassAcquisitionScreen_C.DisplayUpsellState // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetAcquisitionDisplay(struct UKSAcquisition* Acquisition); // Function WBP_BattlePassAcquisitionScreen.WBP_BattlePassAcquisitionScreen_C.SetAcquisitionDisplay // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function WBP_BattlePassAcquisitionScreen.WBP_BattlePassAcquisitionScreen_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnShown(); // Function WBP_BattlePassAcquisitionScreen.WBP_BattlePassAcquisitionScreen_C.OnShown // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function WBP_BattlePassAcquisitionScreen.WBP_BattlePassAcquisitionScreen_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnAcceptPrompt(); // Function WBP_BattlePassAcquisitionScreen.WBP_BattlePassAcquisitionScreen_C.OnAcceptPrompt // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidgetNavigation(); // Function WBP_BattlePassAcquisitionScreen.WBP_BattlePassAcquisitionScreen_C.InitializeWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeWidgetButtonListeners(); // Function WBP_BattlePassAcquisitionScreen.WBP_BattlePassAcquisitionScreen_C.InitializeWidgetButtonListeners // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnTriggerPageLeft(); // Function WBP_BattlePassAcquisitionScreen.WBP_BattlePassAcquisitionScreen_C.OnTriggerPageLeft // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnTriggerPageRight(); // Function WBP_BattlePassAcquisitionScreen.WBP_BattlePassAcquisitionScreen_C.OnTriggerPageRight // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void FocusGroupNavigateRightFailure(int32_t FocusGroup); // Function WBP_BattlePassAcquisitionScreen.WBP_BattlePassAcquisitionScreen_C.FocusGroupNavigateRightFailure // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void FocusGroupNavigateLeftFailure(int32_t FocusGroup); // Function WBP_BattlePassAcquisitionScreen.WBP_BattlePassAcquisitionScreen_C.FocusGroupNavigateLeftFailure // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnHide(); // Function WBP_BattlePassAcquisitionScreen.WBP_BattlePassAcquisitionScreen_C.OnHide // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_BattlePassAcquisitionScreen(int32_t EntryPoint); // Function WBP_BattlePassAcquisitionScreen.WBP_BattlePassAcquisitionScreen_C.ExecuteUbergraph_WBP_BattlePassAcquisitionScreen // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void PlayPremiumTransition__DelegateSignature(); // Function WBP_BattlePassAcquisitionScreen.WBP_BattlePassAcquisitionScreen_C.PlayPremiumTransition__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

