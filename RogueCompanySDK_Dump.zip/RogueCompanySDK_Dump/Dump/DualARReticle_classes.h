// WidgetBlueprintGeneratedClass DualARReticle.DualARReticle_C
// Size: 0x2d0 (Inherited: 0x248)
struct UDualARReticle_C : UReticleBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x248(0x08)
	struct UWidgetAnimation* GrenadeAnim; // 0x250(0x08)
	struct UWidgetAnimation* KillAnim; // 0x258(0x08)
	struct UWidgetAnimation* HeadshotAnim; // 0x260(0x08)
	struct UWidgetAnimation* HitAnim; // 0x268(0x08)
	struct UWidgetAnimation* ADSFade; // 0x270(0x08)
	struct UImage* BarBottom; // 0x278(0x08)
	struct UImage* BarLeft; // 0x280(0x08)
	struct UImage* BarRight; // 0x288(0x08)
	struct UImage* BarTop; // 0x290(0x08)
	struct UImage* CenterDot; // 0x298(0x08)
	struct UImage* HeadshotMarker; // 0x2a0(0x08)
	struct UImage* HitMarker; // 0x2a8(0x08)
	struct UImage* KillMarker; // 0x2b0(0x08)
	struct UImage* reddot; // 0x2b8(0x08)
	struct UImage* Reticle_Circle; // 0x2c0(0x08)
	struct FTimerHandle GrenadeTickTimer; // 0x2c8(0x08)

	void ChangeADS(bool Active); // Function DualARReticle.DualARReticle_C.ChangeADS // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ForceADS(bool Active); // Function DualARReticle.DualARReticle_C.ForceADS // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HitConfirm(); // Function DualARReticle.DualARReticle_C.HitConfirm // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Headshot(); // Function DualARReticle.DualARReticle_C.Headshot // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void KillConfirm(); // Function DualARReticle.DualARReticle_C.KillConfirm // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GrenadeCook(bool Active, float TickPeriod); // Function DualARReticle.DualARReticle_C.GrenadeCook // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GrenadeTick(); // Function DualARReticle.DualARReticle_C.GrenadeTick // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateOffset(float Offset); // Function DualARReticle.DualARReticle_C.UpdateOffset // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_DualARReticle(int32_t EntryPoint); // Function DualARReticle.DualARReticle_C.ExecuteUbergraph_DualARReticle // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

