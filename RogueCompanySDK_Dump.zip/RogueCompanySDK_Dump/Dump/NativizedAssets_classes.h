// Class NativizedAssets.__Delegates__UDirectReviveDroneModInst_C__pf3770280971
// Size: 0x28 (Inherited: 0x28)
struct U__Delegates__UDirectReviveDroneModInst_C__pf3770280971 : UObject {
};

