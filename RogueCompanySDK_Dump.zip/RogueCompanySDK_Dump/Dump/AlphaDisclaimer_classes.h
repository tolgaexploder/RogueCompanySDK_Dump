// WidgetBlueprintGeneratedClass AlphaDisclaimer.AlphaDisclaimer_C
// Size: 0x569 (Inherited: 0x4e0)
struct UAlphaDisclaimer_C : UKSAlphaDisclaimer {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UImage* ArrowDown; // 0x4e8(0x08)
	struct UImage* ArrowUp; // 0x4f0(0x08)
	struct UImage* Divider; // 0x4f8(0x08)
	struct UImage* EulaBg; // 0x500(0x08)
	struct UScrollBox* EulaContainer; // 0x508(0x08)
	struct UTextBlock* EulaText; // 0x510(0x08)
	struct UImage* Image_62; // 0x518(0x08)
	struct UWidgetSwitcher* NextSwitcher; // 0x520(0x08)
	struct UPopupButton_C* PopupButton; // 0x528(0x08)
	struct UImage* ScrollCalloutDown; // 0x530(0x08)
	struct UWidgetSwitcher* ScrollCalloutSwitcher; // 0x538(0x08)
	struct UImage* ScrollCalloutUp; // 0x540(0x08)
	struct UImage* StudioLogo; // 0x548(0x08)
	struct UImage* TitleLogo; // 0x550(0x08)
	struct UVerticalBox* VerticalBox_1; // 0x558(0x08)
	struct FTimerHandle CalloutTimer; // 0x560(0x08)
	bool CalloutHidden; // 0x568(0x01)

	void HideScrollCallout(); // Function AlphaDisclaimer.AlphaDisclaimer_C.HideScrollCallout // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ShowArrows(float Value, float MaxValue); // Function AlphaDisclaimer.AlphaDisclaimer_C.ShowArrows // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function AlphaDisclaimer.AlphaDisclaimer_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function AlphaDisclaimer.AlphaDisclaimer_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidgetNavigation(); // Function AlphaDisclaimer.AlphaDisclaimer_C.InitializeWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeWidgetButtonListeners(); // Function AlphaDisclaimer.AlphaDisclaimer_C.InitializeWidgetButtonListeners // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ScrollUpPressed(); // Function AlphaDisclaimer.AlphaDisclaimer_C.ScrollUpPressed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ScrollDownPressed(); // Function AlphaDisclaimer.AlphaDisclaimer_C.ScrollDownPressed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ScrollUpReleased(); // Function AlphaDisclaimer.AlphaDisclaimer_C.ScrollUpReleased // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ScrollDownReleased(); // Function AlphaDisclaimer.AlphaDisclaimer_C.ScrollDownReleased // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Input State Changed(enum class PGAME_INPUT_STATE InputState); // Function AlphaDisclaimer.AlphaDisclaimer_C.Handle Input State Changed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void CalloutTimerFunction(); // Function AlphaDisclaimer.AlphaDisclaimer_C.CalloutTimerFunction // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BndEvt__PopupButton_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature(int32_t Index); // Function AlphaDisclaimer.AlphaDisclaimer_C.BndEvt__PopupButton_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void OnHide(); // Function AlphaDisclaimer.AlphaDisclaimer_C.OnHide // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnShown(); // Function AlphaDisclaimer.AlphaDisclaimer_C.OnShown // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void Destruct(); // Function AlphaDisclaimer.AlphaDisclaimer_C.Destruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_AlphaDisclaimer(int32_t EntryPoint); // Function AlphaDisclaimer.AlphaDisclaimer_C.ExecuteUbergraph_AlphaDisclaimer // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

