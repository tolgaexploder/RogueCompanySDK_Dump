// WidgetBlueprintGeneratedClass PickupNotify.PickupNotify_C
// Size: 0x610 (Inherited: 0x510)
struct UPickupNotify_C : UKSViewedPawnWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x510(0x08)
	struct UTextBlock* HoldText; // 0x518(0x08)
	struct UImage* Image_435; // 0x520(0x08)
	struct UWBP_InputCallout_C* InputCallout; // 0x528(0x08)
	struct USizeBox* item_container; // 0x530(0x08)
	struct UWBP_AsyncIcon_C* ItemIcon; // 0x538(0x08)
	struct USizeBox* progress_wrapper; // 0x540(0x08)
	struct UVerticalBox* ProgressWrapper; // 0x548(0x08)
	struct UOverlay* prompt_container; // 0x550(0x08)
	struct UTextBlock* PromptText; // 0x558(0x08)
	struct UProgressBar* TimeRemainingBar; // 0x560(0x08)
	struct UTextBlock* TimeRemainingText; // 0x568(0x08)
	struct FText Item Name; // 0x570(0x18)
	struct FText Pickup Key; // 0x588(0x18)
	bool InteractableFlag; // 0x5a0(0x01)
	char UnknownData_5A1[0x7]; // 0x5a1(0x07)
	struct FText Prompt; // 0x5a8(0x18)
	struct TArray<struct FName> ActionName; // 0x5c0(0x10)
	bool Active; // 0x5d0(0x01)
	char UnknownData_5D1[0x3]; // 0x5d1(0x03)
	float EndTime; // 0x5d4(0x04)
	float StartTime; // 0x5d8(0x04)
	float TimeRemaining; // 0x5dc(0x04)
	float MinimumShowProgressTime; // 0x5e0(0x04)
	char UnknownData_5E4[0x4]; // 0x5e4(0x04)
	struct FText PrePromptText; // 0x5e8(0x18)
	struct AActor* Last Hovered Interactable; // 0x600(0x08)
	struct AActor* CachedInteract; // 0x608(0x08)

	void Should Show Interaction(bool Return Value); // Function PickupNotify.PickupNotify_C.Should Show Interaction // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void IsBombDropInteraction(struct AActor* Interactable, bool Return Value); // Function PickupNotify.PickupNotify_C.IsBombDropInteraction // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void BindInteractAction(); // Function PickupNotify.PickupNotify_C.BindInteractAction // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UnBindInteractAction(); // Function PickupNotify.PickupNotify_C.UnBindInteractAction // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetItemIcon(struct AActor* Actor); // Function PickupNotify.PickupNotify_C.SetItemIcon // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void DisplayTimeRemaining(float Seconds); // Function PickupNotify.PickupNotify_C.DisplayTimeRemaining // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnSkydiveEarlyOutChanged(bool CanRemove); // Function PickupNotify.PickupNotify_C.OnSkydiveEarlyOutChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	struct FText Bind_PostButtonText(); // Function PickupNotify.PickupNotify_C.Bind_PostButtonText // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void GetSplitPrompt(struct FString PreSplit, struct FString PostSplit); // Function PickupNotify.PickupNotify_C.GetSplitPrompt // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	struct FText Bind_PreButtonText(); // Function PickupNotify.PickupNotify_C.Bind_PreButtonText // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	enum class ESlateVisibility Bind_RootVisibility(); // Function PickupNotify.PickupNotify_C.Bind_RootVisibility // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void OnHoveredInteractableChanged(struct AActor* Actor); // Function PickupNotify.PickupNotify_C.OnHoveredInteractableChanged // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	struct FText Get Pickup Text(); // Function PickupNotify.PickupNotify_C.Get Pickup Text // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void PreClearPawn(); // Function PickupNotify.PickupNotify_C.PreClearPawn // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void PostSetPawn(); // Function PickupNotify.PickupNotify_C.PostSetPawn // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function PickupNotify.PickupNotify_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ModeChange(enum class PGAME_INPUT_STATE InputState); // Function PickupNotify.PickupNotify_C.ModeChange // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function PickupNotify.PickupNotify_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void HandleKillCamChange(bool Enabled); // Function PickupNotify.PickupNotify_C.HandleKillCamChange // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnKeyBindSettingChanged(struct FName KeyBindName); // Function PickupNotify.PickupNotify_C.OnKeyBindSettingChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void StartInteract(struct AActor* Target, float Duration); // Function PickupNotify.PickupNotify_C.StartInteract // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void StartAction(float Duration, struct FText Prompt); // Function PickupNotify.PickupNotify_C.StartAction // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function PickupNotify.PickupNotify_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void end(); // Function PickupNotify.PickupNotify_C.end // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Bomb State Changed(struct FKSNeutralBombState BombState); // Function PickupNotify.PickupNotify_C.Handle Bomb State Changed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_PickupNotify(int32_t EntryPoint); // Function PickupNotify.PickupNotify_C.ExecuteUbergraph_PickupNotify // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

