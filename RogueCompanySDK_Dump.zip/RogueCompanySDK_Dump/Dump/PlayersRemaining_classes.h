// WidgetBlueprintGeneratedClass PlayersRemaining.PlayersRemaining_C
// Size: 0x504 (Inherited: 0x4e0)
struct UPlayersRemaining_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UTextBlock* CounterText; // 0x4e8(0x08)
	struct UImage* Image_1; // 0x4f0(0x08)
	struct UImage* Image_2; // 0x4f8(0x08)
	int32_t AlivePlayerCounter; // 0x500(0x04)

	void Construct(); // Function PlayersRemaining.PlayersRemaining_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void RefreshPlayerCount(); // Function PlayersRemaining.PlayersRemaining_C.RefreshPlayerCount // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandlePlayerEliminated(struct AKSPlayerState* PlayerState); // Function PlayersRemaining.PlayersRemaining_C.HandlePlayerEliminated // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandlePlayerSpawn(struct AKSCharacterBase* NewCharacter); // Function PlayersRemaining.PlayersRemaining_C.HandlePlayerSpawn // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandlePhaseChange(struct FName NewPhaseName, struct FName PreviousPhaseName); // Function PlayersRemaining.PlayersRemaining_C.HandlePhaseChange // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_PlayersRemaining(int32_t EntryPoint); // Function PlayersRemaining.PlayersRemaining_C.ExecuteUbergraph_PlayersRemaining // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

