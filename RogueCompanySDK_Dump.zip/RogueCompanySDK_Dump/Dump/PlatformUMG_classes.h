// Class PlatformUMG.PUMG_AcquisitionManager
// Size: 0x50 (Inherited: 0x28)
struct UPUMG_AcquisitionManager : UObject {
	struct FMulticastInlineDelegate OnAcquisitionSuccess; // 0x28(0x10)
	struct FMulticastInlineDelegate OnAcquisitionFailed; // 0x38(0x10)
	struct UPUMG_StoreItemHelper* StoreItemHelper; // 0x48(0x08)
};

// Class PlatformUMG.PUMG_AsyncImage
// Size: 0x260 (Inherited: 0x218)
struct UPUMG_AsyncImage : UImage {
	struct UWidget* WaitingWidget; // 0x218(0x08)
	struct FMulticastInlineDelegate OnAsyncImageLoadStarted; // 0x220(0x10)
	struct FMulticastInlineDelegate OnAsyncImageLoadComplete; // 0x230(0x10)
	struct FMulticastInlineDelegate OnAsyncImageLoadCanceled; // 0x240(0x10)
	struct FMulticastInlineDelegate OnAsyncImageBrushChanged; // 0x250(0x10)

	void ShowWaitingWidget(); // Function PlatformUMG.PUMG_AsyncImage.ShowWaitingWidget // (Native|Event|Public|BlueprintEvent) // @ game+0x88c050
	void HideWaitingWidget(); // Function PlatformUMG.PUMG_AsyncImage.HideWaitingWidget // (Native|Event|Public|BlueprintEvent) // @ game+0x88b7e0
};

// Class PlatformUMG.PUMG_BlueprintFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UPUMG_BlueprintFunctionLibrary : UBlueprintFunctionLibrary {

	bool IsWithEditor(); // Function PlatformUMG.PUMG_BlueprintFunctionLibrary.IsWithEditor // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x88b9f0
	float GetUMG_DPI_Scaling(); // Function PlatformUMG.PUMG_BlueprintFunctionLibrary.GetUMG_DPI_Scaling // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x88b750
	struct FName GetKeyName(struct FKey Key); // Function PlatformUMG.PUMG_BlueprintFunctionLibrary.GetKeyName // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x88b4a0
	struct FKey GetGamepadConfirmButton(); // Function PlatformUMG.PUMG_BlueprintFunctionLibrary.GetGamepadConfirmButton // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x88b430
	struct FKey GetGamepadCancelButton(); // Function PlatformUMG.PUMG_BlueprintFunctionLibrary.GetGamepadCancelButton // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x88b3c0
	bool GetGamepadButtonForAction(struct FName Action, struct FKey Button); // Function PlatformUMG.PUMG_BlueprintFunctionLibrary.GetGamepadButtonForAction // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x88b2b0
	bool GetButtonForActionMappingUsingWidget(struct UWidget* InWidget, struct FName Action, struct FKey Button); // Function PlatformUMG.PUMG_BlueprintFunctionLibrary.GetButtonForActionMappingUsingWidget // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x88acd0
	bool GetButtonForActionMapping(struct FName Action, struct FKey Button, bool IsGamepadKey); // Function PlatformUMG.PUMG_BlueprintFunctionLibrary.GetButtonForActionMapping // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x88ab80
	bool GetAllButtonsForActionMappingUsingWidget(struct UWidget* InWidget, struct FName Action, struct TArray<struct FKey> Buttons); // Function PlatformUMG.PUMG_BlueprintFunctionLibrary.GetAllButtonsForActionMappingUsingWidget // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x88aa10
	bool GetAllButtonsForActionMapping(struct FName Action, struct TArray<struct FKey> Buttons, bool IsGamepadKey); // Function PlatformUMG.PUMG_BlueprintFunctionLibrary.GetAllButtonsForActionMapping // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x88a8a0
};

// Class PlatformUMG.PUMG_CanvasPanel
// Size: 0x138 (Inherited: 0x138)
struct UPUMG_CanvasPanel : UCanvasPanel {

	void PlaceWidgetUnder(struct UUserWidget* BottomWidget, struct UUserWidget* TopWidget); // Function PlatformUMG.PUMG_CanvasPanel.PlaceWidgetUnder // (Final|Native|Public|BlueprintCallable) // @ game+0x88bac0
};

// Class PlatformUMG.PUMG_DataFactory
// Size: 0x38 (Inherited: 0x28)
struct UPUMG_DataFactory : UObject {
	struct APUMG_HUD* MyHud; // 0x28(0x08)
	char UnknownData_30[0x8]; // 0x30(0x08)

	bool IsLoggedIn(); // Function PlatformUMG.PUMG_DataFactory.IsLoggedIn // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x88b830
};

// Class PlatformUMG.PUMG_ChatDataFactory
// Size: 0x118 (Inherited: 0x38)
struct UPUMG_ChatDataFactory : UPUMG_DataFactory {
	struct FMulticastInlineDelegate OnChatMessageReceived; // 0x38(0x10)
	struct FMulticastInlineDelegate OnChatMessageRead; // 0x48(0x10)
	struct FMulticastInlineDelegate OnChatChannelJoined; // 0x58(0x10)
	struct FMulticastInlineDelegate OnChatChannelLeft; // 0x68(0x10)
	struct TArray<int32_t> ChatMessageIds; // 0x78(0x10)
	struct TArray<int32_t> PendingChatMessageIds; // 0x88(0x10)
	struct TMap<int32_t, struct FPUMG_ChatData> ChatMessagesById; // 0x98(0x50)
	int32_t LastCreatedMessageId; // 0xe8(0x04)
	char UnknownData_EC[0x4]; // 0xec(0x04)
	struct TArray<int64_t> m_FilteredPlayerIds; // 0xf0(0x10)
	struct TArray<struct FPUMG_ChatCommand> ChatCommands; // 0x100(0x10)
	char UnknownData_110[0x8]; // 0x110(0x08)

	void SetMaxMessageCount(int32_t MaxMessageCount); // Function PlatformUMG.PUMG_ChatDataFactory.SetMaxMessageCount // (Final|Native|Public|BlueprintCallable) // @ game+0x88bfd0
	void SendChatToPlayer(struct FString Message, int64_t TargetPlayerId); // Function PlatformUMG.PUMG_ChatDataFactory.SendChatToPlayer // (Final|Native|Public|BlueprintCallable) // @ game+0x88be70
	void SendChatToChannel(struct FString Message, enum class EPUMG_ChatChannel Channel); // Function PlatformUMG.PUMG_ChatDataFactory.SendChatToChannel // (Final|Native|Public|BlueprintCallable) // @ game+0x88bd90
	bool RemovePlayerFilter(int64_t PlayerId); // Function PlatformUMG.PUMG_ChatDataFactory.RemovePlayerFilter // (Final|Native|Public|BlueprintCallable) // @ game+0x88bce0
	bool RemoveChatCommand(struct FString Command); // Function PlatformUMG.PUMG_ChatDataFactory.RemoveChatCommand // (Final|Native|Public|BlueprintCallable) // @ game+0x88bc30
	bool RemoveAllChatCommands(struct UObject* Target); // Function PlatformUMG.PUMG_ChatDataFactory.RemoveAllChatCommands // (Final|Native|Public|BlueprintCallable) // @ game+0x88bba0
	void QueueCheckPendingMessages(); // Function PlatformUMG.PUMG_ChatDataFactory.QueueCheckPendingMessages // (Final|Native|Protected) // @ game+0x88bb80
	void MarkMessageAsRead(int32_t MessageId); // Function PlatformUMG.PUMG_ChatDataFactory.MarkMessageAsRead // (Final|Native|Public|BlueprintCallable) // @ game+0x88ba40
	void ListChatCommands(); // Function PlatformUMG.PUMG_ChatDataFactory.ListChatCommands // (Final|Native|Public|BlueprintCallable) // @ game+0x88ba20
	bool IsValidMessage(struct FPUMG_ChatData Message); // Function PlatformUMG.PUMG_ChatDataFactory.IsValidMessage // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x88b8f0
	bool IsPlayerFilteredFromChat(int64_t PlayerId); // Function PlatformUMG.PUMG_ChatDataFactory.IsPlayerFilteredFromChat // (Final|Native|Public|BlueprintCallable) // @ game+0x88b860
	void HandleCommunicationSettingChanged(); // Function PlatformUMG.PUMG_ChatDataFactory.HandleCommunicationSettingChanged // (Final|Native|Protected) // @ game+0x88b780
	struct FPUMG_ChatData GetMessage(int32_t MessageId); // Function PlatformUMG.PUMG_ChatDataFactory.GetMessage // (Final|Native|Public|BlueprintCallable) // @ game+0x88b5c0
	int32_t GetMaxMessageCount(); // Function PlatformUMG.PUMG_ChatDataFactory.GetMaxMessageCount // (Final|Native|Public|BlueprintCallable) // @ game+0x88b590
	enum class EPCOM_PrivilegeStatus GetChatPrivilegeStatus(); // Function PlatformUMG.PUMG_ChatDataFactory.GetChatPrivilegeStatus // (Final|Native|Public|BlueprintCallable) // @ game+0x88ae20
	void GetActiveChatChannels(bool IncludePersonalChannel, struct TArray<struct FPUMG_ActiveChatChannelData> ActiveChatChatChannels); // Function PlatformUMG.PUMG_ChatDataFactory.GetActiveChatChannels // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x88a7a0
	int32_t FindChatCommandIndex(struct FString Command); // Function PlatformUMG.PUMG_ChatDataFactory.FindChatCommandIndex // (Final|Native|Protected) // @ game+0x88a6d0
	bool ExecuteChatCommandLine(struct FString CommandLine); // Function PlatformUMG.PUMG_ChatDataFactory.ExecuteChatCommandLine // (Final|Native|Public|BlueprintCallable) // @ game+0x88a620
	void CheckPendingMessages(); // Function PlatformUMG.PUMG_ChatDataFactory.CheckPendingMessages // (Final|Native|Protected) // @ game+0x88a600
	void BeginProcessingChatMessage(struct FPUMG_ChatData Message); // Function PlatformUMG.PUMG_ChatDataFactory.BeginProcessingChatMessage // (Final|Native|Public|HasOutParms) // @ game+0x88a420
	void AddSystemMessage(struct FText Message); // Function PlatformUMG.PUMG_ChatDataFactory.AddSystemMessage // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x88a350
	bool AddPlayerFilter(int64_t PlayerId); // Function PlatformUMG.PUMG_ChatDataFactory.AddPlayerFilter // (Final|Native|Public|BlueprintCallable) // @ game+0x88a2c0
	void AddGameMessage(struct FText Message, enum class EPUMG_ChatChannel Channel); // Function PlatformUMG.PUMG_ChatDataFactory.AddGameMessage // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x88a1a0
	bool AddChatCommand(struct FString Command, struct FText Desc, struct UObject* Target, struct FString Function, struct FString Alias1, struct FString Alias2, struct FString Alias3, struct FString Alias4); // Function PlatformUMG.PUMG_ChatDataFactory.AddChatCommand // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x889e90
};

// Class PlatformUMG.PUMG_CollectionDataFactory
// Size: 0x68 (Inherited: 0x38)
struct UPUMG_CollectionDataFactory : UPUMG_DataFactory {
	struct FMulticastInlineDelegate OnCollectionAvatarsUpdated; // 0x38(0x10)
	struct FMulticastInlineDelegate OnCollectionAvatarAcquisition; // 0x48(0x10)
	struct TArray<struct FPUMG_AvatarData> CollectionAvatars; // 0x58(0x10)
};

// Class PlatformUMG.PUMG_FriendDataFactory
// Size: 0x120 (Inherited: 0x38)
struct UPUMG_FriendDataFactory : UPUMG_DataFactory {
	struct FMulticastInlineDelegate OnFriendDataUpdated; // 0x38(0x10)
	struct FMulticastInlineDelegate OnFriendAddSuccess; // 0x48(0x10)
	struct FMulticastInlineDelegate OnFriendAddError; // 0x58(0x10)
	struct FMulticastInlineDelegate FriendInviteReceived; // 0x68(0x10)
	struct FMulticastInlineDelegate OnFriendAdded; // 0x78(0x10)
	struct FMulticastInlineDelegate OnFriendRejected; // 0x88(0x10)
	int32_t OnlineFriends; // 0x98(0x04)
	int32_t TotalFriends; // 0x9c(0x04)
	struct TArray<struct FPUMG_FriendData> CachedFriends; // 0xa0(0x10)
	struct TArray<struct FPUMG_FriendData> CachedPendingFriends; // 0xb0(0x10)
	struct TArray<struct FPUMG_FriendData> CachedFriendRequests; // 0xc0(0x10)
	char UnknownData_D0[0x28]; // 0xd0(0x28)
	float FriendsListUpdatePollInterval; // 0xf8(0x04)
	char UnknownData_FC[0x4]; // 0xfc(0x04)
	struct FTimerHandle FriendsListUpdatePollingTimerHandle; // 0x100(0x08)
	bool IsFriendsListUpdatePollingEnabled; // 0x108(0x01)
	char UnknownData_109[0x17]; // 0x109(0x17)

	void UIX_OnRemoveFriend(int64_t PlayerId); // Function PlatformUMG.PUMG_FriendDataFactory.UIX_OnRemoveFriend // (Final|Native|Public|BlueprintCallable) // @ game+0x88c270
	void UIX_OnRejectFriendRequest(int64_t PlayerId); // Function PlatformUMG.PUMG_FriendDataFactory.UIX_OnRejectFriendRequest // (Final|Native|Public|BlueprintCallable) // @ game+0x88c1f0
	void UIX_OnCancelFriendRequest(int64_t PlayerId); // Function PlatformUMG.PUMG_FriendDataFactory.UIX_OnCancelFriendRequest // (Final|Native|Public|BlueprintCallable) // @ game+0x88c170
	void UIX_OnAddFriend(struct UPUMG_PlayerInfo* playerinfo); // Function PlatformUMG.PUMG_FriendDataFactory.UIX_OnAddFriend // (Final|Native|Public|BlueprintCallable) // @ game+0x88c0f0
	void UIX_OnAcceptFriendRequest(int64_t PlayerId); // Function PlatformUMG.PUMG_FriendDataFactory.UIX_OnAcceptFriendRequest // (Final|Native|Public|BlueprintCallable) // @ game+0x88c070
	void SetEnableFriendsListUpdatePolling(bool InBool); // Function PlatformUMG.PUMG_FriendDataFactory.SetEnableFriendsListUpdatePolling // (Final|Native|Public|BlueprintCallable) // @ game+0x88bf50
	void RequestUpdateFriendsList(); // Function PlatformUMG.PUMG_FriendDataFactory.RequestUpdateFriendsList // (Final|Native|Public|BlueprintCallable) // @ game+0x88bd70
	bool IsCrossplaySocialEnabled(); // Function PlatformUMG.PUMG_FriendDataFactory.IsCrossplaySocialEnabled // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x88b800
	void HandleFriendsListUpdatePolling(); // Function PlatformUMG.PUMG_FriendDataFactory.HandleFriendsListUpdatePolling // (Final|Native|Public) // @ game+0x88b7c0
	void HandleCrossplaySettingChanged(); // Function PlatformUMG.PUMG_FriendDataFactory.HandleCrossplaySettingChanged // (Final|Native|Protected) // @ game+0x88b7a0
	struct TArray<struct FPUMG_FriendData> GetPendingFriends(); // Function PlatformUMG.PUMG_FriendDataFactory.GetPendingFriends // (Final|Native|Public|BlueprintCallable) // @ game+0x88b660
	struct TArray<struct FPUMG_FriendData> GetFriends(); // Function PlatformUMG.PUMG_FriendDataFactory.GetFriends // (Final|Native|Public|BlueprintCallable) // @ game+0x88b1c0
	struct TArray<struct FPUMG_FriendData> GetFriendRequests(); // Function PlatformUMG.PUMG_FriendDataFactory.GetFriendRequests // (Final|Native|Public|BlueprintCallable) // @ game+0x88b0d0
	struct FText GetFriendName(int64_t PlayerId); // Function PlatformUMG.PUMG_FriendDataFactory.GetFriendName // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x88afe0
	struct TSoftObjectPtr<struct UTexture2D> GetFriendAvatarTexture(struct FPUMG_FriendData Friend); // Function PlatformUMG.PUMG_FriendDataFactory.GetFriendAvatarTexture // (Native|Public|BlueprintCallable) // @ game+0x88ae70
	bool GetEnableFriendsListUpdatePolling(); // Function PlatformUMG.PUMG_FriendDataFactory.GetEnableFriendsListUpdatePolling // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x88ae50
	void FriendRemoveResponse(); // Function PlatformUMG.PUMG_FriendDataFactory.FriendRemoveResponse // (Final|Native|Public) // @ game+0x88a780
	bool CheckAlreadyFriends(struct FString FriendName); // Function PlatformUMG.PUMG_FriendDataFactory.CheckAlreadyFriends // (Final|Native|Public|BlueprintCallable) // @ game+0x88a510
};

// Class PlatformUMG.GamepadPromptInterface
// Size: 0x28 (Inherited: 0x28)
struct UGamepadPromptInterface : UInterface {

	bool UnregisterOnClear(); // Function PlatformUMG.GamepadPromptInterface.UnregisterOnClear // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void SetPrompt(struct FText PromptText); // Function PlatformUMG.GamepadPromptInterface.SetPrompt // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x2587100
	void ClearPrompt(); // Function PlatformUMG.GamepadPromptInterface.ClearPrompt // (Event|Public|BlueprintEvent) // @ game+0x2587100
};

// Class PlatformUMG.PUMG_GamepadDataFactory
// Size: 0x88 (Inherited: 0x38)
struct UPUMG_GamepadDataFactory : UPUMG_DataFactory {
	char UnknownData_38[0x50]; // 0x38(0x50)

	bool UnregisterPromptForButton(struct FKey Button); // Function PlatformUMG.PUMG_GamepadDataFactory.UnregisterPromptForButton // (Final|Native|Public|BlueprintCallable) // @ game+0x892a50
	void SetPromptForGamepadButton(struct FKey Button, struct FText PromptText); // Function PlatformUMG.PUMG_GamepadDataFactory.SetPromptForGamepadButton // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8918a0
	void RemovePromptForGamepadButton(struct FKey Button); // Function PlatformUMG.PUMG_GamepadDataFactory.RemovePromptForGamepadButton // (Final|Native|Public|BlueprintCallable) // @ game+0x8915a0
	bool RegisterPromptWidgetForButton(struct UWidget* Widget, struct FKey Button); // Function PlatformUMG.PUMG_GamepadDataFactory.RegisterPromptWidgetForButton // (Final|Native|Public|BlueprintCallable) // @ game+0x891470
	void ClearAllGamepadPrompts(); // Function PlatformUMG.PUMG_GamepadDataFactory.ClearAllGamepadPrompts // (Final|Native|Public|BlueprintCallable) // @ game+0x88fd70
};

// Class PlatformUMG.PUMG_GameViewportClient
// Size: 0x348 (Inherited: 0x338)
struct UPUMG_GameViewportClient : UGameViewportClient {
	char UnknownData_338[0x10]; // 0x338(0x10)
};

// Class PlatformUMG.PUMG_LobbyHUD
// Size: 0x28 (Inherited: 0x28)
struct UPUMG_LobbyHUD : UInterface {
};

// Class PlatformUMG.PUMG_HUD
// Size: 0x550 (Inherited: 0x310)
struct APUMG_HUD : AHUD {
	struct FMulticastInlineDelegate OnInputStateChanged; // 0x310(0x10)
	struct TMap<int64_t, struct FMulticastInlineDelegate> PlayerDataUpdated; // 0x320(0x50)
	struct UPUMG_InputManager* InputManager; // 0x370(0x08)
	struct UPUMG_ViewManager* ViewManager; // 0x378(0x08)
	struct UPUMG_InputManager* InputManagerClass; // 0x380(0x08)
	struct UPUMG_UISoundTheme* SoundTheme; // 0x388(0x08)
	char UnknownData_390[0x1c0]; // 0x390(0x1c0)

	void TestHirezLogin(struct FString User, struct FString password); // Function PlatformUMG.PUMG_HUD.TestHirezLogin // (Final|Exec|Native|Protected) // @ game+0x891c30
	void TestAutoLogin(int32_t ControllerId); // Function PlatformUMG.PUMG_HUD.TestAutoLogin // (Final|Exec|Native|Protected) // @ game+0x891bb0
	void ShowSystemTrayNotification(struct FString popupType); // Function PlatformUMG.PUMG_HUD.ShowSystemTrayNotification // (Final|Exec|Native|Public|BlueprintCallable) // @ game+0x891b10
	void SetUseNewUIFeatures(bool UseNewFeatures); // Function PlatformUMG.PUMG_HUD.SetUseNewUIFeatures // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void SetUIFocus(); // Function PlatformUMG.PUMG_HUD.SetUIFocus // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x891a10
	void SetNavigationEnabled(bool Enabled); // Function PlatformUMG.PUMG_HUD.SetNavigationEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x891720
	void OnQuit(); // Function PlatformUMG.PUMG_HUD.OnQuit // (Native|Public|BlueprintCallable) // @ game+0x891370
	bool OnNavigateBack(); // Function PlatformUMG.PUMG_HUD.OnNavigateBack // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnConfirmQuit(); // Function PlatformUMG.PUMG_HUD.OnConfirmQuit // (Native|Protected) // @ game+0x891350
	struct UPUMG_PlayerInfo* NewPlayerInfo(); // Function PlatformUMG.PUMG_HUD.NewPlayerInfo // (Final|Native|Protected) // @ game+0x891320
	bool IsLobbyHUD(); // Function PlatformUMG.PUMG_HUD.IsLobbyHUD // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x890e20
	bool IsCrossplayEnabled(); // Function PlatformUMG.PUMG_HUD.IsCrossplayEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x88b800
	void InputStateChangePassthrough(enum class PGAME_INPUT_STATE InputState); // Function PlatformUMG.PUMG_HUD.InputStateChangePassthrough // (Final|Native|Public) // @ game+0x890d40
	struct UPUMG_ViewManager* GetViewManager(); // Function PlatformUMG.PUMG_HUD.GetViewManager // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8908f0
	struct UPUMG_PopupManager* GetPopupManager(); // Function PlatformUMG.PUMG_HUD.GetPopupManager // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	struct APlayerController* GetPlayerControllerOwner(); // Function PlatformUMG.PUMG_HUD.GetPlayerControllerOwner // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x890810
	struct UPUMG_PlayerInfo* GetOrCreatePlayerInfo(int64_t PlayerId); // Function PlatformUMG.PUMG_HUD.GetOrCreatePlayerInfo // (Final|Native|Public) // @ game+0x890280
	struct UPUMG_InputManager* GetInputManager(); // Function PlatformUMG.PUMG_HUD.GetInputManager // (Final|Native|Public|BlueprintCallable) // @ game+0x890160
	enum class PGAME_INPUT_STATE GetCurrentInputState(); // Function PlatformUMG.PUMG_HUD.GetCurrentInputState // (Final|Native|Public|BlueprintCallable) // @ game+0x88ff60
	void DisplayGenericPopup(struct FString sTitle, struct FString sDesc); // Function PlatformUMG.PUMG_HUD.DisplayGenericPopup // (Final|Native|Public|BlueprintCallable) // @ game+0x88fe70
	void DisplayGenericError(struct FString sDesc); // Function PlatformUMG.PUMG_HUD.DisplayGenericError // (Final|Native|Public|BlueprintCallable) // @ game+0x88fdd0
};

// Class PlatformUMG.PUMG_InputManager
// Size: 0xd8 (Inherited: 0x28)
struct UPUMG_InputManager : UObject {
	struct TMap<struct UPUMG_Widget*, struct FPUMG_InputFocusDetails> InputFocusData; // 0x28(0x50)
	char UnknownData_78[0x28]; // 0x78(0x28)
	struct UInputComponent* InputComponent; // 0xa0(0x08)
	char UnknownData_A8[0x30]; // 0xa8(0x30)

	void HandleModeChange(enum class PGAME_INPUT_STATE Mode); // Function PlatformUMG.PUMG_InputManager.HandleModeChange // (Final|Native|Public) // @ game+0x890c30
	bool GetFocusedWidget(struct UPUMG_Widget* ParentWidget, struct UWidget* FocusWidget); // Function PlatformUMG.PUMG_InputManager.GetFocusedWidget // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x890090
	void ClearNavInputThrottled(); // Function PlatformUMG.PUMG_InputManager.ClearNavInputThrottled // (Final|Native|Public) // @ game+0x88fdb0
	void ClearNavInputDebouncedThrottled(); // Function PlatformUMG.PUMG_InputManager.ClearNavInputDebouncedThrottled // (Final|Native|Public) // @ game+0x88fd90
};

// Class PlatformUMG.PUMG_JsonDataFactory
// Size: 0x48 (Inherited: 0x38)
struct UPUMG_JsonDataFactory : UPUMG_DataFactory {
	char UnknownData_38[0x10]; // 0x38(0x10)

	void HandleJsonReady(struct UPGame_LandingPanelJSONHandler* pHandler); // Function PlatformUMG.PUMG_JsonDataFactory.HandleJsonReady // (Native|Protected) // @ game+0x890ba0
	void HandleImagesReady(struct UPGame_LandingPanelJSONHandler* pHandler); // Function PlatformUMG.PUMG_JsonDataFactory.HandleImagesReady // (Native|Protected) // @ game+0x890b10
};

// Class PlatformUMG.PUMG_Loadout
// Size: 0xb0 (Inherited: 0x28)
struct UPUMG_Loadout : UObject {
	struct FMulticastInlineDelegate OnRenamed; // 0x28(0x10)
	struct FMulticastInlineDelegate OnNumberChanged; // 0x38(0x10)
	struct FMulticastInlineDelegate OnTypeChanged; // 0x48(0x10)
	struct FMulticastInlineDelegate OnServerUpdate; // 0x58(0x10)
	struct FMulticastInlineDelegate OnLocalUpdate; // 0x68(0x10)
	char UnknownData_78[0x38]; // 0x78(0x38)
};

// Class PlatformUMG.PUMG_LoadoutDataFactory
// Size: 0xa8 (Inherited: 0x28)
struct UPUMG_LoadoutDataFactory : UObject {
	char UnknownData_28[0x8]; // 0x28(0x08)
	struct FMulticastInlineDelegate OnLoadoutsInitialized; // 0x30(0x10)
	struct FMulticastInlineDelegate OnLoadoutsUpdatedFromServer; // 0x40(0x10)
	struct FMulticastInlineDelegate OnLoadoutFactoryReadyNoLoadouts; // 0x50(0x10)
	struct FMulticastInlineDelegate OnLoadoutChanged; // 0x60(0x10)
	struct FMulticastInlineDelegate OnLoadoutAdded; // 0x70(0x10)
	struct FMulticastInlineDelegate OnLoadoutDeleted; // 0x80(0x10)
	char UnknownData_90[0x8]; // 0x90(0x08)
	struct TArray<struct UPUMG_Loadout*> Loadouts; // 0x98(0x10)
};

// Class PlatformUMG.PUMG_LoginDataFactory
// Size: 0x108 (Inherited: 0x38)
struct UPUMG_LoginDataFactory : UPUMG_DataFactory {
	struct FMulticastInlineDelegate OnLoginUserChanged; // 0x38(0x10)
	struct FMulticastInlineDelegate OnLoginStateChanged; // 0x48(0x10)
	struct FMulticastInlineDelegate OnLoginError; // 0x58(0x10)
	char UnknownData_68[0x8]; // 0x68(0x08)
	struct FMulticastInlineDelegate OnControllerDisconnected; // 0x70(0x10)
	bool bAllowLoginDuringPartialInstall; // 0x80(0x01)
	char UnknownData_81[0x7]; // 0x81(0x07)
	struct UDataTable* ErrorMsgsDT; // 0x88(0x08)
	bool bAttemptedDeferredInviteAutoLogin; // 0x90(0x01)
	char UnknownData_91[0x67]; // 0x91(0x67)
	struct FMulticastInlineDelegate OnLoginWaitQueueMessage; // 0xf8(0x10)

	bool UpdateControllers(); // Function PlatformUMG.PUMG_LoginDataFactory.UpdateControllers // (Final|Native|Public|BlueprintCallable) // @ game+0x892b40
	void UIX_TriggerAutoLogin(); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_TriggerAutoLogin // (Native|Public|BlueprintCallable) // @ game+0x892a30
	void UIX_OnTwoFactorSubmit(struct FString AuthCode); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnTwoFactorSubmit // (Final|Native|Public|BlueprintCallable) // @ game+0x8928c0
	void UIX_OnTwoFactorDecline(); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnTwoFactorDecline // (Final|Native|Public|BlueprintCallable) // @ game+0x8921c0
	void UIX_OnSubmitLogin(struct FString UserName, struct FString password); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnSubmitLogin // (Final|Native|Public|BlueprintCallable) // @ game+0x892750
	void UIX_OnSubmitConsoleLogin(int32_t ControllerId); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnSubmitConsoleLogin // (Final|Native|Public|BlueprintCallable) // @ game+0x8926d0
	void UIX_OnSubmitAutoLogin(int32_t ControllerId); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnSubmitAutoLogin // (Final|Native|Public|BlueprintCallable) // @ game+0x8926d0
	void UIX_OnPlayerCreate(struct FString PlayerName); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnPlayerCreate // (Final|Native|Public|BlueprintCallable) // @ game+0x8925f0
	void UIX_OnLinkExistingAccount(struct FString UserName, struct FString password); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnLinkExistingAccount // (Final|Native|Public|BlueprintCallable) // @ game+0x892480
	void UIX_OnLinkDecline(); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnLinkDecline // (Final|Native|Public|BlueprintCallable) // @ game+0x892460
	void UIX_OnLinkCreateAccount(struct FString UserName, struct FString password, struct FString Email, bool bAcceptAgeReqs); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnLinkCreateAccount // (Final|Native|Public|BlueprintCallable) // @ game+0x892220
	void UIX_OnEulaDecline(); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnEulaDecline // (Final|Native|Public|BlueprintCallable) // @ game+0x8921c0
	void UIX_OnEulaAccept(); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnEulaAccept // (Final|Native|Public|BlueprintCallable) // @ game+0x892200
	void UIX_OnChangeUserAccount(); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnChangeUserAccount // (Final|Native|Public|BlueprintCallable) // @ game+0x8921e0
	void UIX_OnCancelLogin(); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnCancelLogin // (Final|Native|Public|BlueprintCallable) // @ game+0x8921c0
	void UIX_OnAccountCreate(struct FString UserName, struct FString password, struct FString Email, bool bAcceptAgeReqs); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnAccountCreate // (Final|Native|Public|BlueprintCallable) // @ game+0x891f80
	void TriggerAutoLogin(); // Function PlatformUMG.PUMG_LoginDataFactory.TriggerAutoLogin // (Native|Public) // @ game+0x891d20
	bool ShouldDisplayUsername(); // Function PlatformUMG.PUMG_LoginDataFactory.ShouldDisplayUsername // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x891ae0
	bool ShouldDisplayDisconnectError(); // Function PlatformUMG.PUMG_LoginDataFactory.ShouldDisplayDisconnectError // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x891ab0
	void SetUserErrorDataTable(struct UDataTable* ErrorMsgTable); // Function PlatformUMG.PUMG_LoginDataFactory.SetUserErrorDataTable // (Final|Native|Public|BlueprintCallable) // @ game+0x891a30
	void RecordLoginState(enum class EPUMG_LoginState NewState); // Function PlatformUMG.PUMG_LoginDataFactory.RecordLoginState // (Final|Native|Private) // @ game+0x8913f0
	void LoginEvent_ShowEula(); // Function PlatformUMG.PUMG_LoginDataFactory.LoginEvent_ShowEula // (Final|Native|Private) // @ game+0x891300
	void LoginEvent_Queued(uint32_t QueuePosition, uint32_t QueueSize, uint32_t queueEstimatedWait); // Function PlatformUMG.PUMG_LoginDataFactory.LoginEvent_Queued // (Final|Native|Private) // @ game+0x891200
	void LoginEvent_LoginRequested(); // Function PlatformUMG.PUMG_LoginDataFactory.LoginEvent_LoginRequested // (Final|Native|Private) // @ game+0x8911e0
	void LoginEvent_LoggedIn(); // Function PlatformUMG.PUMG_LoginDataFactory.LoginEvent_LoggedIn // (Final|Native|Private) // @ game+0x8911c0
	void LoginEvent_FailedClient(struct FText ErrorMsg); // Function PlatformUMG.PUMG_LoginDataFactory.LoginEvent_FailedClient // (Final|Native|Private) // @ game+0x8910e0
	void LoginEvent_Failed(uint32_t ErrorMsgId); // Function PlatformUMG.PUMG_LoginDataFactory.LoginEvent_Failed // (Final|Native|Private) // @ game+0x891060
	void LoginEvent_CreatePlayer(uint32_t ErrorMsgId); // Function PlatformUMG.PUMG_LoginDataFactory.LoginEvent_CreatePlayer // (Final|Native|Private) // @ game+0x890fe0
	bool LoadEULAFile(struct FString SaveText); // Function PlatformUMG.PUMG_LoginDataFactory.LoadEULAFile // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x890f30
	void HandleControllerPairingChange(int32_t ControllerIndex, int32_t NewUserId, int32_t OldUserId); // Function PlatformUMG.PUMG_LoginDataFactory.HandleControllerPairingChange // (Final|Native|Private) // @ game+0x890a10
	void HandleControllerConnectionChange(bool IsConnection, int32_t UserId, int32_t ControllerIndex); // Function PlatformUMG.PUMG_LoginDataFactory.HandleControllerConnectionChange // (Final|Native|Private) // @ game+0x890910
	struct FString GetVersion(); // Function PlatformUMG.PUMG_LoginDataFactory.GetVersion // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x890870
	bool GetLastDisconnectReason(struct FText ErrorMsg); // Function PlatformUMG.PUMG_LoginDataFactory.GetLastDisconnectReason // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x890180
	bool GetCurrentPlayerName(struct FText NameText); // Function PlatformUMG.PUMG_LoginDataFactory.GetCurrentPlayerName // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x88ffb0
	enum class EPUMG_LoginState GetCurrentLoginState(); // Function PlatformUMG.PUMG_LoginDataFactory.GetCurrentLoginState // (Final|Native|Public|BlueprintCallable) // @ game+0x88ff90
};

// Class PlatformUMG.PUMG_PartyDataFactory
// Size: 0x178 (Inherited: 0x38)
struct UPUMG_PartyDataFactory : UPUMG_DataFactory {
	struct FMulticastInlineDelegate OnPartyDataUpdated; // 0x38(0x10)
	struct FMulticastInlineDelegate OnPartyLocalPlayerLeft; // 0x48(0x10)
	struct FMulticastInlineDelegate OnPartyLocalPlayerPromoted; // 0x58(0x10)
	struct FMulticastInlineDelegate OnPartyMemberPromoted; // 0x68(0x10)
	struct FMulticastInlineDelegate OnPartyMemberDataUpdated; // 0x78(0x10)
	struct FMulticastInlineDelegate OnPartyMemberDataAdded; // 0x88(0x10)
	struct FMulticastInlineDelegate OnPartyMemberRemoved; // 0x98(0x10)
	struct FMulticastInlineDelegate OnPartyMemberLeftGeneric; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnPartyInvitationError; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnPartyInvitationSent; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnPartyInvitationReceived; // 0xd8(0x10)
	struct FMulticastInlineDelegate OnPartyMessageReceived; // 0xe8(0x10)
	struct FMulticastInlineDelegate OnPartyInvitationAccepted; // 0xf8(0x10)
	struct FMulticastInlineDelegate OnPartyInvitationRejected; // 0x108(0x10)
	struct FMulticastInlineDelegate OnPartyInvitationExpired; // 0x118(0x10)
	struct FMulticastInlineDelegate OnPartyInfoUpdated; // 0x128(0x10)
	struct TArray<struct FPUMG_PartyMemberData> PartyMembers; // 0x138(0x10)
	struct UPUMG_PlayerInfo* PartyInviter; // 0x148(0x08)
	struct FString LastInviteSentErrorMessage; // 0x150(0x10)
	char UnknownData_160[0x18]; // 0x160(0x18)

	void UIX_PromoteMemberToLeader(int64_t PlayerId); // Function PlatformUMG.PUMG_PartyDataFactory.UIX_PromoteMemberToLeader // (Native|Public|BlueprintCallable) // @ game+0x8929a0
	void UIX_LeaveParty(); // Function PlatformUMG.PUMG_PartyDataFactory.UIX_LeaveParty // (Native|Public|BlueprintCallable) // @ game+0x891f60
	void UIX_KickMemberFromParty(int64_t PlayerId); // Function PlatformUMG.PUMG_PartyDataFactory.UIX_KickMemberFromParty // (Native|Public|BlueprintCallable) // @ game+0x891ed0
	bool UIX_InviteMemberToParty(int64_t PlayerId); // Function PlatformUMG.PUMG_PartyDataFactory.UIX_InviteMemberToParty // (Native|Public|BlueprintCallable) // @ game+0x891e30
	void UIX_GiveInvitePermission(int64_t PlayerId); // Function PlatformUMG.PUMG_PartyDataFactory.UIX_GiveInvitePermission // (Native|Public|BlueprintCallable) // @ game+0x891da0
	void UIX_DisbandParty(); // Function PlatformUMG.PUMG_PartyDataFactory.UIX_DisbandParty // (Native|Public|BlueprintCallable) // @ game+0x891d80
	void UIX_DenyPartyInvitation(); // Function PlatformUMG.PUMG_PartyDataFactory.UIX_DenyPartyInvitation // (Final|Native|Public|BlueprintCallable) // @ game+0x891d60
	void UIX_AcceptPartyInvitation(); // Function PlatformUMG.PUMG_PartyDataFactory.UIX_AcceptPartyInvitation // (Final|Native|Public|BlueprintCallable) // @ game+0x891d40
	void SetPartyInfo(struct FString Key, struct FString Value); // Function PlatformUMG.PUMG_PartyDataFactory.SetPartyInfo // (Final|Native|Public|BlueprintCallable) // @ game+0x8917b0
	void SendPartyMessage(struct FString Data); // Function PlatformUMG.PUMG_PartyDataFactory.SendPartyMessage // (Final|Native|Public|BlueprintCallable) // @ game+0x891680
	void PartyPromoteResponse(); // Function PlatformUMG.PUMG_PartyDataFactory.PartyPromoteResponse // (Final|Native|Public) // @ game+0x8913d0
	void PartyLeaveResponse(); // Function PlatformUMG.PUMG_PartyDataFactory.PartyLeaveResponse // (Final|Native|Public) // @ game+0x8913b0
	void PartyKickResponse(); // Function PlatformUMG.PUMG_PartyDataFactory.PartyKickResponse // (Final|Native|Public) // @ game+0x891390
	bool IsPlayerInParty(int64_t PlayerId); // Function PlatformUMG.PUMG_PartyDataFactory.IsPlayerInParty // (Native|Public|BlueprintCallable) // @ game+0x890e90
	bool IsPending(); // Function PlatformUMG.PUMG_PartyDataFactory.IsPending // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x890e70
	bool IsPartyMaxed(); // Function PlatformUMG.PUMG_PartyDataFactory.IsPartyMaxed // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x890e50
	bool IsLeader(); // Function PlatformUMG.PUMG_PartyDataFactory.IsLeader // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x890df0
	bool IsInParty(); // Function PlatformUMG.PUMG_PartyDataFactory.IsInParty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x890dc0
	bool HasInvitePrivileges(int64_t PlayerId); // Function PlatformUMG.PUMG_PartyDataFactory.HasInvitePrivileges // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x890cb0
	int32_t GetQueueId(); // Function PlatformUMG.PUMG_PartyDataFactory.GetQueueId // (Final|Native|Public|BlueprintCallable) // @ game+0x890840
	struct FText GetPartyMemeberName(int64_t PlayerId); // Function PlatformUMG.PUMG_PartyDataFactory.GetPartyMemeberName // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x890720
	struct TArray<struct FPUMG_PartyMemberData> GetPartyMembers(); // Function PlatformUMG.PUMG_PartyDataFactory.GetPartyMembers // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x890590
	int32_t GetPartyMemberCount(); // Function PlatformUMG.PUMG_PartyDataFactory.GetPartyMemberCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x890570
	struct FPUMG_PartyMemberData GetPartyMemberByID(int64_t PlayerId); // Function PlatformUMG.PUMG_PartyDataFactory.GetPartyMemberByID // (Final|Native|Public|BlueprintCallable) // @ game+0x890440
	struct UPUMG_PlayerInfo* GetPartyInviter(); // Function PlatformUMG.PUMG_PartyDataFactory.GetPartyInviter // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x890420
	enum class EPUMG_PartyInviteRightsMode GetPartyInviteMode(); // Function PlatformUMG.PUMG_PartyDataFactory.GetPartyInviteMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x890400
	struct FString GetPartyInfo(struct FString Key); // Function PlatformUMG.PUMG_PartyDataFactory.GetPartyInfo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x890310
	int32_t GetMaxPartyMembers(); // Function PlatformUMG.PUMG_PartyDataFactory.GetMaxPartyMembers // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x890260
	bool CheckPartyMemberIsLeader(int64_t PlayerId); // Function PlatformUMG.PUMG_PartyDataFactory.CheckPartyMemberIsLeader // (Final|Native|Public|BlueprintCallable) // @ game+0x88fce0
};

// Class PlatformUMG.PUMG_PlayerDataFactory
// Size: 0xb0 (Inherited: 0x38)
struct UPUMG_PlayerDataFactory : UPUMG_DataFactory {
	struct FMulticastInlineDelegate OnPlayerDataChanged; // 0x38(0x10)
	struct FMulticastInlineDelegate OnPlayerRankChanged; // 0x48(0x10)
	struct FMulticastInlineDelegate OnCrossplayChanged; // 0x58(0x10)
	int64_t PlayerId; // 0x68(0x08)
	struct FString PlayerName; // 0x70(0x10)
	int32_t Level; // 0x80(0x04)
	int32_t AvatarId; // 0x84(0x04)
	int32_t LastMMR; // 0x88(0x04)
	int32_t CurrentMMR; // 0x8c(0x04)
	int32_t BestMMR; // 0x90(0x04)
	int32_t CurrentWinRank; // 0x94(0x04)
	int32_t PreviousWinRank; // 0x98(0x04)
	int32_t CurrentWinPeak; // 0x9c(0x04)
	int32_t PreviousWinPeak; // 0xa0(0x04)
	int32_t CurrentWinStreak; // 0xa4(0x04)
	int32_t PreviousWinStreak; // 0xa8(0x04)
	char UnknownData_AC[0x4]; // 0xac(0x04)

	void OnSelectAvatar(int32_t ItemId); // Function PlatformUMG.PUMG_PlayerDataFactory.OnSelectAvatar // (Final|Native|Public|BlueprintCallable) // @ game+0x8966d0
	struct TSoftObjectPtr<struct UTexture2D> GetAvatarIcon(); // Function PlatformUMG.PUMG_PlayerDataFactory.GetAvatarIcon // (Native|Public|BlueprintCallable) // @ game+0x895750
};

// Class PlatformUMG.PUMG_PlayerInfo
// Size: 0x80 (Inherited: 0x28)
struct UPUMG_PlayerInfo : UObject {
	struct FMulticastInlineDelegate OnFilteredNameSetDel; // 0x28(0x10)
	char UnknownData_38[0x48]; // 0x38(0x48)

	void SetIgnored(bool Ignored); // Function PlatformUMG.PUMG_PlayerInfo.SetIgnored // (Final|Native|Public|BlueprintCallable) // @ game+0x8967d0
	bool IsIgnored(); // Function PlatformUMG.PUMG_PlayerInfo.IsIgnored // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x896320
	int64_t GetPlayerId(); // Function PlatformUMG.PUMG_PlayerInfo.GetPlayerId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x895e60
	struct FText GetName(); // Function PlatformUMG.PUMG_PlayerInfo.GetName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x895d00
	struct FString GetMctsName(); // Function PlatformUMG.PUMG_PlayerInfo.GetMctsName // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x895c80
	int32_t GetAvatarItemId(); // Function PlatformUMG.PUMG_PlayerInfo.GetAvatarItemId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8957c0
};

// Class PlatformUMG.PUMG_PlayerInventoryHelper
// Size: 0x118 (Inherited: 0x28)
struct UPUMG_PlayerInventoryHelper : UObject {
	char UnknownData_28[0xf0]; // 0x28(0xf0)
};

// Class PlatformUMG.PUMG_PlayerWhoDataFactory
// Size: 0x60 (Inherited: 0x38)
struct UPUMG_PlayerWhoDataFactory : UPUMG_DataFactory {
	struct FMulticastInlineDelegate OnSearchByNameResultsUpdated; // 0x38(0x10)
	struct TArray<struct UPUMG_PlayerInfo*> CachedSearchByNameResults; // 0x48(0x10)
	char UnknownData_58[0x8]; // 0x58(0x08)

	void UIX_SearchByNameForPlayer(struct FString PlayerName, bool bIncludeOfflinePlayers); // Function PlatformUMG.PUMG_PlayerWhoDataFactory.UIX_SearchByNameForPlayer // (Final|Native|Public|BlueprintCallable) // @ game+0x896a40
	struct TArray<struct UPUMG_PlayerInfo*> GetSearchByNameResults(); // Function PlatformUMG.PUMG_PlayerWhoDataFactory.GetSearchByNameResults // (Final|Native|Public|BlueprintCallable) // @ game+0x895fd0
};

// Class PlatformUMG.PUMG_Widget
// Size: 0x4a0 (Inherited: 0x238)
struct UPUMG_Widget : UUserWidget {
	struct FMulticastInlineDelegate OnGamepadHovered; // 0x238(0x10)
	struct FMulticastInlineDelegate OnMouseEntered; // 0x248(0x10)
	struct FMulticastInlineDelegate OnNavigateBack; // 0x258(0x10)
	struct FMulticastInlineDelegate OnTextureLoadComplete; // 0x268(0x10)
	struct FMulticastInlineDelegate OnNavigateUpFailed; // 0x278(0x10)
	struct FMulticastInlineDelegate OnNavigateDownFailed; // 0x288(0x10)
	struct FMulticastInlineDelegate OnNavigateLeftFailed; // 0x298(0x10)
	struct FMulticastInlineDelegate OnNavigateRightFailed; // 0x2a8(0x10)
	struct FMulticastInlineDelegate OnFocusGroupNavigateUpFailed; // 0x2b8(0x10)
	struct FMulticastInlineDelegate OnFocusGroupNavigateDownFailed; // 0x2c8(0x10)
	struct FMulticastInlineDelegate OnFocusGroupNavigateLeftFailed; // 0x2d8(0x10)
	struct FMulticastInlineDelegate OnFocusGroupNavigateRightFailed; // 0x2e8(0x10)
	struct FMulticastInlineDelegate OnHideSequenceFinished; // 0x2f8(0x10)
	struct FMulticastInlineDelegate OnShowSequenceFinished; // 0x308(0x10)
	struct FWeakObjectPtr<struct APUMG_HUD> MyHud; // 0x318(0x08)
	bool CloseOnLogout; // 0x320(0x01)
	bool IsComponent; // 0x321(0x01)
	bool StartsHidden; // 0x322(0x01)
	bool UsesBlocker; // 0x323(0x01)
	bool BlockerClickToClose; // 0x324(0x01)
	char UnknownData_325[0x3]; // 0x325(0x03)
	struct TSoftObjectPtr<struct UTexture2D> LoadedTexture; // 0x328(0x28)
	char UnknownData_350[0x150]; // 0x350(0x150)

	void UpdateRegistrationToInputManager(struct UWidget* Widget, int32_t FocusGroup, struct UWidget* Up, struct UWidget* Down, struct UWidget* Left, struct UWidget* Right); // Function PlatformUMG.PUMG_Widget.UpdateRegistrationToInputManager // (Final|Native|Public|BlueprintCallable) // @ game+0x89fc00
	void UnregisterWidgetFromInputManager(struct UWidget* Widget); // Function PlatformUMG.PUMG_Widget.UnregisterWidgetFromInputManager // (Final|Native|Public|BlueprintCallable) // @ game+0x89fb80
	void UnregisterFocusGroup(int32_t FocusGroup); // Function PlatformUMG.PUMG_Widget.UnregisterFocusGroup // (Final|Native|Public|BlueprintCallable) // @ game+0x89fb00
	void UninitializeWidget(); // Function PlatformUMG.PUMG_Widget.UninitializeWidget // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x7ba320
	bool SwapViewRoute(struct FName RouteName, struct FName SwapTargetRoute, bool ForceTransition); // Function PlatformUMG.PUMG_Widget.SwapViewRoute // (Final|Native|Public|BlueprintCallable) // @ game+0x89fa00
	void StartShowSequence(struct FName FromRoute, struct FName ToRoute); // Function PlatformUMG.PUMG_Widget.StartShowSequence // (Native|Event|Public|BlueprintEvent) // @ game+0x89f930
	void StartHideSequence(struct FName FromRoute, struct FName ToRoute); // Function PlatformUMG.PUMG_Widget.StartHideSequence // (Native|Event|Public|BlueprintEvent) // @ game+0x89f860
	void ShowWidget(); // Function PlatformUMG.PUMG_Widget.ShowWidget // (Native|Public|BlueprintCallable) // @ game+0x89f840
	void SetPendingRouteData(struct FName RouteName, struct UObject* Data); // Function PlatformUMG.PUMG_Widget.SetPendingRouteData // (Final|Native|Public|BlueprintCallable) // @ game+0x89f780
	void SetFocusToWidgetOfGroup(int32_t FocusGroup, struct UPUMG_Widget* Widget); // Function PlatformUMG.PUMG_Widget.SetFocusToWidgetOfGroup // (Final|Native|Public|BlueprintCallable) // @ game+0x89f6c0
	struct UWidget* SetFocusToThis(); // Function PlatformUMG.PUMG_Widget.SetFocusToThis // (Final|Native|Public|BlueprintCallable) // @ game+0x89f690
	void SetFocusToGroup(int32_t FocusGroup, bool KeepLastFocus); // Function PlatformUMG.PUMG_Widget.SetFocusToGroup // (Final|Native|Public|BlueprintCallable) // @ game+0x89f5d0
	void SetDefaultFocusForGroup(struct UWidget* Widget, int32_t FocusGroup); // Function PlatformUMG.PUMG_Widget.SetDefaultFocusForGroup // (Final|Native|Public|BlueprintCallable) // @ game+0x89f510
	bool RemoveViewRoute(struct FName RouteName, bool ForceTransition); // Function PlatformUMG.PUMG_Widget.RemoveViewRoute // (Final|Native|Public|BlueprintCallable) // @ game+0x89f450
	bool RemoveTopViewRoute(bool ForceTransition); // Function PlatformUMG.PUMG_Widget.RemoveTopViewRoute // (Final|Native|Public|BlueprintCallable) // @ game+0x89f3c0
	void RegisterWidgetToInputManager(struct UWidget* Widget, int32_t FocusGroup, struct UWidget* Up, struct UWidget* Down, struct UWidget* Left, struct UWidget* Right); // Function PlatformUMG.PUMG_Widget.RegisterWidgetToInputManager // (Final|Native|Public|BlueprintCallable) // @ game+0x89f200
	void OnShown(); // Function PlatformUMG.PUMG_Widget.OnShown // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnHide(); // Function PlatformUMG.PUMG_Widget.OnHide // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnGamepadUnhover(); // Function PlatformUMG.PUMG_Widget.OnGamepadUnhover // (Final|Native|Public|BlueprintCallable) // @ game+0x89f140
	void OnGamepadHover(); // Function PlatformUMG.PUMG_Widget.OnGamepadHover // (Final|Native|Public|BlueprintCallable) // @ game+0x89f120
	void NavigateUpFailure(); // Function PlatformUMG.PUMG_Widget.NavigateUpFailure // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void NavigateRightFailure(); // Function PlatformUMG.PUMG_Widget.NavigateRightFailure // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void NavigateLeftFailure(); // Function PlatformUMG.PUMG_Widget.NavigateLeftFailure // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void NavigateDownFailure(); // Function PlatformUMG.PUMG_Widget.NavigateDownFailure // (Event|Public|BlueprintEvent) // @ game+0x2587100
	bool NavigateConfirmPressed(); // Function PlatformUMG.PUMG_Widget.NavigateConfirmPressed // (Native|Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x89f0f0
	void NavigateConfirmCancelled(); // Function PlatformUMG.PUMG_Widget.NavigateConfirmCancelled // (Native|Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x89f0d0
	bool NavigateConfirm(); // Function PlatformUMG.PUMG_Widget.NavigateConfirm // (Native|Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x89f0a0
	bool NavigateBackPressed(); // Function PlatformUMG.PUMG_Widget.NavigateBackPressed // (Native|Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x89f070
	void NavigateBackCancelled(); // Function PlatformUMG.PUMG_Widget.NavigateBackCancelled // (Native|Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x89f050
	bool NavigateBack(); // Function PlatformUMG.PUMG_Widget.NavigateBack // (Native|Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x89f020
	bool IsFocusEnabled(); // Function PlatformUMG.PUMG_Widget.IsFocusEnabled // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x89eff0
	void InitializeWidgetNavigation(); // Function PlatformUMG.PUMG_Widget.InitializeWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeWidgetButtonListeners(); // Function PlatformUMG.PUMG_Widget.InitializeWidgetButtonListeners // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function PlatformUMG.PUMG_Widget.InitializeWidget // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x89ef60
	void InheritFocusGroupFromWidget(int32_t TargetFocusGroupNum, struct UPUMG_Widget* SourceWidget, int32_t SourceFocusGroupNum); // Function PlatformUMG.PUMG_Widget.InheritFocusGroupFromWidget // (Final|Native|Public|BlueprintCallable) // @ game+0x89ee60
	void HideWidget(); // Function PlatformUMG.PUMG_Widget.HideWidget // (Native|Public|BlueprintCallable) // @ game+0x89ee40
	struct UPUMG_ViewManager* GetViewManager(); // Function PlatformUMG.PUMG_Widget.GetViewManager // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89ee10
	bool GetUsesBlocker(); // Function PlatformUMG.PUMG_Widget.GetUsesBlocker // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x89edf0
	bool GetPendingRouteData(struct FName RouteName, struct UObject* Data); // Function PlatformUMG.PUMG_Widget.GetPendingRouteData // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x89ed20
	struct FGeometry GetGeometryFromLastTick(); // Function PlatformUMG.PUMG_Widget.GetGeometryFromLastTick // (Final|Native|Public|BlueprintCallable) // @ game+0x89ecb0
	bool GetCurrentFocusGroup(int32_t OutFocusGroup); // Function PlatformUMG.PUMG_Widget.GetCurrentFocusGroup // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x89ec10
	struct UWidget* GetCurrentFocusForGroup(int32_t FocusGroup); // Function PlatformUMG.PUMG_Widget.GetCurrentFocusForGroup // (Final|Native|Public|BlueprintCallable) // @ game+0x89eb80
	void GamepadUnhover(); // Function PlatformUMG.PUMG_Widget.GamepadUnhover // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void GamepadHover(); // Function PlatformUMG.PUMG_Widget.GamepadHover // (Event|Public|BlueprintEvent) // @ game+0x2587100
	struct FEventReply GamepadButtonUp(struct FKey Button); // Function PlatformUMG.PUMG_Widget.GamepadButtonUp // (Native|Event|Public|BlueprintEvent) // @ game+0x89ea50
	struct FEventReply GamepadButtonDown(struct FKey Button); // Function PlatformUMG.PUMG_Widget.GamepadButtonDown // (Native|Event|Public|BlueprintEvent) // @ game+0x89e920
	void FocusGroupNavigateUpFailure(int32_t FocusGroup); // Function PlatformUMG.PUMG_Widget.FocusGroupNavigateUpFailure // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void FocusGroupNavigateRightFailure(int32_t FocusGroup); // Function PlatformUMG.PUMG_Widget.FocusGroupNavigateRightFailure // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void FocusGroupNavigateLeftFailure(int32_t FocusGroup); // Function PlatformUMG.PUMG_Widget.FocusGroupNavigateLeftFailure // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void FocusGroupNavigateDownFailure(int32_t FocusGroup); // Function PlatformUMG.PUMG_Widget.FocusGroupNavigateDownFailure // (Event|Public|BlueprintEvent) // @ game+0x2587100
	bool ExplicitNavigateUp(); // Function PlatformUMG.PUMG_Widget.ExplicitNavigateUp // (Final|Native|Public|BlueprintCallable) // @ game+0x89e8f0
	bool ExplicitNavigateRight(); // Function PlatformUMG.PUMG_Widget.ExplicitNavigateRight // (Final|Native|Public|BlueprintCallable) // @ game+0x89e8c0
	bool ExplicitNavigateLeft(); // Function PlatformUMG.PUMG_Widget.ExplicitNavigateLeft // (Final|Native|Public|BlueprintCallable) // @ game+0x89e890
	bool ExplicitNavigateDown(); // Function PlatformUMG.PUMG_Widget.ExplicitNavigateDown // (Final|Native|Public|BlueprintCallable) // @ game+0x89e860
	void DisplayGenericPopup(struct FString sTitle, struct FString sDesc); // Function PlatformUMG.PUMG_Widget.DisplayGenericPopup // (Final|Native|Public|BlueprintCallable) // @ game+0x89e770
	void DisplayGenericError(struct FString sDesc); // Function PlatformUMG.PUMG_Widget.DisplayGenericError // (Final|Native|Public|BlueprintCallable) // @ game+0x89e6d0
	void ClearNavigationInputThrottle(); // Function PlatformUMG.PUMG_Widget.ClearNavigationInputThrottle // (Final|Native|Public|BlueprintCallable) // @ game+0x89e6b0
	bool CanCloseOnLogout(); // Function PlatformUMG.PUMG_Widget.CanCloseOnLogout // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x89e680
	void CallOnShowSequenceFinished(); // Function PlatformUMG.PUMG_Widget.CallOnShowSequenceFinished // (Final|Native|Public|BlueprintCallable) // @ game+0x89e660
	void CallOnHideSequenceFinished(); // Function PlatformUMG.PUMG_Widget.CallOnHideSequenceFinished // (Final|Native|Public|BlueprintCallable) // @ game+0x89e640
	void BindToInputManager(int32_t DefaultFocusGroup); // Function PlatformUMG.PUMG_Widget.BindToInputManager // (Final|Native|Public|BlueprintCallable) // @ game+0x89e5c0
	void AsyncLoadTexture2D(struct TSoftObjectPtr<struct UTexture2D> Texture2DRef); // Function PlatformUMG.PUMG_Widget.AsyncLoadTexture2D // (Final|Native|Public|BlueprintCallable) // @ game+0x89e4e0
	bool AddViewRoute(struct FName RouteName, bool ClearRouteStack, bool ForceTransition, struct UObject* Data); // Function PlatformUMG.PUMG_Widget.AddViewRoute // (Final|Native|Public|BlueprintCallable) // @ game+0x89e370
};

// Class PlatformUMG.PUMG_PopupManager
// Size: 0x5a8 (Inherited: 0x4a0)
struct UPUMG_PopupManager : UPUMG_Widget {
	struct TArray<struct FPUMG_PopupConfig> PopupQueue; // 0x4a0(0x10)
	int32_t m_nPopupId; // 0x4b0(0x04)
	char UnknownData_4B4[0xdc]; // 0x4b4(0xdc)
	struct FText CommittedText; // 0x590(0x18)

	void ShowPopup(struct FPUMG_PopupConfig popupData); // Function PlatformUMG.PUMG_PopupManager.ShowPopup // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void RemovePopup(int32_t PopupId); // Function PlatformUMG.PUMG_PopupManager.RemovePopup // (Final|Native|Public|BlueprintCallable) // @ game+0x896750
	void OnPopupResponse(int32_t nPopupId, int32_t nResponseIndex); // Function PlatformUMG.PUMG_PopupManager.OnPopupResponse // (Final|Native|Public|BlueprintCallable) // @ game+0x896610
	void OnPopupCanceled(); // Function PlatformUMG.PUMG_PopupManager.OnPopupCanceled // (Final|Native|Public|BlueprintCallable) // @ game+0x8965f0
	void NextPopup(); // Function PlatformUMG.PUMG_PopupManager.NextPopup // (Final|Native|Public|BlueprintCallable) // @ game+0x8965d0
	void HidePopup(); // Function PlatformUMG.PUMG_PopupManager.HidePopup // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void CloseUnimportantPopups(); // Function PlatformUMG.PUMG_PopupManager.CloseUnimportantPopups // (Final|Native|Public|BlueprintCallable) // @ game+0x895680
	void CloseAllPopups(); // Function PlatformUMG.PUMG_PopupManager.CloseAllPopups // (Final|Native|Public|BlueprintCallable) // @ game+0x895660
	int32_t AddPopup(struct FPUMG_PopupConfig popupData); // Function PlatformUMG.PUMG_PopupManager.AddPopup // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8952f0
};

// Class PlatformUMG.PUMG_QueueDataFactory
// Size: 0x208 (Inherited: 0x38)
struct UPUMG_QueueDataFactory : UPUMG_DataFactory {
	struct FMulticastInlineDelegate OnQueueJoined; // 0x38(0x10)
	struct FMulticastInlineDelegate OnQueueLeft; // 0x48(0x10)
	struct FMulticastInlineDelegate OnQueueStatusChange; // 0x58(0x10)
	struct FMulticastInlineDelegate OnQueueDataUpdated; // 0x68(0x10)
	struct FMulticastInlineDelegate OnMatchStatusUpdatedError; // 0x78(0x10)
	struct FMulticastInlineDelegate OnCustomMatchJoined; // 0x88(0x10)
	struct FMulticastInlineDelegate OnCustomQueueMemberAdded; // 0x98(0x10)
	struct FMulticastInlineDelegate OnCustomQueueMemberRemoved; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnCustomQueueMemberUpdated; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnCustomQueueChanged; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnCustomInviteErrorRecieved; // 0xd8(0x10)
	int32_t PendingCustomMatchMapId; // 0xe8(0x04)
	char UnknownData_EC[0x4]; // 0xec(0x04)
	struct TArray<struct FPUMG_ActivityQueuePair> ActivityQueuePairs; // 0xf0(0x10)
	struct FString ActivityToJoin; // 0x100(0x10)
	bool bActivityToJoinIsMultiplayer; // 0x110(0x01)
	char UnknownData_111[0x7]; // 0x111(0x07)
	struct TArray<int32_t> QueueIds; // 0x118(0x10)
	char UnknownData_128[0x50]; // 0x128(0x50)
	float QueueUpdatePollInterval; // 0x178(0x04)
	char UnknownData_17C[0x4]; // 0x17c(0x04)
	struct FTimerHandle QueueUpdateTimerHandle; // 0x180(0x08)
	struct TArray<struct FPUMG_CustomMatchMember> CustomMatchMembers; // 0x188(0x10)
	char UnknownData_198[0x6c]; // 0x198(0x6c)
	int32_t CustomMatchSpectateTeamId; // 0x204(0x04)

	void StartCustomMatch(); // Function PlatformUMG.PUMG_QueueDataFactory.StartCustomMatch // (Final|Native|Public|BlueprintCallable|Const) // @ game+0x896a20
	void SetPlayerTeamCustomMatch(int64_t PlayerId, int32_t TeamId); // Function PlatformUMG.PUMG_QueueDataFactory.SetPlayerTeamCustomMatch // (Final|Native|Public|BlueprintCallable|Const) // @ game+0x896960
	void SetPendingMapForCustomQueue(int32_t MapId); // Function PlatformUMG.PUMG_QueueDataFactory.SetPendingMapForCustomQueue // (Final|Native|Public|BlueprintCallable) // @ game+0x8968e0
	void SetMapForCustomMatch(int32_t MapId); // Function PlatformUMG.PUMG_QueueDataFactory.SetMapForCustomMatch // (Final|Native|Public|BlueprintCallable|Const) // @ game+0x896860
	bool LeaveQueue(); // Function PlatformUMG.PUMG_QueueDataFactory.LeaveQueue // (Native|Public|BlueprintCallable) // @ game+0x8965a0
	void KickFromCustomMatch(int64_t PlayerId); // Function PlatformUMG.PUMG_QueueDataFactory.KickFromCustomMatch // (Final|Native|Public|BlueprintCallable) // @ game+0x896520
	bool JoinQueue(int32_t QueueId); // Function PlatformUMG.PUMG_QueueDataFactory.JoinQueue // (Native|Public|BlueprintCallable) // @ game+0x896480
	bool IsQueueActive(int32_t QueueId); // Function PlatformUMG.PUMG_QueueDataFactory.IsQueueActive // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8963e0
	bool IsInQueue(); // Function PlatformUMG.PUMG_QueueDataFactory.IsInQueue // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x8963b0
	bool IsInGame(); // Function PlatformUMG.PUMG_QueueDataFactory.IsInGame // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x896380
	bool IsInCustomMatch(); // Function PlatformUMG.PUMG_QueueDataFactory.IsInCustomMatch // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x896350
	bool IsCustomInvitePending(int64_t PlayerId); // Function PlatformUMG.PUMG_QueueDataFactory.IsCustomInvitePending // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x896290
	void InviteToCustomMatch(int64_t PlayerId); // Function PlatformUMG.PUMG_QueueDataFactory.InviteToCustomMatch // (Final|Native|Public|BlueprintCallable) // @ game+0x896210
	void IncrementPlayerTeamCustomMatch(int64_t PlayerId); // Function PlatformUMG.PUMG_QueueDataFactory.IncrementPlayerTeamCustomMatch // (Final|Native|Public|BlueprintCallable|Const) // @ game+0x896190
	void HandleInviteCooldowns(); // Function PlatformUMG.PUMG_QueueDataFactory.HandleInviteCooldowns // (Final|Native|Protected) // @ game+0x896170
	void HandleConfirmKickCustomPlayer(); // Function PlatformUMG.PUMG_QueueDataFactory.HandleConfirmKickCustomPlayer // (Final|Native|Protected) // @ game+0x896150
	float GetTimeInQueueSeconds(); // Function PlatformUMG.PUMG_QueueDataFactory.GetTimeInQueueSeconds // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x896120
	int32_t GetTeamMemberCount(int32_t TeamId); // Function PlatformUMG.PUMG_QueueDataFactory.GetTeamMemberCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x896090
	struct TArray<int32_t> GetQueueIds(); // Function PlatformUMG.PUMG_QueueDataFactory.GetQueueIds // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x895f10
	int32_t GetPlayerTeamId(int64_t PlayerId); // Function PlatformUMG.PUMG_QueueDataFactory.GetPlayerTeamId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x895e80
	int32_t GetPendingCustomMatchMapId(); // Function PlatformUMG.PUMG_QueueDataFactory.GetPendingCustomMatchMapId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x895e40
	int32_t GetNextTeamId(int32_t RelativeToTeamId); // Function PlatformUMG.PUMG_QueueDataFactory.GetNextTeamId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x895db0
	enum class EPUMG_CustomMatchPermission GetCustomMatchPermissions(int64_t PlayerId); // Function PlatformUMG.PUMG_QueueDataFactory.GetCustomMatchPermissions // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x895bf0
	struct TArray<struct FPUMG_CustomMatchMember> GetCustomMatchMembers(); // Function PlatformUMG.PUMG_QueueDataFactory.GetCustomMatchMembers // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x895b60
	int32_t GetCustomMatchMapId(); // Function PlatformUMG.PUMG_QueueDataFactory.GetCustomMatchMapId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x895b30
	struct UPUMG_PlayerInfo* GetCustomMatchInviterPlayerInfo(); // Function PlatformUMG.PUMG_QueueDataFactory.GetCustomMatchInviterPlayerInfo // (Final|Native|Public|BlueprintCallable) // @ game+0x895b00
	enum class EPUMG_MatchStatus GetCurrentQueueMatchState(); // Function PlatformUMG.PUMG_QueueDataFactory.GetCurrentQueueMatchState // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x895ad0
	bool GetCurrentQueueId(int32_t QueueId); // Function PlatformUMG.PUMG_QueueDataFactory.GetCurrentQueueId // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x895a40
	bool GetCurrentMatchId(int32_t MatchID); // Function PlatformUMG.PUMG_QueueDataFactory.GetCurrentMatchId // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x8959b0
	bool GetBaseQueueInfoById(int32_t QueueId, struct FPUMG_ClientQueueInfo InClientQueueInfo); // Function PlatformUMG.PUMG_QueueDataFactory.GetBaseQueueInfoById // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x8957f0
	void DeclineMatchInvite(); // Function PlatformUMG.PUMG_QueueDataFactory.DeclineMatchInvite // (Final|Native|Public|BlueprintCallable) // @ game+0x895730
	void CreateCustomMatch(int32_t QueueId); // Function PlatformUMG.PUMG_QueueDataFactory.CreateCustomMatch // (Native|Public|BlueprintCallable) // @ game+0x8956a0
	enum class EPUMG_CustomMatchError CheckCustomMatch(); // Function PlatformUMG.PUMG_QueueDataFactory.CheckCustomMatch // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x895630
	bool CanQueue(); // Function PlatformUMG.PUMG_QueueDataFactory.CanQueue // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x895600
	bool CanLocalPlayerPromoteCustomLobbyPlayer(int64_t PlayerId); // Function PlatformUMG.PUMG_QueueDataFactory.CanLocalPlayerPromoteCustomLobbyPlayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x895570
	bool CanLocalPlayerKickCustomLobbyPlayer(int64_t PlayerId); // Function PlatformUMG.PUMG_QueueDataFactory.CanLocalPlayerKickCustomLobbyPlayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8954e0
	bool CanLocalPlayerControlCustomLobbyPlayer(int64_t PlayerId); // Function PlatformUMG.PUMG_QueueDataFactory.CanLocalPlayerControlCustomLobbyPlayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x895450
	bool AttemptRejoinMatch(bool Forced); // Function PlatformUMG.PUMG_QueueDataFactory.AttemptRejoinMatch // (Native|Public|BlueprintCallable) // @ game+0x8953b0
	void AcceptMatchInvite(); // Function PlatformUMG.PUMG_QueueDataFactory.AcceptMatchInvite // (Final|Native|Public|BlueprintCallable) // @ game+0x8952d0
};

// Class PlatformUMG.PUMG_SettingsDataFactory
// Size: 0xd8 (Inherited: 0x38)
struct UPUMG_SettingsDataFactory : UPUMG_DataFactory {
	struct FMulticastInlineDelegate OnPopulateUserSettings; // 0x38(0x10)
	struct FMulticastInlineDelegate OnPopulateUserBindings; // 0x48(0x10)
	struct FMulticastInlineDelegate OnPopulateUserGPBindings; // 0x58(0x10)
	struct FMulticastInlineDelegate OnPostLogin; // 0x68(0x10)
	struct FMulticastInlineDelegate OnPostLogoff; // 0x78(0x10)
	struct FMulticastInlineDelegate OnSettingValueChanged; // 0x88(0x10)
	char UnknownData_98[0x40]; // 0x98(0x40)

	bool OnSettingChanged(struct FName SettingId, int32_t SettingValue); // Function PlatformUMG.PUMG_SettingsDataFactory.OnSettingChanged // (Native|Public|BlueprintCallable) // @ game+0x89c170
	void InitSettingsForPlayer(); // Function PlatformUMG.PUMG_SettingsDataFactory.InitSettingsForPlayer // (Native|Protected|BlueprintCallable) // @ game+0x891d20
};

// Class PlatformUMG.PUMG_StorePurchaseRequest
// Size: 0x60 (Inherited: 0x28)
struct UPUMG_StorePurchaseRequest : UObject {
	int32_t LootTableItemId; // 0x28(0x04)
	int32_t VendorId; // 0x2c(0x04)
	int32_t PriceInUI; // 0x30(0x04)
	char UnknownData_34[0x4]; // 0x34(0x04)
	struct UPlatformInventoryItem* CurrencyType; // 0x38(0x08)
	int32_t Quantity; // 0x40(0x04)
	int32_t LocationId; // 0x44(0x04)
	int32_t CouponId; // 0x48(0x04)
	int32_t GiftPlayerId; // 0x4c(0x04)
	int32_t GiftMsgIndex; // 0x50(0x04)
	bool AnonymousGift; // 0x54(0x01)
	char UnknownData_55[0x3]; // 0x55(0x03)
	struct FWeakObjectPtr<struct UPUMG_StoreItemHelper> pItemHelper; // 0x58(0x08)

	bool SubmitPurchaseRequest(); // Function PlatformUMG.PUMG_StorePurchaseRequest.SubmitPurchaseRequest // (Final|Native|Public|BlueprintCallable) // @ game+0x89c8e0
};

// Class PlatformUMG.PUMG_PortalOffer
// Size: 0xd0 (Inherited: 0x28)
struct UPUMG_PortalOffer : UObject {
	struct FString SKU; // 0x28(0x10)
	float cost; // 0x38(0x04)
	char UnknownData_3C[0x4]; // 0x3c(0x04)
	struct FText DisplayCost; // 0x40(0x18)
	struct FText CurrencyCode; // 0x58(0x18)
	struct FText Name; // 0x70(0x18)
	struct FText Desc; // 0x88(0x18)
	struct FText ShortDesc; // 0xa0(0x18)
	struct FText TaxMessage; // 0xb8(0x18)
};

// Class PlatformUMG.PUMG_StoreItemPrice
// Size: 0x60 (Inherited: 0x28)
struct UPUMG_StoreItemPrice : UObject {
	int32_t PreSalePrice; // 0x28(0x04)
	int32_t Price; // 0x2c(0x04)
	struct TSoftObjectPtr<struct UPlatformInventoryItem> CurrencyType; // 0x30(0x28)
	struct FWeakObjectPtr<struct UPUMG_StoreItemHelper> pItemHelper; // 0x58(0x08)

	int32_t GetDiscountPercentage(); // Function PlatformUMG.PUMG_StoreItemPrice.GetDiscountPercentage // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89ab10
	bool CanAfford(int32_t Quantity); // Function PlatformUMG.PUMG_StoreItemPrice.CanAfford // (Final|Native|Public|BlueprintCallable) // @ game+0x89a6d0
};

// Class PlatformUMG.PUMG_StoreItem
// Size: 0x78 (Inherited: 0x28)
struct UPUMG_StoreItem : UObject {
	struct FMulticastInlineDelegate OnPriceSetDirty; // 0x28(0x10)
	char UnknownData_38[0x10]; // 0x38(0x10)
	struct FWeakObjectPtr<struct UPUMG_StoreItemHelper> pItemHelper; // 0x48(0x08)
	struct TSoftObjectPtr<struct UPlatformInventoryItem> InventoryItem; // 0x50(0x28)

	void UIX_ShowPurchaseConfirmation(struct UPUMG_StoreItemPrice* pPrice); // Function PlatformUMG.PUMG_StoreItem.UIX_ShowPurchaseConfirmation // (Native|Public|BlueprintCallable) // @ game+0x89cb90
	bool ShouldDisplayToUser(); // Function PlatformUMG.PUMG_StoreItem.ShouldDisplayToUser // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89c790
	void PurchaseFromPortal(); // Function PlatformUMG.PUMG_StoreItem.PurchaseFromPortal // (Final|Native|Public|BlueprintCallable) // @ game+0x89c2d0
	bool IsRented(int64_t PlayerId); // Function PlatformUMG.PUMG_StoreItem.IsRented // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89c040
	bool IsRecipeFulfilled(int64_t PlayerId); // Function PlatformUMG.PUMG_StoreItem.IsRecipeFulfilled // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89bfa0
	bool IsOwned(int64_t PlayerId); // Function PlatformUMG.PUMG_StoreItem.IsOwned // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x89bf00
	bool IsOnSale(); // Function PlatformUMG.PUMG_StoreItem.IsOnSale // (Native|Public|BlueprintCallable) // @ game+0x89bed0
	bool IsActive(); // Function PlatformUMG.PUMG_StoreItem.IsActive // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8965a0
	bool HasPortalOffer(); // Function PlatformUMG.PUMG_StoreItem.HasPortalOffer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89bd00
	int32_t GetVendorId(); // Function PlatformUMG.PUMG_StoreItem.GetVendorId // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89b8f0
	int32_t GetUIHint(); // Function PlatformUMG.PUMG_StoreItem.GetUIHint // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89b8c0
	int32_t GetType(); // Function PlatformUMG.PUMG_StoreItem.GetType // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89b890
	int32_t GetSubType(); // Function PlatformUMG.PUMG_StoreItem.GetSubType // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89b7c0
	int32_t GetSortOrder(); // Function PlatformUMG.PUMG_StoreItem.GetSortOrder // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89b400
	struct TSoftObjectPtr<struct UTexture2D> GetSoftItemIcon(); // Function PlatformUMG.PUMG_StoreItem.GetSoftItemIcon // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89b390
	int32_t GetQuantityOwned(int64_t PlayerId); // Function PlatformUMG.PUMG_StoreItem.GetQuantityOwned // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89b2f0
	struct UPUMG_StorePurchaseRequest* GetPurchaseRequest(); // Function PlatformUMG.PUMG_StoreItem.GetPurchaseRequest // (Native|Public|BlueprintCallable) // @ game+0x89b2c0
	struct TArray<struct UPUMG_StoreItemPrice*> GetPrices(); // Function PlatformUMG.PUMG_StoreItem.GetPrices // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x89b240
	struct UPUMG_StoreItemPrice* GetPrice(struct TSoftObjectPtr<struct UPlatformInventoryItem> nCurrencyType); // Function PlatformUMG.PUMG_StoreItem.GetPrice // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x89b150
	struct UPUMG_PortalOffer* GetPortalOffer(); // Function PlatformUMG.PUMG_StoreItem.GetPortalOffer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89b090
	struct FText GetName(); // Function PlatformUMG.PUMG_StoreItem.GetName // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89ae60
	int32_t GetLootQuantity(); // Function PlatformUMG.PUMG_StoreItem.GetLootQuantity // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89ae00
	int32_t GetLootId(); // Function PlatformUMG.PUMG_StoreItem.GetLootId // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89add0
	struct TSoftObjectPtr<struct UPlatformInventoryItem> GetInventoryItem(); // Function PlatformUMG.PUMG_StoreItem.GetInventoryItem // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89acb0
	struct FText GetFormattedNameDisplay(); // Function PlatformUMG.PUMG_StoreItem.GetFormattedNameDisplay // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89abe0
	struct FText GetFormattedDescDisplay(); // Function PlatformUMG.PUMG_StoreItem.GetFormattedDescDisplay // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89ab40
	struct FText GetDescription(); // Function PlatformUMG.PUMG_StoreItem.GetDescription // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89aa70
	int32_t GetBestDiscount(); // Function PlatformUMG.PUMG_StoreItem.GetBestDiscount // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x89a890
	void ConfirmGotoPortalOffer(); // Function PlatformUMG.PUMG_StoreItem.ConfirmGotoPortalOffer // (Final|Native|Public|BlueprintCallable) // @ game+0x89a760
	bool CanAfford(struct UPUMG_StoreItemPrice* Price, int32_t Quantity); // Function PlatformUMG.PUMG_StoreItem.CanAfford // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89a610
};

// Class PlatformUMG.PUMG_XpTable
// Size: 0x30 (Inherited: 0x28)
struct UPUMG_XpTable : UObject {
	char UnknownData_28[0x8]; // 0x28(0x08)

	int64_t GetXpAtLevel(int32_t XpLevel); // Function PlatformUMG.PUMG_XpTable.GetXpAtLevel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89b9e0
	int64_t GetXpAtIndex(int32_t Index); // Function PlatformUMG.PUMG_XpTable.GetXpAtIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89b950
	int32_t GetMinXpLevel(); // Function PlatformUMG.PUMG_XpTable.GetMinXpLevel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89ae30
	int32_t GetLevelCount(); // Function PlatformUMG.PUMG_XpTable.GetLevelCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89ada0
	int32_t GetLevelAtXp(int64_t XpPoints); // Function PlatformUMG.PUMG_XpTable.GetLevelAtXp // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89ad10
	int64_t GetId(); // Function PlatformUMG.PUMG_XpTable.GetId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89ac80
};

// Class PlatformUMG.PUMG_StoreItemHelper
// Size: 0x230 (Inherited: 0x28)
struct UPUMG_StoreItemHelper : UObject {
	struct FMulticastInlineDelegate OnPurchaseItem; // 0x28(0x10)
	struct FMulticastInlineDelegate OnPurchasePortalItem; // 0x38(0x10)
	struct FMulticastInlineDelegate OnNotEnoughCurrency; // 0x48(0x10)
	struct FMulticastInlineDelegate OnReceiveVendor; // 0x58(0x10)
	struct FMulticastInlineDelegate OnReceiveXpTables; // 0x68(0x10)
	struct FMulticastInlineDelegate OnReceivePricePoints; // 0x78(0x10)
	struct FMulticastInlineDelegate OnPortalOffersReceived; // 0x88(0x10)
	struct FMulticastInlineDelegate OnPendingPurchaseReceived; // 0x98(0x10)
	struct FMulticastInlineDelegate OnPurchaseSubmitted; // 0xa8(0x10)
	char UnknownData_B8[0x28]; // 0xb8(0x28)
	struct TMap<int32_t, struct UPUMG_StoreItem*> StoreItems; // 0xe0(0x50)
	char UnknownData_130[0x50]; // 0x130(0x50)
	struct TMap<int64_t, struct UPUMG_XpTable*> XpTables; // 0x180(0x50)
	bool XpTablesLoaded; // 0x1d0(0x01)
	bool PricePointsLoaded; // 0x1d1(0x01)
	bool PortalOffersLoaded; // 0x1d2(0x01)
	char UnknownData_1D3[0x5]; // 0x1d3(0x05)
	struct TMap<int64_t, struct UPUMG_PortalOffer*> PortalOffers; // 0x1d8(0x50)
	struct UGameInstance* GameInstance; // 0x228(0x08)

	void UIX_RedeemCode(struct FString Code); // Function PlatformUMG.PUMG_StoreItemHelper.UIX_RedeemCode // (Final|Native|Public|BlueprintCallable) // @ game+0x89cab0
	bool UIX_CompletePurchaseItem(struct UPUMG_StorePurchaseRequest* PurchaseRequest); // Function PlatformUMG.PUMG_StoreItemHelper.UIX_CompletePurchaseItem // (Native|Public|BlueprintCallable) // @ game+0x89ca10
	int32_t RequestVendorData(struct TArray<int32_t> VendorIds); // Function PlatformUMG.PUMG_StoreItemHelper.RequestVendorData // (Native|Public|BlueprintCallable) // @ game+0x89c5d0
	bool HasPendingPurchase(); // Function PlatformUMG.PUMG_StoreItemHelper.HasPendingPurchase // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89bcc0
	struct UPUMG_XpTable* GetXpTable(int64_t XpTableId); // Function PlatformUMG.PUMG_StoreItemHelper.GetXpTable // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x89ba70
	struct TArray<struct UPUMG_StoreItem*> GetStoreItemsForVendor(int32_t nVendorId, bool bIncludeInctiveItems, bool bSearchSubContainers); // Function PlatformUMG.PUMG_StoreItemHelper.GetStoreItemsForVendor // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x89b670
	struct UPUMG_StoreItem* GetStoreItemForVendorByItemId(int32_t nVendorId, int32_t nItemId); // Function PlatformUMG.PUMG_StoreItemHelper.GetStoreItemForVendorByItemId // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x89b5a0
	struct UPUMG_StoreItem* GetStoreItemForVendor(int32_t nVendorId, int32_t nLootItemId); // Function PlatformUMG.PUMG_StoreItemHelper.GetStoreItemForVendor // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x89b4d0
	struct UPUMG_StoreItem* GetStoreItem(int32_t LootId); // Function PlatformUMG.PUMG_StoreItemHelper.GetStoreItem // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x89b430
	struct UPUMG_PortalOffer* GetPortalOffer(int64_t LootId); // Function PlatformUMG.PUMG_StoreItemHelper.GetPortalOffer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89b0c0
	struct TArray<struct UPUMG_StorePurchaseRequest*> GetPendingPurchaseData(); // Function PlatformUMG.PUMG_StoreItemHelper.GetPendingPurchaseData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89af00
	void ExitInGameStoreUI(); // Function PlatformUMG.PUMG_StoreItemHelper.ExitInGameStoreUI // (Final|Native|Public|BlueprintCallable) // @ game+0x89a870
	void EnterInGameStoreUI(); // Function PlatformUMG.PUMG_StoreItemHelper.EnterInGameStoreUI // (Final|Native|Public|BlueprintCallable) // @ game+0x89a850
	bool DoesPortalHaveOffers(); // Function PlatformUMG.PUMG_StoreItemHelper.DoesPortalHaveOffers // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89a810
	bool AreXpTablesLoaded(); // Function PlatformUMG.PUMG_StoreItemHelper.AreXpTablesLoaded // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x89a5f0
	bool ArePricePointsLoaded(); // Function PlatformUMG.PUMG_StoreItemHelper.ArePricePointsLoaded // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x89a5d0
	bool ArePortalOffersLoaded(); // Function PlatformUMG.PUMG_StoreItemHelper.ArePortalOffersLoaded // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x89a5b0
};

// Class PlatformUMG.PUMG_UISoundTheme
// Size: 0x78 (Inherited: 0x28)
struct UPUMG_UISoundTheme : UObject {
	struct TMap<struct FName, struct FPUMG_SoundThemeEventMapping> SoundEventBindings; // 0x28(0x50)
};

// Class PlatformUMG.PUMG_GenericRouteDataObject
// Size: 0x48 (Inherited: 0x28)
struct UPUMG_GenericRouteDataObject : UObject {
	struct FString StringValue; // 0x28(0x10)
	int32_t IntValue; // 0x38(0x04)
	struct FName NameValue; // 0x3c(0x08)
	char UnknownData_44[0x4]; // 0x44(0x04)
};

// Class PlatformUMG.PUMG_ViewRedirecter
// Size: 0x28 (Inherited: 0x28)
struct UPUMG_ViewRedirecter : UObject {

	bool ShouldRedirect(struct APUMG_HUD* HUD, struct FName Route, struct UObject* SceneData); // Function PlatformUMG.PUMG_ViewRedirecter.ShouldRedirect // (Native|Public|HasOutParms) // @ game+0x89c7c0
};

// Class PlatformUMG.PUMG_ViewLayer
// Size: 0x118 (Inherited: 0x28)
struct UPUMG_ViewLayer : UObject {
	struct UCanvasPanel* DisplayTarget; // 0x28(0x08)
	struct UPUMG_ViewManager* MyManager; // 0x30(0x08)
	enum class EViewManagerTransitionState CurrentTransitionState; // 0x38(0x01)
	char UnknownData_39[0x7]; // 0x39(0x07)
	struct TArray<struct FName> CurrentRouteStack; // 0x40(0x10)
	struct TArray<struct FName> CurrentTransitionRouteStack; // 0x50(0x10)
	struct TMap<struct FName, struct UPUMG_Widget*> RouteWidgetMap; // 0x60(0x50)
	struct FName DefaultRoute; // 0xb0(0x08)
	char UnknownData_B8[0x8]; // 0xb8(0x08)
	struct TMap<struct FName, struct UObject*> PendingRouteData; // 0xc0(0x50)
	struct UDataTable* Routes; // 0x110(0x08)

	bool IsRouteValid(struct FName RouteName); // Function PlatformUMG.PUMG_ViewLayer.IsRouteValid // (Final|Native|Protected|BlueprintCallable) // @ game+0x89c0e0
	void GoToRoute_InternalShowStep(); // Function PlatformUMG.PUMG_ViewLayer.GoToRoute_InternalShowStep // (Final|Native|Protected) // @ game+0x89bc10
	void GoToRoute_HandleShowFinished(struct UPUMG_Widget* Widget); // Function PlatformUMG.PUMG_ViewLayer.GoToRoute_HandleShowFinished // (Final|Native|Protected) // @ game+0x89bb90
	void GoToRoute_HandleHideFinished(struct UPUMG_Widget* Widget); // Function PlatformUMG.PUMG_ViewLayer.GoToRoute_HandleHideFinished // (Final|Native|Protected) // @ game+0x89bb10
};

// Class PlatformUMG.PUMG_ViewManager
// Size: 0xe8 (Inherited: 0x28)
struct UPUMG_ViewManager : UObject {
	struct TArray<struct UPUMG_ViewLayer*> ViewLayers; // 0x28(0x10)
	struct TMap<struct FName, struct UPUMG_Widget*> StickyWidgetMap; // 0x38(0x50)
	struct FMulticastInlineDelegate OnViewStateChanged; // 0x88(0x10)
	struct FMulticastInlineDelegate OnViewStateChangeStarted; // 0x98(0x10)
	struct APUMG_HUD* HudRef; // 0xa8(0x08)
	struct TArray<struct UCanvasPanel*> CanvasPanels; // 0xb0(0x10)
	struct TArray<struct FStickyWidgetData> StickyWidgets; // 0xc0(0x10)
	struct UDataTable* Routes; // 0xd0(0x08)
	struct TArray<struct FViewRouteRedirectData> AlwaysCheckRouteData; // 0xd8(0x10)

	bool SwapRoute(struct FName RouteName, struct FName SwapTargetRoute, bool ForceTransition); // Function PlatformUMG.PUMG_ViewManager.SwapRoute // (Final|Native|Public|BlueprintCallable) // @ game+0x89c910
	void SetPendingRouteData(struct FName RouteName, struct UObject* Data); // Function PlatformUMG.PUMG_ViewManager.SetPendingRouteData // (Final|Native|Public|BlueprintCallable) // @ game+0x89c6d0
	bool ReplaceRoute(struct FName RouteName, bool ForceTransition, struct UObject* Data); // Function PlatformUMG.PUMG_ViewManager.ReplaceRoute // (Final|Native|Public|BlueprintCallable) // @ game+0x89c4c0
	bool RemoveRoute(struct FName RouteName, bool ForceTransition); // Function PlatformUMG.PUMG_ViewManager.RemoveRoute // (Final|Native|Public|BlueprintCallable) // @ game+0x89c400
	bool PushRoute(struct FName RouteName, bool ForceTransition, struct UObject* Data); // Function PlatformUMG.PUMG_ViewManager.PushRoute // (Final|Native|Public|BlueprintCallable) // @ game+0x89c2f0
	bool PopRoute(bool ForceTransition); // Function PlatformUMG.PUMG_ViewManager.PopRoute // (Final|Native|Public|BlueprintCallable) // @ game+0x89c240
	bool IsLayerIdle(enum class EViewManagerLayer LayerType); // Function PlatformUMG.PUMG_ViewManager.IsLayerIdle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89be40
	bool IsEveryLayerIdle(); // Function PlatformUMG.PUMG_ViewManager.IsEveryLayerIdle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89be10
	bool IsBlockingAcquisitions(); // Function PlatformUMG.PUMG_ViewManager.IsBlockingAcquisitions // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89bde0
	void InitializeRoutes(struct UDataTable* RouteTable); // Function PlatformUMG.PUMG_ViewManager.InitializeRoutes // (Final|Native|Protected) // @ game+0x89bd60
	void Initialize(); // Function PlatformUMG.PUMG_ViewManager.Initialize // (Final|Native|Public|BlueprintCallable) // @ game+0x89bd40
	bool HasCompletedRedirectFlow(enum class EViewRouteRedirectionPhase RedirectPhase); // Function PlatformUMG.PUMG_ViewManager.HasCompletedRedirectFlow // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89bc30
	int32_t GetViewRouteCount(); // Function PlatformUMG.PUMG_ViewManager.GetViewRouteCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89b920
	struct UPUMG_Widget* GetTopViewRouteWidget(); // Function PlatformUMG.PUMG_ViewManager.GetTopViewRouteWidget // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89b860
	struct FName GetTopViewRoute(); // Function PlatformUMG.PUMG_ViewManager.GetTopViewRoute // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89b820
	enum class EViewManagerLayer GetTopLayer(); // Function PlatformUMG.PUMG_ViewManager.GetTopLayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89b7f0
	bool GetPendingRouteData(struct FName RouteName, struct UObject* Data); // Function PlatformUMG.PUMG_ViewManager.GetPendingRouteData // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x89afc0
	struct FName GetDefaultRouteForLayer(enum class EViewManagerLayer LayerType); // Function PlatformUMG.PUMG_ViewManager.GetDefaultRouteForLayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89a9e0
	struct FName GetCurrentTransitionRoute(enum class EViewManagerLayer Layer); // Function PlatformUMG.PUMG_ViewManager.GetCurrentTransitionRoute // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89a950
	struct FName GetCurrentRoute(enum class EViewManagerLayer Layer); // Function PlatformUMG.PUMG_ViewManager.GetCurrentRoute // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x89a8c0
	bool ContainsRoute(struct FName RouteName); // Function PlatformUMG.PUMG_ViewManager.ContainsRoute // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x89a780
};

// Class PlatformUMG.PUMG_VoiceChatManager
// Size: 0x70 (Inherited: 0x28)
struct UPUMG_VoiceChatManager : UObject {
	bool bPendingPartyVoipJoin; // 0x28(0x01)
	bool bPendingMatchVoipJoin; // 0x29(0x01)
	char UnknownData_2A[0x6]; // 0x2a(0x06)
	struct FString CurrentPartyVoiceChatChannel; // 0x30(0x10)
	int32_t CurrentPartyId; // 0x40(0x04)
	char UnknownData_44[0x4]; // 0x44(0x04)
	struct FString CurrentMatchVoiceChatChannel; // 0x48(0x10)
	enum class EPUMG_MatchStatus CurrentMatchStatus; // 0x58(0x01)
	char UnknownData_59[0x3]; // 0x59(0x03)
	int32_t CurrentMatchId; // 0x5c(0x04)
	struct UPUMG_PartyDataFactory* PartyDataFactory; // 0x60(0x08)
	struct UPUMG_QueueDataFactory* QueueDataFactory; // 0x68(0x08)

	void OnPartyDataUpdated(); // Function PlatformUMG.PUMG_VoiceChatManager.OnPartyDataUpdated // (Final|Native|Protected) // @ game+0x89f1e0
	void OnMatchStatusUpdated(enum class EPUMG_MatchStatus MatchStatus); // Function PlatformUMG.PUMG_VoiceChatManager.OnMatchStatusUpdated // (Final|Native|Protected) // @ game+0x89f160
};

