// DynamicClass INameplateWidget.INameplateWidget_C
// Size: 0x28 (Inherited: 0x28)
struct UINameplateWidget_C : UInterface {

	void OnUnhovered(); // Function INameplateWidget.INameplateWidget_C.OnUnhovered // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnPossession(struct APlayerState* bpp__PlayerState__pf, struct AKSCharacter* bpp__Character__pf); // Function INameplateWidget.INameplateWidget_C.OnPossession // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnHovered(); // Function INameplateWidget.INameplateWidget_C.OnHovered // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

