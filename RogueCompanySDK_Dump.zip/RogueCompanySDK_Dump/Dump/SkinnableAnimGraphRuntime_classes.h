// Class SkinnableAnimGraphRuntime.AnimNotify_PlaySkinnedParticleEffect
// Size: 0xa0 (Inherited: 0x90)
struct UAnimNotify_PlaySkinnedParticleEffect : UAnimNotify_PlayParticleEffect {
	struct FName SkinKeyword; // 0x90(0x08)
	char UnknownData_98[0x8]; // 0x98(0x08)
};

// Class SkinnableAnimGraphRuntime.AnimNotify_SkinnedAkEvent
// Size: 0x68 (Inherited: 0x38)
struct UAnimNotify_SkinnedAkEvent : UAnimNotify {
	struct FName AttachName; // 0x38(0x08)
	struct UAkAudioEvent* Event; // 0x40(0x08)
	bool bFollow; // 0x48(0x01)
	char UnknownData_49[0x7]; // 0x49(0x07)
	struct FString EventName; // 0x50(0x10)
	struct FName SkinKeyword; // 0x60(0x08)
};

// Class SkinnableAnimGraphRuntime.AnimNotify_SkinSelectiveAkEvent
// Size: 0x58 (Inherited: 0x50)
struct UAnimNotify_SkinSelectiveAkEvent : UAnimNotify_SelectiveAkEvent {
	struct FName SkinKeyword; // 0x50(0x08)
};

// Class SkinnableAnimGraphRuntime.SkinnedAnimInstance
// Size: 0x2d0 (Inherited: 0x270)
struct USkinnedAnimInstance : UAnimInstance {
	char UnknownData_270[0x48]; // 0x270(0x48)
	struct UMultiSkinObject* SkinObject; // 0x2b8(0x08)
	char UnknownData_2C0[0x10]; // 0x2c0(0x10)

	struct UMultiSkinObject* GetSkinObject(); // Function SkinnableAnimGraphRuntime.SkinnedAnimInstance.GetSkinObject // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9a5ca0
	struct UBlendSpace* GetSkinnedBlendSpace(struct FName Keyword, struct UBlendSpace* Default, bool bHasOverride); // Function SkinnableAnimGraphRuntime.SkinnedAnimInstance.GetSkinnedBlendSpace // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9a5ff0
	struct UAnimSequence* GetSkinnedAnimSequence(struct FName Keyword, struct UAnimSequence* Default, bool bHasOverride); // Function SkinnableAnimGraphRuntime.SkinnedAnimInstance.GetSkinnedAnimSequence // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9a5ee0
	struct UAimOffsetBlendSpace* GetSkinnedAnimOffset(struct FName Keyword, struct UAimOffsetBlendSpace* Default, bool bHasOverride); // Function SkinnableAnimGraphRuntime.SkinnedAnimInstance.GetSkinnedAnimOffset // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9a5dd0
	struct UAnimMontage* GetSkinnedAnimMontage(struct FName Keyword, struct UAnimMontage* Default, bool bHasOverride); // Function SkinnableAnimGraphRuntime.SkinnedAnimInstance.GetSkinnedAnimMontage // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9a5cc0
};

