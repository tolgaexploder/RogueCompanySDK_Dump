// WidgetBlueprintGeneratedClass ReticleBase.ReticleBase_C
// Size: 0x248 (Inherited: 0x238)
struct UReticleBase_C : UUserWidget {
	struct UImage* LoneDot; // 0x238(0x08)
	float LowAmmoThreshold; // 0x240(0x04)
	float CriticallyLowAmmoThreshold; // 0x244(0x04)

	void GetAmmoState(struct UKSWeaponComponent* NewParam, enum class EAmmoState Return Value); // Function ReticleBase.ReticleBase_C.GetAmmoState // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void HitConfirm(); // Function ReticleBase.ReticleBase_C.HitConfirm // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ForceADS(bool Active); // Function ReticleBase.ReticleBase_C.ForceADS // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GrenadeCook(bool Active, float TickPeriod); // Function ReticleBase.ReticleBase_C.GrenadeCook // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ChangeADS(bool Active); // Function ReticleBase.ReticleBase_C.ChangeADS // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void KillConfirm(); // Function ReticleBase.ReticleBase_C.KillConfirm // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Headshot(); // Function ReticleBase.ReticleBase_C.Headshot // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateOffset(float Offset); // Function ReticleBase.ReticleBase_C.UpdateOffset // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

