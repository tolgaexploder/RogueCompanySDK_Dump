// DynamicClass Int_InWorld_Reticle.Int_InWorld_Reticle_C
// Size: 0x28 (Inherited: 0x28)
struct UInt_InWorld_Reticle_C : UInterface {

	void OnWeaponSet(struct UKSWeaponComponent* bpp__WeaponComponent__pf); // Function Int_InWorld_Reticle.Int_InWorld_Reticle_C.OnWeaponSet // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnPossession(struct APlayerState* bpp__PlayerState__pf); // Function Int_InWorld_Reticle.Int_InWorld_Reticle_C.OnPossession // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

