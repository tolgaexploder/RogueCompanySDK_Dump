// BlueprintGeneratedClass FlashTrapModInst.FlashTrapModInst_C
// Size: 0x4a9 (Inherited: 0x4a0)
struct UFlashTrapModInst_C : UKSModInst_GiveWeaponOnActivation {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4a0(0x08)
	bool HasDetonator; // 0x4a8(0x01)

	bool CanActivateNow(enum class EKSAbilityUsageFailureType OutAbilityFailureType); // Function FlashTrapModInst.FlashTrapModInst_C.CanActivateNow // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x2587100
	void ReceiveBeginPlay(); // Function FlashTrapModInst.FlashTrapModInst_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnNewGivenItem(); // Function FlashTrapModInst.FlashTrapModInst_C.OnNewGivenItem // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnWeaponStateChanged(struct AKSWeapon* Weapon, enum class EWeaponStateNew OldState, enum class EWeaponStateNew NewState); // Function FlashTrapModInst.FlashTrapModInst_C.OnWeaponStateChanged // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void BeginActivation(); // Function FlashTrapModInst.FlashTrapModInst_C.BeginActivation // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnGrenadeSpawned(struct AKSProjectile_Grenade* Grenade); // Function FlashTrapModInst.FlashTrapModInst_C.OnGrenadeSpawned // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnGrenadeDestroyed(struct AActor* DestroyedActor); // Function FlashTrapModInst.FlashTrapModInst_C.OnGrenadeDestroyed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Init_RemoteThrow(struct AKSWeapon_RemoteThrow* RemoteThrow); // Function FlashTrapModInst.FlashTrapModInst_C.Init_RemoteThrow // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Init_Detonator(struct AKSWeapon_RemoteTrigger* Detonator); // Function FlashTrapModInst.FlashTrapModInst_C.Init_Detonator // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void On Detonator Spawned(struct AKSWeapon_RemoteTrigger* Detonator); // Function FlashTrapModInst.FlashTrapModInst_C.On Detonator Spawned // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void On Remote Throw Spawned(struct AKSWeapon_RemoteThrow* RemoteThrow); // Function FlashTrapModInst.FlashTrapModInst_C.On Remote Throw Spawned // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void FiredOnAuthority(); // Function FlashTrapModInst.FlashTrapModInst_C.FiredOnAuthority // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void On Reclaimed(struct AKSProjectile* Reclaimed); // Function FlashTrapModInst.FlashTrapModInst_C.On Reclaimed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnAbilityReleased(); // Function FlashTrapModInst.FlashTrapModInst_C.OnAbilityReleased // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnNewCharacter(); // Function FlashTrapModInst.FlashTrapModInst_C.OnNewCharacter // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void On Character Died(struct AKSCharacterBase* KillerCharacter, struct AKSCharacterBase* KilledCharacter); // Function FlashTrapModInst.FlashTrapModInst_C.On Character Died // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_FlashTrapModInst(int32_t EntryPoint); // Function FlashTrapModInst.FlashTrapModInst_C.ExecuteUbergraph_FlashTrapModInst // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

