// WidgetBlueprintGeneratedClass StandardButtonNoBorder.StandardButtonNoBorder_C
// Size: 0x548 (Inherited: 0x4e0)
struct UStandardButtonNoBorder_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UWidgetAnimation* Hover; // 0x4e8(0x08)
	struct UImage* HoverLeft; // 0x4f0(0x08)
	struct UButton* LoadoutButton; // 0x4f8(0x08)
	struct UNamedSlot* NamedSlot_1; // 0x500(0x08)
	struct FMulticastInlineDelegate OnClicked; // 0x508(0x10)
	struct FMulticastInlineDelegate OnHovered; // 0x518(0x10)
	struct FMulticastInlineDelegate OnUnhovered; // 0x528(0x10)
	struct UAkAudioEvent* ClickStandardButtonNoBorderSFX; // 0x538(0x08)
	struct UAkAudioEvent* HoverStandardButtonNoBorderSFX; // 0x540(0x08)

	bool NavigateConfirm(); // Function StandardButtonNoBorder.StandardButtonNoBorder_C.NavigateConfirm // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BndEvt__LoadoutButton_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function StandardButtonNoBorder.StandardButtonNoBorder_C.BndEvt__LoadoutButton_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__LoadoutButton_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function StandardButtonNoBorder.StandardButtonNoBorder_C.BndEvt__LoadoutButton_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__LoadoutButton_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature(); // Function StandardButtonNoBorder.StandardButtonNoBorder_C.BndEvt__LoadoutButton_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void GamepadHover(); // Function StandardButtonNoBorder.StandardButtonNoBorder_C.GamepadHover // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void GamepadUnhover(); // Function StandardButtonNoBorder.StandardButtonNoBorder_C.GamepadUnhover // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void GamepadConfirm(); // Function StandardButtonNoBorder.StandardButtonNoBorder_C.GamepadConfirm // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Do Hover(); // Function StandardButtonNoBorder.StandardButtonNoBorder_C.Do Hover // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Do Unhover(); // Function StandardButtonNoBorder.StandardButtonNoBorder_C.Do Unhover // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_StandardButtonNoBorder(int32_t EntryPoint); // Function StandardButtonNoBorder.StandardButtonNoBorder_C.ExecuteUbergraph_StandardButtonNoBorder // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void OnUnhovered__DelegateSignature(struct UWidget* Widget); // Function StandardButtonNoBorder.StandardButtonNoBorder_C.OnUnhovered__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnHovered__DelegateSignature(struct UWidget* Widget); // Function StandardButtonNoBorder.StandardButtonNoBorder_C.OnHovered__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnClicked__DelegateSignature(struct UWidget* Widget); // Function StandardButtonNoBorder.StandardButtonNoBorder_C.OnClicked__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

