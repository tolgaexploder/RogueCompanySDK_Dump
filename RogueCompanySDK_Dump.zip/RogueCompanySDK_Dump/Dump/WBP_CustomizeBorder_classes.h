// WidgetBlueprintGeneratedClass WBP_CustomizeBorder.WBP_CustomizeBorder_C
// Size: 0x578 (Inherited: 0x4e0)
struct UWBP_CustomizeBorder_C : UKSPlayerCosmeticWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UWidgetAnimation* ShowAnim; // 0x4e8(0x08)
	struct UKSSortableGridPanel* ItemContainer; // 0x4f0(0x08)
	struct UScrollBox* ScrollBox_1; // 0x4f8(0x08)
	struct UWBP_CosmeticItem_Border_C* WBP_CosmeticItem_Border; // 0x500(0x08)
	struct UWBP_CosmeticItem_Border_C* WBP_CosmeticItem_Border_2; // 0x508(0x08)
	struct UWBP_CosmeticItem_Border_C* WBP_CosmeticItem_Border_3; // 0x510(0x08)
	struct UWBP_CosmeticItem_Border_C* WBP_CosmeticItem_Border_4; // 0x518(0x08)
	struct UWBP_CosmeticItem_Border_C* WBP_CosmeticItem_Border_5; // 0x520(0x08)
	struct UWBP_CosmeticItem_Border_C* WBP_CosmeticItem_Border_6; // 0x528(0x08)
	struct UWBP_CosmeticItem_Border_C* WBP_CosmeticItem_Border_7; // 0x530(0x08)
	struct UWBP_CosmeticItem_Border_C* WBP_CosmeticItem_Border_8; // 0x538(0x08)
	struct UWBP_PlayerIDCustomize_C* WBP_PlayerIDCustomize; // 0x540(0x08)
	struct TArray<struct UWBP_CosmeticItem_Border_C*> BorderItems; // 0x548(0x10)
	struct UWBP_CosmeticItem_Border_C* EquippedBorder; // 0x558(0x08)
	struct UKSLoadoutDataFactory* LoadoutDataFactory; // 0x560(0x08)
	struct UKSItem* HoveredItem; // 0x568(0x08)
	int32_t VisibleGridRows; // 0x570(0x04)
	int32_t VisibleGridColumns; // 0x574(0x04)

	bool OnSortRarityDescNameAsc(struct UWidget* LHS, struct UWidget* RHS); // Function WBP_CustomizeBorder.WBP_CustomizeBorder_C.OnSortRarityDescNameAsc // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	struct FEventReply OnKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function WBP_CustomizeBorder.WBP_CustomizeBorder_C.OnKeyDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	bool NavigateBack(); // Function WBP_CustomizeBorder.WBP_CustomizeBorder_C.NavigateBack // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void AddEmptySlots(); // Function WBP_CustomizeBorder.WBP_CustomizeBorder_C.AddEmptySlots // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetActiveStates(struct UWBP_CosmeticItem_Border_C* ActiveWidget); // Function WBP_CustomizeBorder.WBP_CustomizeBorder_C.SetActiveStates // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void RegisterNavigation(); // Function WBP_CustomizeBorder.WBP_CustomizeBorder_C.RegisterNavigation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void IsBorderItemEquipped(struct UKSItem* KSItem, bool IsEquipped); // Function WBP_CustomizeBorder.WBP_CustomizeBorder_C.IsBorderItemEquipped // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void ResetBorderSelection(); // Function WBP_CustomizeBorder.WBP_CustomizeBorder_C.ResetBorderSelection // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetContextBar(); // Function WBP_CustomizeBorder.WBP_CustomizeBorder_C.SetContextBar // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetBorderSelection(); // Function WBP_CustomizeBorder.WBP_CustomizeBorder_C.SetBorderSelection // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function WBP_CustomizeBorder.WBP_CustomizeBorder_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidgetNavigation(); // Function WBP_CustomizeBorder.WBP_CustomizeBorder_C.InitializeWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnShown(); // Function WBP_CustomizeBorder.WBP_CustomizeBorder_C.OnShown // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnHide(); // Function WBP_CustomizeBorder.WBP_CustomizeBorder_C.OnHide // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnBackPrompt(); // Function WBP_CustomizeBorder.WBP_CustomizeBorder_C.OnBackPrompt // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnBorderHover(struct UKSItem* KSItem); // Function WBP_CustomizeBorder.WBP_CustomizeBorder_C.OnBorderHover // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnBorderUnhover(); // Function WBP_CustomizeBorder.WBP_CustomizeBorder_C.OnBorderUnhover // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnBorderSelected(struct UKSItem* KSItem, struct UWidget* Widget); // Function WBP_CustomizeBorder.WBP_CustomizeBorder_C.OnBorderSelected // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnBorderGamepadHover(struct UPUMG_Widget* Widget, bool bHovered); // Function WBP_CustomizeBorder.WBP_CustomizeBorder_C.OnBorderGamepadHover // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_CustomizeBorder(int32_t EntryPoint); // Function WBP_CustomizeBorder.WBP_CustomizeBorder_C.ExecuteUbergraph_WBP_CustomizeBorder // (Final|UbergraphFunction) // @ game+0x2587100
};

