// WidgetBlueprintGeneratedClass ScoreboardTeamSection.ScoreboardTeamSection_C
// Size: 0x550 (Inherited: 0x4e0)
struct UScoreboardTeamSection_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct USizeBox* HeightLimit; // 0x4e8(0x08)
	struct UVerticalBox* PlayerContainer; // 0x4f0(0x08)
	struct UTextBlock* PointsHeaderText; // 0x4f8(0x08)
	struct UTextBlock* teamScore; // 0x500(0x08)
	struct UImage* TeamScoreGradient; // 0x508(0x08)
	struct UBorder* TeamScoreWrapper; // 0x510(0x08)
	struct UWBP_PanelDefault_C* WBP_PanelDefault; // 0x518(0x08)
	struct TArray<struct UScoreboardPlayerEntry_C*> PlayerWidgets; // 0x520(0x10)
	int32_t UpdateIndex; // 0x530(0x04)
	char UnknownData_534[0x4]; // 0x534(0x04)
	struct AKSTeamState* Team; // 0x538(0x08)
	struct FMulticastInlineDelegate OnPlayerAdded; // 0x540(0x10)

	void UnhoverPlayerEntries(); // Function ScoreboardTeamSection.ScoreboardTeamSection_C.UnhoverPlayerEntries // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Get Player Widget byPlayerState(struct AKSPlayerState* Player State, struct UScoreboardPlayerEntry_C* Widget); // Function ScoreboardTeamSection.ScoreboardTeamSection_C.Get Player Widget byPlayerState // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void EndUpdate(); // Function ScoreboardTeamSection.ScoreboardTeamSection_C.EndUpdate // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BeginUpdate(); // Function ScoreboardTeamSection.ScoreboardTeamSection_C.BeginUpdate // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdatePlayer(struct UKSPersistentPlayerData* PlayerData); // Function ScoreboardTeamSection.ScoreboardTeamSection_C.UpdatePlayer // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function ScoreboardTeamSection.ScoreboardTeamSection_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void UpdateHeaderColors(); // Function ScoreboardTeamSection.ScoreboardTeamSection_C.UpdateHeaderColors // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnShown(); // Function ScoreboardTeamSection.ScoreboardTeamSection_C.OnShown // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function ScoreboardTeamSection.ScoreboardTeamSection_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Display Cash Changed(); // Function ScoreboardTeamSection.ScoreboardTeamSection_C.Handle Display Cash Changed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Owner UI Relevance Changed(); // Function ScoreboardTeamSection.ScoreboardTeamSection_C.Owner UI Relevance Changed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_ScoreboardTeamSection(int32_t EntryPoint); // Function ScoreboardTeamSection.ScoreboardTeamSection_C.ExecuteUbergraph_ScoreboardTeamSection // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void OnPlayerAdded__DelegateSignature(); // Function ScoreboardTeamSection.ScoreboardTeamSection_C.OnPlayerAdded__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

