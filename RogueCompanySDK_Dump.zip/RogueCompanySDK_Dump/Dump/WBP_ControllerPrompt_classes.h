// WidgetBlueprintGeneratedClass WBP_ControllerPrompt.WBP_ControllerPrompt_C
// Size: 0x518 (Inherited: 0x4e0)
struct UWBP_ControllerPrompt_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UImage* Prompt; // 0x4e8(0x08)
	enum class EGamepadPromptType PromptType; // 0x4f0(0x01)
	char UnknownData_4F1[0x3]; // 0x4f1(0x03)
	struct FName ActionName; // 0x4f4(0x08)
	char UnknownData_4FC[0x4]; // 0x4fc(0x04)
	struct FKey Button; // 0x500(0x18)

	void SetButtonPrompt(struct FKey Button); // Function WBP_ControllerPrompt.WBP_ControllerPrompt_C.SetButtonPrompt // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetIsCancel(); // Function WBP_ControllerPrompt.WBP_ControllerPrompt_C.SetIsCancel // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetIsConfirm(); // Function WBP_ControllerPrompt.WBP_ControllerPrompt_C.SetIsConfirm // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetPromptFromButton(struct FKey Button); // Function WBP_ControllerPrompt.WBP_ControllerPrompt_C.SetPromptFromButton // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateFromSetValues(); // Function WBP_ControllerPrompt.WBP_ControllerPrompt_C.UpdateFromSetValues // (Protected|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetInputAction(struct FName ActionName); // Function WBP_ControllerPrompt.WBP_ControllerPrompt_C.SetInputAction // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PreConstruct(bool IsDesignTime); // Function WBP_ControllerPrompt.WBP_ControllerPrompt_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function WBP_ControllerPrompt.WBP_ControllerPrompt_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_ControllerPrompt(int32_t EntryPoint); // Function WBP_ControllerPrompt.WBP_ControllerPrompt_C.ExecuteUbergraph_WBP_ControllerPrompt // (Final|UbergraphFunction) // @ game+0x2587100
};

