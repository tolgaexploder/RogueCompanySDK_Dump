// WidgetBlueprintGeneratedClass MedDroneMenuOption.MedDroneMenuOption_C
// Size: 0x528 (Inherited: 0x4e0)
struct UMedDroneMenuOption_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UImage* Bg; // 0x4e8(0x08)
	struct UButton* Button_1; // 0x4f0(0x08)
	struct UImage* DownedIcon; // 0x4f8(0x08)
	struct UTextBlock* PlayerName; // 0x500(0x08)
	struct AKSPlayerState* Target Player State; // 0x508(0x08)
	struct FMulticastInlineDelegate Selected; // 0x510(0x10)
	struct AKSWeapon_Targeted* Targeting Weapon; // 0x520(0x08)

	bool NavigateBack(); // Function MedDroneMenuOption.MedDroneMenuOption_C.NavigateBack // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	bool NavigateConfirm(); // Function MedDroneMenuOption.MedDroneMenuOption_C.NavigateConfirm // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function MedDroneMenuOption.MedDroneMenuOption_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void BndEvt__Button_0_K2Node_ComponentBoundEvent_20_OnButtonClickedEvent__DelegateSignature(); // Function MedDroneMenuOption.MedDroneMenuOption_C.BndEvt__Button_0_K2Node_ComponentBoundEvent_20_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void Target Player Check Validity(struct AKSPlayerState* PlayerState); // Function MedDroneMenuOption.MedDroneMenuOption_C.Target Player Check Validity // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void TargetSelected(); // Function MedDroneMenuOption.MedDroneMenuOption_C.TargetSelected // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BndEvt__Button_0_K2Node_ComponentBoundEvent_11_OnButtonHoverEvent__DelegateSignature(); // Function MedDroneMenuOption.MedDroneMenuOption_C.BndEvt__Button_0_K2Node_ComponentBoundEvent_11_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void GamepadHover(); // Function MedDroneMenuOption.MedDroneMenuOption_C.GamepadHover // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void BndEvt__Button_0_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature(); // Function MedDroneMenuOption.MedDroneMenuOption_C.BndEvt__Button_0_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void GamepadUnhover(); // Function MedDroneMenuOption.MedDroneMenuOption_C.GamepadUnhover // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_MedDroneMenuOption(int32_t EntryPoint); // Function MedDroneMenuOption.MedDroneMenuOption_C.ExecuteUbergraph_MedDroneMenuOption // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void Selected__DelegateSignature(struct AKSPlayerState* Selected Target); // Function MedDroneMenuOption.MedDroneMenuOption_C.Selected__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

