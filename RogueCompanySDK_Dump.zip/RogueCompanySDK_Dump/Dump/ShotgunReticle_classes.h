// WidgetBlueprintGeneratedClass ShotgunReticle.ShotgunReticle_C
// Size: 0x2fc (Inherited: 0x248)
struct UShotgunReticle_C : UReticleBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x248(0x08)
	struct UWidgetAnimation* AmmoGaugeCriticallyLowAmmo; // 0x250(0x08)
	struct UWidgetAnimation* AmmoGaugeLowAmmo; // 0x258(0x08)
	struct UWidgetAnimation* GaugeFade; // 0x260(0x08)
	struct UWidgetAnimation* GrenadeAnim; // 0x268(0x08)
	struct UWidgetAnimation* KillAnim; // 0x270(0x08)
	struct UWidgetAnimation* HeadshotAnim; // 0x278(0x08)
	struct UWidgetAnimation* HitAnim; // 0x280(0x08)
	struct UWidgetAnimation* ADSFade; // 0x288(0x08)
	struct UCanvasPanel* AmmoGauge; // 0x290(0x08)
	struct UImage* AmmoGaugeBG; // 0x298(0x08)
	struct UProgressBar* AmmoGaugeFill; // 0x2a0(0x08)
	struct UImage* CenterDot; // 0x2a8(0x08)
	struct UImage* CurveBottomLeft; // 0x2b0(0x08)
	struct UImage* CurveBottomRight; // 0x2b8(0x08)
	struct UImage* CurveTopLeft; // 0x2c0(0x08)
	struct UImage* CurveTopRight; // 0x2c8(0x08)
	struct UImage* HeadshotMarker; // 0x2d0(0x08)
	struct UImage* HitMarker; // 0x2d8(0x08)
	struct UImage* KillMarker; // 0x2e0(0x08)
	struct UImage* reddot; // 0x2e8(0x08)
	struct FTimerHandle GrenadeTickTimer; // 0x2f0(0x08)
	float CachedOffset; // 0x2f8(0x04)

	void IsValidWeaponType(struct UKSWeaponComponent* NewParam, bool IsValidWeaponType); // Function ShotgunReticle.ShotgunReticle_C.IsValidWeaponType // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void ShouldHideAmmoGauge(struct UKSWeaponComponent* NewParam, bool bShouldHideAmmoGauge); // Function ShotgunReticle.ShotgunReticle_C.ShouldHideAmmoGauge // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void UpdateReloadBarPosition(); // Function ShotgunReticle.ShotgunReticle_C.UpdateReloadBarPosition // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateCrosshairDisplay(); // Function ShotgunReticle.ShotgunReticle_C.UpdateCrosshairDisplay // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ColorSet(struct FLinearColor NewColor); // Function ShotgunReticle.ShotgunReticle_C.ColorSet // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void FadeClipMeter(); // Function ShotgunReticle.ShotgunReticle_C.FadeClipMeter // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateOffset(float Offset); // Function ShotgunReticle.ShotgunReticle_C.UpdateOffset // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ChangeADS(bool Active); // Function ShotgunReticle.ShotgunReticle_C.ChangeADS // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HitConfirm(); // Function ShotgunReticle.ShotgunReticle_C.HitConfirm // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Headshot(); // Function ShotgunReticle.ShotgunReticle_C.Headshot // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void KillConfirm(); // Function ShotgunReticle.ShotgunReticle_C.KillConfirm // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GrenadeCook(bool Active, float TickPeriod); // Function ShotgunReticle.ShotgunReticle_C.GrenadeCook // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GrenadeTick(); // Function ShotgunReticle.ShotgunReticle_C.GrenadeTick // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateAmmoGauge(struct UKSWeaponComponent* Weapon); // Function ShotgunReticle.ShotgunReticle_C.UpdateAmmoGauge // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_ShotgunReticle(int32_t EntryPoint); // Function ShotgunReticle.ShotgunReticle_C.ExecuteUbergraph_ShotgunReticle // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

