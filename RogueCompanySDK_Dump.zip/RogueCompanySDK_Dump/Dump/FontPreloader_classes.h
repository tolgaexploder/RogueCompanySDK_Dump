// WidgetBlueprintGeneratedClass FontPreloader.FontPreloader_C
// Size: 0x261 (Inherited: 0x238)
struct UFontPreloader_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UFontPreloaderText_C* FontPreloaderText; // 0x240(0x08)
	struct UVerticalBox* MyVerticalBox; // 0x248(0x08)
	struct TArray<struct FSlateFontInfo> FontsToLoad; // 0x250(0x10)
	bool DebugFontPreloader; // 0x260(0x01)

	void Construct(); // Function FontPreloader.FontPreloader_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_FontPreloader(int32_t EntryPoint); // Function FontPreloader.FontPreloader_C.ExecuteUbergraph_FontPreloader // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

