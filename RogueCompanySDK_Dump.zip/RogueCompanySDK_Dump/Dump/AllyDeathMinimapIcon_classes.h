// WidgetBlueprintGeneratedClass AllyDeathMinimapIcon.AllyDeathMinimapIcon_C
// Size: 0x360 (Inherited: 0x318)
struct UAllyDeathMinimapIcon_C : UKSMapIconWidgetBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x318(0x08)
	struct UWidgetAnimation* Ping; // 0x320(0x08)
	struct UImage* AboveIndicator; // 0x328(0x08)
	struct UImage* BelowIndicator; // 0x330(0x08)
	struct UImage* ImageIcon; // 0x338(0x08)
	struct UScaleBox* ScaleBox_1; // 0x340(0x08)
	struct FMulticastInlineDelegate PingExpired; // 0x348(0x10)
	struct AKSPlayerState* Represented Player State; // 0x358(0x08)

	bool ShouldUpdate(); // Function AllyDeathMinimapIcon.AllyDeathMinimapIcon_C.ShouldUpdate // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function AllyDeathMinimapIcon.AllyDeathMinimapIcon_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Start Fade(); // Function AllyDeathMinimapIcon.AllyDeathMinimapIcon_C.Start Fade // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateMeetsHeightThreshold(bool bHeight, bool bDepth); // Function AllyDeathMinimapIcon.AllyDeathMinimapIcon_C.UpdateMeetsHeightThreshold // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void HandleMapIconWidgetReady(); // Function AllyDeathMinimapIcon.AllyDeathMinimapIcon_C.HandleMapIconWidgetReady // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_AllyDeathMinimapIcon(int32_t EntryPoint); // Function AllyDeathMinimapIcon.AllyDeathMinimapIcon_C.ExecuteUbergraph_AllyDeathMinimapIcon // (Final|UbergraphFunction) // @ game+0x2587100
	void PingExpired__DelegateSignature(enum class None IconType, int32_t UniqueId); // Function AllyDeathMinimapIcon.AllyDeathMinimapIcon_C.PingExpired__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

