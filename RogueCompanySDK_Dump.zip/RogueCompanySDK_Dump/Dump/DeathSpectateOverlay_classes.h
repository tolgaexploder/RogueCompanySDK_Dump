// WidgetBlueprintGeneratedClass DeathSpectateOverlay.DeathSpectateOverlay_C
// Size: 0x590 (Inherited: 0x510)
struct UDeathSpectateOverlay_C : UKSViewedPawnWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x510(0x08)
	struct UHorizontalBox* GamepadGroup; // 0x518(0x08)
	struct UImage* GamepadLeft; // 0x520(0x08)
	struct UImage* GamepadRight; // 0x528(0x08)
	struct UImage* Image; // 0x530(0x08)
	struct UImage* Image_2; // 0x538(0x08)
	struct UImage* Image_3; // 0x540(0x08)
	struct UImage* Image_256; // 0x548(0x08)
	struct UHorizontalBox* MouseGroup; // 0x550(0x08)
	struct UImage* MouseLeft; // 0x558(0x08)
	struct UImage* MouseRight; // 0x560(0x08)
	struct UHorizontalBox* NextTeammateControls; // 0x568(0x08)
	struct UWBP_PlayerIdentity_Full_C* PlayerIdentityCard; // 0x570(0x08)
	struct UTextBlock* SpectateTitle; // 0x578(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_1; // 0x580(0x08)
	struct AKSTeamState* CurrentSpectatedTeam; // 0x588(0x08)

	void UpdateViewNextTeammate(); // Function DeathSpectateOverlay.DeathSpectateOverlay_C.UpdateViewNextTeammate // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function DeathSpectateOverlay.DeathSpectateOverlay_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function DeathSpectateOverlay.DeathSpectateOverlay_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Input State Changed(enum class PGAME_INPUT_STATE InputState); // Function DeathSpectateOverlay.DeathSpectateOverlay_C.Handle Input State Changed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Spectate State Changed(bool IsSpectating); // Function DeathSpectateOverlay.DeathSpectateOverlay_C.Handle Spectate State Changed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void TeamMemberEliminated(struct AKSPlayerState* PlayerState); // Function DeathSpectateOverlay.DeathSpectateOverlay_C.TeamMemberEliminated // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void DetermineLocalPlayerControlled(); // Function DeathSpectateOverlay.DeathSpectateOverlay_C.DetermineLocalPlayerControlled // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Refresh Player Identity(struct AKSPlayerState* InKSPlayerState); // Function DeathSpectateOverlay.DeathSpectateOverlay_C.Refresh Player Identity // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PostSetPlayerState(); // Function DeathSpectateOverlay.DeathSpectateOverlay_C.PostSetPlayerState // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void PreClearPlayerState(); // Function DeathSpectateOverlay.DeathSpectateOverlay_C.PreClearPlayerState // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void Update Team State Bindings(); // Function DeathSpectateOverlay.DeathSpectateOverlay_C.Update Team State Bindings // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Clear Bound Team State(); // Function DeathSpectateOverlay.DeathSpectateOverlay_C.Clear Bound Team State // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_DeathSpectateOverlay(int32_t EntryPoint); // Function DeathSpectateOverlay.DeathSpectateOverlay_C.ExecuteUbergraph_DeathSpectateOverlay // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

