// WidgetBlueprintGeneratedClass WBP_AsyncIcon.WBP_AsyncIcon_C
// Size: 0x590 (Inherited: 0x4e0)
struct UWBP_AsyncIcon_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UKSAsyncImage* Icon; // 0x4e8(0x08)
	struct UThrobber* LoadingThrobber; // 0x4f0(0x08)
	struct FMulticastInlineDelegate OnIconUpdated; // 0x4f8(0x10)
	struct FSlateBrush DefaultBrush; // 0x508(0x88)

	void Set Brush from Texture on Item(struct UKSItem* Item, bool MatchSize, struct TSoftObjectPtr<struct UTexture2D> Texture); // Function WBP_AsyncIcon.WBP_AsyncIcon_C.Set Brush from Texture on Item // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Get Material(struct UMaterialInstanceDynamic* MaterialInstanceDynamic); // Function WBP_AsyncIcon.WBP_AsyncIcon_C.Get Material // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void SetMaterialToUse(struct UMaterialInterface* Material); // Function WBP_AsyncIcon.WBP_AsyncIcon_C.SetMaterialToUse // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ApplyDefaultBrush(); // Function WBP_AsyncIcon.WBP_AsyncIcon_C.ApplyDefaultBrush // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetBrushFromSoftTexture(struct TSoftObjectPtr<struct UTexture2D> Texture, bool MatchSize); // Function WBP_AsyncIcon.WBP_AsyncIcon_C.SetBrushFromSoftTexture // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetBrushFromTexture(struct UTexture2D* Texture, bool MatchSize); // Function WBP_AsyncIcon.WBP_AsyncIcon_C.SetBrushFromTexture // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetBrushFromItemIcon(struct UPlatformInventoryItem* Item, bool MatchSize); // Function WBP_AsyncIcon.WBP_AsyncIcon_C.SetBrushFromItemIcon // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PreConstruct(bool IsDesignTime); // Function WBP_AsyncIcon.WBP_AsyncIcon_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function WBP_AsyncIcon.WBP_AsyncIcon_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnStartLoad(struct UPUMG_AsyncImage* Image); // Function WBP_AsyncIcon.WBP_AsyncIcon_C.OnStartLoad // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnFinishLoad(struct UPUMG_AsyncImage* Image); // Function WBP_AsyncIcon.WBP_AsyncIcon_C.OnFinishLoad // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_AsyncIcon(int32_t EntryPoint); // Function WBP_AsyncIcon.WBP_AsyncIcon_C.ExecuteUbergraph_WBP_AsyncIcon // (Final|UbergraphFunction) // @ game+0x2587100
	void OnIconUpdated__DelegateSignature(struct UTexture2D* Texture); // Function WBP_AsyncIcon.WBP_AsyncIcon_C.OnIconUpdated__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

