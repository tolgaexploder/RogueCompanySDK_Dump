// WidgetBlueprintGeneratedClass WBP_BattlePassEmblem.WBP_BattlePassEmblem_C
// Size: 0x518 (Inherited: 0x4e0)
struct UWBP_BattlePassEmblem_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UWidgetSwitcher* EmblemSwitcher; // 0x4e8(0x08)
	struct UWidgetSwitcher* LevelOrBadgeSwitcher; // 0x4f0(0x08)
	struct UImage* LockIcon; // 0x4f8(0x08)
	struct UWBP_AsyncIcon_C* PremiumEmblem; // 0x500(0x08)
	struct UWBP_AsyncIcon_C* StandardEmblem; // 0x508(0x08)
	struct UTextBlock* TierNumber; // 0x510(0x08)

	void SetPremiumUpsellState(); // Function WBP_BattlePassEmblem.WBP_BattlePassEmblem_C.SetPremiumUpsellState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetBattlePassInfoExplicit(bool HasPremium, int32_t Tier); // Function WBP_BattlePassEmblem.WBP_BattlePassEmblem_C.SetBattlePassInfoExplicit // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetBattlePassInfoFromStoreItem(struct UPUMG_StoreItem* StoreItem); // Function WBP_BattlePassEmblem.WBP_BattlePassEmblem_C.SetBattlePassInfoFromStoreItem // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetBattlePassInfoFromActivityInstance(struct UKSActivityInstance* ActivityInstance); // Function WBP_BattlePassEmblem.WBP_BattlePassEmblem_C.SetBattlePassInfoFromActivityInstance // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeBadgeTextures(); // Function WBP_BattlePassEmblem.WBP_BattlePassEmblem_C.InitializeBadgeTextures // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function WBP_BattlePassEmblem.WBP_BattlePassEmblem_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_BattlePassEmblem(int32_t EntryPoint); // Function WBP_BattlePassEmblem.WBP_BattlePassEmblem_C.ExecuteUbergraph_WBP_BattlePassEmblem // (Final|UbergraphFunction) // @ game+0x2587100
};

