// Class PlatformGameFramework.DistributionVectorUniformParameter
// Size: 0x60 (Inherited: 0x38)
struct UDistributionVectorUniformParameter : UDistributionVector {
	struct FName MaxParamName; // 0x38(0x08)
	struct FName MinParamName; // 0x40(0x08)
	struct FVector DefaultMaxValue; // 0x48(0x0c)
	struct FVector DefaultMinValue; // 0x54(0x0c)
};

// Class PlatformGameFramework.PGame_BlueprintFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UPGame_BlueprintFunctionLibrary : UBlueprintFunctionLibrary {

	void ShowSkinnedMeshMaterialSection(struct USkinnedMeshComponent* SkinnedMeshComponent, int32_t MaterialID, int32_t SectionIndex, bool bShow, int32_t LODIndex); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.ShowSkinnedMeshMaterialSection // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7ba830
	void SetLightingChannels(struct UPrimitiveComponent* PrimitiveComponent, struct FLightingChannels NewLightingChannels); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.SetLightingChannels // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7ba770
	bool IsSteamClient(); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.IsSteamClient // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x7ba1e0
	bool IsPlatformType(bool IsConsole, bool IsPC, bool IsMobile); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.IsPlatformType // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x7ba0d0
	bool IsPlatform(bool IsXboxOne, bool IsPS4, bool IsSwitch, bool IsWindows, bool IsMac, bool IsLinux, bool IsIOS, bool IsAndroid, bool IsXSX, bool IsPS5); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.IsPlatform // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x7b9de0
	bool IsGameBit(enum class EGameBits GameBit); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.IsGameBit // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x7b9d60
	bool IsAnonymousLogin(); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.IsAnonymousLogin // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x7b9d30
	float GetPropertyClampedValue(struct FPGame_Property Prop); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.GetPropertyClampedValue // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x7b99a0
	enum class EGameLocalizationType GetGameLocalizationType(); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.GetGameLocalizationType // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x7b98d0
	void FrameDelay(struct UObject* WorldContextObject, int32_t NumFramesToDelay, struct FLatentActionInfo LatentInfo); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.FrameDelay // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7b9570
	struct FLightingChannels ConvertToEngineLightingChannels(struct FPGame_BlueprintableLightingChannels BlueprintableLightingChannels); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.ConvertToEngineLightingChannels // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x7b9220
	struct FPGame_BlueprintableLightingChannels ConvertToBlueprintableLightingChannels(struct FLightingChannels EngineLightChannels); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.ConvertToBlueprintableLightingChannels // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x7b9190
	bool AreMeshComponentTexturesFullyStreamedIn(struct UMeshComponent* InMeshComponent); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.AreMeshComponentTexturesFullyStreamedIn // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x7b8ee0
	bool AreActorTexturesFullyStreamedIn(struct AActor* InActor); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.AreActorTexturesFullyStreamedIn // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x7b8e60
};

// Class PlatformGameFramework.PGame_Character
// Size: 0x500 (Inherited: 0x4c0)
struct APGame_Character : ACharacter {
	char UnknownData_4C0[0x8]; // 0x4c0(0x08)
	struct UPGame_EffectManagerComponent* m_EffectManager; // 0x4c8(0x08)
	struct FTweenInfo r_TweenInfo; // 0x4d0(0x14)
	struct FChargeInfo r_ChargeInfo; // 0x4e4(0x1c)

	void OnRep_Tween(); // Function PlatformGameFramework.PGame_Character.OnRep_Tween // (Native|Protected) // @ game+0x7ba340
	void OnRep_Charge(); // Function PlatformGameFramework.PGame_Character.OnRep_Charge // (Native|Protected) // @ game+0x7ba270
};

// Class PlatformGameFramework.PGame_CharacterMovementComponent
// Size: 0x670 (Inherited: 0x610)
struct UPGame_CharacterMovementComponent : UCharacterMovementComponent {
	char UnknownData_610[0x20]; // 0x610(0x20)
	bool bUseTweenWalkingPhysics; // 0x630(0x01)
	char UnknownData_631[0x7]; // 0x631(0x07)
	struct FChargeInfo r_ChargeInfo; // 0x638(0x1c)
	struct FTweenInfo r_TweenInfo; // 0x654(0x14)
	char UnknownData_668[0x8]; // 0x668(0x08)

	void StopTween(); // Function PlatformGameFramework.PGame_CharacterMovementComponent.StopTween // (Native|Public) // @ game+0x7bacc0
	void StopCharge(); // Function PlatformGameFramework.PGame_CharacterMovementComponent.StopCharge // (Native|Public) // @ game+0x7baca0
	void StartTween(enum class None TweenType, struct FVector TweenDestination, float TweenTime); // Function PlatformGameFramework.PGame_CharacterMovementComponent.StartTween // (Native|Public|HasOutParms|HasDefaults) // @ game+0x7bab80
	void StartCharge(enum class None ChargeType, float ChargeInitialYaw, struct FVector ChargeInitialLocation, float ChargeSpeed, float ChargeRange); // Function PlatformGameFramework.PGame_CharacterMovementComponent.StartCharge // (Native|Public|HasOutParms|HasDefaults) // @ game+0x7ba9b0
	void OnRep_Tween(struct FTweenInfo TweenInfo); // Function PlatformGameFramework.PGame_CharacterMovementComponent.OnRep_Tween // (Native|Public|HasOutParms) // @ game+0x7ba360
	void OnRep_Charge(struct FChargeInfo ChargeInfo); // Function PlatformGameFramework.PGame_CharacterMovementComponent.OnRep_Charge // (Native|Public|HasOutParms) // @ game+0x7ba290
};

// Class PlatformGameFramework.PGame_CheatComponent
// Size: 0xb0 (Inherited: 0xb0)
struct UPGame_CheatComponent : UActorComponent {

	void TestFubar(); // Function PlatformGameFramework.PGame_CheatComponent.TestFubar // (Final|Exec|Native|Protected) // @ game+0x7bace0
	void ServerTestFubar(); // Function PlatformGameFramework.PGame_CheatComponent.ServerTestFubar // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x7ba5f0
	void ServerExecCall(struct FString request); // Function PlatformGameFramework.PGame_CheatComponent.ServerExecCall // (Net|Native|Event|Protected|NetServer|NetValidate) // @ game+0x7ba530
	void ServerExec(struct FString request); // Function PlatformGameFramework.PGame_CheatComponent.ServerExec // (Exec|Native|Protected) // @ game+0x7ba490
	void Logout(); // Function PlatformGameFramework.PGame_CheatComponent.Logout // (Final|Exec|Native|Protected) // @ game+0x7ba230
	void gmmf(); // Function PlatformGameFramework.PGame_CheatComponent.gmmf // (Final|Exec|Native|Protected) // @ game+0x7bae50
	void gmJoinQueue(int32_t QueueId); // Function PlatformGameFramework.PGame_CheatComponent.gmJoinQueue // (Final|Exec|Native|Protected) // @ game+0x7badd0
	void gmCommand(struct FString request); // Function PlatformGameFramework.PGame_CheatComponent.gmCommand // (Final|Exec|Native|Protected) // @ game+0x7bad30
	void gmC(struct FString request); // Function PlatformGameFramework.PGame_CheatComponent.gmC // (Final|Exec|Native|Protected) // @ game+0x7bad30
	void DumpAnimationStats(); // Function PlatformGameFramework.PGame_CheatComponent.DumpAnimationStats // (Final|Exec|Native|Protected) // @ game+0x7b9480
	void CustomForceStart(); // Function PlatformGameFramework.PGame_CheatComponent.CustomForceStart // (Final|Exec|Native|Protected) // @ game+0x7b9460
};

// Class PlatformGameFramework.PGame_CombatLogVisualizer
// Size: 0x230 (Inherited: 0x220)
struct APGame_CombatLogVisualizer : AActor {
	struct FString LogFileName; // 0x220(0x10)

	void Visualize(); // Function PlatformGameFramework.PGame_CombatLogVisualizer.Visualize // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void LoadCombatLog(); // Function PlatformGameFramework.PGame_CombatLogVisualizer.LoadCombatLog // (Final|Native|Public) // @ game+0x7ba210
	void ClearVisualization(); // Function PlatformGameFramework.PGame_CombatLogVisualizer.ClearVisualization // (Event|Public|BlueprintEvent) // @ game+0x2587100
};

// Class PlatformGameFramework.PGame_EffectManagerComponent
// Size: 0x380 (Inherited: 0xb0)
struct UPGame_EffectManagerComponent : UActorComponent {
	char UnknownData_B0[0x28]; // 0xb0(0x28)
	struct FPGame_PersistentEffectRepDataContainer r_ReplicatedEffectData; // 0xd8(0x120)
	struct FPGame_EffectManagerPropertyContainer r_ReplicatedProperties; // 0x1f8(0x170)
	char UnknownData_368[0x18]; // 0x368(0x18)

	void OnRep_EffectData(); // Function PlatformGameFramework.PGame_EffectManagerComponent.OnRep_EffectData // (Native|Public) // @ game+0x7ba320
	void InstantEffectBroadcast(struct FPGame_InstantEffectRepData repData); // Function PlatformGameFramework.PGame_EffectManagerComponent.InstantEffectBroadcast // (Net|Native|Event|NetMulticast|Public) // @ game+0x7b9c60
	int32_t GetPropertyValueIntFromBlueprint(int32_t PropertyId); // Function PlatformGameFramework.PGame_EffectManagerComponent.GetPropertyValueIntFromBlueprint // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7b9b30
	float GetPropertyValueFromBlueprint(int32_t PropertyId); // Function PlatformGameFramework.PGame_EffectManagerComponent.GetPropertyValueFromBlueprint // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7b9a90
	struct UPGame_EffectGroupPersistent* GetDefaultEffectGroupForPersistentRepData(struct FPGame_PersistentEffectRepData repData); // Function PlatformGameFramework.PGame_EffectManagerComponent.GetDefaultEffectGroupForPersistentRepData // (Final|Native|Public|HasOutParms|Const) // @ game+0x7b9750
	struct UPGame_EffectGroupInstant* GetDefaultEffectGroupForInstantRepData(struct FPGame_InstantEffectRepData repData); // Function PlatformGameFramework.PGame_EffectManagerComponent.GetDefaultEffectGroupForInstantRepData // (Final|Native|Public|HasOutParms|Const) // @ game+0x7b9690
	struct UPGame_EffectAttachment* CreatePersistentAttachment(struct FPGame_PersistentEffectRepData repData); // Function PlatformGameFramework.PGame_EffectManagerComponent.CreatePersistentAttachment // (Native|Public|HasOutParms) // @ game+0x7b9370
	void CreateInstantAttachment(struct FPGame_InstantEffectRepData repData); // Function PlatformGameFramework.PGame_EffectManagerComponent.CreateInstantAttachment // (Native|Public|HasOutParms) // @ game+0x7b92c0
};

// Class PlatformGameFramework.PGame_EffectAttachment
// Size: 0xb0 (Inherited: 0xb0)
struct UPGame_EffectAttachment : UActorComponent {
};

// Class PlatformGameFramework.PGame_EffectGroup
// Size: 0x80 (Inherited: 0x28)
struct UPGame_EffectGroup : UObject {
	struct FGameplayTagContainer m_EffectGroupTypes; // 0x28(0x20)
	struct FGameplayTagContainer m_BehaviorCategories; // 0x48(0x20)
	struct TArray<struct UPGame_Effect*> m_Effects; // 0x68(0x10)
	struct UPGame_EffectAttachment* m_AttachmentClass; // 0x78(0x08)
};

// Class PlatformGameFramework.PGame_EffectGroupPersistent
// Size: 0xa0 (Inherited: 0x80)
struct UPGame_EffectGroupPersistent : UPGame_EffectGroup {
	struct FGameplayTag m_StackingCategory; // 0x80(0x08)
	enum class EEffectGroupApplicationRule m_ApplicationRule; // 0x88(0x04)
	enum class None m_nMaxStackCount; // 0x8c(0x01)
	bool m_bApplyInstantOnInterval; // 0x8d(0x01)
	bool m_bApplyStackOnInterval; // 0x8e(0x01)
	char UnknownData_8F[0x1]; // 0x8f(0x01)
	float m_fStartDuration; // 0x90(0x04)
	float m_fDuration; // 0x94(0x04)
	float m_fIntervalDuration; // 0x98(0x04)
	float m_fApplicationStrength; // 0x9c(0x04)
};

// Class PlatformGameFramework.PGame_EffectGroupInstant
// Size: 0x80 (Inherited: 0x80)
struct UPGame_EffectGroupInstant : UPGame_EffectGroup {
};

// Class PlatformGameFramework.PGame_Effect
// Size: 0x50 (Inherited: 0x28)
struct UPGame_Effect : UObject {
	struct FPGame_Property m_Property; // 0x28(0x24)
	bool m_bApplyOnInternal; // 0x4c(0x01)
	char UnknownData_4D[0x3]; // 0x4d(0x03)
};

// Class PlatformGameFramework.PGame_Effectable
// Size: 0x28 (Inherited: 0x28)
struct UPGame_Effectable : UInterface {

	int32_t GetIntPropertyValue(int32_t propIdInt); // Function PlatformGameFramework.PGame_Effectable.GetIntPropertyValue // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7b9900
	float GetFloatPropertyValue(int32_t propIdInt); // Function PlatformGameFramework.PGame_Effectable.GetFloatPropertyValue // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7b9830
};

// Class PlatformGameFramework.PGame_EffectSource
// Size: 0x28 (Inherited: 0x28)
struct UPGame_EffectSource : UInterface {
};

// Class PlatformGameFramework.PGame_GameInstance
// Size: 0x230 (Inherited: 0x198)
struct UPGame_GameInstance : UGameInstance {
	char UnknownData_198[0x80]; // 0x198(0x80)
	bool bStartHotfixProcessingOnUpdateAppSettings; // 0x218(0x01)
	char UnknownData_219[0x17]; // 0x219(0x17)

	void EndLoadingScreen(struct UWorld* World); // Function PlatformGameFramework.PGame_GameInstance.EndLoadingScreen // (Native|Protected) // @ game+0x7b94a0
	void BeginLoadingScreen(struct FString mapName); // Function PlatformGameFramework.PGame_GameInstance.BeginLoadingScreen // (Native|Protected) // @ game+0x7b8f60
};

// Class PlatformGameFramework.PGame_GameModeBase
// Size: 0x398 (Inherited: 0x308)
struct APGame_GameModeBase : AGameMode {
	char UnknownData_308[0x50]; // 0x308(0x50)
	struct FString PersistentMapSuffix; // 0x358(0x10)
	struct TArray<struct FString> SublevelSuffixes; // 0x368(0x10)
	struct TArray<struct FString> HighMemorySublevelSuffixes; // 0x378(0x10)
	struct TArray<struct FString> LowMemorySublevelSuffixes; // 0x388(0x10)
};

// Class PlatformGameFramework.PGame_GameMode
// Size: 0x470 (Inherited: 0x398)
struct APGame_GameMode : APGame_GameModeBase {
	char UnknownData_398[0x30]; // 0x398(0x30)
	bool bAutoEnableCombatLog; // 0x3c8(0x01)
	bool bUploadCombatLogOverride; // 0x3c9(0x01)
	char UnknownData_3CA[0x3e]; // 0x3ca(0x3e)
	bool bFubarForCPUFramerate; // 0x408(0x01)
	bool bFubarForPacketLoss; // 0x409(0x01)
	char UnknownData_40A[0x2]; // 0x40a(0x02)
	float FubarShutdownWaitTimeoutTime; // 0x40c(0x04)
	char UnknownData_410[0x8]; // 0x410(0x08)
	struct FString SonyActivityId; // 0x418(0x10)
	float SonyMatchOwnerNetTimeout; // 0x428(0x04)
	char UnknownData_42C[0x4]; // 0x42c(0x04)
	struct FPGame_SonyMatchData SonyMatchData; // 0x430(0x18)
	struct TArray<uint32_t> SonyIneligibleMatchOwners; // 0x448(0x10)
	char UnknownData_458[0x8]; // 0x458(0x08)
	struct TArray<struct FPGame_InactivePlayerStateEntry> PGame_InactivePlayerArray; // 0x460(0x10)

	void OnFubarShutdownTimeout(); // Function PlatformGameFramework.PGame_GameMode.OnFubarShutdownTimeout // (Final|Native|Protected) // @ game+0x7ba250
	void InactivePlayerStateDestroyed(struct AActor* InActor); // Function PlatformGameFramework.PGame_GameMode.InactivePlayerStateDestroyed // (Final|Native|Private) // @ game+0x7b9be0
	void FinalShutdown(); // Function PlatformGameFramework.PGame_GameMode.FinalShutdown // (Final|Native|Protected) // @ game+0x7b9530
	void FinalizeMatchEnded(); // Function PlatformGameFramework.PGame_GameMode.FinalizeMatchEnded // (Native|Protected) // @ game+0x7b9550
};

// Class PlatformGameFramework.PGame_GameState
// Size: 0x290 (Inherited: 0x290)
struct APGame_GameState : AGameState {
};

// Class PlatformGameFramework.PGame_LandingPanelJSONHandler
// Size: 0x160 (Inherited: 0x28)
struct UPGame_LandingPanelJSONHandler : UObject {
	struct FMulticastInlineDelegate OnHandlerObjectReady; // 0x28(0x10)
	struct FMulticastInlineDelegate OnJsonDownloaded; // 0x38(0x10)
	struct FMulticastInlineDelegate OnImagesDownloaded; // 0x48(0x10)
	char UnknownData_58[0xb8]; // 0x58(0xb8)
	struct TMap<struct FString, struct UTexture2DDynamic*> mapFilePathToTexture; // 0x110(0x50)

	void RequestNewJson(); // Function PlatformGameFramework.PGame_LandingPanelJSONHandler.RequestNewJson // (Final|Native|Private) // @ game+0x7ba470
};

// Class PlatformGameFramework.PGame_PerformanceCaptureSettings
// Size: 0x70 (Inherited: 0x28)
struct UPGame_PerformanceCaptureSettings : UObject {
	float FOV; // 0x28(0x04)
	char UnknownData_2C[0x4]; // 0x2c(0x04)
	struct TArray<struct FString> StatsToCollect; // 0x30(0x10)
	struct TArray<struct FString> MapsToProfile; // 0x40(0x10)
	float StartingOffsetTime; // 0x50(0x04)
	int32_t NumberOfSamples; // 0x54(0x04)
	float TimeBetweenSamples; // 0x58(0x04)
	char UnknownData_5C[0x4]; // 0x5c(0x04)
	struct TArray<struct FPGame_PerformanceCaptureProfile> Profiles; // 0x60(0x10)
};

// Class PlatformGameFramework.PGame_PlayerController
// Size: 0x6b0 (Inherited: 0x588)
struct APGame_PlayerController : APlayerController {
	char UnknownData_588[0xd0]; // 0x588(0xd0)
	struct FString SonyMatchId; // 0x658(0x10)
	struct FString SonyActivityId; // 0x668(0x10)
	enum class ESonyMatchState SonyMatchState; // 0x678(0x01)
	enum class ESonyMatchState QueuedSonyMatchState; // 0x679(0x01)
	bool bIsSonyMatchOwner; // 0x67a(0x01)
	bool bIsEligibleSonyMatchOwner; // 0x67b(0x01)
	bool bIsExclusiveSonyMatchOwner; // 0x67c(0x01)
	char UnknownData_67D[0x13]; // 0x67d(0x13)
	struct UPGame_CheatComponent* m_CheatComponentClass; // 0x690(0x08)
	struct UPGame_CheatComponent* r_CheatComponent; // 0x698(0x08)
	struct FSerializedMctsNetId r_ReplicatedNetId; // 0x6a0(0x08)
	struct UInputComponent* InputComponentClass; // 0x6a8(0x08)

	void ServerUpdateSonyMatchOwnerEligibility(bool bIsEligible); // Function PlatformGameFramework.PGame_PlayerController.ServerUpdateSonyMatchOwnerEligibility // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x7ba6e0
	void ServerUpdateSonyMatchData(struct FString InMatchId); // Function PlatformGameFramework.PGame_PlayerController.ServerUpdateSonyMatchData // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x7ba640
	void ClientUpdateSonyMatchData(struct FString InMatchId, struct FString InActivityId); // Function PlatformGameFramework.PGame_PlayerController.ClientUpdateSonyMatchData // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x7b90a0
	void ClientGameFubared(enum class EFubarReason Reason); // Function PlatformGameFramework.PGame_PlayerController.ClientGameFubared // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x7b9020
	void ClientCheckSonyMatchOwnerEligibility(); // Function PlatformGameFramework.PGame_PlayerController.ClientCheckSonyMatchOwnerEligibility // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x7b9000
};

// Class PlatformGameFramework.PGame_PlayerInputDefault
// Size: 0x30 (Inherited: 0x28)
struct UPGame_PlayerInputDefault : UObject {
	bool bRestrictInvalidInputType; // 0x28(0x01)
	char UnknownData_29[0x7]; // 0x29(0x07)
};

// Class PlatformGameFramework.PGame_PlayerInput
// Size: 0x1330 (Inherited: 0x12f0)
struct UPGame_PlayerInput : UPlayerInput {
	char UnknownData_12F0[0x20]; // 0x12f0(0x20)
	float KeyMouseSwitchDelta; // 0x1310(0x04)
	char UnknownData_1314[0x4]; // 0x1314(0x04)
	float GamepadSwitchDelta; // 0x1318(0x04)
	char UnknownData_131C[0x14]; // 0x131c(0x14)
};

// Class PlatformGameFramework.PGame_HierarchicalInputComponent
// Size: 0x198 (Inherited: 0x138)
struct UPGame_HierarchicalInputComponent : UInputComponent {
	char UnknownData_138[0x60]; // 0x138(0x60)
};

// Class PlatformGameFramework.PGame_PositionHistoryComponent
// Size: 0xe8 (Inherited: 0xb0)
struct UPGame_PositionHistoryComponent : UActorComponent {
	enum class EPositionHistoryRecordMode PositionRecordMode; // 0xb0(0x01)
	bool ExtrapolateFromLastEntry; // 0xb1(0x01)
	bool bAutoPopulateOnBeginPlay; // 0xb2(0x01)
	char UnknownData_B3[0x15]; // 0xb3(0x15)
	struct TArray<struct FPrimitivePriority> TrackedPrimitives; // 0xc8(0x10)
	char UnknownData_D8[0x10]; // 0xd8(0x10)

	void RemoveTrackedPrimitive(struct UPrimitiveComponent* InPrimitive); // Function PlatformGameFramework.PGame_PositionHistoryComponent.RemoveTrackedPrimitive // (Final|Native|Public|BlueprintCallable) // @ game+0x7ba3f0
	void AddTrackedPrimitive(struct UPrimitiveComponent* InPrimitive, int32_t Priority); // Function PlatformGameFramework.PGame_PositionHistoryComponent.AddTrackedPrimitive // (Final|Native|Public|BlueprintCallable) // @ game+0x7b8da0
};

// Class PlatformGameFramework.PGame_ShippingConsole
// Size: 0x138 (Inherited: 0x138)
struct UPGame_ShippingConsole : UShippingConsole {
};

// Class PlatformGameFramework.PGame_WorldSettings
// Size: 0x3d0 (Inherited: 0x3a0)
struct APGame_WorldSettings : AWorldSettings {
	struct TArray<struct AActor*> ActorsToAlwaysSpawn; // 0x3a0(0x10)
	struct TArray<struct FString> HighMemorySublevelSuffixes; // 0x3b0(0x10)
	struct TArray<struct FString> LowMemorySublevelSuffixes; // 0x3c0(0x10)
};

// Class PlatformGameFramework.PGameBTComposite_ParallelSequence
// Size: 0x90 (Inherited: 0x90)
struct UPGameBTComposite_ParallelSequence : UBTCompositeNode {
};

// Class PlatformGameFramework.PGameBTComposite_Random
// Size: 0xa0 (Inherited: 0x90)
struct UPGameBTComposite_Random : UBTCompositeNode {
	struct TArray<float> Probabilities; // 0x90(0x10)
};

// Class PlatformGameFramework.PGameBTComposite_Random_Selector
// Size: 0xa0 (Inherited: 0xa0)
struct UPGameBTComposite_Random_Selector : UPGameBTComposite_Random {
};

// Class PlatformGameFramework.PGameBTComposite_Random_Sequence
// Size: 0xa0 (Inherited: 0xa0)
struct UPGameBTComposite_Random_Sequence : UPGameBTComposite_Random {
};

// Class PlatformGameFramework.PGameBTTask_AlwaysReturn
// Size: 0x78 (Inherited: 0x70)
struct UPGameBTTask_AlwaysReturn : UBTTaskNode {
	enum class EBTNodeResult AlwaysReturn; // 0x70(0x01)
	char UnknownData_71[0x7]; // 0x71(0x07)
};

// Class PlatformGameFramework.PGameBTTask_ClearBlackboardKey
// Size: 0x98 (Inherited: 0x98)
struct UPGameBTTask_ClearBlackboardKey : UBTTask_BlackboardBase {
};

