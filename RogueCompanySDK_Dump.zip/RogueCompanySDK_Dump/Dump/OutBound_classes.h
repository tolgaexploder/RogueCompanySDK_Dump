// WidgetBlueprintGeneratedClass OutBound.OutBound_C
// Size: 0x538 (Inherited: 0x510)
struct UOutBound_C : UKSViewedPawnWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x510(0x08)
	struct UTextBlock* Timer; // 0x518(0x08)
	struct UTextBlock* WarningMsg; // 0x520(0x08)
	struct UTextBlock* WarningTitle; // 0x528(0x08)
	struct AKSCharacter* KSCharacter; // 0x530(0x08)

	void Construct(); // Function OutBound.OutBound_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void HandleOutBoundsStart(); // Function OutBound.OutBound_C.HandleOutBoundsStart // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleOutBoundsWarningEnd(struct AKSCharacter* Character); // Function OutBound.OutBound_C.HandleOutBoundsWarningEnd // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleOutBoundsEnd(); // Function OutBound.OutBound_C.HandleOutBoundsEnd // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function OutBound.OutBound_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void OpenGate(); // Function OutBound.OutBound_C.OpenGate // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void CloseGate(); // Function OutBound.OutBound_C.CloseGate // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PostSetPawn(); // Function OutBound.OutBound_C.PostSetPawn // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void PreClearPawn(); // Function OutBound.OutBound_C.PreClearPawn // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_OutBound(int32_t EntryPoint); // Function OutBound.OutBound_C.ExecuteUbergraph_OutBound // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

