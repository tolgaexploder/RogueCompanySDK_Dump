// BlueprintGeneratedClass MinimapRenderer.MinimapRenderer_C
// Size: 0x280 (Inherited: 0x220)
struct AMinimapRenderer_C : AKSMinimapRendererBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct UCameraComponent* TestCam; // 0x228(0x08)
	struct USceneCaptureComponent2D* SceneCaptureComponent2D; // 0x230(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x238(0x08)
	struct UTexture2D* WorkingTexture; // 0x240(0x08)
	float MapWidth; // 0x248(0x04)
	char UnknownData_24C[0x4]; // 0x24c(0x04)
	struct TSoftObjectPtr<struct UTexture2D> TextureAssetPtr; // 0x250(0x28)
	float HeightDifferenceThreshold; // 0x278(0x04)
	int32_t TextureSize; // 0x27c(0x04)

	float GetMinimapWidth(); // Function MinimapRenderer.MinimapRenderer_C.GetMinimapWidth // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x2587100
	void UserConstructionScript(); // Function MinimapRenderer.MinimapRenderer_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnLoaded_1F80951A45CA8E54458A18AA362E670C(struct UObject* Loaded); // Function MinimapRenderer.MinimapRenderer_C.OnLoaded_1F80951A45CA8E54458A18AA362E670C // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void 3_CaptureMinimap(); // Function MinimapRenderer.MinimapRenderer_C.3_CaptureMinimap // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void 1_LoadMinimapTexture(); // Function MinimapRenderer.MinimapRenderer_C.1_LoadMinimapTexture // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void 5_ResetVRAM(); // Function MinimapRenderer.MinimapRenderer_C.5_ResetVRAM // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void 4_SaveToTexture(); // Function MinimapRenderer.MinimapRenderer_C.4_SaveToTexture // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void 2_PrepareRenderTarget(); // Function MinimapRenderer.MinimapRenderer_C.2_PrepareRenderTarget // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_MinimapRenderer(int32_t EntryPoint); // Function MinimapRenderer.MinimapRenderer_C.ExecuteUbergraph_MinimapRenderer // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

