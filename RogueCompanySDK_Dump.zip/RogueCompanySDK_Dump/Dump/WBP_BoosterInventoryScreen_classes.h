// WidgetBlueprintGeneratedClass WBP_BoosterInventoryScreen.WBP_BoosterInventoryScreen_C
// Size: 0x5a0 (Inherited: 0x4e0)
struct UWBP_BoosterInventoryScreen_C : UKSBoostInventoryWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UWidgetAnimation* OpenPanel; // 0x4e8(0x08)
	struct UVerticalBox* ActiveBoostsContainer; // 0x4f0(0x08)
	struct UWidgetSwitcher* ActiveBoostsSwitcher; // 0x4f8(0x08)
	struct UWBP_Header3_C* ActiveBoostsTitle; // 0x500(0x08)
	struct UButton* Blocker; // 0x508(0x08)
	struct UWrapBox* BoostInventoryContainer; // 0x510(0x08)
	struct UWidgetSwitcher* BoostInventorySwitcher; // 0x518(0x08)
	struct UWBP_Header3_C* BoostInventoryTitle; // 0x520(0x08)
	struct UImage* Image_114; // 0x528(0x08)
	struct UImage* Image_157; // 0x530(0x08)
	struct UOverlay* NoBoostsInfoGroup; // 0x538(0x08)
	struct UWBP_ActiveBoosterEntry_C* WBP_ActiveBoosterEntry; // 0x540(0x08)
	struct UWBP_ActiveBoosterEntry_C* WBP_ActiveBoosterEntry_2; // 0x548(0x08)
	struct UWBP_BoosterInventoryItem_C* WBP_BoosterInventoryItem; // 0x550(0x08)
	struct UWBP_BoosterInventoryItem_C* WBP_BoosterInventoryItem_2; // 0x558(0x08)
	struct UWBP_BoosterInventoryItem_C* WBP_BoosterInventoryItem_3; // 0x560(0x08)
	struct UWBP_BoosterInventoryItem_C* WBP_BoosterInventoryItem_4; // 0x568(0x08)
	struct UWBP_BoosterInventoryItem_C* WBP_BoosterInventoryItem_5; // 0x570(0x08)
	struct UWBP_BoosterInventoryItem_C* WBP_BoosterInventoryItem_6; // 0x578(0x08)
	struct UWBP_BoosterInventoryItem_C* WBP_BoosterInventoryItem_7; // 0x580(0x08)
	struct UWBP_BoosterInventoryItem_C* WBP_BoosterInventoryItem_8; // 0x588(0x08)
	struct UWBP_Header1_C* WBP_Header1; // 0x590(0x08)
	struct UWBP_SidePanel_Left_C* WBP_SidePanel_Left; // 0x598(0x08)

	struct FEventReply OnKeyUp(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function WBP_BoosterInventoryScreen.WBP_BoosterInventoryScreen_C.OnKeyUp // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PopulateActiveBoosts(); // Function WBP_BoosterInventoryScreen.WBP_BoosterInventoryScreen_C.PopulateActiveBoosts // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PopulateInactiveBoostInventory(); // Function WBP_BoosterInventoryScreen.WBP_BoosterInventoryScreen_C.PopulateInactiveBoostInventory // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	bool NavigateBack(); // Function WBP_BoosterInventoryScreen.WBP_BoosterInventoryScreen_C.NavigateBack // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BndEvt__Blocker_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_BoosterInventoryScreen.WBP_BoosterInventoryScreen_C.BndEvt__Blocker_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void StartHideSequence(struct FName FromRoute, struct FName ToRoute); // Function WBP_BoosterInventoryScreen.WBP_BoosterInventoryScreen_C.StartHideSequence // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void StartShowSequence(struct FName FromRoute, struct FName ToRoute); // Function WBP_BoosterInventoryScreen.WBP_BoosterInventoryScreen_C.StartShowSequence // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnShown(); // Function WBP_BoosterInventoryScreen.WBP_BoosterInventoryScreen_C.OnShown // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeWidgetNavigation(); // Function WBP_BoosterInventoryScreen.WBP_BoosterInventoryScreen_C.InitializeWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnViewStateChange(struct FName CurrentRoute, struct FName PreviousRoute, enum class EViewManagerLayer Layer); // Function WBP_BoosterInventoryScreen.WBP_BoosterInventoryScreen_C.OnViewStateChange // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function WBP_BoosterInventoryScreen.WBP_BoosterInventoryScreen_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnAcquisition(struct UKSAcquisition* Acquisition); // Function WBP_BoosterInventoryScreen.WBP_BoosterInventoryScreen_C.OnAcquisition // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_BoosterInventoryScreen(int32_t EntryPoint); // Function WBP_BoosterInventoryScreen.WBP_BoosterInventoryScreen_C.ExecuteUbergraph_WBP_BoosterInventoryScreen // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

