// AnimBlueprintGeneratedClass MasterLobby_ABP.MasterLobby_ABP_C
// Size: 0x2459 (Inherited: 0x1090)
struct UMasterLobby_ABP_C : UKSCharacterAnimInst {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1090(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x1098(0x38)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x10d0(0x80)
	struct FAnimNode_SequenceSkinned AnimGraphNode_SequenceSkinned; // 0x1150(0x158)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0x12a8(0x38)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0x12e0(0xb8)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_3; // 0x1398(0x28)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_3; // 0x13c0(0x28)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend; // 0x13e8(0xc8)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x14b0(0x80)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_2; // 0x1530(0xf8)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone; // 0x1628(0xf8)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_3; // 0x1720(0xc0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_5; // 0x17e0(0x30)
	bool __CustomProperty_bIsLobby_90FBADB5424A5A00D7B0F4B018D67A66; // 0x1810(0x01)
	bool __CustomProperty_bIsServer_90FBADB5424A5A00D7B0F4B018D67A66; // 0x1811(0x01)
	char UnknownData_1812[0x6]; // 0x1812(0x06)
	struct FAnimNode_LinkedAnimGraph AnimGraphNode_SubInstance; // 0x1818(0xa8)
	struct FAnimNode_Slot AnimGraphNode_Slot_2; // 0x18c0(0x50)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2; // 0x1910(0xa8)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_2; // 0x19b8(0x28)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_2; // 0x19e0(0x28)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone; // 0x1a08(0x110)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_2; // 0x1b18(0xc0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_4; // 0x1bd8(0x30)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_3; // 0x1c08(0x30)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool; // 0x1c38(0xa8)
	struct FAnimNode_RigidBodySkipServer AnimGraphNode_RigidBodySkipServer; // 0x1ce0(0x5a0)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0x2280(0x28)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // 0x22a8(0x28)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose; // 0x22d0(0xc0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2; // 0x2390(0x30)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose; // 0x23c0(0x30)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x23f0(0x50)
	float R_Prop_Lock_Alpha; // 0x2440(0x04)
	float L_Prop_Lock_Alpha; // 0x2444(0x04)
	bool bIsServer; // 0x2448(0x01)
	bool SkinUseCharacterScale; // 0x2449(0x01)
	char UnknownData_244A[0x2]; // 0x244a(0x02)
	struct FVector CharacterScale; // 0x244c(0x0c)
	bool ChildPhysicsAssetEnable; // 0x2458(0x01)

	void AnimGraph(struct FPoseLink AnimGraph); // Function MasterLobby_ABP.MasterLobby_ABP_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void AnimNotify_Lobby_Unlock_LProp(); // Function MasterLobby_ABP.MasterLobby_ABP_C.AnimNotify_Lobby_Unlock_LProp // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void AnimNotify_Lobby_Unlock_RProp(); // Function MasterLobby_ABP.MasterLobby_ABP_C.AnimNotify_Lobby_Unlock_RProp // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void AnimNotify_Lobby_Lock_LProp(); // Function MasterLobby_ABP.MasterLobby_ABP_C.AnimNotify_Lobby_Lock_LProp // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void AnimNotify_Lobby_Lock_RProp(); // Function MasterLobby_ABP.MasterLobby_ABP_C.AnimNotify_Lobby_Lock_RProp // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BlueprintInitializeAnimation(); // Function MasterLobby_ABP.MasterLobby_ABP_C.BlueprintInitializeAnimation // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void Set Skinned Local Parameters(struct TSet<struct FName> Keywords); // Function MasterLobby_ABP.MasterLobby_ABP_C.Set Skinned Local Parameters // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateTurnInPlace(float DeltaSeconds); // Function MasterLobby_ABP.MasterLobby_ABP_C.UpdateTurnInPlace // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_MasterLobby_ABP(int32_t EntryPoint); // Function MasterLobby_ABP.MasterLobby_ABP_C.ExecuteUbergraph_MasterLobby_ABP // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

