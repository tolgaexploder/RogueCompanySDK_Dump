// Class SkinnableAnimNotifies.AnimNotifyState_SkinnedPropBase
// Size: 0x88 (Inherited: 0x30)
struct UAnimNotifyState_SkinnedPropBase : UAnimNotifyState {
	struct FName SkinObjectName; // 0x30(0x08)
	struct FName MeshSkinKeyword; // 0x38(0x08)
	struct FName ComponentClassSkinKeyword; // 0x40(0x08)
	struct FName PropIdentifier; // 0x48(0x08)
	float ExtendedLifetime; // 0x50(0x04)
	struct FPoolAttachmentInfo PropAttachmentInfo; // 0x54(0x30)
	char UnknownData_84[0x4]; // 0x84(0x04)
};

// Class SkinnableAnimNotifies.AnimNotifyState_SkinnedSkelProp
// Size: 0x98 (Inherited: 0x88)
struct UAnimNotifyState_SkinnedSkelProp : UAnimNotifyState_SkinnedPropBase {
	struct FName AnimClassSkinKeyword; // 0x88(0x08)
	struct UAnimMontage* ActivationMontage; // 0x90(0x08)
};

// Class SkinnableAnimNotifies.AnimNotifyState_SkinStaticProp
// Size: 0x88 (Inherited: 0x88)
struct UAnimNotifyState_SkinStaticProp : UAnimNotifyState_SkinnedPropBase {
};

// Class SkinnableAnimNotifies.SkelPropManagerComponent
// Size: 0x1d0 (Inherited: 0xb0)
struct USkelPropManagerComponent : UActorComponent {
	char UnknownData_B0[0xb8]; // 0xb0(0xb8)
	struct TArray<struct FActiveSkelProp> ActiveNamelessProps; // 0x168(0x10)
	struct TMap<struct FPropIdentifier, struct FActiveSkelProp> ActiveProps; // 0x178(0x50)
	bool bAllowSpawnerPooling; // 0x1c8(0x01)
	char UnknownData_1C9[0x3]; // 0x1c9(0x03)
	float SpawnerPoolingLifespan; // 0x1cc(0x04)
};

// Class SkinnableAnimNotifies.StaticPropManagerComponent
// Size: 0x1d0 (Inherited: 0xb0)
struct UStaticPropManagerComponent : UActorComponent {
	char UnknownData_B0[0xb8]; // 0xb0(0xb8)
	struct TArray<struct FActiveStaticProp> ActiveNamelessProps; // 0x168(0x10)
	struct TMap<struct FPropIdentifier, struct FActiveStaticProp> ActiveProps; // 0x178(0x50)
	bool bAllowSpawnerPooling; // 0x1c8(0x01)
	char UnknownData_1C9[0x3]; // 0x1c9(0x03)
	float SpawnerPoolingLifespan; // 0x1cc(0x04)
};

