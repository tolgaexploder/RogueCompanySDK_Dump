// WidgetBlueprintGeneratedClass GameTimerBarScorePip.GameTimerBarScorePip_C
// Size: 0x508 (Inherited: 0x4e0)
struct UGameTimerBarScorePip_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UImage* Bg; // 0x4e8(0x08)
	struct UImage* Fill; // 0x4f0(0x08)
	struct FLinearColor PipColor; // 0x4f8(0x10)

	void Set Pip(bool On); // Function GameTimerBarScorePip.GameTimerBarScorePip_C.Set Pip // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function GameTimerBarScorePip.GameTimerBarScorePip_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_GameTimerBarScorePip(int32_t EntryPoint); // Function GameTimerBarScorePip.GameTimerBarScorePip_C.ExecuteUbergraph_GameTimerBarScorePip // (Final|UbergraphFunction) // @ game+0x2587100
};

