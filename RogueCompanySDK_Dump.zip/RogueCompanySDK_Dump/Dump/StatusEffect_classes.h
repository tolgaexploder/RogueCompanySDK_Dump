// WidgetBlueprintGeneratedClass StatusEffect.StatusEffect_C
// Size: 0x528 (Inherited: 0x510)
struct UStatusEffect_C : UKSViewedPawnWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x510(0x08)
	struct UTextBlock* StatusText; // 0x518(0x08)
	struct FTimerHandle HideTimerHandle; // 0x520(0x08)

	void StopHideTimer(); // Function StatusEffect.StatusEffect_C.StopHideTimer // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void StartHideTimer(float Time); // Function StatusEffect.StatusEffect_C.StartHideTimer // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PreClearPawn(); // Function StatusEffect.StatusEffect_C.PreClearPawn // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void PostSetPawn(); // Function StatusEffect.StatusEffect_C.PostSetPawn // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void RevealStatus(bool Revealed, bool Permanent); // Function StatusEffect.StatusEffect_C.RevealStatus // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnStuck(); // Function StatusEffect.StatusEffect_C.OnStuck // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HideTimeExpired(); // Function StatusEffect.StatusEffect_C.HideTimeExpired // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateRevealStatus(bool IsRevealed); // Function StatusEffect.StatusEffect_C.UpdateRevealStatus // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleRootChanged(bool Rooted); // Function StatusEffect.StatusEffect_C.HandleRootChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_StatusEffect(int32_t EntryPoint); // Function StatusEffect.StatusEffect_C.ExecuteUbergraph_StatusEffect // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

