// WidgetBlueprintGeneratedClass NewStartMenu.NewStartMenu_C
// Size: 0x540 (Inherited: 0x4e0)
struct UNewStartMenu_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UVerticalBox* ButtonBox; // 0x4e8(0x08)
	struct UWBP_StandardButton_02_C* ButtonNews; // 0x4f0(0x08)
	struct UWBP_StandardButton_02_C* ButtonQuit; // 0x4f8(0x08)
	struct UWBP_StandardButton_02_C* ButtonSettings; // 0x500(0x08)
	struct UImage* logo; // 0x508(0x08)
	struct UOverlay* MenuContainer; // 0x510(0x08)
	struct UTextBlock* VersionDisplay; // 0x518(0x08)
	struct UWBP_panel_bevel_C* WBP_panel_bevel; // 0x520(0x08)
	struct UWBP_panel_bevel_C* WBP_panel_bevel_C_1; // 0x528(0x08)
	struct FName CachedLastRoute; // 0x530(0x08)
	struct UAkAudioEvent* BackClickNewStartMenuSFX; // 0x538(0x08)

	void set version text(); // Function NewStartMenu.NewStartMenu_C.set version text // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	bool NavigateBack(); // Function NewStartMenu.NewStartMenu_C.NavigateBack // (Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ShowMenuAnim(float ElapsedTime, float ElapsedAlpha); // Function NewStartMenu.NewStartMenu_C.ShowMenuAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ShowMenuFinished(); // Function NewStartMenu.NewStartMenu_C.ShowMenuFinished // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitHideAnimation(); // Function NewStartMenu.NewStartMenu_C.InitHideAnimation // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HideMenuFinished(); // Function NewStartMenu.NewStartMenu_C.HideMenuFinished // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HideMenuAnim(float ElapsedTime, float ElapsedAlpha); // Function NewStartMenu.NewStartMenu_C.HideMenuAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void StartHideAnim(); // Function NewStartMenu.NewStartMenu_C.StartHideAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function NewStartMenu.NewStartMenu_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidgetNavigation(); // Function NewStartMenu.NewStartMenu_C.InitializeWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void BackToLastScreen(); // Function NewStartMenu.NewStartMenu_C.BackToLastScreen // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void StartShowSequence(struct FName FromRoute, struct FName ToRoute); // Function NewStartMenu.NewStartMenu_C.StartShowSequence // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void StartHideSequence(struct FName FromRoute, struct FName ToRoute); // Function NewStartMenu.NewStartMenu_C.StartHideSequence // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeTickAnimations(); // Function NewStartMenu.NewStartMenu_C.InitializeTickAnimations // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void StartShowAnim(); // Function NewStartMenu.NewStartMenu_C.StartShowAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function NewStartMenu.NewStartMenu_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void BndEvt__ButtonNews_K2Node_ComponentBoundEvent_1_OnClicked__DelegateSignature(struct UWidget* Widget); // Function NewStartMenu.NewStartMenu_C.BndEvt__ButtonNews_K2Node_ComponentBoundEvent_1_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__ButtonQuit_K2Node_ComponentBoundEvent_5_OnClicked__DelegateSignature(struct UWidget* Widget); // Function NewStartMenu.NewStartMenu_C.BndEvt__ButtonQuit_K2Node_ComponentBoundEvent_5_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__ButtonSettings_K2Node_ComponentBoundEvent_7_OnClicked__DelegateSignature(struct UWidget* Widget); // Function NewStartMenu.NewStartMenu_C.BndEvt__ButtonSettings_K2Node_ComponentBoundEvent_7_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void OnBackButton(); // Function NewStartMenu.NewStartMenu_C.OnBackButton // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_NewStartMenu(int32_t EntryPoint); // Function NewStartMenu.NewStartMenu_C.ExecuteUbergraph_NewStartMenu // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

