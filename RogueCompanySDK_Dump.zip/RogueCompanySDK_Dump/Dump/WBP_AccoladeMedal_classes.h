// WidgetBlueprintGeneratedClass WBP_AccoladeMedal.WBP_AccoladeMedal_C
// Size: 0x628 (Inherited: 0x4e0)
struct UWBP_AccoladeMedal_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UWidgetAnimation* PlaySheen; // 0x4e8(0x08)
	struct UWidgetAnimation* TransitionOut; // 0x4f0(0x08)
	struct UWidgetAnimation* FadeOut; // 0x4f8(0x08)
	struct UWidgetAnimation* ShowMultipler; // 0x500(0x08)
	struct UWidgetAnimation* ShowAccolade; // 0x508(0x08)
	struct UImage* AccoladeBadge; // 0x510(0x08)
	struct UImage* AccoladeIcon; // 0x518(0x08)
	struct UScaleBox* AccoladeIconWrapper; // 0x520(0x08)
	struct UOverlay* AccoladeImage; // 0x528(0x08)
	struct UTextBlock* AccoladeName; // 0x530(0x08)
	struct UBorder* Border_1; // 0x538(0x08)
	struct UTextBlock* Multipler; // 0x540(0x08)
	struct USizeBox* SizeBox_1; // 0x548(0x08)
	struct USizeBox* SizeBox_2; // 0x550(0x08)
	struct USizeBox* SizeBox_3; // 0x558(0x08)
	struct UMaterialInstanceDynamic* ShineMat; // 0x560(0x08)
	float PositionY; // 0x568(0x04)
	float PositionX; // 0x56c(0x04)
	float NewPositionX; // 0x570(0x04)
	float IconOpacity; // 0x574(0x04)
	float Scale; // 0x578(0x04)
	char UnknownData_57C[0x4]; // 0x57c(0x04)
	struct FMulticastInlineDelegate OnRemoveAccolade; // 0x580(0x10)
	bool bTransitionOut; // 0x590(0x01)
	char UnknownData_591[0x7]; // 0x591(0x07)
	struct FMulticastInlineDelegate OnShowAnimStarted; // 0x598(0x10)
	struct FMulticastInlineDelegate OnShowAnimFinished; // 0x5a8(0x10)
	struct FAccoladeDisplayInfo AccoladeInfo_New; // 0x5b8(0x60)
	float PresentationSpeed; // 0x618(0x04)
	float FadeOutDelayTimer; // 0x61c(0x04)
	float ShowNextDelayTimer; // 0x620(0x04)
	float Stacked Accolade Delay; // 0x624(0x04)

	void SequenceEvent__ENTRYPOINTWBP_AccoladeMedal_4(); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.SequenceEvent__ENTRYPOINTWBP_AccoladeMedal_4 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SequenceEvent__ENTRYPOINTWBP_AccoladeMedal_3(); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.SequenceEvent__ENTRYPOINTWBP_AccoladeMedal_3 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SequenceEvent__ENTRYPOINTWBP_AccoladeMedal_2(); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.SequenceEvent__ENTRYPOINTWBP_AccoladeMedal_2 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SequenceEvent__ENTRYPOINTWBP_AccoladeMedal_1(); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.SequenceEvent__ENTRYPOINTWBP_AccoladeMedal_1 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ResetAnimations(); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.ResetAnimations // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void TickShowNextDelay(float DeltaTime); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.TickShowNextDelay // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ShowNextAccolade(); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.ShowNextAccolade // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void TickFadeOutDelay(float DeltaTime); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.TickFadeOutDelay // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetPresentationSpeed(float NewPresentationSpeed); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.SetPresentationSpeed // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PlayThudSFX(); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.PlayThudSFX // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void StartSheenAnim(); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.StartSheenAnim // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnShowFinish(); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.OnShowFinish // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnSheenStart(); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.OnSheenStart // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnShowStart(); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.OnShowStart // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PreConstruct(bool IsDesignTime); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void PlayShowAnim(); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.PlayShowAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PlayMoveAccoladeAnim(int32_t Index, int32_t TotalAccolade); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.PlayMoveAccoladeAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void StartMoveAnim(float NewPositionX); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.StartMoveAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void CloseMoveAnim(); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.CloseMoveAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleRemoveSelf(); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.HandleRemoveSelf // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PlayFadeOutAnim(); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.PlayFadeOutAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PlayTransitionOutAnim(); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.PlayTransitionOutAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleAnimationStarted(); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.HandleAnimationStarted // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_AccoladeMedal(int32_t EntryPoint); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.ExecuteUbergraph_WBP_AccoladeMedal // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void OnShowAnimFinished__DelegateSignature(); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.OnShowAnimFinished__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnShowAnimStarted__DelegateSignature(); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.OnShowAnimStarted__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnRemoveAccolade__DelegateSignature(struct UWidget* Widget); // Function WBP_AccoladeMedal.WBP_AccoladeMedal_C.OnRemoveAccolade__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

