// WidgetBlueprintGeneratedClass ActivePerkSlot.ActivePerkSlot_C
// Size: 0x260 (Inherited: 0x238)
struct UActivePerkSlot_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UWidgetAnimation* TriggeredPing; // 0x240(0x08)
	struct UImage* background; // 0x248(0x08)
	struct UWBP_AsyncIcon_C* PerkIcon; // 0x250(0x08)
	struct UKSPlayerModInstance* ModInstance; // 0x258(0x08)

	void Construct(); // Function ActivePerkSlot.ActivePerkSlot_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void HandleOnModTriggered(); // Function ActivePerkSlot.ActivePerkSlot_C.HandleOnModTriggered // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_ActivePerkSlot(int32_t EntryPoint); // Function ActivePerkSlot.ActivePerkSlot_C.ExecuteUbergraph_ActivePerkSlot // (Final|UbergraphFunction) // @ game+0x2587100
};

