// WidgetBlueprintGeneratedClass WBP_BattlePassTitle.WBP_BattlePassTitle_C
// Size: 0x549 (Inherited: 0x4e0)
struct UWBP_BattlePassTitle_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UImage* BackGradient; // 0x4e8(0x08)
	struct UTextBlock* BattlePassSeasonName; // 0x4f0(0x08)
	struct UTextBlock* CurrentXpText; // 0x4f8(0x08)
	struct UImage* Fill; // 0x500(0x08)
	struct UImage* FillStandard; // 0x508(0x08)
	struct UImage* Glow; // 0x510(0x08)
	struct UImage* Glow_2; // 0x518(0x08)
	struct UTextBlock* NeededXpText; // 0x520(0x08)
	struct UWidgetSwitcher* TypeSwitcher; // 0x528(0x08)
	struct UWBP_BattlePassEmblem_C* WBP_BattlePassEmblem; // 0x530(0x08)
	struct UWBP_ProgressEarnedBar_C* WBP_ProgressEarnedBar; // 0x538(0x08)
	struct UTextBlock* XPGainLabel; // 0x540(0x08)
	bool HasPremium; // 0x548(0x01)

	void InitializeWithActivityInstance(struct UKSActivityInstance* ActivityInstance); // Function WBP_BattlePassTitle.WBP_BattlePassTitle_C.InitializeWithActivityInstance // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function WBP_BattlePassTitle.WBP_BattlePassTitle_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_BattlePassTitle(int32_t EntryPoint); // Function WBP_BattlePassTitle.WBP_BattlePassTitle_C.ExecuteUbergraph_WBP_BattlePassTitle // (Final|UbergraphFunction) // @ game+0x2587100
};

