// WidgetBlueprintGeneratedClass WBP_BattlePassOfferPanel.WBP_BattlePassOfferPanel_C
// Size: 0x548 (Inherited: 0x4e0)
struct UWBP_BattlePassOfferPanel_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UImage* BtnBkg; // 0x4e8(0x08)
	struct UTextBlock* DLCDesc; // 0x4f0(0x08)
	struct UTextBlock* DLCName; // 0x4f8(0x08)
	struct UVerticalBox* DLCNameWrapper; // 0x500(0x08)
	struct UImage* GradientBG; // 0x508(0x08)
	struct UWBP_AsyncIcon_C* ItemImage; // 0x510(0x08)
	struct UWBP_StorePriceDisplay_C* PriceDisplay; // 0x518(0x08)
	struct UImage* RarityDecro_2; // 0x520(0x08)
	struct UWBP_StorePanelButton_C* WBP_StorePanelButton; // 0x528(0x08)
	struct UPUMG_StoreItem* BattlePassBundle; // 0x530(0x08)
	struct FMulticastInlineDelegate OnOfferPanelClicked; // 0x538(0x10)

	bool NavigateConfirm(); // Function WBP_BattlePassOfferPanel.WBP_BattlePassOfferPanel_C.NavigateConfirm // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Display Battle Pass Bundle(struct UPUMG_StoreItem* Bundle); // Function WBP_BattlePassOfferPanel.WBP_BattlePassOfferPanel_C.Display Battle Pass Bundle // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BndEvt__WBP_StorePanelButton_K2Node_ComponentBoundEvent_0_OnBtnClicked__DelegateSignature(); // Function WBP_BattlePassOfferPanel.WBP_BattlePassOfferPanel_C.BndEvt__WBP_StorePanelButton_K2Node_ComponentBoundEvent_0_OnBtnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void OnGamepadConfirm(); // Function WBP_BattlePassOfferPanel.WBP_BattlePassOfferPanel_C.OnGamepadConfirm // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GamepadHover(); // Function WBP_BattlePassOfferPanel.WBP_BattlePassOfferPanel_C.GamepadHover // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void GamepadUnhover(); // Function WBP_BattlePassOfferPanel.WBP_BattlePassOfferPanel_C.GamepadUnhover // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_BattlePassOfferPanel(int32_t EntryPoint); // Function WBP_BattlePassOfferPanel.WBP_BattlePassOfferPanel_C.ExecuteUbergraph_WBP_BattlePassOfferPanel // (Final|UbergraphFunction) // @ game+0x2587100
	void OnOfferPanelClicked__DelegateSignature(struct UPUMG_StoreItem* BattlePassOffer); // Function WBP_BattlePassOfferPanel.WBP_BattlePassOfferPanel_C.OnOfferPanelClicked__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

