// WidgetBlueprintGeneratedClass AllyFullMapIcon.AllyFullMapIcon_C
// Size: 0x36c (Inherited: 0x318)
struct UAllyFullMapIcon_C : UKSMapIconWidgetBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x318(0x08)
	struct UImage* AboveIndicator; // 0x320(0x08)
	struct UBorder* AllyBorder; // 0x328(0x08)
	struct UImage* BelowIndicator; // 0x330(0x08)
	struct UImage* Image_2; // 0x338(0x08)
	struct UImage* ImageIcon; // 0x340(0x08)
	struct UScaleBox* ScaleBox_3; // 0x348(0x08)
	struct UBorder* SelfBorder; // 0x350(0x08)
	struct UWidgetSwitcher* WidgetSwitch; // 0x358(0x08)
	struct AKSPlayerState* Represented Player State; // 0x360(0x08)
	float Height Threshold; // 0x368(0x04)

	struct FVector GetWorldPosition(); // Function AllyFullMapIcon.AllyFullMapIcon_C.GetWorldPosition // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	float GetWorldYaw(); // Function AllyFullMapIcon.AllyFullMapIcon_C.GetWorldYaw // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	bool ShouldUpdate(); // Function AllyFullMapIcon.AllyFullMapIcon_C.ShouldUpdate // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function AllyFullMapIcon.AllyFullMapIcon_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Ally State(struct AKSPlayerState* PlayerState); // Function AllyFullMapIcon.AllyFullMapIcon_C.Ally State // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleMapIconWidgetReady(); // Function AllyFullMapIcon.AllyFullMapIcon_C.HandleMapIconWidgetReady // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_AllyFullMapIcon(int32_t EntryPoint); // Function AllyFullMapIcon.AllyFullMapIcon_C.ExecuteUbergraph_AllyFullMapIcon // (Final|UbergraphFunction) // @ game+0x2587100
};

