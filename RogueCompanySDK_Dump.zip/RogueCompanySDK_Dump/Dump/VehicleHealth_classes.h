// WidgetBlueprintGeneratedClass VehicleHealth.VehicleHealth_C
// Size: 0x524 (Inherited: 0x4e0)
struct UVehicleHealth_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UImage* Bar; // 0x4e8(0x08)
	struct UImage* BarBackground; // 0x4f0(0x08)
	struct UTextBlock* HealthValueText; // 0x4f8(0x08)
	struct UImage* Image_1; // 0x500(0x08)
	struct UImage* Image_2; // 0x508(0x08)
	struct UImage* Image_3; // 0x510(0x08)
	float TargetValue; // 0x518(0x04)
	float CurrentValue; // 0x51c(0x04)
	float LerpPerSecond; // 0x520(0x04)

	void Set Target Value(float TargetValue); // Function VehicleHealth.VehicleHealth_C.Set Target Value // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Set Value(float Percent); // Function VehicleHealth.VehicleHealth_C.Set Value // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function VehicleHealth.VehicleHealth_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_VehicleHealth(int32_t EntryPoint); // Function VehicleHealth.VehicleHealth_C.ExecuteUbergraph_VehicleHealth // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

