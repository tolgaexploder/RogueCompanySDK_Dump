// WidgetBlueprintGeneratedClass WBP_CountdownVersusMessage.WBP_CountdownVersusMessage_C
// Size: 0x568 (Inherited: 0x528)
struct UWBP_CountdownVersusMessage_C : UKSAnnouncementQueuedMessageWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x528(0x08)
	struct UWidgetAnimation* DisplayVS_only; // 0x530(0x08)
	struct UWidgetAnimation* Display; // 0x538(0x08)
	struct UTextBlock* EnemyCount; // 0x540(0x08)
	struct UTextBlock* FriendlyCount; // 0x548(0x08)
	struct UTextBlock* Message; // 0x550(0x08)
	int32_t CurrentTeamAdvantage; // 0x558(0x04)
	char UnknownData_55C[0x4]; // 0x55c(0x04)
	struct UWBP_TeamMessage_C* ParentWidget; // 0x560(0x08)

	void Construct(); // Function WBP_CountdownVersusMessage.WBP_CountdownVersusMessage_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnAnimFinished(); // Function WBP_CountdownVersusMessage.WBP_CountdownVersusMessage_C.OnAnimFinished // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PreConstruct(bool IsDesignTime); // Function WBP_CountdownVersusMessage.WBP_CountdownVersusMessage_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_CountdownVersusMessage(int32_t EntryPoint); // Function WBP_CountdownVersusMessage.WBP_CountdownVersusMessage_C.ExecuteUbergraph_WBP_CountdownVersusMessage // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

