// BlueprintGeneratedClass BloodEffectCurveComponent.BloodEffectCurveComponent_C
// Size: 0x140 (Inherited: 0x138)
struct UBloodEffectCurveComponent_C : UKSBloodSplatterComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x138(0x08)

	void UpdateScalarTrack(struct FName TrackName, float TrackValue); // Function BloodEffectCurveComponent.BloodEffectCurveComponent_C.UpdateScalarTrack // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_BloodEffectCurveComponent(int32_t EntryPoint); // Function BloodEffectCurveComponent.BloodEffectCurveComponent_C.ExecuteUbergraph_BloodEffectCurveComponent // (Final|UbergraphFunction) // @ game+0x2587100
};

