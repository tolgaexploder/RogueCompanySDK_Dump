// Class AsyncTraceUtil.AsyncTraceUtilBPLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAsyncTraceUtilBPLibrary : UBlueprintFunctionLibrary {

	void OnMultiAsyncTraceResult__DelegateSignature(bool bBlockingHit, struct TArray<struct FHitResult> OutHits, struct FVector start, struct FVector end); // DelegateFunction AsyncTraceUtil.AsyncTraceUtilBPLibrary.OnMultiAsyncTraceResult__DelegateSignature // (Public|Delegate|HasOutParms|HasDefaults) // @ game+0x2587100
	bool MultipleLineTraceAsync(struct UObject* WorldContextObject, struct TArray<struct FVector> Starts, struct TArray<struct FVector> Ends, enum class ECollisionChannel TraceChannel, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct TArray<struct FHitResult> OutHits, bool bIgnoreSelf, struct FLatentActionInfo LatentInfo, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function AsyncTraceUtil.AsyncTraceUtilBPLibrary.MultipleLineTraceAsync // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x1a34860
	void MultiLineTraceByChannelAsync(struct UObject* WorldContextObject, struct FVector start, struct FVector end, enum class ECollisionChannel TraceChannel, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct FDelegate OnTraceComplete, bool bIgnoreSelf, struct FLatentActionInfo LatentInfo, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function AsyncTraceUtil.AsyncTraceUtilBPLibrary.MultiLineTraceByChannelAsync // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x1a34430
};

