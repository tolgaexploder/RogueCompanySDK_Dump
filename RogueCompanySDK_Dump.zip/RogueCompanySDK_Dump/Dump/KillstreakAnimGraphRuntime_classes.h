// Class KillstreakAnimGraphRuntime.RecoilProfileAsset
// Size: 0x220 (Inherited: 0x30)
struct URecoilProfileAsset : UDataAsset {
	struct FRecoilProfile RecoilProfile; // 0x30(0x1ec)
	bool DontPlayRecoilMontage; // 0x21c(0x01)
	char UnknownData_21D[0x3]; // 0x21d(0x03)
};

