// WidgetBlueprintGeneratedClass LootSiteMarker_v2.LootSiteMarker_v2_C
// Size: 0x3f8 (Inherited: 0x338)
struct ULootSiteMarker_v2_C : UKSLootSiteMarkerWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x338(0x08)
	struct UImage* Arrow; // 0x340(0x08)
	struct UTextBlock* DebugText; // 0x348(0x08)
	struct UImage* IconBg; // 0x350(0x08)
	struct UScaleBox* IconScale; // 0x358(0x08)
	struct UImage* IconStar; // 0x360(0x08)
	struct UImage* Image_1; // 0x368(0x08)
	struct UImage* Pin; // 0x370(0x08)
	struct USizeBox* PinSize; // 0x378(0x08)
	bool IsInspectMode; // 0x380(0x01)
	char UnknownData_381[0x7]; // 0x381(0x07)
	struct UTexture2D* Common Loot Texture; // 0x388(0x08)
	struct UTexture2D* Epic Loot Texture; // 0x390(0x08)
	struct UTexture2D* Common Pin Texture; // 0x398(0x08)
	struct FName State; // 0x3a0(0x08)
	float Hover Distance; // 0x3a8(0x04)
	float Inspect Hover Tolerance; // 0x3ac(0x04)
	struct UMarkerDisplay_C* ParentMapWidgetAsMarkerDisplay; // 0x3b0(0x08)
	int32_t DisplayDistance; // 0x3b8(0x04)
	char UnknownData_3BC[0x4]; // 0x3bc(0x04)
	struct UTexture2D* Rare Pin Texture; // 0x3c0(0x08)
	struct UTexture2D* Epic Pin Texture; // 0x3c8(0x08)
	struct UTexture2D* Legendary Pin Texture; // 0x3d0(0x08)
	struct UTexture2D* Uncommon Loot Texture; // 0x3d8(0x08)
	struct UTexture2D* Rare Loot Texture; // 0x3e0(0x08)
	struct UTexture2D* Legendary Loot Texture; // 0x3e8(0x08)
	struct UTexture2D* Uncommon Pin Texture; // 0x3f0(0x08)

	void Get Visibility State For Distance(enum class ESlateVisibility NewParam); // Function LootSiteMarker_v2.LootSiteMarker_v2_C.Get Visibility State For Distance // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	bool IsHovering(); // Function LootSiteMarker_v2.LootSiteMarker_v2_C.IsHovering // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	bool ShouldUpdateHover(); // Function LootSiteMarker_v2.LootSiteMarker_v2_C.ShouldUpdateHover // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Get Default Icon Visibility(enum class ESlateVisibility NewParam); // Function LootSiteMarker_v2.LootSiteMarker_v2_C.Get Default Icon Visibility // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void Get Icon Scale(float Icon Scale); // Function LootSiteMarker_v2.LootSiteMarker_v2_C.Get Icon Scale // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void GetLootTexture(struct UTexture2D* Texture2D); // Function LootSiteMarker_v2.LootSiteMarker_v2_C.GetLootTexture // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void GetPinTexture(struct UTexture2D* Texture); // Function LootSiteMarker_v2.LootSiteMarker_v2_C.GetPinTexture // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void Get Pin Height(float Pin Height); // Function LootSiteMarker_v2.LootSiteMarker_v2_C.Get Pin Height // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void Get Render Opacity(float Render Opacity); // Function LootSiteMarker_v2.LootSiteMarker_v2_C.Get Render Opacity // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void Is Still In Initial Render Position(bool Still In Initial Render Position); // Function LootSiteMarker_v2.LootSiteMarker_v2_C.Is Still In Initial Render Position // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void GetHitboxMultiplierByDistance(float HitboxMultiplier); // Function LootSiteMarker_v2.LootSiteMarker_v2_C.GetHitboxMultiplierByDistance // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	enum class ESlateVisibility Update(); // Function LootSiteMarker_v2.LootSiteMarker_v2_C.Update // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function LootSiteMarker_v2.LootSiteMarker_v2_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void UpdateMetersAway(int32_t Meters); // Function LootSiteMarker_v2.LootSiteMarker_v2_C.UpdateMetersAway // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnHoverStateChanged(enum class EIconHoverState NewHoverState); // Function LootSiteMarker_v2.LootSiteMarker_v2_C.OnHoverStateChanged // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void HandleLootSiteRarityChanged(enum class ELootSiteRarity CurrentRarity); // Function LootSiteMarker_v2.LootSiteMarker_v2_C.HandleLootSiteRarityChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetScreenRegion(enum class EIconMarkerScreenRegion ScreenRegion); // Function LootSiteMarker_v2.LootSiteMarker_v2_C.SetScreenRegion // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void SetArrowAngle(float Angle); // Function LootSiteMarker_v2.LootSiteMarker_v2_C.SetArrowAngle // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_LootSiteMarker_v2(int32_t EntryPoint); // Function LootSiteMarker_v2.LootSiteMarker_v2_C.ExecuteUbergraph_LootSiteMarker_v2 // (Final|UbergraphFunction) // @ game+0x2587100
};

