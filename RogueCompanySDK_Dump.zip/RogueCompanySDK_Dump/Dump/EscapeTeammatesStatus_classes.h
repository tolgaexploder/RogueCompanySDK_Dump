// WidgetBlueprintGeneratedClass EscapeTeammatesStatus.EscapeTeammatesStatus_C
// Size: 0x518 (Inherited: 0x4e0)
struct UEscapeTeammatesStatus_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UTextBlock* DownedText; // 0x4e8(0x08)
	struct UTextBlock* EliminatedText; // 0x4f0(0x08)
	struct UImage* Image_1; // 0x4f8(0x08)
	struct UTextBlock* SafeAndAliveText; // 0x500(0x08)
	struct TArray<struct AKSPlayerState*> Safe Players; // 0x508(0x10)

	void Refresh(); // Function EscapeTeammatesStatus.EscapeTeammatesStatus_C.Refresh // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Player Downed Changed(struct AKSPlayerState* PlayerState); // Function EscapeTeammatesStatus.EscapeTeammatesStatus_C.Handle Player Downed Changed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Player Death(struct FCombatEventInfo EventInfo); // Function EscapeTeammatesStatus.EscapeTeammatesStatus_C.Handle Player Death // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Escape Point Changed(struct TArray<struct AKSPlayerState*> ContainedPlayers); // Function EscapeTeammatesStatus.EscapeTeammatesStatus_C.Handle Escape Point Changed // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function EscapeTeammatesStatus.EscapeTeammatesStatus_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Handle Round Start(struct FRoundInitState RoundInitState); // Function EscapeTeammatesStatus.EscapeTeammatesStatus_C.Handle Round Start // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_EscapeTeammatesStatus(int32_t EntryPoint); // Function EscapeTeammatesStatus.EscapeTeammatesStatus_C.ExecuteUbergraph_EscapeTeammatesStatus // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

