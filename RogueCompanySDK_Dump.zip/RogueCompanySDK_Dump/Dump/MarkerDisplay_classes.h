// WidgetBlueprintGeneratedClass MarkerDisplay.MarkerDisplay_C
// Size: 0x730 (Inherited: 0x6a0)
struct UMarkerDisplay_C : UKSMarkerDisplayBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x6a0(0x08)
	struct UWidgetAnimation* FadeOut; // 0x6a8(0x08)
	struct UWidgetAnimation* Inspect; // 0x6b0(0x08)
	struct UImage* Bar; // 0x6b8(0x08)
	struct UCanvasPanel* DisplayRoot; // 0x6c0(0x08)
	struct UImage* Image_1; // 0x6c8(0x08)
	struct UImage* Image_2; // 0x6d0(0x08)
	struct UCanvasPanel* InspectArea; // 0x6d8(0x08)
	struct UImage* LootIcon; // 0x6e0(0x08)
	struct UCanvasPanel* LootInspectGroup; // 0x6e8(0x08)
	struct UTextBlock* LootViewText; // 0x6f0(0x08)
	struct UCanvasPanel* ReticleArea; // 0x6f8(0x08)
	struct UImage* Tail; // 0x700(0x08)
	float Margin X; // 0x708(0x04)
	float Margin Y; // 0x70c(0x04)
	struct ULootSiteMarker_v2_C* Current Inspect Marker; // 0x710(0x08)
	struct FVector2D Inspect Anim Initial Translation; // 0x718(0x08)
	struct FMulticastInlineDelegate OnMarkerAddedToScreen; // 0x720(0x10)

	void AddIconToScreen(struct UKSMapIconWidgetBase* Icon); // Function MarkerDisplay.MarkerDisplay_C.AddIconToScreen // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	struct UKSMapIconWidgetBase* CreateNewIconWidget(struct UKSMapIconWidgetBase* WidgetClass, int32_t UniqueId, struct AKSPlayerState* CreatingPlayer, enum class EDisplayType ParentMapDisplayType, struct AActor* AssociatedActor, struct UObject* AssociatedObject, struct FVector DefaultLocation, float Lifespan); // Function MarkerDisplay.MarkerDisplay_C.CreateNewIconWidget // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Receive Loot Inspect Off From Marker(struct ULootSiteMarker_v2_C* Marker); // Function MarkerDisplay.MarkerDisplay_C.Receive Loot Inspect Off From Marker // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Receive Loot Inspect Request From Marker(struct AKSLootSiteBase* Loot Site, struct ULootSiteMarker_v2_C* Marker); // Function MarkerDisplay.MarkerDisplay_C.Receive Loot Inspect Request From Marker // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeTickAnimations(); // Function MarkerDisplay.MarkerDisplay_C.InitializeTickAnimations // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void Inspect Anim Update(float ElapsedTime, float ElapsedAlpha); // Function MarkerDisplay.MarkerDisplay_C.Inspect Anim Update // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Inspect Anim Finished(); // Function MarkerDisplay.MarkerDisplay_C.Inspect Anim Finished // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function MarkerDisplay.MarkerDisplay_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnScrambleStateChanged(bool Scrambled); // Function MarkerDisplay.MarkerDisplay_C.OnScrambleStateChanged // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void Handle Loot Site State Changed(struct FLootSiteState Loot Site State); // Function MarkerDisplay.MarkerDisplay_C.Handle Loot Site State Changed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function MarkerDisplay.MarkerDisplay_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void DisplayToMapWidget(struct UKSMapIconWidgetBase* MapIcon); // Function MarkerDisplay.MarkerDisplay_C.DisplayToMapWidget // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_MarkerDisplay(int32_t EntryPoint); // Function MarkerDisplay.MarkerDisplay_C.ExecuteUbergraph_MarkerDisplay // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void OnMarkerAddedToScreen__DelegateSignature(struct UKSMapIconWidgetBase* Marker); // Function MarkerDisplay.MarkerDisplay_C.OnMarkerAddedToScreen__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

