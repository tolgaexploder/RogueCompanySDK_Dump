// WidgetBlueprintGeneratedClass WBP_AttackerDefenderScreen.WBP_AttackerDefenderScreen_C
// Size: 0x598 (Inherited: 0x4e0)
struct UWBP_AttackerDefenderScreen_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UWidgetAnimation* HideScreen; // 0x4e8(0x08)
	struct UWidgetAnimation* ShowScreen; // 0x4f0(0x08)
	struct UImage* BGBlue; // 0x4f8(0x08)
	struct UImage* BGRed; // 0x500(0x08)
	struct UWBP_ScorePips_C* BluePips; // 0x508(0x08)
	struct UTextBlock* BlueScoreText; // 0x510(0x08)
	struct UImage* CurrentRoleIcon; // 0x518(0x08)
	struct UTextBlock* GameModeRound; // 0x520(0x08)
	struct UOverlay* Header; // 0x528(0x08)
	struct UImage* Image_321; // 0x530(0x08)
	struct UImage* Image_778; // 0x538(0x08)
	struct UOverlay* PreRoundWrapper; // 0x540(0x08)
	struct UImage* PreviousRoleIcon; // 0x548(0x08)
	struct UWBP_ScorePips_C* RedPips; // 0x550(0x08)
	struct UTextBlock* RedScoreText; // 0x558(0x08)
	struct UTextBlock* RoleText; // 0x560(0x08)
	struct UTextBlock* RoundsLabel; // 0x568(0x08)
	struct UTextBlock* RoundsToWin; // 0x570(0x08)
	struct UTextBlock* TeamLabel; // 0x578(0x08)
	bool PrePrepareRoundShown; // 0x580(0x01)
	char UnknownData_581[0x3]; // 0x581(0x03)
	int32_t CachedRoundsToWin; // 0x584(0x04)
	int32_t CachedBlueTeamScore; // 0x588(0x04)
	int32_t CachedRedTeamScore; // 0x58c(0x04)
	struct FName CurrentPhase; // 0x590(0x08)

	void HandleShowAnimationFinished(); // Function WBP_AttackerDefenderScreen.WBP_AttackerDefenderScreen_C.HandleShowAnimationFinished // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ShowScreenAnimation(); // Function WBP_AttackerDefenderScreen.WBP_AttackerDefenderScreen_C.ShowScreenAnimation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleTeamAdded(struct AKSTeamState* TeamState); // Function WBP_AttackerDefenderScreen.WBP_AttackerDefenderScreen_C.HandleTeamAdded // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetTeamRole(); // Function WBP_AttackerDefenderScreen.WBP_AttackerDefenderScreen_C.SetTeamRole // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleAttackingTeamUpdated(struct AKSTeamState* Team); // Function WBP_AttackerDefenderScreen.WBP_AttackerDefenderScreen_C.HandleAttackingTeamUpdated // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetRounds(); // Function WBP_AttackerDefenderScreen.WBP_AttackerDefenderScreen_C.SetRounds // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ResetPreRoundScreen(); // Function WBP_AttackerDefenderScreen.WBP_AttackerDefenderScreen_C.ResetPreRoundScreen // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Get Pre Round Text(struct FText PreRoundText); // Function WBP_AttackerDefenderScreen.WBP_AttackerDefenderScreen_C.Get Pre Round Text // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void IsAttackerRole(bool IsAttacker); // Function WBP_AttackerDefenderScreen.WBP_AttackerDefenderScreen_C.IsAttackerRole // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void HandlePhaseChanged(struct FName NewPhaseName, struct FName PreviousPhaseName); // Function WBP_AttackerDefenderScreen.WBP_AttackerDefenderScreen_C.HandlePhaseChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PreRoundAnimComplete(); // Function WBP_AttackerDefenderScreen.WBP_AttackerDefenderScreen_C.PreRoundAnimComplete // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function WBP_AttackerDefenderScreen.WBP_AttackerDefenderScreen_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_AttackerDefenderScreen(int32_t EntryPoint); // Function WBP_AttackerDefenderScreen.WBP_AttackerDefenderScreen_C.ExecuteUbergraph_WBP_AttackerDefenderScreen // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

