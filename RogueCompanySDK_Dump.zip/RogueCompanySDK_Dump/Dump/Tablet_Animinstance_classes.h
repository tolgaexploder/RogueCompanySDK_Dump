// AnimBlueprintGeneratedClass Tablet_Animinstance.Tablet_Animinstance_C
// Size: 0x90a (Inherited: 0x310)
struct UTablet_Animinstance_C : UKSTabletAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x310(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x318(0x38)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4; // 0x350(0x30)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3; // 0x380(0x30)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // 0x3b0(0x30)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // 0x3e0(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4; // 0x410(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4; // 0x490(0x38)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // 0x4c8(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3; // 0x548(0x38)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x580(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // 0x600(0x38)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x638(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0x6b8(0x38)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0x6f0(0xb8)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone; // 0x7a8(0x110)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // 0x8b8(0x28)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0x8e0(0x28)
	bool Is Fully Opened; // 0x908(0x01)
	bool Is Fully Closed; // 0x909(0x01)

	void AnimGraph(struct FPoseLink AnimGraph); // Function Tablet_Animinstance.Tablet_Animinstance_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	bool CheckFullyClosed(); // Function Tablet_Animinstance.Tablet_Animinstance_C.CheckFullyClosed // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	bool CheckFullyOpened(); // Function Tablet_Animinstance.Tablet_Animinstance_C.CheckFullyOpened // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Tablet_Animinstance_AnimGraphNode_TransitionResult_C6030DE749FE3B92159BDE9A75441D4B(); // Function Tablet_Animinstance.Tablet_Animinstance_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Tablet_Animinstance_AnimGraphNode_TransitionResult_C6030DE749FE3B92159BDE9A75441D4B // (BlueprintEvent) // @ game+0x2587100
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Tablet_Animinstance_AnimGraphNode_TransitionResult_663822E3415C75ED19679CB91FC56195(); // Function Tablet_Animinstance.Tablet_Animinstance_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Tablet_Animinstance_AnimGraphNode_TransitionResult_663822E3415C75ED19679CB91FC56195 // (BlueprintEvent) // @ game+0x2587100
	void AnimNotify_BecomeFullyOpened(); // Function Tablet_Animinstance.Tablet_Animinstance_C.AnimNotify_BecomeFullyOpened // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void AnimNotify_EndFullyOpened(); // Function Tablet_Animinstance.Tablet_Animinstance_C.AnimNotify_EndFullyOpened // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void AnimNotify_BecomeFullyClosed(); // Function Tablet_Animinstance.Tablet_Animinstance_C.AnimNotify_BecomeFullyClosed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void AnimNotify_EndFullyClosed(); // Function Tablet_Animinstance.Tablet_Animinstance_C.AnimNotify_EndFullyClosed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_Tablet_Animinstance(int32_t EntryPoint); // Function Tablet_Animinstance.Tablet_Animinstance_C.ExecuteUbergraph_Tablet_Animinstance // (Final|UbergraphFunction) // @ game+0x2587100
};

