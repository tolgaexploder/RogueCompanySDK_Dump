// WidgetBlueprintGeneratedClass PlayerActivePerks.PlayerActivePerks_C
// Size: 0x538 (Inherited: 0x510)
struct UPlayerActivePerks_C : UKSViewedPawnWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x510(0x08)
	struct UHorizontalBox* PerkSlotWrapper; // 0x518(0x08)
	struct AKSPlayerState* BoundPlayerState; // 0x520(0x08)
	bool IsDirty; // 0x528(0x01)
	char UnknownData_529[0x7]; // 0x529(0x07)
	struct AKSCharacter* BoundPawn; // 0x530(0x08)

	void PostSetPawn(); // Function PlayerActivePerks.PlayerActivePerks_C.PostSetPawn // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void PreClearPawn(); // Function PlayerActivePerks.PlayerActivePerks_C.PreClearPawn // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void HandleModsUpdated(struct AKSCharacter* KSCharacter); // Function PlayerActivePerks.PlayerActivePerks_C.HandleModsUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleDownedElim(struct AKSPlayerState* KSPlayerState); // Function PlayerActivePerks.PlayerActivePerks_C.HandleDownedElim // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Bind Callbacks to Player State(struct AKSPlayerState* In Player State); // Function PlayerActivePerks.PlayerActivePerks_C.Bind Callbacks to Player State // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Unbind Callbacks to Player State(); // Function PlayerActivePerks.PlayerActivePerks_C.Unbind Callbacks to Player State // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Bind Callbacks to Pawn(struct AKSCharacter* In Pawn); // Function PlayerActivePerks.PlayerActivePerks_C.Bind Callbacks to Pawn // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Unbind Callbacks to Pawn(); // Function PlayerActivePerks.PlayerActivePerks_C.Unbind Callbacks to Pawn // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PreClearPlayerState(); // Function PlayerActivePerks.PlayerActivePerks_C.PreClearPlayerState // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void PostSetPlayerState(); // Function PlayerActivePerks.PlayerActivePerks_C.PostSetPlayerState // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void SetPlayerStateUIRelevanceChanged(); // Function PlayerActivePerks.PlayerActivePerks_C.SetPlayerStateUIRelevanceChanged // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void Try To Show On UI Relevant(); // Function PlayerActivePerks.PlayerActivePerks_C.Try To Show On UI Relevant // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_PlayerActivePerks(int32_t EntryPoint); // Function PlayerActivePerks.PlayerActivePerks_C.ExecuteUbergraph_PlayerActivePerks // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

