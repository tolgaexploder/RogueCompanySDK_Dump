// WidgetBlueprintGeneratedClass ReloadReticle.ReloadReticle_C
// Size: 0x280 (Inherited: 0x238)
struct UReloadReticle_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UImage* circle_progress; // 0x240(0x08)
	struct UImage* circle_progress_bg; // 0x248(0x08)
	struct UImage* Image_1; // 0x250(0x08)
	struct UImage* Image_2; // 0x258(0x08)
	struct UProgressBar* ProgressBar_1; // 0x260(0x08)
	struct UImage* ShotgunProgress; // 0x268(0x08)
	struct UImage* ShotgunProgressBG; // 0x270(0x08)
	float ReloadTime; // 0x278(0x04)
	float ReloadTimeLeft; // 0x27c(0x04)

	void ColorSet(struct FLinearColor NewColor); // Function ReloadReticle.ReloadReticle_C.ColorSet // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateShotgunReload(float ReloadTime, float Percent); // Function ReloadReticle.ReloadReticle_C.UpdateShotgunReload // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetReloadTime(float NewTime); // Function ReloadReticle.ReloadReticle_C.SetReloadTime // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function ReloadReticle.ReloadReticle_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Circle Progress Open(); // Function ReloadReticle.ReloadReticle_C.Circle Progress Open // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Circle Progress Close(); // Function ReloadReticle.ReloadReticle_C.Circle Progress Close // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PreventCircleFill(); // Function ReloadReticle.ReloadReticle_C.PreventCircleFill // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ShotgunCircleOpen(); // Function ReloadReticle.ReloadReticle_C.ShotgunCircleOpen // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ShotgunCircleClose(); // Function ReloadReticle.ReloadReticle_C.ShotgunCircleClose // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_ReloadReticle(int32_t EntryPoint); // Function ReloadReticle.ReloadReticle_C.ExecuteUbergraph_ReloadReticle // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

