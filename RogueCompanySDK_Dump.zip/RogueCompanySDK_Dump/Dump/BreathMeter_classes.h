// WidgetBlueprintGeneratedClass BreathMeter.BreathMeter_C
// Size: 0x268 (Inherited: 0x238)
struct UBreathMeter_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UImage* background; // 0x240(0x08)
	struct UProgressBar* BreathMeter; // 0x248(0x08)
	float MaxLungCapacity; // 0x250(0x04)
	float NewLungCapacity; // 0x254(0x04)
	float OldLungCapacity; // 0x258(0x04)
	float DeltaTime; // 0x25c(0x04)
	struct AKSCharacter* ViewedChar; // 0x260(0x08)

	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function BreathMeter.BreathMeter_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void OpenGate(); // Function BreathMeter.BreathMeter_C.OpenGate // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void CloseGate(); // Function BreathMeter.BreathMeter_C.CloseGate // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function BreathMeter.BreathMeter_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void UpdateCharacter(struct AKSCharacter* NewCharacter); // Function BreathMeter.BreathMeter_C.UpdateCharacter // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UnbindCharacter(); // Function BreathMeter.BreathMeter_C.UnbindCharacter // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateBreath(float NewBreath); // Function BreathMeter.BreathMeter_C.UpdateBreath // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_BreathMeter(int32_t EntryPoint); // Function BreathMeter.BreathMeter_C.ExecuteUbergraph_BreathMeter // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

