// WidgetBlueprintGeneratedClass LocalPlayerHealth.LocalPlayerHealth_C
// Size: 0x622 (Inherited: 0x560)
struct ULocalPlayerHealth_C : UKSPlayerHealthWidgetBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x560(0x08)
	struct UWidgetAnimation* FadeOut; // 0x568(0x08)
	struct UWidgetAnimation* DamagePulse_Downed_1; // 0x570(0x08)
	struct UWidgetAnimation* DamagePulse_Downed; // 0x578(0x08)
	struct UWidgetAnimation* LowHealth; // 0x580(0x08)
	struct UWidgetAnimation* DamagePulse; // 0x588(0x08)
	struct UImage* Image_55; // 0x590(0x08)
	struct UTextBlock* MaxHealthText; // 0x598(0x08)
	struct UPlayerHealthMeter_C* PlayerHealthMeter; // 0x5a0(0x08)
	struct UTextBlock* ResourceValueDigit0; // 0x5a8(0x08)
	struct UTextBlock* ResourceValueDigit1; // 0x5b0(0x08)
	struct UTextBlock* ResourceValueDigit2; // 0x5b8(0x08)
	struct UKSAsyncImage* RogueIconAsync; // 0x5c0(0x08)
	struct UWBP_HeadstrongPerkActive_C* WBP_HeadstrongPerkActive; // 0x5c8(0x08)
	struct UWBP_LocalPlayerModBar_C* WBP_LocalPlayerModBar; // 0x5d0(0x08)
	struct AKSPlayerState* Player; // 0x5d8(0x08)
	struct UMaterialInstanceDynamic* FillDynMat; // 0x5e0(0x08)
	float NumSegments; // 0x5e8(0x04)
	int32_t MaxHealth; // 0x5ec(0x04)
	struct FLinearColor RegularHealthColor; // 0x5f0(0x10)
	struct FLinearColor OverhealedHealthColor; // 0x600(0x10)
	struct FLinearColor DownedHealthColor; // 0x610(0x10)
	bool Cached Is Downed; // 0x620(0x01)
	bool Cached Is Dead; // 0x621(0x01)

	void CheckMods(struct AKSPlayerState* ViewedPawnPlayerState); // Function LocalPlayerHealth.LocalPlayerHealth_C.CheckMods // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ResetVisbility(); // Function LocalPlayerHealth.LocalPlayerHealth_C.ResetVisbility // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void TriggerFadeAnim(); // Function LocalPlayerHealth.LocalPlayerHealth_C.TriggerFadeAnim // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnOverhealChanged(float OldOverheal, float NewOverheal, bool bAnimatedChange); // Function LocalPlayerHealth.LocalPlayerHealth_C.OnOverhealChanged // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function LocalPlayerHealth.LocalPlayerHealth_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void View_OnDeathStateChanged(); // Function LocalPlayerHealth.LocalPlayerHealth_C.View_OnDeathStateChanged // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function LocalPlayerHealth.LocalPlayerHealth_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnHealthMeterStateChanged(); // Function LocalPlayerHealth.LocalPlayerHealth_C.OnHealthMeterStateChanged // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void SetHealthText(); // Function LocalPlayerHealth.LocalPlayerHealth_C.SetHealthText // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnJobChanged(struct UKSJobItem* Job); // Function LocalPlayerHealth.LocalPlayerHealth_C.OnJobChanged // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnHealthDecreased(); // Function LocalPlayerHealth.LocalPlayerHealth_C.OnHealthDecreased // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void PostSetPawn(); // Function LocalPlayerHealth.LocalPlayerHealth_C.PostSetPawn // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnModAdded(struct UKSPlayerMod* Mod, struct UKSPlayerModInstance* ModInstance); // Function LocalPlayerHealth.LocalPlayerHealth_C.OnModAdded // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnModRemoved(struct UKSPlayerMod* Mod, struct UKSPlayerModInstance* ModInstance); // Function LocalPlayerHealth.LocalPlayerHealth_C.OnModRemoved // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PreClearPawn(); // Function LocalPlayerHealth.LocalPlayerHealth_C.PreClearPawn // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void PostSetPlayerState(); // Function LocalPlayerHealth.LocalPlayerHealth_C.PostSetPlayerState // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void PreClearPlayerState(); // Function LocalPlayerHealth.LocalPlayerHealth_C.PreClearPlayerState // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_LocalPlayerHealth(int32_t EntryPoint); // Function LocalPlayerHealth.LocalPlayerHealth_C.ExecuteUbergraph_LocalPlayerHealth // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

