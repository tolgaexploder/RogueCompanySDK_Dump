// BlueprintGeneratedClass CINE_HUD_INTERFACE.CINE_HUD_INTERFACE_C
// Size: 0x28 (Inherited: 0x28)
struct UCINE_HUD_INTERFACE_C : UInterface {

	void Init WalkIn Widget(struct AKSJobSelectPreviewActor* In Player 01, struct AKSJobSelectPreviewActor* In Player 02, struct AKSJobSelectPreviewActor* In Player 03, struct AKSJobSelectPreviewActor* In Player 04); // Function CINE_HUD_INTERFACE.CINE_HUD_INTERFACE_C.Init WalkIn Widget // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Set Cinematic Nameplate Data(struct UKSPersistentPlayerData* Player Data, int32_t Index); // Function CINE_HUD_INTERFACE.CINE_HUD_INTERFACE_C.Set Cinematic Nameplate Data // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Play Cinematic Nameplate Anim(int32_t Index); // Function CINE_HUD_INTERFACE.CINE_HUD_INTERFACE_C.Play Cinematic Nameplate Anim // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

