// BlueprintGeneratedClass ANotify_Ragdoll.ANotify_Ragdoll_C
// Size: 0x38 (Inherited: 0x38)
struct UANotify_Ragdoll_C : UAnimNotify {

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function ANotify_Ragdoll.ANotify_Ragdoll_C.Received_Notify // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x2587100
};

