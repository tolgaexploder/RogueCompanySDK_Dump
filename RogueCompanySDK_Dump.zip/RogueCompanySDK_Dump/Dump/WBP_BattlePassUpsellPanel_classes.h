// WidgetBlueprintGeneratedClass WBP_BattlePassUpsellPanel.WBP_BattlePassUpsellPanel_C
// Size: 0x550 (Inherited: 0x4e0)
struct UWBP_BattlePassUpsellPanel_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UVerticalBox* AdditionalUnlocks; // 0x4e8(0x08)
	struct UTextBlock* AlsoUnlockText; // 0x4f0(0x08)
	struct UTextBlock* IconText; // 0x4f8(0x08)
	struct UImage* Image_613; // 0x500(0x08)
	struct UTextBlock* InstantUnlocksText; // 0x508(0x08)
	struct UTextBlock* PremiumRewardsText; // 0x510(0x08)
	struct UVerticalBox* RogueBucksStack; // 0x518(0x08)
	struct UTextBlock* RogueBucksText; // 0x520(0x08)
	struct UTextBlock* TitleText; // 0x528(0x08)
	struct UWBP_PanelDefault_C* WBP_PanelDefault; // 0x530(0x08)
	struct UWBP_YellowButton_C* WBP_YellowButton; // 0x538(0x08)
	struct FMulticastInlineDelegate OnButtonClicked; // 0x540(0x10)

	void RefreshDisplay(); // Function WBP_BattlePassUpsellPanel.WBP_BattlePassUpsellPanel_C.RefreshDisplay // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BndEvt__WBP_YellowButton_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature(struct UWidget* Widget); // Function WBP_BattlePassUpsellPanel.WBP_BattlePassUpsellPanel_C.BndEvt__WBP_YellowButton_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function WBP_BattlePassUpsellPanel.WBP_BattlePassUpsellPanel_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function WBP_BattlePassUpsellPanel.WBP_BattlePassUpsellPanel_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_BattlePassUpsellPanel(int32_t EntryPoint); // Function WBP_BattlePassUpsellPanel.WBP_BattlePassUpsellPanel_C.ExecuteUbergraph_WBP_BattlePassUpsellPanel // (Final|UbergraphFunction) // @ game+0x2587100
	void OnButtonClicked__DelegateSignature(); // Function WBP_BattlePassUpsellPanel.WBP_BattlePassUpsellPanel_C.OnButtonClicked__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

