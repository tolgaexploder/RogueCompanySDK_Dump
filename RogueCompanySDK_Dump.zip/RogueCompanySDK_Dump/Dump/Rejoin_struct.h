// Enum Rejoin.ERejoinStatus
enum class ERejoinStatus : uint8 {
	NoMatchToRejoin,
	RejoinAvailable,
	UpdatingStatus,
	NeedsRecheck,
	NoMatchToRejoin_MatchEnded,
	ERejoinStatus_MAX,
};

