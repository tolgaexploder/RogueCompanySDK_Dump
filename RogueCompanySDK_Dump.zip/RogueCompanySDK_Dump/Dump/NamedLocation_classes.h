// BlueprintGeneratedClass NamedLocation.NamedLocation_C
// Size: 0x240 (Inherited: 0x220)
struct ANamedLocation_C : AKSNamedLocation {
	struct UTextRenderComponent* TextRender; // 0x220(0x08)
	struct FText LocationName; // 0x228(0x18)

	void UserConstructionScript(); // Function NamedLocation.NamedLocation_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

