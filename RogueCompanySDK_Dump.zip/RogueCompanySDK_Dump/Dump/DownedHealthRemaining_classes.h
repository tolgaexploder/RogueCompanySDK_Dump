// WidgetBlueprintGeneratedClass DownedHealthRemaining.DownedHealthRemaining_C
// Size: 0x5e0 (Inherited: 0x530)
struct UDownedHealthRemaining_C : UKSViewedTargetHealthWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x530(0x08)
	struct UWidgetAnimation* FadeOut; // 0x538(0x08)
	struct UWBP_InputCallout_C* BleedOutInputCallout; // 0x540(0x08)
	struct UImage* BurstImg; // 0x548(0x08)
	struct UHorizontalBox* GiveUpGroup; // 0x550(0x08)
	struct UWidgetSwitcher* GiveUpImageSwitcher; // 0x558(0x08)
	struct UProgressBar* GiveUpProgress; // 0x560(0x08)
	struct UImage* GrayBlur; // 0x568(0x08)
	struct UImage* HealthIcon; // 0x570(0x08)
	struct UImage* MeterFill; // 0x578(0x08)
	struct UOverlay* RadialProgressBarOverlay; // 0x580(0x08)
	struct UImage* Scanlines; // 0x588(0x08)
	struct UTextBlock* Status; // 0x590(0x08)
	bool revive; // 0x598(0x01)
	char UnknownData_599[0x3]; // 0x599(0x03)
	float ReviveProgress; // 0x59c(0x04)
	struct AKSCharacter* Char; // 0x5a0(0x08)
	struct AKSPlayerState* Player; // 0x5a8(0x08)
	bool ShowedDownStatus; // 0x5b0(0x01)
	char UnknownData_5B1[0x7]; // 0x5b1(0x07)
	struct UMaterialInstanceDynamic* Fill_Dyn_Mat; // 0x5b8(0x08)
	struct FText ReviverName; // 0x5c0(0x18)
	float GiveUpMaxSeconds; // 0x5d8(0x04)
	float GiveUpLocalTween; // 0x5dc(0x04)

	void Unbind Player State(); // Function DownedHealthRemaining.DownedHealthRemaining_C.Unbind Player State // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	struct FText StatusTextBind(); // Function DownedHealthRemaining.DownedHealthRemaining_C.StatusTextBind // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	struct FLinearColor OverallColorBind(); // Function DownedHealthRemaining.DownedHealthRemaining_C.OverallColorBind // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	float BarPercentBind(); // Function DownedHealthRemaining.DownedHealthRemaining_C.BarPercentBind // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void Handle Give Up Timer Active(bool bActive); // Function DownedHealthRemaining.DownedHealthRemaining_C.Handle Give Up Timer Active // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function DownedHealthRemaining.DownedHealthRemaining_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void PreClearPawn(); // Function DownedHealthRemaining.DownedHealthRemaining_C.PreClearPawn // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void PostSetPawn(); // Function DownedHealthRemaining.DownedHealthRemaining_C.PostSetPawn // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void DownStateChanged(struct AKSPlayerState* PlayerState); // Function DownedHealthRemaining.DownedHealthRemaining_C.DownStateChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void FadedOutFinished(); // Function DownedHealthRemaining.DownedHealthRemaining_C.FadedOutFinished // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function DownedHealthRemaining.DownedHealthRemaining_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function DownedHealthRemaining.DownedHealthRemaining_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PostSetPlayerState(); // Function DownedHealthRemaining.DownedHealthRemaining_C.PostSetPlayerState // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void PreClearPlayerState(); // Function DownedHealthRemaining.DownedHealthRemaining_C.PreClearPlayerState // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void On Character Give Up Allowed(bool Allowed); // Function DownedHealthRemaining.DownedHealthRemaining_C.On Character Give Up Allowed // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_DownedHealthRemaining(int32_t EntryPoint); // Function DownedHealthRemaining.DownedHealthRemaining_C.ExecuteUbergraph_DownedHealthRemaining // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

