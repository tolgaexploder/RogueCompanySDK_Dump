// DynamicClass NameplateWidget.NameplateWidget_C
// Size: 0x540 (Inherited: 0x238)
struct UNameplateWidget_C : UUserWidget {
	char UnknownData_238[0x8]; // 0x238(0x08)
	struct UWidgetAnimation* DamagePulse; // 0x240(0x08)
	struct USizeBox* CrackedState; // 0x248(0x08)
	struct UImage* CrackedStateIcon; // 0x250(0x08)
	struct UImage* DownedArrow; // 0x258(0x08)
	struct UWidgetSwitcher* DownedPlayer; // 0x260(0x08)
	struct UInvalidationBox* InvalidationBox_1; // 0x268(0x08)
	struct UImage* ObjectiveIcon; // 0x270(0x08)
	struct USizeBox* ObjectiveWrapper; // 0x278(0x08)
	struct UPlayerHealthMeter_C* PlayerHealthMeter; // 0x280(0x08)
	struct UTextBlock* PlayerName; // 0x288(0x08)
	struct UImage* RogueIcon; // 0x290(0x08)
	struct APlayerState* Nameplate_PlayerState; // 0x298(0x08)
	struct AKSCharacter* Nameplate_Character; // 0x2a0(0x08)
	bool Killcam_Enabled; // 0x2a8(0x01)
	char UnknownData_2A9[0x3]; // 0x2a9(0x03)
	struct FName HoverState; // 0x2ac(0x08)
	float ResidualFadeAlpha; // 0x2b4(0x04)
	float ResidualFadeDelayTime; // 0x2b8(0x04)
	struct FVector2D DamageLerpEndpoints; // 0x2bc(0x08)
	float ResidualFadeTime; // 0x2c4(0x04)
	float Manual Tick Delta Time; // 0x2c8(0x04)
	float ResidualFadeDelayTimer; // 0x2cc(0x04)
	float DamageLerpAlpha; // 0x2d0(0x04)
	float ResidualFadePower; // 0x2d4(0x04)
	float DamageLerpPower; // 0x2d8(0x04)
	float DamageLerpTime; // 0x2dc(0x04)
	float PreviousHealth; // 0x2e0(0x04)
	struct FPlayerHealthMeterState CurrentMeterState; // 0x2e4(0x18)
	bool HasDeferredUpdate; // 0x2fc(0x01)
	bool ShowObjective; // 0x2fd(0x01)
	char UnknownData_2FE[0x2]; // 0x2fe(0x02)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate; // 0x300(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2; // 0x310(0x10)
	struct AKSPlayerState* K2Node_DynamicCast_AsKSPlayer_State; // 0x320(0x08)
	bool K2Node_DynamicCast_bSuccess; // 0x328(0x01)
	char UnknownData_329[0x7]; // 0x329(0x07)
	struct AKSPlayerState* K2Node_CustomEvent_PlayerState_2; // 0x330(0x08)
	bool Temp_bool_Variable; // 0x338(0x01)
	char UnknownData_339[0x7]; // 0x339(0x07)
	struct AKSCharacterBase* K2Node_CustomEvent_Character; // 0x340(0x08)
	struct AKSGameState* K2Node_DynamicCast_AsKSGame_State; // 0x348(0x08)
	bool K2Node_DynamicCast_bSuccess_2; // 0x350(0x01)
	char UnknownData_351[0x3]; // 0x351(0x03)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3; // 0x354(0x10)
	char UnknownData_364[0x4]; // 0x364(0x04)
	struct AKSPlayerState* K2Node_CustomEvent_PlayerState; // 0x368(0x08)
	struct AKSGameState* K2Node_DynamicCast_AsKSGame_State_2; // 0x370(0x08)
	bool K2Node_DynamicCast_bSuccess_3; // 0x378(0x01)
	char UnknownData_379[0x7]; // 0x379(0x07)
	struct UKSPlayerMod* K2Node_CustomEvent_Mod_2; // 0x380(0x08)
	struct UKSPlayerModInstance* K2Node_CustomEvent_ModInstance_2; // 0x388(0x08)
	struct UKSPlayerMod* K2Node_CustomEvent_Mod; // 0x390(0x08)
	struct UKSPlayerModInstance* K2Node_CustomEvent_ModInstance; // 0x398(0x08)
	struct AKSPlayerState* K2Node_CustomEvent_PlayerState_3; // 0x3a0(0x08)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4; // 0x3a8(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5; // 0x3b8(0x10)
	bool K2Node_CustomEvent_IsEnabled; // 0x3c8(0x01)
	bool CallFunc_Player_Is_Blinded_Is_Blind; // 0x3c9(0x01)
	char UnknownData_3CA[0x6]; // 0x3ca(0x06)
	struct AKSCharacterBase* K2Node_CustomEvent_Character_2; // 0x3d0(0x08)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter; // 0x3d8(0x08)
	bool K2Node_DynamicCast_bSuccess_4; // 0x3e0(0x01)
	char UnknownData_3E1[0x7]; // 0x3e1(0x07)
	struct APlayerState* K2Node_Event_PlayerState; // 0x3e8(0x08)
	struct AKSCharacter* K2Node_Event_Character; // 0x3f0(0x08)
	bool CallFunc_Should_Show_Enemy_Nameplate_ShouldShow; // 0x3f8(0x01)
	char UnknownData_3F9[0x7]; // 0x3f9(0x07)
	struct UObject* Temp_object_Variable; // 0x400(0x08)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6; // 0x408(0x10)
	struct UTexture2D* K2Node_DynamicCast_AsTexture_2D; // 0x418(0x08)
	bool K2Node_DynamicCast_bSuccess_5; // 0x420(0x01)
	char UnknownData_421[0x7]; // 0x421(0x07)
	struct UKSLocalPlayer* K2Node_DynamicCast_AsKSLocal_Player; // 0x428(0x08)
	bool K2Node_DynamicCast_bSuccess_6; // 0x430(0x01)
	bool Temp_bool_Has_Been_Initd_Variable; // 0x431(0x01)
	char UnknownData_432[0x6]; // 0x432(0x06)
	struct UObject* K2Node_CustomEvent_Loaded; // 0x438(0x08)
	enum class ESlateVisibility Temp_byte_Variable; // 0x440(0x01)
	char UnknownData_441[0x7]; // 0x441(0x07)
	struct AKSPlayerState* K2Node_DynamicCast_AsKSPlayer_State_2; // 0x448(0x08)
	bool K2Node_DynamicCast_bSuccess_7; // 0x450(0x01)
	char UnknownData_451[0x3]; // 0x451(0x03)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_7; // 0x454(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_8; // 0x464(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_9; // 0x474(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_10; // 0x484(0x10)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable; // 0x494(0x01)
	enum class ESlateVisibility Temp_byte_Variable_2; // 0x495(0x01)
	char UnknownData_496[0x2]; // 0x496(0x02)
	float Temp_float_Variable; // 0x498(0x04)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_11; // 0x49c(0x10)
	char UnknownData_4AC[0x4]; // 0x4ac(0x04)
	struct AKSPlayerState* K2Node_DynamicCast_AsKSPlayer_State_3; // 0x4b0(0x08)
	bool K2Node_DynamicCast_bSuccess_8; // 0x4b8(0x01)
	char UnknownData_4B9[0x3]; // 0x4b9(0x03)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_12; // 0x4bc(0x10)
	bool Temp_bool_IsClosed_Variable; // 0x4cc(0x01)
	char UnknownData_4CD[0x3]; // 0x4cd(0x03)
	struct TScriptInterface<None> CallFunc_BindToObjectiveStateChanged_self_CastInput; // 0x4d0(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_13; // 0x4e0(0x10)
	float Temp_float_Variable_2; // 0x4f0(0x04)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_14; // 0x4f4(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_15; // 0x504(0x10)
	bool Temp_bool_Variable_2; // 0x514(0x01)
	char UnknownData_515[0x3]; // 0x515(0x03)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_16; // 0x518(0x10)
	float K2Node_Select_Default; // 0x528(0x04)
	char UnknownData_52C[0x4]; // 0x52c(0x04)
	struct AKSPlayerState* K2Node_DynamicCast_AsKSPlayer_State_4; // 0x530(0x08)
	bool K2Node_DynamicCast_bSuccess_9; // 0x538(0x01)
	enum class ESlateVisibility K2Node_Select_Default_2; // 0x539(0x01)
	char UnknownData_53A[0x6]; // 0x53a(0x06)

	void Unbind Events From PlayerState(); // Function NameplateWidget.NameplateWidget_C.Unbind Events From PlayerState // (Native|Public|BlueprintCallable) // @ game+0x1a0f700
	void Should Show Enemy Nameplate(bool bpp__ShouldShow__pf); // Function NameplateWidget.NameplateWidget_C.Should Show Enemy Nameplate // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1a0f660
	void SetObjectiveMarkerFromGameState(bool bpp__ShowObjective__pf, struct UTexture2D* bpp__ObjectiveIcon__pf); // Function NameplateWidget.NameplateWidget_C.SetObjectiveMarkerFromGameState // (Native|Public|BlueprintCallable) // @ game+0x1a0f590
	void SetNamePlateColor(struct AKSPlayerState* bpp__PlayerxState__pfT); // Function NameplateWidget.NameplateWidget_C.SetNamePlateColor // (Native|Public|BlueprintCallable) // @ game+0x19dc280
	void Player Is Blinded(bool bpp__IsxBlind__pfT); // Function NameplateWidget.NameplateWidget_C.Player Is Blinded // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1a0f4f0
	void OnUnhovered(); // Function NameplateWidget.NameplateWidget_C.OnUnhovered // (Native|Event|Public|BlueprintCallable) // @ game+0x89ee40
	void OnPossession(struct APlayerState* bpp__PlayerState__pf, struct AKSCharacter* bpp__Character__pf); // Function NameplateWidget.NameplateWidget_C.OnPossession // (Native|Event|Public|BlueprintCallable) // @ game+0x1a0f420
	void OnPlayerUINeedsUpdate(struct AKSPlayerState* bpp__PlayerState__pf); // Function NameplateWidget.NameplateWidget_C.OnPlayerUINeedsUpdate // (Native|Public|BlueprintCallable) // @ game+0x1a0f390
	void OnPlayerDownedChanged_Event(struct AKSPlayerState* bpp__PlayerState__pf); // Function NameplateWidget.NameplateWidget_C.OnPlayerDownedChanged_Event // (Native|Public|BlueprintCallable) // @ game+0x1a0f300
	void OnModRemoved(struct UKSPlayerMod* bpp__Mod__pf, struct UKSPlayerModInstance* bpp__ModInstance__pf); // Function NameplateWidget.NameplateWidget_C.OnModRemoved // (Native|Public|BlueprintCallable) // @ game+0x89f860
	void OnModAdded(struct UKSPlayerMod* bpp__Mod__pf, struct UKSPlayerModInstance* bpp__ModInstance__pf); // Function NameplateWidget.NameplateWidget_C.OnModAdded // (Native|Public|BlueprintCallable) // @ game+0x1a0f230
	void OnLoaded_F5BCD8C84871643FB2979DA9F519484F(struct UObject* bpp__Loaded__pf); // Function NameplateWidget.NameplateWidget_C.OnLoaded_F5BCD8C84871643FB2979DA9F519484F // (Native|Public|BlueprintCallable) // @ game+0x1a0f1a0
	void OnKillCamEnabled(bool bpp__IsEnabled__pf); // Function NameplateWidget.NameplateWidget_C.OnKillCamEnabled // (Native|Public|BlueprintCallable) // @ game+0x1a0f110
	void OnHovered(); // Function NameplateWidget.NameplateWidget_C.OnHovered // (Native|Event|Public|BlueprintCallable) // @ game+0x89f840
	void OnDead(struct AKSPlayerState* bpp__PlayerState__pf); // Function NameplateWidget.NameplateWidget_C.OnDead // (Native|Public|BlueprintCallable) // @ game+0x1a0f080
	void Manual Tick(); // Function NameplateWidget.NameplateWidget_C.Manual Tick // (Native|Public|BlueprintCallable) // @ game+0x1a0f060
	void Handle Overheal Changed(struct AKSCharacterBase* bpp__Character__pf__const); // Function NameplateWidget.NameplateWidget_C.Handle Overheal Changed // (Native|Public|BlueprintCallable) // @ game+0x1a0efd0
	void Handle Job Changed(); // Function NameplateWidget.NameplateWidget_C.Handle Job Changed // (Native|Public|BlueprintCallable) // @ game+0x1a0efb0
	void HandleObjectiveStateChanged(struct TScriptInterface<None> bpp__Objective__pf); // Function NameplateWidget.NameplateWidget_C.HandleObjectiveStateChanged // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1a0ef10
	void HandleNameChanged(struct AKSPlayerState* bpp__InKSPlayerState__pf); // Function NameplateWidget.NameplateWidget_C.HandleNameChanged // (Native|Public|BlueprintCallable) // @ game+0x1a0ee80
	void HandleModActivationChanged(struct UKSPlayerMod_Activated* bpp__ActivatedxMod__pfT, bool bpp__Active__pf); // Function NameplateWidget.NameplateWidget_C.HandleModActivationChanged // (Native|Public|BlueprintCallable) // @ game+0x1a0edb0
	void HandleGameObjectiveChanged(struct TScriptInterface<None> bpp__GameObjective__pf); // Function NameplateWidget.NameplateWidget_C.HandleGameObjectiveChanged // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1a0ed10
	void ExecuteUbergraph_NameplateWidget_8(int32_t bpp__EntryPoint__pf); // Function NameplateWidget.NameplateWidget_C.ExecuteUbergraph_NameplateWidget_8 // (Final|Native|Public) // @ game+0x1a0ec90
	void ExecuteUbergraph_NameplateWidget_15(int32_t bpp__EntryPoint__pf); // Function NameplateWidget.NameplateWidget_C.ExecuteUbergraph_NameplateWidget_15 // (Final|Native|Public) // @ game+0x1a0ec10
	void Destruct(); // Function NameplateWidget.NameplateWidget_C.Destruct // (BlueprintCosmetic|Native|Event|Public) // @ game+0x1a0ebf0
	void Deferred Player State Open(); // Function NameplateWidget.NameplateWidget_C.Deferred Player State Open // (Native|Public|BlueprintCallable) // @ game+0x1a0ebd0
	void Construct(); // Function NameplateWidget.NameplateWidget_C.Construct // (BlueprintCosmetic|Native|Event|Public) // @ game+0x1a0ebb0
	void CheckMods(struct AKSPlayerState* bpp__PlayerState__pf); // Function NameplateWidget.NameplateWidget_C.CheckMods // (Native|Public|BlueprintCallable) // @ game+0x1a0eb20
	void CharacterHealthChange(struct AKSCharacterBase* bpp__Character__pf__const); // Function NameplateWidget.NameplateWidget_C.CharacterHealthChange // (Native|Public|BlueprintCallable) // @ game+0x1a0ea90
	void OnUIRelevantPlayerStateChanged__DelegateSignature(struct AKSPlayerState* bpp__PlayerState__pf); // DelegateFunction NameplateWidget.NameplateWidget_C.OnUIRelevantPlayerStateChanged__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnPlayerModActivationChange__DelegateSignature(struct UKSPlayerMod_Activated* bpp__ActivatedMod__pf, bool bpp__Active__pf); // DelegateFunction NameplateWidget.NameplateWidget_C.OnPlayerModActivationChange__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnPlayerEliminated__DelegateSignature(struct AKSPlayerState* bpp__PlayerState__pf); // DelegateFunction NameplateWidget.NameplateWidget_C.OnPlayerEliminated__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnPlayerDownedChanged__DelegateSignature(struct AKSPlayerState* bpp__PlayerState__pf); // DelegateFunction NameplateWidget.NameplateWidget_C.OnPlayerDownedChanged__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnModRemoved__DelegateSignature(struct UKSPlayerMod* bpp__Mod__pf, struct UKSPlayerModInstance* bpp__ModInstance__pf); // DelegateFunction NameplateWidget.NameplateWidget_C.OnModRemoved__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnModAdded__DelegateSignature(struct UKSPlayerMod* bpp__Mod__pf, struct UKSPlayerModInstance* bpp__ModInstance__pf); // DelegateFunction NameplateWidget.NameplateWidget_C.OnModAdded__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnKSPlayerStateTeamChanged__DelegateSignature(struct AKSPlayerState* bpp__KSPlayerState__pf); // DelegateFunction NameplateWidget.NameplateWidget_C.OnKSPlayerStateTeamChanged__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnKSPlayerStateNameChanged__DelegateSignature(struct AKSPlayerState* bpp__KSPlayerState__pf); // DelegateFunction NameplateWidget.NameplateWidget_C.OnKSPlayerStateNameChanged__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnKillCamEnabled__DelegateSignature(bool bpp__bEnabled__pf); // DelegateFunction NameplateWidget.NameplateWidget_C.OnKillCamEnabled__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnJobChanged__DelegateSignature(); // DelegateFunction NameplateWidget.NameplateWidget_C.OnJobChanged__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnHealthChanged__DelegateSignature(struct AKSCharacterBase* bpp__Character__pf); // DelegateFunction NameplateWidget.NameplateWidget_C.OnHealthChanged__DelegateSignature // (Public|Delegate) // @ game+0x2587100
	void OnGameObjectiveChanged__DelegateSignature(struct TScriptInterface<None> bpp__GameObjective__pf); // DelegateFunction NameplateWidget.NameplateWidget_C.OnGameObjectiveChanged__DelegateSignature // (Public|Delegate|HasOutParms) // @ game+0x2587100
};

