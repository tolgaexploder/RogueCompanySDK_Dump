// WidgetBlueprintGeneratedClass GameTimer.GameTimer_C
// Size: 0x56a (Inherited: 0x4e0)
struct UGameTimer_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UInvalidationBox* InvalidationBox_1; // 0x4e8(0x08)
	struct UTextBlock* Timer; // 0x4f0(0x08)
	struct UBorder* TimerWrapper; // 0x4f8(0x08)
	bool Colors Set; // 0x500(0x01)
	bool Timer Only; // 0x501(0x01)
	char UnknownData_502[0x6]; // 0x502(0x06)
	struct TMap<int32_t, int32_t> TeamAliveCount; // 0x508(0x50)
	bool IsDisplayDirty; // 0x558(0x01)
	char UnknownData_559[0x3]; // 0x559(0x03)
	float SecondTimeout; // 0x55c(0x04)
	float CurrentSecond; // 0x560(0x04)
	float CountdownMax; // 0x564(0x04)
	bool ActiveBomb; // 0x568(0x01)
	bool UseCustomTimer; // 0x569(0x01)

	void ConvertSecondToTime(float Second, struct FText TimeText); // Function GameTimer.GameTimer_C.ConvertSecondToTime // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void SetLocalTimer(float DeltaTime); // Function GameTimer.GameTimer_C.SetLocalTimer // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetUseCustomTimer(bool bUseCustomTimer); // Function GameTimer.GameTimer_C.SetUseCustomTimer // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ShouldPlayCountdownSound(bool ShouldPlay); // Function GameTimer.GameTimer_C.ShouldPlayCountdownSound // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void PlayFinalCountdownSound(); // Function GameTimer.GameTimer_C.PlayFinalCountdownSound // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void DebugIssues(struct FString Message); // Function GameTimer.GameTimer_C.DebugIssues // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetRoundTimerSize(int32_t NewSize); // Function GameTimer.GameTimer_C.SetRoundTimerSize // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function GameTimer.GameTimer_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function GameTimer.GameTimer_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void OpenRetryGameStateBind(); // Function GameTimer.GameTimer_C.OpenRetryGameStateBind // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void CloseRetryGameStateBind(); // Function GameTimer.GameTimer_C.CloseRetryGameStateBind // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void RetryGameStateBind(); // Function GameTimer.GameTimer_C.RetryGameStateBind // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnUIRelevantPlayerStateChanged(struct AKSPlayerState* PlayerState); // Function GameTimer.GameTimer_C.OnUIRelevantPlayerStateChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnGameTimerUpdate(float NewTruncatedSeconds); // Function GameTimer.GameTimer_C.OnGameTimerUpdate // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeTimer(); // Function GameTimer.GameTimer_C.InitializeTimer // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleKillCamEnabled(bool bEnabled); // Function GameTimer.GameTimer_C.HandleKillCamEnabled // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Unbind OnGameTimerUpdate(); // Function GameTimer.GameTimer_C.Unbind OnGameTimerUpdate // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleKillCamViewPawn(struct APawn* ViewedPawn); // Function GameTimer.GameTimer_C.HandleKillCamViewPawn // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BombTimerActive(bool bActive); // Function GameTimer.GameTimer_C.BombTimerActive // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void BombTimerTick(float Seconds); // Function GameTimer.GameTimer_C.BombTimerTick // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void HandleObjectiveTimerTick(float Seconds); // Function GameTimer.GameTimer_C.HandleObjectiveTimerTick // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_GameTimer(int32_t EntryPoint); // Function GameTimer.GameTimer_C.ExecuteUbergraph_GameTimer // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

