// WidgetBlueprintGeneratedClass ExpDisplay.ExpDisplay_C
// Size: 0x578 (Inherited: 0x530)
struct UExpDisplay_C : UKSExpDisplayWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x530(0x08)
	struct UCashEarnedElement_C* CashBonusElement; // 0x538(0x08)
	struct UCashEarnedElement_C* CashEarnedElement; // 0x540(0x08)
	struct UVerticalBox* DisplayScroll; // 0x548(0x08)
	struct UWidgetSwitcher* ExpDisplaySwitcher; // 0x550(0x08)
	struct TArray<struct AKSPlayerState*> PlayerStates; // 0x558(0x10)
	struct TArray<struct FKSScoreChangeEvent> PendingCashChangeEvents; // 0x568(0x10)

	void Make Cash Message(struct FKSScoreChangeEvent Event); // Function ExpDisplay.ExpDisplay_C.Make Cash Message // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void MakePopup(struct FExpDisplayInfo ExpInfo); // Function ExpDisplay.ExpDisplay_C.MakePopup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function ExpDisplay.ExpDisplay_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnScoreChanged(struct FKSScoreChangeEvent ScoreChangeEvent); // Function ExpDisplay.ExpDisplay_C.OnScoreChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnUIRelevantPlayerStateChanged(struct AKSPlayerState* PlayerState); // Function ExpDisplay.ExpDisplay_C.OnUIRelevantPlayerStateChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void DisplayExpInfo(); // Function ExpDisplay.ExpDisplay_C.DisplayExpInfo // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void ShowNextQueue(); // Function ExpDisplay.ExpDisplay_C.ShowNextQueue // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PreConstruct(bool IsDesignTime); // Function ExpDisplay.ExpDisplay_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnCashChange(struct FKSScoreChangeEvent Score Change); // Function ExpDisplay.ExpDisplay_C.OnCashChange // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_ExpDisplay(int32_t EntryPoint); // Function ExpDisplay.ExpDisplay_C.ExecuteUbergraph_ExpDisplay // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

