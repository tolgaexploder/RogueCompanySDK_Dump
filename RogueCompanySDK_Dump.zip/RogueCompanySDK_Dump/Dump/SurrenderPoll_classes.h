// BlueprintGeneratedClass SurrenderPoll.SurrenderPoll_C
// Size: 0xec (Inherited: 0xe0)
struct USurrenderPoll_C : UKSPollBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xe0(0x08)
	int32_t WinningTeamNum; // 0xe8(0x04)

	bool CanPlayerProposeThisPoll(struct AKSPlayerState* Player); // Function SurrenderPoll.SurrenderPoll_C.CanPlayerProposeThisPoll // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x2587100
	void OnPollPassed(struct AKSGameState* GameState, int32_t TeamNum); // Function SurrenderPoll.SurrenderPoll_C.OnPollPassed // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnPollFailed(struct AKSGameState* GameState, int32_t TeamNum); // Function SurrenderPoll.SurrenderPoll_C.OnPollFailed // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnPollStarted(struct AKSGameState* GameState, int32_t TeamNum); // Function SurrenderPoll.SurrenderPoll_C.OnPollStarted // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_SurrenderPoll(int32_t EntryPoint); // Function SurrenderPoll.SurrenderPoll_C.ExecuteUbergraph_SurrenderPoll // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

