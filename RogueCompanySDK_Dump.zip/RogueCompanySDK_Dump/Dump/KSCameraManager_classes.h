// BlueprintGeneratedClass KSCameraManager.KSCameraManager_C
// Size: 0x2940 (Inherited: 0x27d0)
struct AKSCameraManager_C : AKSPlayerCameraManager {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x27d0(0x08)
	struct FVector Vault_Medium_Running_Rotation_19357AD44276670DB6B495B6695BBF6C; // 0x27d8(0x0c)
	struct FVector Vault_Medium_Running_Location_19357AD44276670DB6B495B6695BBF6C; // 0x27e4(0x0c)
	float Vault_Medium_Running_FOV_19357AD44276670DB6B495B6695BBF6C; // 0x27f0(0x04)
	enum class ETimelineDirection Vault_Medium_Running__Direction_19357AD44276670DB6B495B6695BBF6C; // 0x27f4(0x01)
	char UnknownData_27F5[0x3]; // 0x27f5(0x03)
	struct UTimelineComponent* Vault_Medium_Running; // 0x27f8(0x08)
	struct FVector Vault_Short_Rotation_F73D9F61446F5474502BD8BF3252D762; // 0x2800(0x0c)
	struct FVector Vault_Short_Location_F73D9F61446F5474502BD8BF3252D762; // 0x280c(0x0c)
	float Vault_Short_FOV_F73D9F61446F5474502BD8BF3252D762; // 0x2818(0x04)
	enum class ETimelineDirection Vault_Short__Direction_F73D9F61446F5474502BD8BF3252D762; // 0x281c(0x01)
	char UnknownData_281D[0x3]; // 0x281d(0x03)
	struct UTimelineComponent* Vault_Short; // 0x2820(0x08)
	struct FVector Vault_Medium_Rotation_973BB77943BEA34D1A27C0A9070CFD1F; // 0x2828(0x0c)
	struct FVector Vault_Medium_Location_973BB77943BEA34D1A27C0A9070CFD1F; // 0x2834(0x0c)
	float Vault_Medium_FOV_973BB77943BEA34D1A27C0A9070CFD1F; // 0x2840(0x04)
	enum class ETimelineDirection Vault_Medium__Direction_973BB77943BEA34D1A27C0A9070CFD1F; // 0x2844(0x01)
	char UnknownData_2845[0x3]; // 0x2845(0x03)
	struct UTimelineComponent* Vault_Medium; // 0x2848(0x08)
	struct FVector Vault_Tall_Rotation_7F94194A49D4BE17D3B299B0FF993F6D; // 0x2850(0x0c)
	struct FVector Vault_Tall_Location_7F94194A49D4BE17D3B299B0FF993F6D; // 0x285c(0x0c)
	float Vault_Tall_FOV_7F94194A49D4BE17D3B299B0FF993F6D; // 0x2868(0x04)
	enum class ETimelineDirection Vault_Tall__Direction_7F94194A49D4BE17D3B299B0FF993F6D; // 0x286c(0x01)
	char UnknownData_286D[0x3]; // 0x286d(0x03)
	struct UTimelineComponent* Vault_Tall; // 0x2870(0x08)
	struct FVector Mantle_Short_Rotation_CF02379640077BEA8312A4A97CABFFE5; // 0x2878(0x0c)
	struct FVector Mantle_Short_Location_CF02379640077BEA8312A4A97CABFFE5; // 0x2884(0x0c)
	float Mantle_Short_FOV_CF02379640077BEA8312A4A97CABFFE5; // 0x2890(0x04)
	enum class ETimelineDirection Mantle_Short__Direction_CF02379640077BEA8312A4A97CABFFE5; // 0x2894(0x01)
	char UnknownData_2895[0x3]; // 0x2895(0x03)
	struct UTimelineComponent* Mantle_Short; // 0x2898(0x08)
	struct FVector Mantle_Medium_Rotation_BD9A8E7641CB9B707C1CE6BA8842B569; // 0x28a0(0x0c)
	struct FVector Mantle_Medium_Location_BD9A8E7641CB9B707C1CE6BA8842B569; // 0x28ac(0x0c)
	float Mantle_Medium_FOV_BD9A8E7641CB9B707C1CE6BA8842B569; // 0x28b8(0x04)
	enum class ETimelineDirection Mantle_Medium__Direction_BD9A8E7641CB9B707C1CE6BA8842B569; // 0x28bc(0x01)
	char UnknownData_28BD[0x3]; // 0x28bd(0x03)
	struct UTimelineComponent* Mantle_Medium; // 0x28c0(0x08)
	struct FVector Mantle_Tall_Rotation_745F8D394D1BA4D0F0F12C9F36C8F1F2; // 0x28c8(0x0c)
	struct FVector Mantle_Tall_Location_745F8D394D1BA4D0F0F12C9F36C8F1F2; // 0x28d4(0x0c)
	float Mantle_Tall_FOV_745F8D394D1BA4D0F0F12C9F36C8F1F2; // 0x28e0(0x04)
	enum class ETimelineDirection Mantle_Tall__Direction_745F8D394D1BA4D0F0F12C9F36C8F1F2; // 0x28e4(0x01)
	char UnknownData_28E5[0x3]; // 0x28e5(0x03)
	struct UTimelineComponent* Mantle_Tall; // 0x28e8(0x08)
	struct FVector JumpLanding_Rotation_F0A9B6BE484D0B52D2A1D2A14592B75A; // 0x28f0(0x0c)
	struct FVector JumpLanding_Location_F0A9B6BE484D0B52D2A1D2A14592B75A; // 0x28fc(0x0c)
	float JumpLanding_FOV_F0A9B6BE484D0B52D2A1D2A14592B75A; // 0x2908(0x04)
	enum class ETimelineDirection JumpLanding__Direction_F0A9B6BE484D0B52D2A1D2A14592B75A; // 0x290c(0x01)
	char UnknownData_290D[0x3]; // 0x290d(0x03)
	struct UTimelineComponent* JumpLanding; // 0x2910(0x08)
	struct FVector JumpStart_Rotation_626F506A47DB820B20B53DBAEA84159F; // 0x2918(0x0c)
	struct FVector JumpStart_Location_626F506A47DB820B20B53DBAEA84159F; // 0x2924(0x0c)
	float JumpStart_FOV_626F506A47DB820B20B53DBAEA84159F; // 0x2930(0x04)
	enum class ETimelineDirection JumpStart__Direction_626F506A47DB820B20B53DBAEA84159F; // 0x2934(0x01)
	char UnknownData_2935[0x3]; // 0x2935(0x03)
	struct UTimelineComponent* JumpStart; // 0x2938(0x08)

	void GetMantleHeightFromKSChar(bool NoMantleCamera); // Function KSCameraManager.KSCameraManager_C.GetMantleHeightFromKSChar // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void NotifyCamModFinished(struct UCameraModifier* Modifier Class); // Function KSCameraManager.KSCameraManager_C.NotifyCamModFinished // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateCamModValues(struct UCameraModifier* Modifier Class, struct FVector In Location, struct FVector In Rotation, float In FOV, bool Success); // Function KSCameraManager.KSCameraManager_C.UpdateCamModValues // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void JumpStart__FinishedFunc(); // Function KSCameraManager.KSCameraManager_C.JumpStart__FinishedFunc // (BlueprintEvent) // @ game+0x2587100
	void JumpStart__UpdateFunc(); // Function KSCameraManager.KSCameraManager_C.JumpStart__UpdateFunc // (BlueprintEvent) // @ game+0x2587100
	void JumpLanding__FinishedFunc(); // Function KSCameraManager.KSCameraManager_C.JumpLanding__FinishedFunc // (BlueprintEvent) // @ game+0x2587100
	void JumpLanding__UpdateFunc(); // Function KSCameraManager.KSCameraManager_C.JumpLanding__UpdateFunc // (BlueprintEvent) // @ game+0x2587100
	void Mantle_Tall__FinishedFunc(); // Function KSCameraManager.KSCameraManager_C.Mantle_Tall__FinishedFunc // (BlueprintEvent) // @ game+0x2587100
	void Mantle_Tall__UpdateFunc(); // Function KSCameraManager.KSCameraManager_C.Mantle_Tall__UpdateFunc // (BlueprintEvent) // @ game+0x2587100
	void Mantle_Medium__FinishedFunc(); // Function KSCameraManager.KSCameraManager_C.Mantle_Medium__FinishedFunc // (BlueprintEvent) // @ game+0x2587100
	void Mantle_Medium__UpdateFunc(); // Function KSCameraManager.KSCameraManager_C.Mantle_Medium__UpdateFunc // (BlueprintEvent) // @ game+0x2587100
	void Mantle_Short__FinishedFunc(); // Function KSCameraManager.KSCameraManager_C.Mantle_Short__FinishedFunc // (BlueprintEvent) // @ game+0x2587100
	void Mantle_Short__UpdateFunc(); // Function KSCameraManager.KSCameraManager_C.Mantle_Short__UpdateFunc // (BlueprintEvent) // @ game+0x2587100
	void Vault_Tall__FinishedFunc(); // Function KSCameraManager.KSCameraManager_C.Vault_Tall__FinishedFunc // (BlueprintEvent) // @ game+0x2587100
	void Vault_Tall__UpdateFunc(); // Function KSCameraManager.KSCameraManager_C.Vault_Tall__UpdateFunc // (BlueprintEvent) // @ game+0x2587100
	void Vault_Medium__FinishedFunc(); // Function KSCameraManager.KSCameraManager_C.Vault_Medium__FinishedFunc // (BlueprintEvent) // @ game+0x2587100
	void Vault_Medium__UpdateFunc(); // Function KSCameraManager.KSCameraManager_C.Vault_Medium__UpdateFunc // (BlueprintEvent) // @ game+0x2587100
	void Vault_Short__FinishedFunc(); // Function KSCameraManager.KSCameraManager_C.Vault_Short__FinishedFunc // (BlueprintEvent) // @ game+0x2587100
	void Vault_Short__UpdateFunc(); // Function KSCameraManager.KSCameraManager_C.Vault_Short__UpdateFunc // (BlueprintEvent) // @ game+0x2587100
	void Vault_Medium_Running__FinishedFunc(); // Function KSCameraManager.KSCameraManager_C.Vault_Medium_Running__FinishedFunc // (BlueprintEvent) // @ game+0x2587100
	void Vault_Medium_Running__UpdateFunc(); // Function KSCameraManager.KSCameraManager_C.Vault_Medium_Running__UpdateFunc // (BlueprintEvent) // @ game+0x2587100
	void Play Jump Start(); // Function KSCameraManager.KSCameraManager_C.Play Jump Start // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PlayJumpLanding(); // Function KSCameraManager.KSCameraManager_C.PlayJumpLanding // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Play Mantle(int32_t Mantle Index); // Function KSCameraManager.KSCameraManager_C.Play Mantle // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_KSCameraManager(int32_t EntryPoint); // Function KSCameraManager.KSCameraManager_C.ExecuteUbergraph_KSCameraManager // (Final|UbergraphFunction) // @ game+0x2587100
};

