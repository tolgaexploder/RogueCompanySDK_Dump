// WidgetBlueprintGeneratedClass WBP_Context_Menu_Prompt.WBP_Context_Menu_Prompt_C
// Size: 0x2c0 (Inherited: 0x238)
struct UWBP_Context_Menu_Prompt_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UCanvasPanel* GamepadContainer; // 0x240(0x08)
	struct UTextBlock* GamepadContextText; // 0x248(0x08)
	struct UImage* GamepadIcon; // 0x250(0x08)
	struct UWBP_StandardButton_02_C* KBMButton; // 0x258(0x08)
	struct UTextBlock* KBMButtonText; // 0x260(0x08)
	struct UButton* KBMButtonWrapper; // 0x268(0x08)
	struct UTextBlock* KBMContextText; // 0x270(0x08)
	struct UWBP_StandardButton_02_C* KBMWithKeyButton; // 0x278(0x08)
	struct UButton* KBMWithKeyWrapper; // 0x280(0x08)
	struct UTextBlock* KeyText; // 0x288(0x08)
	struct UBorder* KeyWrapper; // 0x290(0x08)
	struct UContextActionData* Data; // 0x298(0x08)
	enum class PGAME_INPUT_STATE CurrentInputState; // 0x2a0(0x01)
	char UnknownData_2A1[0x7]; // 0x2a1(0x07)
	struct FMulticastInlineDelegate OnPromptClicked; // 0x2a8(0x10)
	struct UAkAudioEvent* IsBackBtnOverrideSFX; // 0x2b8(0x08)

	void SetInputState(enum class PGAME_INPUT_STATE InputState); // Function WBP_Context_Menu_Prompt.WBP_Context_Menu_Prompt_C.SetInputState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Populate(); // Function WBP_Context_Menu_Prompt.WBP_Context_Menu_Prompt_C.Populate // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PreConstruct(bool IsDesignTime); // Function WBP_Context_Menu_Prompt.WBP_Context_Menu_Prompt_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function WBP_Context_Menu_Prompt.WBP_Context_Menu_Prompt_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void BndEvt__WBP_StandardButton_02_K2Node_ComponentBoundEvent_2_OnClicked__DelegateSignature(struct UWidget* Widget); // Function WBP_Context_Menu_Prompt.WBP_Context_Menu_Prompt_C.BndEvt__WBP_StandardButton_02_K2Node_ComponentBoundEvent_2_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__WBP_StandardButton_02_C_1_K2Node_ComponentBoundEvent_3_OnClicked__DelegateSignature(struct UWidget* Widget); // Function WBP_Context_Menu_Prompt.WBP_Context_Menu_Prompt_C.BndEvt__WBP_StandardButton_02_C_1_K2Node_ComponentBoundEvent_3_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__KBMWithKeyButton_K2Node_ComponentBoundEvent_0_OnHovered__DelegateSignature(struct UWidget* Widget); // Function WBP_Context_Menu_Prompt.WBP_Context_Menu_Prompt_C.BndEvt__KBMWithKeyButton_K2Node_ComponentBoundEvent_0_OnHovered__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__KBMWithKeyButton_K2Node_ComponentBoundEvent_1_OnUnhovered__DelegateSignature(struct UWidget* Widget); // Function WBP_Context_Menu_Prompt.WBP_Context_Menu_Prompt_C.BndEvt__KBMWithKeyButton_K2Node_ComponentBoundEvent_1_OnUnhovered__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__KBMButton_K2Node_ComponentBoundEvent_4_OnHovered__DelegateSignature(struct UWidget* Widget); // Function WBP_Context_Menu_Prompt.WBP_Context_Menu_Prompt_C.BndEvt__KBMButton_K2Node_ComponentBoundEvent_4_OnHovered__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void BndEvt__KBMButton_K2Node_ComponentBoundEvent_5_OnUnhovered__DelegateSignature(struct UWidget* Widget); // Function WBP_Context_Menu_Prompt.WBP_Context_Menu_Prompt_C.BndEvt__KBMButton_K2Node_ComponentBoundEvent_5_OnUnhovered__DelegateSignature // (BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_Context_Menu_Prompt(int32_t EntryPoint); // Function WBP_Context_Menu_Prompt.WBP_Context_Menu_Prompt_C.ExecuteUbergraph_WBP_Context_Menu_Prompt // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void OnPromptClicked__DelegateSignature(); // Function WBP_Context_Menu_Prompt.WBP_Context_Menu_Prompt_C.OnPromptClicked__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

