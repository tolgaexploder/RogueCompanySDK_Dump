// WidgetBlueprintGeneratedClass WBP_ContextualPingMapIcon.WBP_ContextualPingMapIcon_C
// Size: 0x3b9 (Inherited: 0x3a0)
struct UWBP_ContextualPingMapIcon_C : UKSContextualPingMarkerWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3a0(0x08)
	struct UWBP_AsyncIcon_C* PingIcon; // 0x3a8(0x08)
	struct UScaleBox* ScaleBox_1; // 0x3b0(0x08)
	bool WasRemoved; // 0x3b8(0x01)

	void Construct(); // Function WBP_ContextualPingMapIcon.WBP_ContextualPingMapIcon_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void HandlePingRemoved(); // Function WBP_ContextualPingMapIcon.WBP_ContextualPingMapIcon_C.HandlePingRemoved // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetupPingOnReady(); // Function WBP_ContextualPingMapIcon.WBP_ContextualPingMapIcon_C.SetupPingOnReady // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_ContextualPingMapIcon(int32_t EntryPoint); // Function WBP_ContextualPingMapIcon.WBP_ContextualPingMapIcon_C.ExecuteUbergraph_WBP_ContextualPingMapIcon // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

