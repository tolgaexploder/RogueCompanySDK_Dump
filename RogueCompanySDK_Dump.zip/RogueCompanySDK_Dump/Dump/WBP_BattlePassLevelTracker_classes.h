// WidgetBlueprintGeneratedClass WBP_BattlePassLevelTracker.WBP_BattlePassLevelTracker_C
// Size: 0x764 (Inherited: 0x4e0)
struct UWBP_BattlePassLevelTracker_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e0(0x08)
	struct UWidgetAnimation* NewTierLoop; // 0x4e8(0x08)
	struct UWidgetAnimation* FadeIn; // 0x4f0(0x08)
	struct UWidgetAnimation* OnPlayerLevelUp; // 0x4f8(0x08)
	struct UCanvasPanel* CanvasPanel_1; // 0x500(0x08)
	struct UImage* EmblemOverlaySheen; // 0x508(0x08)
	struct UImage* Fill; // 0x510(0x08)
	struct UImage* FillStandard_3; // 0x518(0x08)
	struct UImage* GlitchOverlay; // 0x520(0x08)
	struct UImage* Glow_2; // 0x528(0x08)
	struct UImage* Glow_3; // 0x530(0x08)
	struct UImage* Gradient; // 0x538(0x08)
	struct USizeBox* LevelRewardWrapper; // 0x540(0x08)
	struct UTextBlock* LevelUpText; // 0x548(0x08)
	struct UWBP_ProgressionTally_C* ProgressionTally; // 0x550(0x08)
	struct UTextBlock* RequiredXPForLevel; // 0x558(0x08)
	struct UTextBlock* RequiredXPForLevel_2; // 0x560(0x08)
	struct UImage* RewardShimmer; // 0x568(0x08)
	struct UWidgetSwitcher* TypeSwitcher; // 0x570(0x08)
	struct UWBP_BattlePassEmblem_C* WBP_BattlePassEmblem; // 0x578(0x08)
	struct UWBP_KSCosmeticItemDisplay_C* WBP_KSCosmeticItemDisplay_3; // 0x580(0x08)
	struct UTextBlock* XPAmountText; // 0x588(0x08)
	struct UWBP_ProgressEarnedBar_C* XPBar; // 0x590(0x08)
	struct UImage* XPBarShimmer; // 0x598(0x08)
	struct UTextBlock* XPCurrencyText; // 0x5a0(0x08)
	struct UHorizontalBox* XPDisplayBox; // 0x5a8(0x08)
	struct UHorizontalBox* XPInfoBox; // 0x5b0(0x08)
	struct UTextBlock* XPProgressInLevel; // 0x5b8(0x08)
	struct FPlayerProgression Progression; // 0x5c0(0x170)
	bool CanAnimate; // 0x730(0x01)
	char UnknownData_731[0x3]; // 0x731(0x03)
	float BaseFillPercentage; // 0x734(0x04)
	float LerpTimeframe; // 0x738(0x04)
	int32_t CurrentTierIndex; // 0x73c(0x04)
	float CurrentLerpIncrement; // 0x740(0x04)
	char UnknownData_744[0x4]; // 0x744(0x04)
	struct UAkAudioEvent* PlayLevelUpRewardSFX; // 0x748(0x08)
	struct UAkAudioEvent* PlayLevelProgressionSFX; // 0x750(0x08)
	struct UAkAudioEvent* StopLevelProgressionSFX; // 0x758(0x08)
	int32_t XPProgressNumber; // 0x760(0x04)

	void DisplayFinishedState(); // Function WBP_BattlePassLevelTracker.WBP_BattlePassLevelTracker_C.DisplayFinishedState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetConstantTextElements(); // Function WBP_BattlePassLevelTracker.WBP_BattlePassLevelTracker_C.SetConstantTextElements // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void TriggerLevelUpEvent(); // Function WBP_BattlePassLevelTracker.WBP_BattlePassLevelTracker_C.TriggerLevelUpEvent // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void GetXpProgressPercentageInLevel(float PercentProgress, int32_t XpNumber); // Function WBP_BattlePassLevelTracker.WBP_BattlePassLevelTracker_C.GetXpProgressPercentageInLevel // (Private|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void SetNewLerpTimeframe(); // Function WBP_BattlePassLevelTracker.WBP_BattlePassLevelTracker_C.SetNewLerpTimeframe // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void UpdateLevelDisplay(); // Function WBP_BattlePassLevelTracker.WBP_BattlePassLevelTracker_C.UpdateLevelDisplay // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	struct FText GetXPRequiredForLevel(); // Function WBP_BattlePassLevelTracker.WBP_BattlePassLevelTracker_C.GetXPRequiredForLevel // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	struct FText GetNextLevel(); // Function WBP_BattlePassLevelTracker.WBP_BattlePassLevelTracker_C.GetNextLevel // (Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	struct FText GetCurrentLevel(); // Function WBP_BattlePassLevelTracker.WBP_BattlePassLevelTracker_C.GetCurrentLevel // (Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2587100
	void DisplayXPAnimationState(); // Function WBP_BattlePassLevelTracker.WBP_BattlePassLevelTracker_C.DisplayXPAnimationState // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnLevelUpAnimCompleted(); // Function WBP_BattlePassLevelTracker.WBP_BattlePassLevelTracker_C.OnLevelUpAnimCompleted // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void SetPalette(); // Function WBP_BattlePassLevelTracker.WBP_BattlePassLevelTracker_C.SetPalette // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ProcessPlayerProgression(struct FPlayerProgression PlayerProgression); // Function WBP_BattlePassLevelTracker.WBP_BattlePassLevelTracker_C.ProcessPlayerProgression // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void InitializeWidget(struct APUMG_HUD* HUD); // Function WBP_BattlePassLevelTracker.WBP_BattlePassLevelTracker_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_BattlePassLevelTracker.WBP_BattlePassLevelTracker_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void PlayProgressionAnim(float Delay); // Function WBP_BattlePassLevelTracker.WBP_BattlePassLevelTracker_C.PlayProgressionAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void PreConstruct(bool IsDesignTime); // Function WBP_BattlePassLevelTracker.WBP_BattlePassLevelTracker_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void Construct(); // Function WBP_BattlePassLevelTracker.WBP_BattlePassLevelTracker_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_WBP_BattlePassLevelTracker(int32_t EntryPoint); // Function WBP_BattlePassLevelTracker.WBP_BattlePassLevelTracker_C.ExecuteUbergraph_WBP_BattlePassLevelTracker // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
};

