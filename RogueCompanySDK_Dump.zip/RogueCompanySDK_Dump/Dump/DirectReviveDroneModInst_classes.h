// BlueprintGeneratedClass DirectReviveDroneModInst.DirectReviveDroneModInst_C
// Size: 0x57c (Inherited: 0x510)
struct UDirectReviveDroneModInst_C : UKSModInst_ReviveDrone {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x510(0x08)
	struct FMulticastInlineDelegate OnTargetDeath; // 0x518(0x10)
	struct FMulticastInlineDelegate OnTargetRevive; // 0x528(0x10)
	struct FMulticastInlineDelegate OnDroneDestroy; // 0x538(0x10)
	struct FMulticastInlineDelegate OnReviveBegin; // 0x548(0x10)
	struct FMulticastInlineDelegate OnReviveComplete; // 0x558(0x10)
	struct FMulticastInlineDelegate OnDroneAborted; // 0x568(0x10)
	int32_t GameDisplayInfoHandle; // 0x578(0x04)

	void ReceiveBeginPlay(); // Function DirectReviveDroneModInst.DirectReviveDroneModInst_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void OnActivation(); // Function DirectReviveDroneModInst.DirectReviveDroneModInst_C.OnActivation // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void OnReviveDroneEvent(enum class EKSReviveDroneEvent KSReviveDroneEvent); // Function DirectReviveDroneModInst.DirectReviveDroneModInst_C.OnReviveDroneEvent // (Event|Protected|BlueprintEvent) // @ game+0x2587100
	void PlayAbilityVO(); // Function DirectReviveDroneModInst.DirectReviveDroneModInst_C.PlayAbilityVO // (BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function DirectReviveDroneModInst.DirectReviveDroneModInst_C.ReceiveEndPlay // (Event|Public|BlueprintEvent) // @ game+0x2587100
	void ExecuteUbergraph_DirectReviveDroneModInst(int32_t EntryPoint); // Function DirectReviveDroneModInst.DirectReviveDroneModInst_C.ExecuteUbergraph_DirectReviveDroneModInst // (Final|UbergraphFunction|HasDefaults) // @ game+0x2587100
	void OnDroneAborted__DelegateSignature(); // Function DirectReviveDroneModInst.DirectReviveDroneModInst_C.OnDroneAborted__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnReviveComplete__DelegateSignature(); // Function DirectReviveDroneModInst.DirectReviveDroneModInst_C.OnReviveComplete__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnReviveBegin__DelegateSignature(); // Function DirectReviveDroneModInst.DirectReviveDroneModInst_C.OnReviveBegin__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnDroneDestroy__DelegateSignature(); // Function DirectReviveDroneModInst.DirectReviveDroneModInst_C.OnDroneDestroy__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnTargetRevive__DelegateSignature(); // Function DirectReviveDroneModInst.DirectReviveDroneModInst_C.OnTargetRevive__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
	void OnTargetDeath__DelegateSignature(); // Function DirectReviveDroneModInst.DirectReviveDroneModInst_C.OnTargetDeath__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x2587100
};

